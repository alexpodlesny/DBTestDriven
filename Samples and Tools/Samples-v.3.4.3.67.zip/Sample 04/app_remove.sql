/*
*************************************************************************************************
-- SQL Server - DBTestDriven - Samples - 3.4.3.67
-- COPYRIGHT:  (c) 2011-2012 Job Continent, DBTestDriven Project by Alex Podlesny
-- http://www.dbtestdriven.com
-- Sample Set 04
*************************************************************************************************
*/

EXEC DBTD_DROP_PROC_IF_EXISTS 'SP_LOAD_DENIAL_EVENTS','';
EXEC DBTD_DROP_PROC_IF_EXISTS 'SP_LOAD_ASSET_INFO','';

EXEC DBTD_DROP_TABLE_IF_EXISTS 'DENIED_USER_ACCESS';
EXEC DBTD_DROP_TABLE_IF_EXISTS 'ASSET';