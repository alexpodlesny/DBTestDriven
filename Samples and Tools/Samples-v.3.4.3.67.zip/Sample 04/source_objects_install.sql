/*
*************************************************************************************************
-- SQL Server - DBTestDriven - Samples - 3.4.3.67
-- COPYRIGHT:  (c) 2011-2012 Job Continent, DBTestDriven Project by Alex Podlesny
-- http://www.dbtestdriven.com
-- Sample Set 04
*************************************************************************************************
*/

--************************************************************************************************
--Table that stores all user access attempts
--Data consolidated and loaded nightly by third party application 
--note: this table might have other extra fields but for this test we are interested only in following
CREATE TABLE ACCESS_LOG
(
	ACCESS_LOG_ID	INT IDENTITY (1, 1) NOT NULL,	--Unique access log ID
	USER_NM			VARCHAR(50),					--User name
	OBJECT_NM		VARCHAR(250),					--Name of the object that user attempts to access
	ACCESS_ST		VARCHAR(50),					--Access status 
	DATA_SOURCE_NM	VARCHAR(50)						--Name of the Data Source where data came from 
);
GO
