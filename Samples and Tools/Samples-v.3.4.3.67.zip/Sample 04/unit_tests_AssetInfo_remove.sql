/*
*************************************************************************************************
-- SQL Server - DBTestDriven - Samples - 3.4.3.67
-- COPYRIGHT:  (c) 2011-2012 Job Continent, DBTestDriven Project by Alex Podlesny
-- http://www.dbtestdriven.com
-- Sample Set 04
*************************************************************************************************
*/
EXEC DBTD_DROP_PROC_IF_EXISTS 'UT_ASSETINFO_SETUP','';
EXEC DBTD_DROP_PROC_IF_EXISTS 'UT_ASSETINFO_TEARDOWN','';
EXEC DBTD_DROP_PROC_IF_EXISTS 'UT_ASSETINFO_CheckData','';
EXEC DBTD_DROP_PROC_IF_EXISTS 'UT_ASSETINFO_AssetIdentifierIsUnique','';
EXEC DBTD_DROP_PROC_IF_EXISTS 'UT_ASSETINFO_AssetIdentifierIsNotNull','';
EXEC DBTD_DROP_PROC_IF_EXISTS 'UT_ASSETINFO_NoDuplicateAssets','';
EXEC DBTD_DROP_PROC_IF_EXISTS 'UT_ASSETINFO_AllAssetsLoaded','';
EXEC DBTD_DROP_PROC_IF_EXISTS 'UT_ASSETINFO_CheckAssertTable','';

