/*
*************************************************************************************************
-- SQL Server - DBTestDriven - Samples - 3.4.3.67
-- COPYRIGHT:  (c) 2011-2012 Job Continent, DBTestDriven Project by Alex Podlesny
-- http://www.dbtestdriven.com
-- Sample Set 04
*************************************************************************************************
*/

--test data related DDL removals
EXEC DBTD_DROP_PROC_IF_EXISTS 'UTD_LOAD_TEST_DATA_INTO_ACCESS_LOG','';
EXEC DBTD_DROP_PROC_IF_EXISTS 'UTD_REMOVE_TEST_DATA_FROM_ACCESS_LOG','';
