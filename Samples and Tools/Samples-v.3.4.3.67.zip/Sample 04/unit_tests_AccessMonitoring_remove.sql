/*
*************************************************************************************************
-- SQL Server - DBTestDriven - Samples - 3.4.3.67
-- COPYRIGHT:  (c) 2011-2012 Job Continent, DBTestDriven Project by Alex Podlesny
-- http://www.dbtestdriven.com
-- Sample Set 04
*************************************************************************************************
*/
EXEC DBTD_DROP_PROC_IF_EXISTS 'UT_ACCESSMONITORING_SETUP','';
EXEC DBTD_DROP_PROC_IF_EXISTS 'UT_ACCESSMONITORING_TEARDOWN','';
EXEC DBTD_DROP_PROC_IF_EXISTS 'UT_ACCESSMONITORING_AllAvailableDenialsAreLoaded','';
EXEC DBTD_DROP_PROC_IF_EXISTS 'UT_ACCESSMONITORING_DenialsAreNotDuplicated','';
EXEC DBTD_DROP_PROC_IF_EXISTS 'UT_ACCESSMONITORING_DenialIDsAresUnique','';
EXEC DBTD_DROP_PROC_IF_EXISTS 'UT_ACCESSMONITORING_DenialSelectedUnderSpecifiedThreshold','';
EXEC DBTD_DROP_PROC_IF_EXISTS 'UT_ACCESSMONITORING_HasDeniedOnly','';
EXEC DBTD_DROP_PROC_IF_EXISTS 'UT_ACCESSMONITORING_CheckSourceData','';
EXEC DBTD_DROP_PROC_IF_EXISTS 'UT_ACCESSMONITORING_ShouldHaveRecords','';
