/*
*************************************************************************************************
-- SQL Server - DBTestDriven - Samples - 3.4.3.67
-- COPYRIGHT:  (c) 2011-2012 Job Continent, DBTestDriven Project by Alex Podlesny
-- http://www.dbtestdriven.com
-- Sample Set 04
*************************************************************************************************
*/

--************************************************************************************************
--Table will have the list of all records when access was denied to a user
CREATE TABLE DENIED_USER_ACCESS 
(
	DENIAL_ID		INT IDENTITY (1, 1) NOT NULL,	--Unique denial record ID
	ACCESS_LOG_ID	INT,							--Unique access log ID
	USER_NM			VARCHAR(50),					--User name
	OBJECT_NM		VARCHAR(250),					--Name of the object that user attempts to access
	ACCESS_ST		VARCHAR(50)						--Access status 
);
GO

--************************************************************************************************
--Table will have the list of all available assets or objects that werer found int he log records
CREATE TABLE ASSET
(
	ASSET_ID		INT IDENTITY (1, 1) NOT NULL,	--Unique asset  ID
	OBJECT_NM		VARCHAR(250),					--Name of the object
	DATA_SOURCE_NM	VARCHAR(50),					--Name of the Data Source where data came from 
	RECORDED_DT		DATETIME						--Time stamp when record were added 
);
GO

--************************************************************************************************
--inserts new denial events into the DENIED_USER_ACCESS table
CREATE PROCEDURE SP_LOAD_DENIAL_EVENTS
AS
BEGIN
	INSERT INTO DENIED_USER_ACCESS( ACCESS_LOG_ID, USER_NM,	OBJECT_NM, ACCESS_ST)
	SELECT 
		L.ACCESS_LOG_ID, 
		L.USER_NM,	
		L.OBJECT_NM, 
		L.ACCESS_ST
	FROM 
		ACCESS_LOG AS L
		LEFT OUTER JOIN 
		DENIED_USER_ACCESS AS D
		ON 
			L.ACCESS_LOG_ID = D.ACCESS_LOG_ID
	WHERE
		L.ACCESS_ST	IN ('DENIED')
		AND D.ACCESS_LOG_ID IS NULL;
END;
GO


--************************************************************************************************
--procedure sample #1
--CREATE PROCEDURE SP_LOAD_ASSET_INFO
--AS
--BEGIN
--	EXEC DBTD_LOG_MESSAGE 'WARNING','todo: create logic';
--END;
--GO

--************************************************************************************************
--procedure sample #2
--CREATE PROCEDURE SP_LOAD_ASSET_INFO
--AS
--BEGIN
--	INSERT INTO ASSET(OBJECT_NM, DATA_SOURCE_NM, RECORDED_DT)	
--	SELECT 
--		DISTINCT 
--		OBJECT_NM,
--		DATA_SOURCE_NM,
--		GETDATE() AS RECORDED_DT	
--	FROM 
--		ACCESS_LOG;
--END;
--GO

--************************************************************************************************
--populates asset information
CREATE PROCEDURE SP_LOAD_ASSET_INFO
AS
BEGIN
	INSERT INTO ASSET(OBJECT_NM, DATA_SOURCE_NM, RECORDED_DT)	
	SELECT 
		DISTINCT 
		L.OBJECT_NM,
		L.DATA_SOURCE_NM,
		GETDATE() AS RECORDED_DT	
	FROM 
		ACCESS_LOG AS L
		LEFT OUTER JOIN 
		ASSET AS A
		ON 
			A.OBJECT_NM = L.OBJECT_NM 
			AND A.DATA_SOURCE_NM = L.DATA_SOURCE_NM
	WHERE 
		A.RECORDED_DT IS NULL;
END;
GO