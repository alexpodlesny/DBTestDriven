/*
*************************************************************************************************
-- SQL Server - DBTestDriven - Samples - 3.4.3.67
-- COPYRIGHT:  (c) 2011-2012 Job Continent, DBTestDriven Project by Alex Podlesny
-- http://www.dbtestdriven.com
-- Sample Set 04
*************************************************************************************************
*/

--************************************************************************************************
--CREATE PROCEDURE UT_ASSETINFO_SETUP
--AS
--BEGIN
--	EXEC DBTD_RUN_ONCE 'Setup will run only once for all the unit tests in the ASSETINFO suite';
--	EXEC DBTD_LOG_MESSAGE 'INFO', 'RUNNING UT_ASSETINFO_SETUP';
--	--load test data 
--	EXEC UTD_LOAD_TEST_DATA_INTO_ACCESS_LOG;
--	--run app logic
--	EXEC SP_LOAD_ASSET_INFO;
--END;
--GO

--************************************************************************************************
CREATE PROCEDURE UT_ASSETINFO_SETUP
AS
BEGIN
	EXEC DBTD_RUN_ONCE 'Setup will run only once for all the unit tests in the ASSETINFO suite';
	EXEC DBTD_LOG_MESSAGE 'INFO', 'RUNNING UT_ASSETINFO_SETUP';
	--load test data 
	EXEC UTD_LOAD_TEST_DATA_INTO_ACCESS_LOG;
	--run app logic first time 
	EXEC SP_LOAD_ASSET_INFO;
	--run app logic second and third time in attempt to create duplicates
	EXEC SP_LOAD_ASSET_INFO;
	EXEC SP_LOAD_ASSET_INFO;
END;
GO

--************************************************************************************************
--CREATE PROCEDURE UT_ASSETINFO_TEARDOWN
--AS
--BEGIN
--	EXEC DBTD_RUN_ONCE 'Teardown will run only once for all the unit tests in the ASSETINFO suite';
--	EXEC DBTD_LOG_MESSAGE 'INFO', 'RUNNING UT_ASSETINFO_TEARDOWN';
--	--todo: create logic that clean up asset data
--END;
--GO

--************************************************************************************************
CREATE PROCEDURE UT_ASSETINFO_TEARDOWN
AS
BEGIN
	EXEC DBTD_RUN_ONCE 'Teardown will run only once for all the unit tests in the ASSETINFO suite';
	EXEC DBTD_LOG_MESSAGE 'INFO', 'RUNNING UT_ASSETINFO_TEARDOWN';
	--remove test data 
	EXEC UTD_REMOVE_TEST_DATA_FROM_ACCESS_LOG;
END;
GO

--************************************************************************************************
-- make sure that at list some data is available in the table
CREATE PROCEDURE UT_ASSETINFO_CheckData
AS
BEGIN
	EXEC DBTD_ASSERT_IS_NOT_EXPECTED_COUNT 0, 'ASSET', '', 'ASSET table has no data';
END;
GO

--************************************************************************************************
CREATE PROCEDURE UT_ASSETINFO_CheckAssertTable
AS
BEGIN
	--chec that table exist 
	EXEC DBTD_ASSERT_TABLE_EXISTS 'ASSET', 'Could not find ASSET table';
	--check that columns we need exist and correct
	EXEC DBTD_ASSERT_COLUMN_TYPE_AND_PRECISION 'ASSET', 'ASSET_ID', 'INT', '', ' Unique asset ID column not found';
	EXEC DBTD_ASSERT_COLUMN_TYPE_AND_PRECISION 'ASSET', 'OBJECT_NM', 'VARCHAR', '(250)', 'Name column not found';
	EXEC DBTD_ASSERT_COLUMN_TYPE_AND_PRECISION 'ASSET', 'DATA_SOURCE_NM', 'VARCHAR', '(50)', 'Name of the Data Source where data came from column not found';
	EXEC DBTD_ASSERT_COLUMN_TYPE_AND_PRECISION 'ASSET', 'RECORDED_DT', 'DATETIME', '', 'Time stamp when record were added column not found';
END;
GO

--************************************************************************************************
CREATE PROCEDURE UT_ASSETINFO_AssetIdentifierIsUnique 
AS
BEGIN
	EXEC DBTD_ASSERT_IS_COLUMN_VALUE_UNIQUE 'ASSET', 'ASSET_ID', 'Duplicate ASSET_IDs are found in the ASSET table'; 	
END;
GO

--************************************************************************************************
CREATE PROCEDURE UT_ASSETINFO_AssetIdentifierIsNotNull
AS
BEGIN
	EXEC DBTD_ASSERT_IS_EXPECTED_COUNT 0, 'ASSET', 'ASSET_ID IS NULL', 'ASSET_IDs could not be NULL';
END;
GO

--************************************************************************************************
--note: assuming that we might have assets with similar name located in different data sources
CREATE PROCEDURE UT_ASSETINFO_NoDuplicateAssets 
AS
BEGIN
	DECLARE @v_Expected_Count INT;
	DECLARE @v_Not_Expected_Count INT;
	DECLARE @v_Actual_Count INT;

	--run app logic one more time to create more duplicates
	EXEC SP_LOAD_ASSET_INFO;

	SET @v_Expected_Count = 0;

	SELECT @v_Actual_Count = count(*) 
	FROM 
		(
		SELECT OBJECT_NM, DATA_SOURCE_NM, COUNT(1) AS CT
		FROM ASSET
		GROUP BY OBJECT_NM, DATA_SOURCE_NM
		) AS T
	WHERE CT > 1;
		
	EXEC DBTD_ASSERT_ARE_EQUAL @v_Actual_Count, @v_Expected_Count, 'Same Asset were loaded multiple times under different IDs';
END;
GO

--************************************************************************************************
--CREATE PROCEDURE UT_ASSETINFO_AllAssetsLoaded
--AS
--BEGIN
--	EXEC DBTD_FAILURE 'Not Implemented';
--END;
--GO

--************************************************************************************************
CREATE PROCEDURE UT_ASSETINFO_AllAssetsLoaded
AS
BEGIN
	DECLARE @v_Expected_Count INT;
	DECLARE @v_Not_Expected_Count INT;
	DECLARE @v_Actual_Count INT;

	SET @v_Expected_Count = 0;

	SELECT @v_Actual_Count = count(*) 
	FROM 
		(
		SELECT DISTINCT OBJECT_NM, DATA_SOURCE_NM
		FROM ACCESS_LOG
		) AS S
		LEFT OUTER JOIN 
		ASSET AS A
			ON A.OBJECT_NM = S.OBJECT_NM
			AND A.DATA_SOURCE_NM = S.DATA_SOURCE_NM
	WHERE 
		A.ASSET_ID IS NULL;

	EXEC DBTD_ASSERT_ARE_EQUAL @v_Actual_Count, @v_Expected_Count, 'Not all assets are loaded into the Asset table';
END;
GO
