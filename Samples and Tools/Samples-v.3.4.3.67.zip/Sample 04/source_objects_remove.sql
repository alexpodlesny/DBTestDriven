/*
*************************************************************************************************
-- SQL Server - DBTestDriven - Samples - 3.4.3.67
-- COPYRIGHT:  (c) 2011-2012 Job Continent, DBTestDriven Project by Alex Podlesny
-- http://www.dbtestdriven.com
-- Sample Set 04
*************************************************************************************************
*/

EXEC DBTD_DROP_TABLE_IF_EXISTS 'ACCESS_LOG';
