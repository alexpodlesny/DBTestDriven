/*
*************************************************************************************************
-- SQL Server - DBTestDriven - Samples - 3.4.3.67
-- COPYRIGHT:  (c) 2011-2012 Job Continent, DBTestDriven Project by Alex Podlesny
-- http://www.dbtestdriven.com
-- Sample Set 02
*************************************************************************************************
*/

--************************************************************************************************
--Table that stores all user access attempts
--Data consolidated and loaded nightly by third party application 
--note: this table might have other extra fields but for this test we are interested only in following
CREATE TABLE ACCESS_LOG
(
	ACCESS_LOG_ID	INT IDENTITY (1, 1) NOT NULL,	--Unique access log ID
	USER_NM			VARCHAR(50),					--User name
	OBJECT_NM		VARCHAR(250),					--Name of the object that user attempts to access
	ACCESS_ST		VARCHAR(50)						--Access status 
);
GO

--************************************************************************************************
--Table will have the list of all records when access was denied to a user
CREATE TABLE DENIED_USER_ACCESS 
(
	DENIAL_ID		INT IDENTITY (1, 1) NOT NULL,	--Unique denial record ID
	ACCESS_LOG_ID	INT,							--Unique access log ID
	USER_NM			VARCHAR(50),					--User name
	OBJECT_NM		VARCHAR(250),					--Name of the object that user attempts to access
	ACCESS_ST		VARCHAR(50)						--Access status 
);
GO

/*
--old DENIED_USER_ACCESS implementation from prior samples 
CREATE VIEW DENIED_USER_ACCESS 
AS 
SELECT 
	USER_NM,
	OBJECT_NM,
	ACCESS_ST
FROM ACCESS_LOG
WHERE ACCESS_ST	IN ('DENIED');
GO
*/

--************************************************************************************************
--inserts new denial events into the DENIED_USER_ACCESS table
CREATE PROCEDURE SP_LOAD_DENIAL_EVENTS
AS
BEGIN
	INSERT INTO DENIED_USER_ACCESS( ACCESS_LOG_ID, USER_NM,	OBJECT_NM, ACCESS_ST)
	SELECT 
		L.ACCESS_LOG_ID, 
		L.USER_NM,	
		L.OBJECT_NM, 
		L.ACCESS_ST
	FROM 
		ACCESS_LOG AS L
		LEFT OUTER JOIN 
		DENIED_USER_ACCESS AS D
		ON 
			L.ACCESS_LOG_ID = D.ACCESS_LOG_ID
	WHERE
		L.ACCESS_ST	IN ('DENIED')
		AND D.ACCESS_LOG_ID IS NULL;
END;
GO

/*
--note: this commented version of the SP_LOAD_DENIAL_EVENTS procedure will 
--      insert all denial events again and again into the DENIED_USER_ACCESS table
--      resulting in many duplicates.
--      we kept this code to show how unit test will catch this issue
CREATE PROCEDURE SP_LOAD_DENIAL_EVENTS
AS
BEGIN
	INSERT INTO DENIED_USER_ACCESS( ACCESS_LOG_ID, USER_NM,	OBJECT_NM, ACCESS_ST)
	SELECT ACCESS_LOG_ID, USER_NM,	OBJECT_NM, ACCESS_ST
	FROM ACCESS_LOG
	WHERE ACCESS_ST	IN ('DENIED');
END;
GO
*/