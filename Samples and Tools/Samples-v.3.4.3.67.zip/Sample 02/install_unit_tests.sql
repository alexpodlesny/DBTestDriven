/*
*************************************************************************************************
-- SQL Server - DBTestDriven - Samples - 3.4.3.67
-- COPYRIGHT:  (c) 2011-2012 Job Continent, DBTestDriven Project by Alex Podlesny
-- http://www.dbtestdriven.com
-- Sample Set 02
*************************************************************************************************
*/

--************************************************************************************************
--check that we are loading all "DENIED" records that availble in the ACCESS_LOG
CREATE PROCEDURE UT_ACCESSMONITORING_AllAvailableDenialsAreLoaded
AS
BEGIN
	DECLARE @v_Expected_Count INT;
	DECLARE @v_Not_Expected_Count INT;
	DECLARE @v_Actual_Count INT;

	--check how many records are availble in the ACCESS_LOG
	SELECT @v_Expected_Count = count(*) 
	FROM ACCESS_LOG
	WHERE ACCESS_ST = 'DENIED';

	--now check that they are all loaded int to denial table
	EXEC DBTD_ASSERT_IS_EXPECTED_COUNT @v_Expected_Count, 'DENIED_USER_ACCESS', '', 'DENIED_USER_ACCESS does not have expected number of denial records loaded from the ACCESS_LOG';
END;
GO

--************************************************************************************************
--check that we are loading "DENIED" records only once
--note: we assume that data loading procedure has been run miltiple times before this test 
CREATE PROCEDURE UT_ACCESSMONITORING_DenialsAreNotDuplicated
AS
BEGIN
	DECLARE @v_Expected_Count INT;
	DECLARE @v_Not_Expected_Count INT;
	DECLARE @v_Actual_Count INT;

	SET @v_Expected_Count = 0;

	SELECT @v_Actual_Count = count(*) 
	FROM 
		(
		SELECT ACCESS_LOG_ID, COUNT(1) AS CT
		FROM DENIED_USER_ACCESS
		GROUP BY ACCESS_LOG_ID
		) AS T
	WHERE CT > 1;

	--now check that they are all loaded int to denial table
	EXEC DBTD_ASSERT_ARE_EQUAL @v_Actual_Count, @v_Expected_Count, 'DENIED_USER_ACCESS table has duplicate records loaded from ACCESS_LOG';
END;
GO

--************************************************************************************************
--check that DENIAL_ID are unique
--note: we assume that data loading procedure has been run miltiple times before this test 
CREATE PROCEDURE UT_ACCESSMONITORING_DenialIDsAresUnique
AS
BEGIN
	DECLARE @v_Expected_Count INT;
	DECLARE @v_Not_Expected_Count INT;
	DECLARE @v_Actual_Count INT;

	SET @v_Expected_Count = 0;

	SELECT @v_Actual_Count = count(*) 
	FROM 
		(
		SELECT DENIAL_ID, COUNT(1) AS CT
		FROM DENIED_USER_ACCESS
		GROUP BY DENIAL_ID
		) AS T
	WHERE CT > 1;

	--now check that they are all loaded int to denial table
	EXEC DBTD_ASSERT_ARE_EQUAL @v_Actual_Count, @v_Expected_Count, 'DENIED_USER_ACCESS has records with duplicate DENIAL_ID';
END;
GO

--************************************************************************************************
--check that DENIAL_ID are unique
--note: we assume that data loading procedure has been run miltiple times before this test 
CREATE PROCEDURE UT_ACCESSMONITORING_DenialSelectedUnderSpecifiedThreshold
AS
BEGIN
	DECLARE @v_Message varchar(250);
	DECLARE @v_Expected_Count INT;
	DECLARE @v_Not_Expected_Count INT;
	DECLARE @v_Actual_Count INT;
	DECLARE @v_Expected_Threshold INT = 10; --in seconds 
	DECLARE @v_Actual_Threshold INT;	--in seconds 
	DECLARE @v_Start_Time DATETIME;
	DECLARE @v_End_Time DATETIME;

	SET @v_Start_Time = GETDATE();

	SELECT * FROM DENIED_USER_ACCESS;

	SET @v_End_Time = GETDATE();

	SET @v_Actual_Threshold = ABS(DATEDIFF(second, @v_Start_Time, @v_End_Time ));
	SET @v_Message = 'Getting data from DENIED_USER_ACCESS is slowr than ' + CAST(@v_Expected_Threshold AS VARCHAR) + ' seconds';
	EXEC DBTD_ASSERT_IS_GREATER @v_Expected_Threshold, @v_Actual_Threshold, @v_Message;
END;
GO



--************************************************************************************************
--note: below are the existing tests that we have created earlier in prior tutorials
--************************************************************************************************
--check that object have only "DENIED" records
CREATE PROCEDURE UT_ACCESSMONITORING_HasDeniedOnly
AS
BEGIN
	DECLARE @v_Expected_Count INT;
	DECLARE @v_Not_Expected_Count INT;
	DECLARE @v_Actual_Count INT;

	SET @v_Expected_Count = 0;
	SELECT @v_Actual_Count = count(*) 
	FROM DENIED_USER_ACCESS 
	WHERE ACCESS_ST != 'DENIED';

	EXEC DBTD_ASSERT_ARE_EQUAL @v_Actual_Count, @v_Expected_Count, 'DENIED_USER_ACCESS inclure records that have status other than "DENIED"';
END;
GO

--************************************************************************************************
--check that object have records and not just an empty recordset
CREATE PROCEDURE UT_ACCESSMONITORING_ShouldHaveRecords
AS
BEGIN
	DECLARE @v_Expected_Count INT;
	DECLARE @v_Not_Expected_Count INT;
	DECLARE @v_Actual_Count INT;

	SET @v_Not_Expected_Count = 0;
	SELECT @v_Actual_Count = count(*) 
	FROM DENIED_USER_ACCESS;

	EXEC DBTD_ASSERT_ARE_NOT_EQUAL @v_Actual_Count, @v_Not_Expected_Count, 'DENIED_USER_ACCESS does not have any records';
END;
GO

