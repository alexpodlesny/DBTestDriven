/*
*************************************************************************************************
-- SQL Server - DBTestDriven - Samples - 3.4.3.67
-- COPYRIGHT:  (c) 2011-2012 Job Continent, DBTestDriven Project by Alex Podlesny
-- http://www.dbtestdriven.com
-- Sample Set 01
*************************************************************************************************
*/

--************************************************************************************************
--check that object have only "DENIED" records
CREATE PROCEDURE UT_ACCESSMONITORING_HasDeniedOnly
AS
BEGIN
	DECLARE @v_Expected_Count INT;
	DECLARE @v_Not_Expected_Count INT;
	DECLARE @v_Actual_Count INT;

	SET @v_Expected_Count = 0;
	SELECT @v_Actual_Count = count(*) 
	FROM DENIED_USER_ACCESS 
	WHERE ACCESS_ST != 'DENIED';

	EXEC DBTD_ASSERT_ARE_EQUAL @v_Actual_Count, @v_Expected_Count, 'DENIED_USER_ACCESS inclure records that have status other than "DENIED"';
END;
GO

--************************************************************************************************
--check that object have records and not just an empty recordset
CREATE PROCEDURE UT_ACCESSMONITORING_ShouldHaveRecords
AS
BEGIN
	DECLARE @v_Expected_Count INT;
	DECLARE @v_Not_Expected_Count INT;
	DECLARE @v_Actual_Count INT;

	SET @v_Not_Expected_Count = 0;
	SELECT @v_Actual_Count = count(*) 
	FROM DENIED_USER_ACCESS;

	EXEC DBTD_ASSERT_ARE_NOT_EQUAL @v_Actual_Count, @v_Not_Expected_Count, 'DENIED_USER_ACCESS does not have any records';
END;
GO

