/*
*************************************************************************************************
-- SQL Server - DBTestDriven - Samples - 3.4.3.67
-- COPYRIGHT:  (c) 2011-2012 Job Continent, DBTestDriven Project by Alex Podlesny
-- http://www.dbtestdriven.com
-- Sample Set 01
*************************************************************************************************
*/

IF EXISTS (SELECT * FROM DBO.SYSOBJECTS WHERE ID = OBJECT_ID(N'[DBO].[ACCESS_LOG]') AND OBJECTPROPERTY(ID, N'ISUSERTABLE') = 1)
DROP TABLE [DBO].[ACCESS_LOG]
GO

IF EXISTS (SELECT * FROM DBO.SYSOBJECTS WHERE ID = OBJECT_ID(N'[DBO].[DENIED_USER_ACCESS]'))
DROP VIEW [DBO].[DENIED_USER_ACCESS]
GO

