/*
*************************************************************************************************
-- SQL Server - DBTestDriven - Samples - 3.4.3.67
-- COPYRIGHT:  (c) 2011-2012 Job Continent, DBTestDriven Project by Alex Podlesny
-- http://www.dbtestdriven.com
-- Sample Set 01
*************************************************************************************************
*/

--Table that stores all user access attempts
--Data consolidated and loaded nightly by third party application 
--note: this table might have other extra fields but for this test we are interested only in following
CREATE TABLE ACCESS_LOG
(
	USER_NM		varchar(50),	--user name
	OBJECT_NM	varchar(250),	--object name that user attempts to access
	ACCESS_ST	varchar(50)		--access status 
);
GO

--View will show the list of all occurances where status wa denied to a user
CREATE VIEW DENIED_USER_ACCESS 
AS 
SELECT 
	USER_NM,
	OBJECT_NM,
	ACCESS_ST
FROM ACCESS_LOG
WHERE ACCESS_ST	IN ('DENIED');
GO
