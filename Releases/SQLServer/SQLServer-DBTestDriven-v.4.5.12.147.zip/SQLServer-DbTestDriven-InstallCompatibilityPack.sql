﻿/*
--************************************************************************************************
-- VERSION:	   DBTestDriven - SQL Server - Version 4.5.12.147
-- COPYRIGHT:  (c) 2011-2014 Job Continent, DBTestDriven Project by Alex Podlesny
-- http://www.dbtestdriven.com
--************************************************************************************************
*/

--************************************************************************************************
--COMPATIBILITY PACK
--DBTD_ASSERT_TABLE_OR_VIEW_EXISTS - Synonym
--verifies that view or table does exists in the database
--NOTE: Oracle Compatibility
CREATE PROCEDURE DBTD_ASSERT_TBL_OR_VW_EXISTS
(
	@v_ObjectName	SYSNAME,		--table or view name
	@v_UserMessage	NVARCHAR(MAX)	--user message
)
WITH ENCRYPTION AS
BEGIN
	SET NOCOUNT ON;
	DECLARE @v_ThisProcName	NVARCHAR(128) = OBJECT_NAME(@@PROCID)
	DECLARE @v_Message NVARCHAR(MAX) = 'Running ' + @v_ThisProcName;
	EXEC DBTD_LOG_MESSAGE_EXT 'DEBUG', @v_ThisProcName, @v_Message;

	EXEC DBTD_LOG_MESSAGE_EXT 'DEBUG', @v_ThisProcName, 'Running DBTD_ASSERT_TABLE_OR_VIEW_EXISTS in the compatibility mode.';
	EXEC DBTD_ASSERT_TABLE_OR_VIEW_EXISTS @v_ObjectName, @v_UserMessage;
END;
GO

--************************************************************************************************
--COMPATIBILITY PACK
--DBTD_ASSERT_COLUMN_TYPE_AND_PRECISION - Synonym
--Will fail if column with given type and precision cannot be found in the table or view
--NOTE: Oracle Compatibility
CREATE PROCEDURE DBTD_ASSERT_COL_TYPE_AND_PRCN
(
	@v_ObjectName		NVARCHAR(255),	--Table or View name
	@v_ColumnName		NVARCHAR(255),	--Column Name
	@v_ColumnType		NVARCHAR(255),	--Column Type
	@v_ColumnPrecScale	NVARCHAR(255),	--Column precision and scale
	@v_UserMessage		NVARCHAR(MAX)	--User message
)
WITH ENCRYPTION AS
BEGIN
	SET NOCOUNT ON;
	DECLARE @v_ThisProcName	NVARCHAR(128) = OBJECT_NAME(@@PROCID)
	DECLARE @v_Message NVARCHAR(MAX) = 'Running ' + @v_ThisProcName;
	EXEC DBTD_LOG_MESSAGE_EXT 'DEBUG', @v_ThisProcName, @v_Message;

	EXEC DBTD_LOG_MESSAGE_EXT 'DEBUG', @v_ThisProcName, 'Running DBTD_ASSERT_COLUMN_TYPE_AND_PRECISION in compatibility mode.';
	EXEC DBTD_ASSERT_COLUMN_TYPE_AND_PRECISION @v_ObjectName, @v_ColumnName, @v_ColumnType, @v_ColumnPrecScale, @v_UserMessage;
END;
GO

--************************************************************************************************
--COMPATIBILITY PACK
--DBTD_ASSERT_COLUMN_IS_NOT_NULLABLE - Synonym
-- Checks that column is NOT nullable in the existing table or view 
-- Will fail if corresponding view or table cannot be found
--NOTE: Oracle Compatibility
CREATE PROCEDURE DBTD_ASSERT_COL_NOT_NULLABLE
(
	@v_ObjectName	NVARCHAR(255),	--Table or View name
	@v_ColumnName	NVARCHAR(255),	--Column Name
	@v_UserMessage	NVARCHAR(MAX)	--User message
)
WITH ENCRYPTION AS
BEGIN
	SET NOCOUNT ON;
	DECLARE @v_ThisProcName	NVARCHAR(128) = OBJECT_NAME(@@PROCID)
	DECLARE @v_Message NVARCHAR(MAX) = 'Running ' + @v_ThisProcName;
	EXEC DBTD_LOG_MESSAGE_EXT 'DEBUG', @v_ThisProcName, @v_Message;

	EXEC DBTD_LOG_MESSAGE_EXT 'DEBUG', @v_ThisProcName, 'Running DBTD_ASSERT_COLUMN_IS_NOT_NULLABLE in compatibility mode.';
	EXEC DBTD_ASSERT_COLUMN_IS_NOT_NULLABLE @v_ObjectName, @v_ColumnName, @v_UserMessage;
END;
GO

--************************************************************************************************
--COMPATIBILITY PACK
--DBTD_ASSERT_IS_COLUMN_VALUE_UNIQUE - Synonym
-- Checks that column is NOT nullable in the existing table or view 
-- Will fail if corresponding view or table cannot be found
--NOTE: Oracle Compatibility
CREATE PROCEDURE DBTD_ASSERT_COL_VALUE_UNIQUE
(
	@v_TableName		NVARCHAR(255),	--Table name
	@v_ColumnName		NVARCHAR(255),	--column that should have unique\distinct values only
	@v_UserMessage		NVARCHAR(MAX)	--User message
)
WITH ENCRYPTION AS
BEGIN
	SET NOCOUNT ON;
	DECLARE @v_ThisProcName	NVARCHAR(128) = OBJECT_NAME(@@PROCID)
	DECLARE @v_Message NVARCHAR(MAX) = 'Running ' + @v_ThisProcName;
	EXEC DBTD_LOG_MESSAGE_EXT 'DEBUG', @v_ThisProcName, @v_Message;

	EXEC DBTD_LOG_MESSAGE_EXT 'DEBUG', @v_ThisProcName, 'Running DBTD_ASSERT_IS_COLUMN_VALUE_UNIQUE in compatibility mode.';
	EXEC DBTD_ASSERT_IS_COLUMN_VALUE_UNIQUE @v_TableName, @v_ColumnName, @v_UserMessage;
END;
GO

--************************************************************************************************
--COMPATIBILITY PACK
--DBTD_ASSERT_COLUMN_HAS_NO_VALUE - Synonym
--checks that column have a given value at list in one row of a given table 
--NOTE: Oracle Compatibility
CREATE PROCEDURE DBTD_ASSERT_COL_HAS_NO_VALUE
(
	@v_TableName		NVARCHAR(255),	--table name
	@v_ColumnName		NVARCHAR(255),	--column that will be checked for a value
	@v_Value			NVARCHAR(4000),	--asserted value
	@v_ValueDataType	NVARCHAR(255),	--value data type
	@v_UserMessage		NVARCHAR(MAX)	--user message
)
WITH ENCRYPTION AS
BEGIN
	SET NOCOUNT ON;
	DECLARE @v_ThisProcName	NVARCHAR(128) = OBJECT_NAME(@@PROCID)
	DECLARE @v_Message NVARCHAR(MAX) = 'Running ' + @v_ThisProcName;
	EXEC DBTD_LOG_MESSAGE_EXT 'DEBUG', @v_ThisProcName, @v_Message;

	EXEC DBTD_LOG_MESSAGE_EXT 'DEBUG', @v_ThisProcName, 'Running DBTD_ASSERT_COLUMN_HAS_NO_VALUE in compatibility mode.';
	EXEC DBTD_ASSERT_COLUMN_HAS_NO_VALUE @v_TableName, @v_ColumnName, @v_Value, @v_ValueDataType, @v_UserMessage;
END;
GO

--************************************************************************************************
--COMPATIBILITY PACK
--DBTD_ASSERT_SAME_NUMBER_OF_ROWS - Synonym
--checks that both tables have same number of rows
--NOTE: Oracle Compatibility
CREATE PROCEDURE DBTD_ASSERT_SAME_NMBR_OF_ROWS
(
	@v_TableNameA	NVARCHAR(255),	--name of the first table 
	@v_TableNameB	NVARCHAR(255),	--name of the second table 
	@v_UserMessage	NVARCHAR(MAX)	--User message
)
WITH ENCRYPTION AS
BEGIN
	SET NOCOUNT ON;
	DECLARE @v_ThisProcName	NVARCHAR(128) = OBJECT_NAME(@@PROCID)
	DECLARE @v_Message NVARCHAR(MAX) = 'Running ' + @v_ThisProcName;
	EXEC DBTD_LOG_MESSAGE_EXT 'DEBUG', @v_ThisProcName, @v_Message;

	EXEC DBTD_LOG_MESSAGE_EXT 'DEBUG', @v_ThisProcName, 'Running DBTD_ASSERT_SAME_NUMBER_OF_ROWS in compatibility mode.';
	EXEC DBTD_ASSERT_SAME_NUMBER_OF_ROWS @v_TableNameA, @v_TableNameB, @v_UserMessage;
END;
GO
