﻿/*
--************************************************************************************************
-- VERSION:	   DBTestDriven - SQL Server - Version 4.5.12.147
-- COPYRIGHT:  (c) 2011-2014 Job Continent, DBTestDriven Project
-- http://www.dbtestdriven.com
-- 
-- Note:	"xp_instance_regread" is unsupported/undocumented procedure
--			http://connect.microsoft.com/SQLServer/feedback/details/515132/management-studio-generates-scripts-that-use-unsupported-undocumented-procedures
--************************************************************************************************
*/

USE [master]
GO

DECLARE @v_DefaultData 	NVARCHAR(1000),
		@v_DefaultLog 	NVARCHAR(1000),
		@v_MasterData 	NVARCHAR(1000),
		@v_MasterLog 	NVARCHAR(1000),
		@v_DataPath 	NVARCHAR(1000),
		@v_IndexesPath 	NVARCHAR(1000),
		@v_LogPath 		NVARCHAR(1000),
		@v_Subdirectory NVARCHAR(100)

--************************************************************************************************
----	Get default values, if possible (if defined):
EXEC master.dbo.xp_instance_regread N'HKEY_LOCAL_MACHINE', N'Software\Microsoft\MSSQLServer\MSSQLServer', N'DefaultData', @v_DefaultData OUTPUT
EXEC master.dbo.xp_instance_regread N'HKEY_LOCAL_MACHINE', N'Software\Microsoft\MSSQLServer\MSSQLServer', N'DefaultLog', @v_DefaultLog OUTPUT
----	Get data path for master database:
EXEC master.dbo.xp_instance_regread N'HKEY_LOCAL_MACHINE', N'Software\Microsoft\MSSQLServer\MSSQLServer\Parameters', N'SqlArg0', @v_MasterData OUTPUT
SELECT @v_MasterData = SUBSTRING(@v_MasterData, 3, 255)
SELECT @v_MasterData = SUBSTRING(@v_MasterData, 1, LEN(@v_MasterData) - CHARINDEX('\', REVERSE(@v_MasterData)))
----	Get log path for master database:
EXEC master.dbo.xp_instance_regread N'HKEY_LOCAL_MACHINE', N'Software\Microsoft\MSSQLServer\MSSQLServer\Parameters', N'SqlArg2', @v_MasterLog OUTPUT
SELECT @v_MasterLog = SUBSTRING(@v_MasterLog, 3, 255)
SELECT @v_MasterLog = SUBSTRING(@v_MasterLog, 1, LEN(@v_MasterLog) - CHARINDEX('\', REVERSE(@v_MasterLog)))

DECLARE @v_DirTree TABLE (
						subdirectory nvarchar(255), 
						[depth] INT
						)

--************************************************************************************************
-- 2 - Initialize 
SET	@v_Subdirectory = 'DBTestDriven'
SET @v_DataPath 	= ISNULL(@v_DefaultData, @v_MasterData) + '\' + @v_Subdirectory
SET @v_IndexesPath 	= @v_DataPath
SET @v_LogPath 		= ISNULL(@v_DefaultLog, @v_MasterLog) + '\' + @v_Subdirectory

--************************************************************************************************
-- 3 - @v_DataPath values
INSERT INTO @v_DirTree(subdirectory, depth)
EXEC master.sys.xp_dirtree @v_DataPath

--************************************************************************************************
-- 4 - Create the @v_DataPath directory
IF NOT EXISTS (SELECT 1 FROM @v_DirTree WHERE subdirectory = @v_Subdirectory)
BEGIN
	EXEC master.dbo.xp_create_subdir @v_DataPath
END

--************************************************************************************************
-- 3 - @v_LogPath values
INSERT INTO @v_DirTree(subdirectory, depth)
EXEC master.sys.xp_dirtree @v_LogPath

--************************************************************************************************
-- 4 - Create the @v_LogPath directory
IF NOT EXISTS (SELECT 1 FROM @v_DirTree WHERE subdirectory = @v_LogPath)
EXEC master.dbo.xp_create_subdir @v_LogPath

--************************************************************************************************
-- If you run for the second or more time(s) please uncommect following code (drop database):
IF EXISTS(SELECT 1 FROM sys.databases WHERE [name] = @v_Subdirectory)
BEGIN
	EXEC msdb.dbo.sp_delete_database_backuphistory @database_name = @v_Subdirectory;
	EXECUTE ('ALTER DATABASE '+ @v_Subdirectory +' SET  SINGLE_USER WITH ROLLBACK IMMEDIATE;
	ALTER DATABASE '+ @v_Subdirectory +' SET  SINGLE_USER ;
	DROP DATABASE '+ @v_Subdirectory +';')
END

EXECUTE('CREATE DATABASE ['+ @v_Subdirectory +'] ON  PRIMARY 
( NAME = N''_sysdata'', FILENAME = N'''+@v_DataPath+ '\'+ @v_Subdirectory +'_sysdata.mdf'', FILEGROWTH = 1024KB ), 
 FILEGROUP [_data] ( NAME = N''_data'', FILENAME = N''' +@v_DataPath+ '\'+ @v_Subdirectory +'_data.ndf'', FILEGROWTH = 1024KB ),
 FILEGROUP [_indexes] ( NAME = N''_indexes'', FILENAME = N''' +@v_IndexesPath+ '\'+ @v_Subdirectory +'_indexes.ndf'', FILEGROWTH = 1024KB )
 LOG ON ( NAME = N''_log'', FILENAME = N''' +@v_LogPath+ '\'+ @v_Subdirectory +'_log.ldf'', FILEGROWTH = 10%)
')
GO

IF (1 = FULLTEXTSERVICEPROPERTY('IsFullTextInstalled'))
BEGIN
	EXEC [DBTestDriven].[dbo].[sp_fulltext_database] @action = 'disable'
END
GO

ALTER DATABASE [DBTestDriven] SET ANSI_NULL_DEFAULT OFF 
GO
ALTER DATABASE [DBTestDriven] SET ANSI_NULLS OFF 
GO
ALTER DATABASE [DBTestDriven] SET ANSI_PADDING OFF 
GO
ALTER DATABASE [DBTestDriven] SET ANSI_WARNINGS OFF 
GO
ALTER DATABASE [DBTestDriven] SET ARITHABORT OFF 
GO
ALTER DATABASE [DBTestDriven] SET AUTO_CLOSE OFF 
GO
ALTER DATABASE [DBTestDriven] SET AUTO_CREATE_STATISTICS ON
GO
ALTER DATABASE [DBTestDriven] SET AUTO_SHRINK OFF 
GO
ALTER DATABASE [DBTestDriven] SET AUTO_UPDATE_STATISTICS ON
GO
ALTER DATABASE [DBTestDriven] SET CURSOR_CLOSE_ON_COMMIT OFF 
GO
ALTER DATABASE [DBTestDriven] SET CURSOR_DEFAULT  GLOBAL 
GO
ALTER DATABASE [DBTestDriven] SET CONCAT_NULL_YIELDS_NULL OFF 
GO
ALTER DATABASE [DBTestDriven] SET NUMERIC_ROUNDABORT OFF 
GO
ALTER DATABASE [DBTestDriven] SET QUOTED_IDENTIFIER OFF 
GO
ALTER DATABASE [DBTestDriven] SET RECURSIVE_TRIGGERS OFF 
GO
ALTER DATABASE [DBTestDriven] SET AUTO_UPDATE_STATISTICS_ASYNC OFF 
GO
ALTER DATABASE [DBTestDriven] SET DATE_CORRELATION_OPTIMIZATION OFF 
GO
ALTER DATABASE [DBTestDriven] SET PARAMETERIZATION SIMPLE 
GO
ALTER DATABASE [DBTestDriven] SET  READ_WRITE 
GO
ALTER DATABASE [DBTestDriven] SET RECOVERY SIMPLE 
GO
ALTER DATABASE [DBTestDriven] SET  MULTI_USER 
GO
ALTER DATABASE [DBTestDriven] SET PAGE_VERIFY CHECKSUM  
GO

USE [DBTestDriven]
GO

--************************************************************************************************
IF NOT EXISTS (SELECT name FROM sys.filegroups WHERE is_default=1 AND name = N'_data')
BEGIN
	ALTER DATABASE [DBTestDriven] MODIFY FILEGROUP [_data] DEFAULT
END
GO
