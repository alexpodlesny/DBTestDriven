﻿/*
--************************************************************************************************
-- VERSION:	   DBTestDriven - SQL Server - Version 4.7.1.497
-- COPYRIGHT:  (c) 2011-2014 Job Continent, DBTestDriven Project by Alex Podlesny
-- http://www.dbtestdriven.com
--
-- INSTALL: Step Two (Required)
--
-- NOTE: Follow installation guide on the DBTestDriven web site http://www.dbtestdriven.com/installation.aspx 
--       this is the SECOND INSTALLATION STEP 
--
-- NOTE: list of useful tools usd by framework
--
--************************************************************************************************
*/

IF EXISTS (SELECT 1 FROM DBO.SYSOBJECTS WHERE ID = OBJECT_ID(N'[DBO].[DBTD_DROP_TABLE_IF_EXISTS]') AND OBJECTPROPERTY(ID, N'ISPROCEDURE') = 1)
	DROP PROCEDURE [DBO].[DBTD_DROP_TABLE_IF_EXISTS]
GO
IF EXISTS (SELECT 1 FROM DBO.SYSOBJECTS WHERE ID = OBJECT_ID(N'[DBO].[DBTD_DROP_VIEW_IF_EXISTS]') AND OBJECTPROPERTY(ID, N'ISPROCEDURE') = 1)
	DROP PROCEDURE [DBO].[DBTD_DROP_VIEW_IF_EXISTS]
GO
IF EXISTS (SELECT 1 FROM DBO.SYSOBJECTS WHERE ID = OBJECT_ID(N'[DBO].[DBTD_DROP_PROC_IF_EXISTS]') AND OBJECTPROPERTY(ID, N'ISPROCEDURE') = 1)
	DROP PROCEDURE [DBO].[DBTD_DROP_PROC_IF_EXISTS]
GO
IF EXISTS (SELECT 1 FROM DBO.SYSOBJECTS WHERE ID = OBJECT_ID(N'[DBO].[DBTD_DROP_SEQUENCE_IF_EXISTS]') AND OBJECTPROPERTY(ID, N'ISPROCEDURE') = 1)
	DROP PROCEDURE [DBO].[DBTD_DROP_SEQUENCE_IF_EXISTS]
GO
IF EXISTS (SELECT 1 FROM DBO.SYSOBJECTS WHERE ID = OBJECT_ID(N'[DBO].[DBTD_DROP_TRIGGER_IF_EXISTS]') AND OBJECTPROPERTY(ID, N'ISPROCEDURE') = 1)
	DROP PROCEDURE [DBO].[DBTD_DROP_TRIGGER_IF_EXISTS]
GO
IF EXISTS (SELECT 1 FROM DBO.SYSOBJECTS WHERE ID = OBJECT_ID(N'[DBO].[DBTD_DROP_INDEX_IF_EXISTS]') AND OBJECTPROPERTY(ID, N'ISPROCEDURE') = 1)
	DROP PROCEDURE [DBO].[DBTD_DROP_INDEX_IF_EXISTS]
GO
IF EXISTS (SELECT 1 FROM DBO.SYSOBJECTS WHERE ID = OBJECT_ID(N'[DBO].[DBTD_DROP_FUNC_IF_EXISTS]') AND OBJECTPROPERTY(ID, N'ISPROCEDURE') = 1)
	DROP PROCEDURE [DBO].[DBTD_DROP_FUNC_IF_EXISTS]
GO
IF EXISTS (SELECT 1 FROM DBO.SYSOBJECTS WHERE ID = OBJECT_ID(N'[DBO].[DBTD_DROP_SCHEMA_IF_EXISTS]') AND OBJECTPROPERTY(ID, N'ISPROCEDURE') = 1)
	DROP PROCEDURE [DBO].[DBTD_DROP_SCHEMA_IF_EXISTS]
GO
IF EXISTS (SELECT 1 FROM DBO.SYSOBJECTS WHERE ID = OBJECT_ID(N'[DBO].[DBTD_DROP_SYNONYM_IF_EXISTS]') AND OBJECTPROPERTY(ID, N'ISPROCEDURE') = 1)
	DROP PROCEDURE [DBO].[DBTD_DROP_SYNONYM_IF_EXISTS]
GO
IF EXISTS (SELECT 1 FROM DBO.SYSOBJECTS WHERE ID = OBJECT_ID(N'[DBO].[DBTD_SP_EXECUTESQL]') AND OBJECTPROPERTY(ID, N'ISPROCEDURE') = 1)
	DROP PROCEDURE [DBO].[DBTD_SP_EXECUTESQL]
GO
IF EXISTS (SELECT 1 FROM DBO.SYSOBJECTS WHERE ID = OBJECT_ID(N'[DBO].[DBTD_SPLIT_FOUR_PART_OBJECT_NAME]') AND OBJECTPROPERTY(ID, N'ISPROCEDURE') = 1)
	DROP PROCEDURE [DBO].[DBTD_SPLIT_FOUR_PART_OBJECT_NAME]
GO
IF EXISTS (SELECT 1 FROM DBO.SYSOBJECTS WHERE ID = OBJECT_ID(N'DBO.DBTD_GET_OBJECT_ID') AND OBJECTPROPERTY(ID, N'ISPROCEDURE') = 1)
	DROP PROCEDURE DBO.DBTD_GET_OBJECT_ID
GO
IF EXISTS (SELECT 1 FROM DBO.SYSOBJECTS WHERE ID = OBJECT_ID(N'[DBO].[DBTD_PREPARE_FOUR_PART_OBJECT_NAME]') AND OBJECTPROPERTY(ID, N'ISPROCEDURE') = 1)
	DROP PROCEDURE [DBO].[DBTD_PREPARE_FOUR_PART_OBJECT_NAME]
GO
IF EXISTS (SELECT 1 FROM DBO.SYSOBJECTS WHERE ID = OBJECT_ID(N'[DBO].[DBTD_CREATE_SCHEMA_UNIT_TEST]') AND OBJECTPROPERTY(ID, N'ISPROCEDURE') = 1)
	DROP PROCEDURE [DBO].DBTD_CREATE_SCHEMA_UNIT_TEST
GO
IF EXISTS (SELECT 1 FROM DBO.SYSOBJECTS WHERE ID = OBJECT_ID(N'[DBO].[DBTD_SPLIT_STRING_TO_TABLE]'))
	DROP FUNCTION [DBO].[DBTD_SPLIT_STRING_TO_TABLE]
GO
IF EXISTS (SELECT 1 FROM DBO.SYSOBJECTS WHERE ID = OBJECT_ID(N'DBO.DBTD_DROP_FULLTEXT_CATALOG_IF_EXISTS') AND OBJECTPROPERTY(ID, N'ISPROCEDURE') = 1)
	DROP PROCEDURE [DBO].DBTD_DROP_FULLTEXT_CATALOG_IF_EXISTS
GO
IF EXISTS (SELECT 1 FROM DBO.SYSOBJECTS WHERE ID = OBJECT_ID(N'DBO.DBTD_DROP_FULLTEXT_INDEX_IF_EXISTS') AND OBJECTPROPERTY(ID, N'ISPROCEDURE') = 1)
	DROP PROCEDURE [DBO].DBTD_DROP_FULLTEXT_INDEX_IF_EXISTS
GO
IF EXISTS (SELECT 1 FROM DBO.SYSOBJECTS WHERE ID = OBJECT_ID(N'DBO.DBTD_fnSQLServerMajorProductVersion') )
	DROP FUNCTION [DBO].DBTD_fnSQLServerMajorProductVersion
GO
--************************************************************************************************
CREATE PROCEDURE DBO.DBTD_SP_EXECUTESQL
(
	@v_TargetDatabase SYSNAME,	--Target database
	@v_SQLCode NVARCHAR(MAX)	--SQL Code that will be executed in the target database
)
WITH ENCRYPTION AS
BEGIN
	SET NOCOUNT ON;
	DECLARE @v_InterDBCode NVARCHAR(MAX),
			@v_ProcName	NVARCHAR(128) = OBJECT_NAME(@@PROCID)

	CREATE TABLE #DBTD_INTER_DB_SQL(
		SQLCode NVARCHAR(MAX)
	);
	INSERT INTO #DBTD_INTER_DB_SQL (SQLCode) VALUES (@v_SQLCode);
	IF OBJECT_ID('dbo.DBTD_TBL_LOG') IS NOT NULL
	BEGIN
		INSERT INTO dbo.DBTD_TBL_LOG 
			(EventType, EventSource, EventTime, [Message]) 
			VALUES ('INFO', 'DBTD_SP_EXECUTESQL', GETDATE(), @v_SQLCode);
	END

	SET @v_InterDBCode = 
		'
		DECLARE @v NVARCHAR(MAX); 
		SELECT @v = SQLCode FROM #DBTD_INTER_DB_SQL; 
		EXECUTE '+@v_TargetDatabase+'.dbo.sp_executesql @v;
		';

	EXECUTE dbo.sp_executesql @v_InterDBCode;

	DROP TABLE #DBTD_INTER_DB_SQL --explicity drop the table
END;
GO

--************************************************************************************************
--Function separates a v_Name string lile 'server.database.schema.object' into four distinct 
--object name parts: server, database, schema and object.
--NOTE: if @v_CorrectTempTablesLocation set to 1, procedure will:
--             - correct temp table location to be server.TEMPDB.dbo.#temptable, DEFAULT value is 1 
--             - uses DBO as default schema 
--INTERNAL: Do not use this function in your unit tests, procedure can be removed,
--          signature or procedure name can be changed at any release
CREATE PROCEDURE DBO.DBTD_SPLIT_FOUR_PART_OBJECT_NAME
(
	@v_Name		SYSNAME,				-- Fully qualified SQL name
	@v_Server	NVARCHAR(128) OUTPUT,
	@v_Database NVARCHAR(128) OUTPUT,
	@v_Schema	NVARCHAR(128) OUTPUT,
	@v_Object	NVARCHAR(128) OUTPUT,
	@v_CorrectedName SYSNAME OUTPUT,	
	@v_CorrectTempTablesLocation BIT = 1
)
WITH ENCRYPTION 
AS
BEGIN
	SET NOCOUNT ON;
	DECLARE @v_TmpStr VARCHAR(2000),
			@v_Separator CHAR(1) = '.',
			@v_NumberOfParts INT,
			@v_PartsCount INT = 0,
			@v_SeparatorIndex INT,
			@v_CurrentPart VARCHAR(255) = '',
			@v_Part1 VARCHAR(255) = '',
			@v_Part2 VARCHAR(255) = '',
			@v_Part3 VARCHAR(255) = '',
			@v_Part4 VARCHAR(255) = '',
			@v_TempObjectFlag BIT

	SELECT @v_Server = '', @v_Database = '', @v_Schema = '', @v_Object = '';
	SET @v_TmpStr = @v_Name;
	SET @v_NumberOfParts = (LEN(@v_TmpStr) - LEN(REPLACE(@v_TmpStr, @v_Separator, ''))) + 1
	SET @v_TmpStr = LTRIM(RTRIM(@v_Name));

	SET @v_CorrectedName = @v_TmpStr -- at first use the same name for corrected name

	IF @v_NumberOfParts = 1 
	BEGIN 
		SET @v_Part1 = LTRIM(RTRIM(@v_TmpStr))
	END 
	ELSE BEGIN 
		WHILE 
			(@v_PartsCount < @v_NumberOfParts)				--no more string
			AND (CHARINDEX(@v_Separator, @v_TmpStr)) != 0	--no more parts
		BEGIN
			SET @v_PartsCount = @v_PartsCount + 1
			
			SET @v_SeparatorIndex = CHARINDEX(@v_Separator, @v_TmpStr);
			SET @v_CurrentPart = SUBSTRING (@v_TmpStr , 1, @v_SeparatorIndex -1 )
			SET @v_TmpStr = RIGHT(@v_TmpStr, LEN(@v_TmpStr)-@v_SeparatorIndex);
			
			IF @v_PartsCount = 1 BEGIN SET @v_Part1 = LTRIM(RTRIM(@v_CurrentPart)); SET @v_Part2 = LTRIM(RTRIM(@v_TmpStr)); END
			IF @v_PartsCount = 2 BEGIN SET @v_Part2 = LTRIM(RTRIM(@v_CurrentPart)); SET @v_Part3 = LTRIM(RTRIM(@v_TmpStr)); END
			IF @v_PartsCount = 3 BEGIN SET @v_Part3 = LTRIM(RTRIM(@v_CurrentPart)); SET @v_Part4 = LTRIM(RTRIM(@v_TmpStr)); END
		END
	END
	
	--select @v_Part1, @v_Part2, @v_Part3, @v_Part4	
	IF @v_NumberOfParts = 4 SELECT @v_Server = @v_Part1, @v_Database = @v_Part2, @v_Schema = @v_Part3, @v_Object = @v_Part4;
	IF @v_NumberOfParts = 3 SELECT @v_Database = @v_Part1, @v_Schema = @v_Part2, @v_Object = @v_Part3;
	IF @v_NumberOfParts = 2 SELECT @v_Schema = @v_Part1, @v_Object = @v_Part2;
	IF @v_NumberOfParts = 1 SELECT @v_Object = @v_Part1;

	--cleanup brackets
	SET @v_Server = REPLACE(REPLACE(@v_Server, ']', ''), '[', ''); 
	SET @v_Database = REPLACE(REPLACE(@v_Database, ']', ''), '[', ''); 
	SET @v_Schema = REPLACE(REPLACE(@v_Schema, ']', ''), '[', ''); 
	SET @v_Object = REPLACE(REPLACE(@v_Object, ']', ''), '[', ''); 

	IF LTRIM(RTRIM(@v_Schema)) = '' SET @v_Schema = 'dbo'; --default schema is DBO

	--correct temp DB settings 
	SET @v_TempObjectFlag = CASE WHEN CHARINDEX('#',@v_Object) != 0 THEN 1 ELSE 0 END;
	IF @v_CorrectTempTablesLocation = 1 AND @v_TempObjectFlag = 1
	BEGIN 
		SET @v_Database = 'TEMPDB';
		SET @v_Schema = 'dbo';
	END 

	IF LTRIM(RTRIM(@v_Database)) = '' SET @v_Database = DB_NAME(); --default database is database in which we run

	SET @v_Server = CASE WHEN @v_Server IS NULL OR @v_Server = '' THEN '' ELSE '['+@v_Server+']' END; 
	SET @v_Database = CASE WHEN @v_Database IS NULL OR @v_Database = '' THEN '' ELSE '['+@v_Database+']' END;
	SET @v_Schema = CASE WHEN @v_Schema IS NULL OR @v_Schema = '' THEN '' ELSE '['+@v_Schema+']' END;
	SET @v_Object = CASE WHEN @v_Object IS NULL OR @v_Object = '' THEN '' ELSE '['+@v_Object+']' END;

		-- reconstruct the name 
	SET @v_CorrectedName = 
			CASE WHEN @v_Server != '' THEN @v_Server + '.' ELSE '' END 
			+ CASE 
				WHEN @v_Database != '' THEN @v_Database + '.' 
				WHEN @v_Server != '' THEN '.'
				ELSE '' 
			END 
			+ CASE WHEN @v_Schema != '' THEN @v_Schema + '.' ELSE '' END --we will always have schema
			+ @v_Object;
END
GO

--************************************************************************************************
--Function prepares four part object name 'server.database.schema.object' base on the provided values
--INTERNAL: Do not use this function in your unit tests, procedure can be removed,
--          signature or procedure name can be changed at any release
CREATE PROCEDURE DBO.DBTD_PREPARE_FOUR_PART_OBJECT_NAME
(
	@v_Server	NVARCHAR(128),
	@v_Database NVARCHAR(128),
	@v_Schema	NVARCHAR(128),
	@v_Object	NVARCHAR(128),
	@v_FullName		SYSNAME OUTPUT,					-- Fully qualified SQL name
	@v_CorrectedName SYSNAME OUTPUT,	
	@v_CorrectTempTablesLocation BIT = 1
)
WITH ENCRYPTION 
AS
BEGIN
	SET NOCOUNT ON;
	DECLARE @v_TempObjectFlag BIT 

	--Cleanup brackets
	SET @v_Server = LTRIM(RTRIM(REPLACE(REPLACE(ISNULL(@v_Server,''), ']', ''), '[', ''))); 
	SET @v_Database = LTRIM(RTRIM(REPLACE(REPLACE(ISNULL(@v_Database,''), ']', ''), '[', ''))); 
	SET @v_Schema = LTRIM(RTRIM(REPLACE(REPLACE(ISNULL(@v_Schema,''), ']', ''), '[', ''))); 
	SET @v_Object = LTRIM(RTRIM(REPLACE(REPLACE(ISNULL(@v_Object,''), ']', ''), '[', ''))); 

	IF @v_Schema = '' SET @v_Schema = 'dbo'; --default schema is DBO

	--Correct temp DB settings 
	SET @v_TempObjectFlag = CASE WHEN charindex('#',@v_Object) != 0 THEN 1 ELSE 0 END;
	IF @v_CorrectTempTablesLocation = 1	AND @v_TempObjectFlag = 1
	BEGIN 
		SET @v_Database = 'TEMPDB';
		SET @v_Schema = 'dbo';
	END 

	SET @v_Server	= CASE WHEN @v_Server IS NULL OR @v_Server = '' THEN '' ELSE '['+@v_Server+']' END; 
	SET @v_Database = CASE WHEN @v_Database IS NULL OR @v_Database = '' THEN '' ELSE '['+@v_Database+']' END;
	SET @v_Schema	= CASE WHEN @v_Schema IS NULL OR @v_Schema = '' THEN '' ELSE '['+@v_Schema+']' END;
	SET @v_Object	= CASE WHEN @v_Object IS NULL OR @v_Object = '' THEN '' ELSE '['+@v_Object+']' END;

	--Reconstruct the name 
	SET @v_CorrectedName = 
			CASE WHEN @v_Server != '' THEN @v_Server + '.' ELSE '' END 
			+ CASE 
				WHEN @v_Database != '' THEN @v_Database + '.' 
				WHEN @v_Server != '' THEN '.'
				ELSE '' 
			END 
			+ CASE WHEN @v_Schema != '' THEN @v_Schema + '.' ELSE '' END --we will always have schema
			+ @v_Object;
	SET @v_FullName = REPLACE(REPLACE(@v_CorrectedName, ']', ''), '[', '');
END
GO

--************************************************************************************************
CREATE PROCEDURE DBO.DBTD_GET_OBJECT_ID
(
	@v_Object_Name SYSNAME,
	@v_Object_ID BIGINT OUTPUT
)
WITH ENCRYPTION AS 
BEGIN
	SET NOCOUNT ON;
	DECLARE @v_SQL NVARCHAR(MAX) = '',
			@v_Server NVARCHAR(2000),
			@v_Database NVARCHAR(2000),
			@v_Schema NVARCHAR(2000),
			@v_CorrectedName NVARCHAR(2000),
			@v_Object NVARCHAR(2000),
			@v_ParmDefinition NVARCHAR(MAX) = N'@v_InternaltObjectID INT OUTPUT'

	EXEC DBTD_SPLIT_FOUR_PART_OBJECT_NAME 
		@v_Object_Name, 
		@v_Server = @v_Server OUTPUT, @v_Database = @v_Database OUTPUT, @v_Schema = @v_Schema OUTPUT, 
		@v_Object = @v_Object OUTPUT, @v_CorrectedName = @v_CorrectedName OUTPUT,
		@v_CorrectTempTablesLocation = 1;
	SET @v_Sql = 'SELECT @v_InternaltObjectID = OBJECT_ID ('''+@v_CorrectedName+'''); ';
	EXEC sp_executeSQL
		@v_Sql,
		@v_ParmDefinition,
		@v_InternaltObjectID = @v_Object_ID OUTPUT
END
GO

--************************************************************************************************
--NOTE: Object is supported in SQL Server 2012 
--      earlier version do not support SEQUENCE objects
CREATE PROCEDURE DBO.DBTD_DROP_SEQUENCE_IF_EXISTS
(
	@v_Object_Name	SYSNAME	--Sequence Name
)
WITH ENCRYPTION AS
BEGIN
	SET NOCOUNT ON;

	DECLARE @v_SQL NVARCHAR(255);
	DECLARE @v_Message VARCHAR(2000);

	SET @v_Message = 'Cannot drop "' + @v_Object_Name + '" sequence. Functionality is not supported for compatibility with earlier versions of SQL Server.';
	PRINT @v_Message;
	RETURN 0; 
	SELECT @@VERSION
	--BEGIN TRY 
	--	IF EXISTS (	SELECT 1 FROM SYS.SEQUENCES  
	--				WHERE name = OBJECT_ID(v_Object_Name))
	--	BEGIN
	--		SET @v_SQL = 'DROP SEQUENCE ' + v_Object_Name;
	--		EXECUTE sp_executesql @v_SQL;
	--		SET @v_Message = 'Sequence "' + @v_Object_Name + '" has been dropped.';
	--		PRINT @v_Message;
	--		RETURN 1; 
	--	END
	--	ELSE BEGIN 
	--		SET @v_Message = 'Cannot find sequence "' + v_Object_Name + '" ';
	--		PRINT @v_Message;
	--		RETURN 0; 
	--	END; 
	--END TRY
	--BEGIN CATCH
	--	SET @v_Message = 'Cannot drop "' + v_Object_Name + '" sequence ';
	--	PRINT @v_Message;
	--	RETURN 0; 
	--END CATCH 
END;
GO

--************************************************************************************************
CREATE PROCEDURE DBO.DBTD_DROP_TABLE_IF_EXISTS
(
	@v_Object_Name SYSNAME	--Table name 
)
WITH ENCRYPTION AS
BEGIN
	SET NOCOUNT ON;

	DECLARE @v_SQL NVARCHAR(MAX) = '',
			@v_Message VARCHAR(2000),
			@v_Server NVARCHAR(2000),
			@v_Database NVARCHAR(2000),
			@v_Schema NVARCHAR(2000),
			@v_CorrectedName NVARCHAR(2000),
			@v_Object NVARCHAR(2000),
			@v_InternaltObjectID INT = NULL

	EXEC DBTD_SPLIT_FOUR_PART_OBJECT_NAME 
		@v_Object_Name, 
		@v_Server = @v_Server OUTPUT, @v_Database = @v_Database OUTPUT, @v_Schema = @v_Schema OUTPUT, 
		@v_Object = @v_Object OUTPUT, @v_CorrectedName = @v_CorrectedName OUTPUT,
		@v_CorrectTempTablesLocation = 1;

	BEGIN TRY 
		EXEC DBO.DBTD_GET_OBJECT_ID @v_CorrectedName, @v_Object_ID = @v_InternaltObjectID OUTPUT;

		IF (@v_InternaltObjectID IS NOT NULL)
		BEGIN
			SET @v_SQL = 'DROP TABLE ' + @v_Object_Name;

			EXEC DBO.DBTD_SP_EXECUTESQL	@v_Database, @v_SQL

			SET @v_Message = 'Table "' + @v_CorrectedName + '" has been dropped from ' + @v_Database + ' database.';
			PRINT @v_Message;
			RETURN 1; 
		END
		ELSE BEGIN 
			SET @v_Message = 'Cannot drop TABLE, object not found: "' + @v_CorrectedName + '" ';
			PRINT @v_Message;
			RETURN 0; 
		END; 
	END TRY
	BEGIN CATCH
		SET @v_Message = 'Cannot drop "' + @v_CorrectedName + '" table. ' + ERROR_MESSAGE();
		PRINT @v_Message;
		RETURN 0; 
	END CATCH 
END;
GO

--************************************************************************************************
CREATE PROCEDURE DBO.DBTD_DROP_PROC_IF_EXISTS
(
	@v_Object_Name	SYSNAME,			-- Procedure name
	@v_Signature	VARCHAR(128) = ''	-- Reserved
)
WITH ENCRYPTION AS
BEGIN
	SET NOCOUNT ON;

	DECLARE @v_SQL NVARCHAR(MAX) = '',
			@v_Message VARCHAR(2000),
			@v_Server NVARCHAR(2000),
			@v_Database NVARCHAR(2000),
			@v_Schema NVARCHAR(2000),
			@v_CorrectedName NVARCHAR(2000),
			@v_Object NVARCHAR(2000),
			@v_InternaltObjectID INT = NULL

	EXEC dbo.DBTD_SPLIT_FOUR_PART_OBJECT_NAME 
		@v_Object_Name, 
		@v_Server = @v_Server OUTPUT, @v_Database = @v_Database OUTPUT, @v_Schema = @v_Schema OUTPUT, 
		@v_Object = @v_Object OUTPUT, @v_CorrectedName = @v_CorrectedName OUTPUT,
		@v_CorrectTempTablesLocation = 1;
	 
	BEGIN TRY 
		EXEC DBO.DBTD_GET_OBJECT_ID @v_CorrectedName, @v_Object_ID = @v_InternaltObjectID OUTPUT;

		IF (@v_InternaltObjectID IS NOT NULL)
		BEGIN
			SET @v_SQL = 'DROP PROCEDURE ' + ISNULL( @v_Schema + '.', '') + @v_Object;

			EXEC DBO.DBTD_SP_EXECUTESQL	@v_Database, @v_SQL

			SET @v_Message = 'Stored Procedure "' + @v_CorrectedName + '" has been dropped from ' + @v_Database + ' database.';
			PRINT @v_Message;
			RETURN 1; 
		END
		ELSE BEGIN 
			SET @v_Message = 'Cannot drop PROCEDURE, object not found: "' + @v_Object_Name + '"';
			PRINT @v_Message;
			RETURN 0; 
		END; 
	END TRY
	BEGIN CATCH
		SET @v_Message = 'Cannot drop "' + @v_Object_Name + '" procedure. ' + ERROR_MESSAGE();
		PRINT @v_Message;
		RETURN 0; 
	END CATCH 
END;
GO

--************************************************************************************************
CREATE PROCEDURE DBO.DBTD_DROP_VIEW_IF_EXISTS
(
	@v_Object_Name	SYSNAME	--View Name
)
WITH ENCRYPTION AS
BEGIN
	SET NOCOUNT ON;

	DECLARE @v_SQL NVARCHAR(MAX) = '',
			@v_Message VARCHAR(2000),
			@v_Server NVARCHAR(2000),
			@v_Database NVARCHAR(2000),
			@v_Schema NVARCHAR(2000),
			@v_CorrectedName NVARCHAR(2000),
			@v_Object NVARCHAR(2000),
			@v_InternaltObjectID INT = NULL
			
	EXEC DBTD_SPLIT_FOUR_PART_OBJECT_NAME 
		@v_Object_Name, 
		@v_Server = @v_Server OUTPUT, @v_Database = @v_Database OUTPUT, @v_Schema = @v_Schema OUTPUT, 
		@v_Object = @v_Object OUTPUT, @v_CorrectedName = @v_CorrectedName OUTPUT,
		@v_CorrectTempTablesLocation = 1;

	BEGIN TRY 
		EXEC DBO.DBTD_GET_OBJECT_ID @v_CorrectedName, @v_Object_ID = @v_InternaltObjectID OUTPUT;
			
		IF (@v_InternaltObjectID IS NOT NULL)
		BEGIN
			SET @v_SQL = 'DROP VIEW ' + ISNULL( @v_Schema + '.', '') + @v_Object;

			EXEC DBO.DBTD_SP_EXECUTESQL	@v_Database, @v_SQL

			SET @v_Message = 'View "' + @v_Object_Name + '" has been dropped from ' + @v_Database + 'database.';
			PRINT @v_Message;
			RETURN 1; 
		END
		ELSE BEGIN 
			SET @v_Message = 'Cannot drop VIEW, object not found: "' + @v_Object_Name + '" ';
			PRINT @v_Message;
			RETURN 0; 
		END; 
	END TRY
	BEGIN CATCH
		SET @v_Message = 'Cannot drop "' + @v_Object_Name + '" view. ' + ERROR_MESSAGE();
		PRINT @v_Message;
		RETURN 0; 
	END CATCH 
END;
GO

--************************************************************************************************
CREATE PROCEDURE DBO.DBTD_DROP_FUNC_IF_EXISTS
(
	@v_Object_Name	SYSNAME,			-- Procedure name
	@v_Signature	VARCHAR(128) = ''	-- Reserved
)
WITH ENCRYPTION AS
BEGIN
	SET NOCOUNT ON;

	DECLARE @v_SQL NVARCHAR(MAX) = '',
			@v_Message VARCHAR(2000),
			@v_Server NVARCHAR(2000),
			@v_Database NVARCHAR(2000),
			@v_Schema NVARCHAR(2000),
			@v_CorrectedName NVARCHAR(2000),
			@v_Object NVARCHAR(2000),
			@v_InternaltObjectID INT = NULL

	EXEC DBTD_SPLIT_FOUR_PART_OBJECT_NAME 
		@v_Object_Name, 
		@v_Server = @v_Server OUTPUT, @v_Database = @v_Database OUTPUT, @v_Schema = @v_Schema OUTPUT, 
		@v_Object = @v_Object OUTPUT, @v_CorrectedName = @v_CorrectedName OUTPUT,
		@v_CorrectTempTablesLocation = 1;

	BEGIN TRY 
		EXEC DBO.DBTD_GET_OBJECT_ID @v_CorrectedName, @v_Object_ID = @v_InternaltObjectID OUTPUT;

		IF (@v_InternaltObjectID IS NOT NULL)
		BEGIN
			SET @v_SQL = 'DROP FUNCTION ' + ISNULL( @v_Schema + '.', '') + @v_Object;

			EXEC DBO.DBTD_SP_EXECUTESQL	@v_Database, @v_SQL

			SET @v_Message = 'Function "' + @v_Object_Name + '" has been dropped from ' + @v_Database + ' database.';
			PRINT @v_Message;
			RETURN 1; 
		END
		ELSE BEGIN 
			SET @v_Message = 'Cannot drop FUNCTION, object not found: "' + @v_Object_Name + '" ';
			PRINT @v_Message;
			RETURN 0; 
		END; 
	END TRY
	BEGIN CATCH
		SET @v_Message = 'Cannot drop "' + @v_Object_Name + '" function. ' + ERROR_MESSAGE();
		PRINT @v_Message;
		RETURN 0; 
	END CATCH 
END;
GO

--************************************************************************************************
CREATE PROCEDURE DBO.DBTD_DROP_SCHEMA_IF_EXISTS
(
	@v_Object_Name	SYSNAME,
	@v_Database_Name NVARCHAR(128) = NULL --When null is specified then schema will be removed in the current context
)
WITH ENCRYPTION AS
BEGIN
	SET NOCOUNT ON;

	DECLARE @v_SQL NVARCHAR(255),
			@v_Message VARCHAR(2000),
			@v_InternalSchemaID INT = NULL,
			@v_ParmDefinition NVARCHAR(MAX) = N' @v_InternalSchemaID INT OUTPUT, @v_Object_Name NVARCHAR(255) '
	
	IF (LTRIM(RTRIM(@v_Database_Name)) = '') SET @v_Database_Name = DB_NAME();
	IF (@v_Database_Name IS NULL) SET @v_Database_Name = DB_NAME();

	BEGIN TRY 
		SET @v_SQL = ' SELECT @v_InternalSchemaID = schema_id FROM ' + @v_Database_Name + '.SYS.SCHEMAS WHERE NAME = UPPER(@v_Object_Name) '
		EXECUTE sp_executeSQL
				@v_Sql,
				@v_ParmDefinition,
				@v_InternalSchemaID = @v_InternalSchemaID OUTPUT,
				@v_Object_Name = @v_Object_Name

		IF (@v_InternalSchemaID IS NOT NULL)
		BEGIN
			SET @v_SQL = 'DROP SCHEMA ' + @v_Object_Name;

			EXEC DBO.DBTD_SP_EXECUTESQL	@v_Database_Name, @v_SQL

			SET @v_Message = 'Schema "' + @v_Object_Name + '" has been dropped from [' + @v_Database_Name + '] database.';
			PRINT @v_Message;
			RETURN 1; 
		END
		ELSE BEGIN 
			SET @v_Message = 'Cannot drop SCHEMA, object not found:  "' + @v_Object_Name + '" schema in the [' + @v_Database_Name + '] database.';
			PRINT @v_Message;
			RETURN 0; 
		END; 
	END TRY
	BEGIN CATCH
		SET @v_Message = 'ERROR!!! Cannot drop "' + @v_Object_Name + '" schema. ' + ERROR_MESSAGE();
		PRINT @v_Message;
		RETURN 0; 
	END CATCH 
END;
GO

--************************************************************************************************
CREATE PROCEDURE DBO.DBTD_DROP_SYNONYM_IF_EXISTS
(
	@v_Object_Name	SYSNAME
)
WITH ENCRYPTION AS
BEGIN
	SET NOCOUNT ON;

	DECLARE @v_SQL NVARCHAR(MAX) = '',
			@v_Message VARCHAR(2000),
			@v_Server NVARCHAR(2000),
			@v_Database NVARCHAR(2000),
			@v_Schema NVARCHAR(2000),
			@v_CorrectedName NVARCHAR(2000),
			@v_Object NVARCHAR(2000),
			@v_InternaltObjectID INT = NULL

	EXEC DBTD_SPLIT_FOUR_PART_OBJECT_NAME 
		@v_Object_Name, 
		@v_Server = @v_Server OUTPUT, @v_Database = @v_Database OUTPUT, @v_Schema = @v_Schema OUTPUT, 
		@v_Object = @v_Object OUTPUT, @v_CorrectedName = @v_CorrectedName OUTPUT,
		@v_CorrectTempTablesLocation = 1;

	BEGIN TRY 
		EXEC DBO.DBTD_GET_OBJECT_ID @v_CorrectedName, @v_Object_ID = @v_InternaltObjectID OUTPUT;

		IF (@v_InternaltObjectID IS NOT NULL)
		BEGIN
			SET @v_SQL = 'DROP SYNONYM ' + ISNULL( @v_Schema + '.', '') + @v_Object;

			EXEC DBO.DBTD_SP_EXECUTESQL	@v_Database, @v_SQL

			SET @v_Message = 'Synonym "' + @v_CorrectedName + '" has been dropped from ' + @v_Database + ' database.';
			PRINT @v_Message;
			RETURN 1; 
		END
		ELSE BEGIN 
			SET @v_Message = 'Cannot drop SYNONYM, object not found:  "' + @v_CorrectedName + '" synonym in the ' + @v_Database + ' database.';
			PRINT @v_Message;
			RETURN 0; 
		END; 
	END TRY
	BEGIN CATCH
		SET @v_Message = 'ERROR!!! Cannot drop "' + @v_CorrectedName + '" synonym. ' + ERROR_MESSAGE();
		PRINT @v_Message;
		RETURN 0; 
	END CATCH 
END;
GO

--************************************************************************************************
CREATE PROCEDURE DBO.DBTD_DROP_TRIGGER_IF_EXISTS
(
	@v_Object_Name	SYSNAME	--Trigger Name
)
WITH ENCRYPTION AS
BEGIN
	SET NOCOUNT ON;
	DECLARE @v_SQL NVARCHAR(MAX) = '',
			@v_Message VARCHAR(2000),
			@v_Server NVARCHAR(2000),
			@v_Database NVARCHAR(2000),
			@v_Schema NVARCHAR(2000),
			@v_CorrectedName NVARCHAR(2000),
			@v_Object NVARCHAR(2000),
			@v_InternaltObjectID INT = NULL

	EXEC DBTD_SPLIT_FOUR_PART_OBJECT_NAME 
		@v_Object_Name, 
		@v_Server = @v_Server OUTPUT, @v_Database = @v_Database OUTPUT, @v_Schema = @v_Schema OUTPUT, 
		@v_Object = @v_Object OUTPUT, @v_CorrectedName = @v_CorrectedName OUTPUT,
		@v_CorrectTempTablesLocation = 1;

	BEGIN TRY 
		EXEC DBO.DBTD_GET_OBJECT_ID @v_CorrectedName, @v_Object_ID = @v_InternaltObjectID OUTPUT;

		--IF  OBJECT_ID (@v_Object_Name, 'TR') IS NOT NULL --find if there is a trigger with such a name
		IF (@v_InternaltObjectID IS NOT NULL)
		BEGIN
			SET @v_SQL = 'DROP TRIGGER ' + ISNULL( @v_Schema + '.', '') + @v_Object;

			EXEC DBO.DBTD_SP_EXECUTESQL	@v_Database, @v_SQL
			
			SET @v_Message = 'Trigger "' + @v_CorrectedName + '" has been dropped in the ' + @v_Database + ' database.';
			PRINT @v_Message;
			RETURN 1; 
		END
		ELSE BEGIN 
			SET @v_Message = 'Cannot drop TRIGGER, object not found:  "' + @v_CorrectedName + '" ';
			PRINT @v_Message;
			RETURN 0; 
		END; 
	END TRY
	BEGIN CATCH
		SET @v_Message = 'Cannot drop "' + @v_CorrectedName + '" trigger. ' + ERROR_MESSAGE();
		PRINT @v_Message;
		RETURN 0; 
	END CATCH 
END;
GO

--************************************************************************************************
CREATE PROCEDURE DBO.DBTD_DROP_FULLTEXT_INDEX_IF_EXISTS
(
	@v_Object_Name	SYSNAME --Name of a table of indexed view for which full text index need to be removed
)
WITH ENCRYPTION AS
BEGIN
	SET NOCOUNT ON;

	DECLARE @v_SQL NVARCHAR(MAX) = '',
			@v_Message VARCHAR(2000),
			@v_Server NVARCHAR(2000),
			@v_Database NVARCHAR(2000),
			@v_Schema NVARCHAR(2000),
			@v_CorrectedName NVARCHAR(2000),
			@v_Object NVARCHAR(2000),
			@v_InternaltObjectID INT = NULL,
			@v_HadError BIT = 0

	CREATE TABLE #DBTD_TablesWithFullTextIndex(
		ObjectName NVARCHAR(128)
	)

	EXEC DBTD_SPLIT_FOUR_PART_OBJECT_NAME  
		@v_Object_Name, 
		@v_Server = @v_Server OUTPUT, @v_Database = @v_Database OUTPUT, @v_Schema = @v_Schema OUTPUT, 
		@v_Object = @v_Object OUTPUT, @v_CorrectedName = @v_CorrectedName OUTPUT,
		@v_CorrectTempTablesLocation = 1;

	BEGIN TRY 
		EXEC DBO.DBTD_GET_OBJECT_ID @v_CorrectedName, @v_Object_ID = @v_InternaltObjectID OUTPUT;
		IF (@v_InternaltObjectID IS NOT NULL)
		BEGIN
			SET @v_SQL = 
				'INSERT INTO #DBTD_TablesWithFullTextIndex
					(ObjectName)
					SELECT ''' + LTRIM(RTRIM(@v_Database)) + '.['' + s.name + ''].['' + o.name + '']''
					FROM ' + LTRIM(RTRIM(@v_Database)) + '.sys.fulltext_indexes AS i
						INNER JOIN ' + LTRIM(RTRIM(@v_Database)) + '.sys.objects AS o
							ON i.object_id = o.object_id
						INNER JOIN DBTestDriven.sys.schemas AS S
							ON o.schema_id = s.schema_id
					WHERE o.name = ''' + REPLACE(REPLACE(@v_Object,'[',''),']','') + '''
						AND s.name = ''' + REPLACE(REPLACE(@v_Schema,'[',''),']','') + ''';'
			EXEC DBTD_SP_EXECUTESQL @v_Database, @v_SQL
			IF EXISTS( SELECT 1 FROM #DBTD_TablesWithFullTextIndex )
			BEGIN
				SET @v_SQL = 'DROP FULLTEXT INDEX ON ' + @v_CorrectedName;
				EXEC DBO.DBTD_SP_EXECUTESQL	@v_Database, @v_SQL
				SET @v_Message = 'FULL TEXT index has been dropped from [' + @v_CorrectedName +  '] object.';
				PRINT @v_Message;
				RETURN 1; 
			END 
			ELSE BEGIN 
				SET @v_Message = 'Cannot drop FULL TEXT index, object not found [' + @v_CorrectedName +  '] object.';
				PRINT @v_Message;
				RETURN 0; 
			END
		END
		ELSE BEGIN 
			SET @v_Message = 'Cannot drop INDEX, object not found: [' + @v_CorrectedName +  ']';
			PRINT @v_Message;
			RETURN 0; 
		END; 
	END TRY
	BEGIN CATCH
		SET @v_Message = 'ERROR!!! Cannot drop FULL TEXT index created for ' + @v_CorrectedName +  ' object. ' + ERROR_MESSAGE();
		PRINT @v_Message;
		SET @v_HadError = 1
		--check if we are within DBTD_RUNONETEST_EXT and if not then just exit
		IF OBJECT_ID('tempdb.dbo.#DBTD_RunningNowUnitTest') IS NULL 
		BEGIN
			RETURN 0; 
		END
	END CATCH 
	/*
	TODO: remove this code, it does not belong here
	--and now lets see if we had error to flash back so that unit test will fail because full text index cannot be dropped 
	--under transaction
	IF OBJECT_ID('tempdb.dbo.#DBTD_RunningNowUnitTest') IS NOT NULL 
		AND @v_HadError = 1
		AND OBJECT_ID('DBTD_FAILURE') IS NOT NULL 
		AND @@TRANCOUNT > 0
	BEGIN
		--TODO: failing in the tools might not be an option...
		--      review the code one more time and make sure that it does not cross single responcibility rules
		EXEC DBTD_FAILURE @v_Message
	END
	*/
END;
GO

--************************************************************************************************
CREATE PROCEDURE DBO.DBTD_DROP_FULLTEXT_CATALOG_IF_EXISTS
(
	@v_Catalog_Name	SYSNAME,	--Full text catalog name 
	@v_Database_Name SYSNAME,	--A database where this catalog has been created
	@v_Drop_All_Indexes BIT = 0 --default value is 0, when set to 1 this procedure will drop all full text indexes that exist in this catalog
)
WITH ENCRYPTION AS
BEGIN
	SET NOCOUNT ON;
	DECLARE @v_SQL NVARCHAR(MAX) = '',
			@v_Message VARCHAR(2000),
			@v_ParmDefinition NVARCHAR(MAX) = N' @v_InternalCatalogID INT OUTPUT, @v_Catalog_Name NVARCHAR(255)',
			@v_InternalCatalogID INT

	CREATE TABLE #DBTD_TablesWithFullTextIndexes(
		ObjectName NVARCHAR(128)
	)
	
	BEGIN TRY 

		SET @v_SQL = 
			'SELECT @v_InternalCatalogID = C.fulltext_catalog_id 
			FROM ' +@v_Database_Name+ '.SYS.FULLTEXT_CATALOGS AS C
			WHERE UPPER(C.NAME) = LTRIM(RTRIM(UPPER(@v_Catalog_Name)))'
		EXECUTE sp_executeSQL
				@v_Sql,
				@v_ParmDefinition,
				@v_InternalCatalogID = @v_InternalCatalogID OUTPUT,
				@v_Catalog_Name = @v_Catalog_Name

		IF (@v_InternalCatalogID IS NOT NULL)
		BEGIN
			IF @v_Drop_All_Indexes = 1
			BEGIN
				--get list of tables that have full text indexes assigned to the target catalog
				SET @v_SQL = 
					'INSERT INTO #DBTD_TablesWithFullTextIndexes
						(ObjectName)
						SELECT ''' + LTRIM(RTRIM(@v_Database_Name)) + '.['' + s.name + ''].['' + o.name + '']''
						FROM ' + LTRIM(RTRIM(@v_Database_Name)) + '.sys.fulltext_indexes AS i
							INNER JOIN ' + LTRIM(RTRIM(@v_Database_Name)) + '.sys.objects AS o
								ON i.object_id = o.object_id
							INNER JOIN DBTestDriven.sys.schemas AS S
								ON o.schema_id = s.schema_id;'
				EXEC DBTD_SP_EXECUTESQL @v_Database_Name, @v_SQL

				--remove related indexes
				SET @v_SQL = '' 
				SELECT @v_SQL = COALESCE(@v_SQL+ ' ', '') + 'EXEC ' + DB_NAME() + '.DBO.DBTD_DROP_FULLTEXT_INDEX_IF_EXISTS @v_Object_Name = ''' + ObjectName + ''';'
				FROM #DBTD_TablesWithFullTextIndexes
				EXEC DBTD_SP_EXECUTESQL @v_Database_Name, @v_SQL
			END 

			--and finally remove catalog
			SET @v_SQL = 'DROP FULLTEXT CATALOG ' + @v_Catalog_Name;
			EXEC DBO.DBTD_SP_EXECUTESQL	@v_Database_Name, @v_SQL
			SET @v_Message = 'Full Text Catalog [' + @v_Catalog_Name + '] has been dropped from ['+@v_Database_Name+'] database.';
			PRINT @v_Message;
			RETURN 1; 
		END
		ELSE BEGIN 
			SET @v_Message = 'Cannot find full text catalog [' + @v_Catalog_Name + '] from ['+@v_Database_Name+'] database.';
			PRINT @v_Message;
			RETURN 0; 
		END; 
	END TRY
	BEGIN CATCH
		SET @v_Message = 'Cannot drop [' + @v_Catalog_Name + '] full text catalog from ['+@v_Database_Name+'] database.' + ERROR_MESSAGE();
		PRINT @v_Message;
		RETURN 0; 
	END CATCH 
END;
GO

--************************************************************************************************
CREATE PROCEDURE DBO.DBTD_DROP_INDEX_IF_EXISTS
(
	@v_Index_Name	SYSNAME,	--Index Name
	@v_Object_Name	SYSNAME		--Object name (Table or View)
)
WITH ENCRYPTION AS
BEGIN
	SET NOCOUNT ON;
	DECLARE @v_SQL NVARCHAR(MAX) = '',
			@v_Message VARCHAR(2000),
			@v_Server NVARCHAR(2000),
			@v_Database NVARCHAR(2000),
			@v_Schema NVARCHAR(2000),
			@v_CorrectedName NVARCHAR(2000),
			@v_Object NVARCHAR(2000),
			@v_Object_ID INT = NULL,
			@v_ParmDefinition NVARCHAR(MAX) = N' @v_InternalIndexID INT OUTPUT, @v_Index_Name NVARCHAR(255), @v_Object_ID INT ',
			@v_InternalIndexID INT


	EXEC DBTD_SPLIT_FOUR_PART_OBJECT_NAME 
		@v_Object_Name, 
		@v_Server = @v_Server OUTPUT, @v_Database = @v_Database OUTPUT, @v_Schema = @v_Schema OUTPUT, 
		@v_Object = @v_Object OUTPUT, @v_CorrectedName = @v_CorrectedName OUTPUT,
		@v_CorrectTempTablesLocation = 1;

	BEGIN TRY 
		EXEC DBO.DBTD_GET_OBJECT_ID @v_CorrectedName, @v_Object_ID = @v_Object_ID OUTPUT;

		SET @v_SQL = ' SELECT @v_InternalIndexID = I.index_id FROM ' +@v_Database+ '.SYS.INDEXES AS I INNER JOIN '+@v_Database+'.dbo.SYSOBJECTS AS O ON I.object_ID = O.ID
				    WHERE UPPER(I.NAME) = LTRIM(RTRIM(UPPER(@v_Index_Name))) AND O.id = @v_Object_ID '
		EXECUTE sp_executeSQL
				@v_Sql,
				@v_ParmDefinition,
				@v_InternalIndexID = @v_InternalIndexID OUTPUT,
				@v_Index_Name = @v_Index_Name,
				@v_Object_ID = @v_Object_ID

		IF (@v_InternalIndexID IS NOT NULL)
		BEGIN
			SET @v_SQL = 'DROP INDEX ' + @v_Index_Name + ' ON ' + @v_Object_Name;
			EXECUTE sp_executesql @v_SQL;
			SET @v_Message = 'Index [' + @v_Index_Name + '] has been dropped for ['+@v_Object_Name+'] object.';
			PRINT @v_Message;
			RETURN 1; 
		END
		ELSE BEGIN 
			SET @v_Message = 'Cannot find index [' + @v_Index_Name + '] that belongs to ['+@v_Object_Name+'] object.';
			PRINT @v_Message;
			RETURN 0; 
		END; 
	END TRY
	BEGIN CATCH
		SET @v_Message = 'Cannot drop [' + @v_Index_Name + '] index that belongs to ['+@v_Object_Name+'] object. ' + ERROR_MESSAGE();
		PRINT @v_Message;
		RETURN 0; 
	END CATCH 
END;
GO

--************************************************************************************************
CREATE FUNCTION DBO.DBTD_SPLIT_STRING_TO_TABLE 
(
	@v_String NVARCHAR(MAX), 
	@v_Delimeter VARCHAR(250) = ','
)
RETURNS @v_Strings TABLE ( [String] NVARCHAR(MAX) )
WITH ENCRYPTION AS
BEGIN
	DECLARE @v_Index INT = -1 
 
	WHILE (LEN(@v_String) > 0) 
	BEGIN  
		SET @v_Index = CHARINDEX(@v_Delimeter , @v_String)  

		IF (@v_Index = 0) AND (LEN(@v_String) >= 0)  
		BEGIN   
			INSERT INTO @v_Strings ([String]) VALUES (@v_String)
			BREAK;  
		END  

		IF (@v_Index > 1)  
		BEGIN   
			INSERT INTO @v_Strings ([String]) VALUES (LEFT(@v_String, @v_Index - 1))   
		END  

		SET @v_String = RIGHT(@v_String, (LEN(@v_String) - @v_Index)) 
	END
	RETURN;
END
GO

--************************************************************************************************
CREATE PROCEDURE DBO.DBTD_CREATE_SCHEMA_UNIT_TEST
	@v_FullObjectName		SYSNAME,							--Full name should be provided int he MyDatabase.MySchema.MyObject format
	@v_UnitTestSQL			NVARCHAR(MAX) OUTPUT,
	@v_UnitTestName			NVARCHAR(128) OUTPUT,

	@v_UnitTestSuite		SYSNAME = 'DBSchemaTests',			--The name of the unit test suite 
	@v_FrameworkDatabase	SYSNAME = 'DBTestDriven',
	@v_GenerateAssertsThatCheckTableAndViewColumns BIT = 1,		--Set to 1 to check tables or views columns
	@v_GenerateAssertsThatCheckTableIndexes BIT = 1,
	@v_AutoGenMessage		VARCHAR(500) = NULL
WITH ENCRYPTION AS
BEGIN
	SET NOCOUNT ON
	DECLARE @v_sql_AutoGenMessage	NVARCHAR(250) = ISNULL('/*'+ ISNULL(@v_AutoGenMessage, CAST(NEWID() AS VARCHAR(50)))+'*/','') 
	DECLARE @v_sql_EndOfLine		NVARCHAR(10) = ' ' + CHAR(10), --CHAR(13) --CHAR(10) + CHAR(13)
			@v_sql_Tab				NVARCHAR(10) = CHAR(9)
	DECLARE	@v_sql_CommentSeparator NVARCHAR(500) = '/**************************************************************************************************/' + @v_sql_EndOfLine,
			@v_sql_UnitTestPREFIX	NVARCHAR(MAX) = 'UT_'+@v_UnitTestSuite+'_'	
	DECLARE @v_sql_USE_DATABASE		NVARCHAR(MAX) = @v_sql_CommentSeparator + 'USE ' + @v_FrameworkDatabase + @v_sql_EndOfLine + 'GO' + @v_sql_EndOfLine + @v_sql_EndOfLine
	DECLARE @v_sql_UnitTestCREATE	NVARCHAR(MAX) = ISNULL(@v_sql_AutoGenMessage + @v_sql_EndOfLine, '') + 'CREATE PROCEDURE '
	DECLARE @v_sql_UnitTestBEGIN	NVARCHAR(MAX) = @v_sql_EndOfLine + @v_sql_Tab + '(@v_Debug BIT = 0) ' + @v_sql_EndOfLine 
													+ 'AS ' + @v_sql_EndOfLine 
													+ 'BEGIN ' + @v_sql_EndOfLine 
													+ @v_sql_Tab + 'EXEC DBTD_UNIT_TEST '''+@v_UnitTestSuite+''';' + @v_sql_EndOfLine
													+ @v_sql_Tab + 'EXEC DBTD_USE_TRANSACTION ''Just in case''' + @v_sql_EndOfLine 
	DECLARE @v_sql_UnitTestEND		NVARCHAR(MAX) = @v_sql_EndOfLine + 'END' + @v_sql_EndOfLine +'GO'+@v_sql_EndOfLine 

	DECLARE @v_sql_FullObjectName	NVARCHAR(128),
			@v_ObjectID				BIGINT,
			@v_ObjectType			VARCHAR(128), 
			@v_SQL					NVARCHAR(MAX) = '',
			@v_AssertsSQL			NVARCHAR(MAX) = '',
			@v_DependentObjectsAssertsSQL NVARCHAR(MAX) = '',
			@v_Server				NVARCHAR(2000),
			@v_Database				NVARCHAR(2000),
			@v_Schema				NVARCHAR(2000),
			@v_CorrectedName		NVARCHAR(2000),
			@v_Object				NVARCHAR(2000),
			@v_ObjectTypeDesc		NVARCHAR(128),
			@v_Has_DependentObjects BIT = 0,
			@v_Has_AssertsForColumns BIT = 0,
			@v_Has_AssertsForIndexes BIT = 0,
			@v_TheUnitTestName		NVARCHAR(128) = ''

	CREATE TABLE #ObjectRelatedInformation(
		ObjectID			BIGINT,
		ObjectName			NVARCHAR(128),
		ObjectType			NVARCHAR(128),
		ObjectTypeDesc		NVARCHAR(128),
		IsNullable			BIT,
		IsUniqueConstraint	BIT,
		ObjectDefinition	NVARCHAR(MAX)
	)

	EXEC DBTD_SPLIT_FOUR_PART_OBJECT_NAME 
		@v_FullObjectName, 
		@v_Server = @v_Server OUTPUT, @v_Database = @v_Database OUTPUT, @v_Schema = @v_Schema OUTPUT, 
		@v_Object = @v_Object OUTPUT, @v_CorrectedName = @v_sql_FullObjectName OUTPUT,
		@v_CorrectTempTablesLocation = 1;

	SET @v_TheUnitTestName = '[' + @v_sql_UnitTestPREFIX + UPPER(REPLACE(REPLACE(@v_Schema, '[',''),']','')) + '_' + REPLACE(REPLACE(@v_Object, '[',''),']','') + ']'
	SET @v_ObjectID = OBJECT_ID(@v_sql_FullObjectName);
	SET @v_SQL = 'INSERT INTO #ObjectRelatedInformation(ObjectType,ObjectTypeDesc) SELECT [type], type_desc FROM sys.objects WHERE object_id = ' + CAST(@v_ObjectID AS VARCHAR(50))
	EXEC DBTD_SP_EXECUTESQL @v_Database, @v_SQL; 

	SELECT 
		TOP 1 
		@v_ObjectType = ObjectType,
		@v_ObjectTypeDesc = ObjectTypeDesc
	FROM #ObjectRelatedInformation

	--**** PART 1 - Get Generic assersions ************************************************************************************************************************************************************
	SET @v_AssertsSQL = 
			CASE 
				--TODO:
				--PC	CLR_STORED_PROCEDURE
				--IT	INTERNAL_TABLE
				--SQ	SERVICE_QUEUE
				--IF	SQL_INLINE_TABLE_VALUED_FUNCTION
				--TT	TYPE_TABLE
				WHEN @v_ObjectType = 'U' THEN @v_sql_Tab + 'EXEC DBTD_ASSERT_TABLE_EXISTS '''	+ @v_sql_FullObjectName + ''', ''Cannot find '+@v_ObjectTypeDesc+' object in the '+@v_Database+' database'';' + @v_sql_EndOfLine
				WHEN @v_ObjectType = 'V' THEN @v_sql_Tab + 'EXEC DBTD_ASSERT_VIEW_EXISTS '''	+ @v_sql_FullObjectName + ''', ''Cannot find '+@v_ObjectTypeDesc+' object in the '+@v_Database+' database'';' + @v_sql_EndOfLine
				WHEN @v_ObjectType = 'P' THEN @v_sql_Tab + 'EXEC DBTD_ASSERT_PROC_EXISTS '''	+ @v_sql_FullObjectName + ''', ''Cannot find '+@v_ObjectTypeDesc+' object in the '+@v_Database+' database'';' + @v_sql_EndOfLine
				WHEN @v_ObjectType IN ('TF','FN','FS', 'FT', 'AF', 'IF') THEN @v_sql_Tab + 'EXEC DBTD_ASSERT_FUNC_EXISTS  ''' + @v_sql_FullObjectName + ''', ''Cannot find '+@v_ObjectTypeDesc+' object in the '+@v_Database+' database'';' + @v_sql_EndOfLine
				WHEN @v_ObjectType = 'SN' THEN @v_sql_Tab + 'EXEC DBTD_ASSERT_SYNONYM_EXISTS  '''+ @v_sql_FullObjectName + ''', ''Cannot find '+@v_ObjectTypeDesc+' object in the '+@v_Database+' database'';' + @v_sql_EndOfLine
				ELSE @v_sql_Tab + 'EXEC DBTD_ASSERT_OBJECT_EXISTS '''			+ @v_sql_FullObjectName + ''', ''Cannot find '+@v_ObjectTypeDesc+' object in the '+@v_Database+' database'';' + @v_sql_EndOfLine
			END
		
	--**** PART 2 - Get clildren objects asserts for the given object ************************************************************************************************************************************************************
	TRUNCATE TABLE #ObjectRelatedInformation
	SET @v_SQL = 'INSERT INTO #ObjectRelatedInformation(ObjectID,ObjectName,ObjectType,ObjectTypeDesc) SELECT object_id, name, [type], type_desc FROM sys.objects WHERE parent_object_id = ' + CAST(@v_ObjectID AS VARCHAR(50))
	EXEC DBTD_SP_EXECUTESQL @v_Database, @v_SQL; 

	SET @v_SQL = 'UPDATE o SET o.ObjectDefinition = dc.[definition] FROM #ObjectRelatedInformation AS o INNER JOIN sys.default_constraints AS dc ON o.ObjectID = dc.object_id WHERE o.ObjectType = ''D'''
	EXEC DBTD_SP_EXECUTESQL @v_Database, @v_SQL; 

	SET @v_DependentObjectsAssertsSQL = ''
	SELECT 
		@v_DependentObjectsAssertsSQL = @v_DependentObjectsAssertsSQL
									+ COALESCE( 
											CASE
												--TODO: 
												--C 	CHECK_CONSTRAINT
												--D 	!!!! DEFAULT_CONSTRAINT - TODO: we have everything to get this simplemented
												WHEN ObjectType = 'D' THEN @v_sql_Tab + ' EXEC DBTD_ASSERT_DEFAULT_CONSTRAINT @v_DefaultConstrant=''' + ObjectName + ''', @v_TableName=''' + @v_sql_FullObjectName + ''', '
																			+ '@v_DefaultConstrantDefinition=''' + ObjectDefinition + ''','
																			+ '@v_UserMessage=''Cannot find ' + UPPER(ObjectTypeDesc) + ' in the ' + @v_Database + ' database''; ' + @v_sql_EndOfLine

												--F 	FOREIGN_KEY_CONSTRAINT
												--IT	INTERNAL_TABLE
												--PK	PRIMARY_KEY_CONSTRAINT
												--UQ	UNIQUE_CONSTRAINT
												WHEN ObjectType = 'TR' THEN @v_sql_Tab + ' EXEC DBTD_ASSERT_TRIGGER_EXISTS ''[' + @v_Database + '].[' + @v_Schema + '].['			
																			+ ObjectName + ']'', ''Cannot find ' 				  	
																			+ UPPER(ObjectTypeDesc) + ' in the '
																			+ @v_Database + ' database''; ' + @v_sql_EndOfLine
											END, '')
	FROM #ObjectRelatedInformation

	--Add asserts for depended objects
	IF @v_DependentObjectsAssertsSQL IS NOT NULL AND LTRIM(RTRIM(@v_DependentObjectsAssertsSQL)) != ''
	BEGIN
		SET @v_Has_DependentObjects = 1
		SET @v_AssertsSQL = @v_AssertsSQL + @v_sql_EndOfLine + @v_sql_Tab + '/*Check Related Objects*/' + @v_sql_EndOfLine + @v_DependentObjectsAssertsSQL 
		SET @v_DependentObjectsAssertsSQL = '' --Reset value
	END

	--**** PART 3 - For tables and view check their columns ************************************************************************************************************************************************************
	IF	@v_ObjectType IN ('U','V') AND @v_GenerateAssertsThatCheckTableAndViewColumns = 1
	BEGIN
		TRUNCATE TABLE #ObjectRelatedInformation
		SET @v_SQL = 
			'INSERT INTO #ObjectRelatedInformation(ObjectName,ObjectType,ObjectTypeDesc, IsNullable) 
			 SELECT c.name, t.name, '''', c.is_nullable
			 FROM sys.columns c
			 INNER JOIN sys.types t
				ON c.user_type_id = t.user_type_id
			 WHERE c.object_id = ' + CAST(@v_ObjectID AS VARCHAR(50))
		EXEC DBTD_SP_EXECUTESQL @v_Database, @v_SQL; 

		SELECT 
			@v_DependentObjectsAssertsSQL = @v_DependentObjectsAssertsSQL
				+ COALESCE( CASE
								WHEN @v_ObjectType = 'V'
									THEN @v_sql_Tab + 'EXEC DBTD_ASSERT_COLUMN_EXISTS '''	+ @v_sql_FullObjectName + ''', '''+ObjectName+''', ''Cannot find column ['+ObjectName+'] in the '+@v_sql_FullObjectName+''';' + @v_sql_EndOfLine
								WHEN @v_ObjectType = 'U'
									THEN @v_sql_Tab + 'EXEC DBTD_ASSERT_COLUMN_EXISTS '''	+ @v_sql_FullObjectName + ''', '''+ObjectName+''', ''Cannot find column ['+ObjectName+'] in the '+@v_sql_FullObjectName+''';' + @v_sql_EndOfLine 
											+ @v_sql_Tab + 'EXEC DBTD_ASSERT_COLUMN_TYPE '''	+ @v_sql_FullObjectName + ''', '''+ObjectName+''', ''' + ObjectType + ''', ''Column ['+ObjectName+'] does not have expected type of ['+ObjectType+'] in the '+@v_sql_FullObjectName+' table'';' + @v_sql_EndOfLine
											+ @v_sql_Tab + 'EXEC '
													+ CASE
														WHEN IsNullable = 0 THEN 'DBTD_ASSERT_COLUMN_IS_NOT_NULLABLE'
														ELSE 'DBTD_ASSERT_COLUMN_IS_NULLABLE'
													END
													+ ' ''' + @v_sql_FullObjectName + ''', '''+ObjectName+''', ''Column ['+ObjectName+'] NULLABILITY criteria does not match expectations in the '+@v_sql_FullObjectName+' table'';' + @v_sql_EndOfLine 
							END	
						, '')
		FROM #ObjectRelatedInformation
		--Add asserts for coluns
		IF	@v_DependentObjectsAssertsSQL IS NOT NULL AND LTRIM(RTRIM(@v_DependentObjectsAssertsSQL)) != '' AND @v_GenerateAssertsThatCheckTableAndViewColumns = 1
		BEGIN
			SET @v_AssertsSQL = @v_AssertsSQL + @v_sql_EndOfLine + @v_sql_Tab + '/*Check TABLE Columns*/' + @v_sql_EndOfLine + @v_DependentObjectsAssertsSQL 
			SET @v_DependentObjectsAssertsSQL = ''
			SET @v_Has_AssertsForColumns = 1
		END
	END

	--**** PART 4 - For tables check their indexes ************************************************************************************************************************************************************
	IF	@v_ObjectType IN ('U') AND @v_GenerateAssertsThatCheckTableIndexes = 1
	BEGIN
		TRUNCATE TABLE #ObjectRelatedInformation
		SET @v_SQL = 
			'INSERT INTO #ObjectRelatedInformation(ObjectName,ObjectType,ObjectTypeDesc, IsUniqueConstraint) 
			 SELECT i.name, CAST(i.type AS VARCHAR), '''', i.is_unique_constraint
			 FROM sys.indexes i
			 WHERE i.name IS NOT NULL
				AND i.object_id = ' + CAST(@v_ObjectID AS VARCHAR(50))
		EXEC DBTD_SP_EXECUTESQL @v_Database, @v_SQL; 

		SELECT 
			@v_DependentObjectsAssertsSQL = @v_DependentObjectsAssertsSQL
				+ COALESCE( 
							@v_sql_Tab + 'EXEC DBTD_ASSERT_INDEX_EXISTS '''+ObjectName+''', ''' + @v_sql_FullObjectName + ''', ''Cannot find index ['+ObjectName+'] for the '+@v_sql_FullObjectName+' table'';' + @v_sql_EndOfLine		
							+ CASE 
									WHEN ObjectType = '1' --IsClusteredAssertNeeded
										THEN @v_sql_Tab + 'EXEC DBTD_ASSERT_INDEX_CLUSTERED '''+ObjectName+''', ''' + @v_sql_FullObjectName + ''', ''Index ['+ObjectName+'] expected to be CLUSTERED for the '+@v_sql_FullObjectName+' table'';' + @v_sql_EndOfLine		
									ELSE '' 
								END 
							+ CASE 
									WHEN IsUniqueConstraint = 1 --IsUniqueAssertNeeded
										THEN @v_sql_Tab + 'EXEC DBTD_ASSERT_INDEX_UNIQUE '''+ObjectName+''', ''' + @v_sql_FullObjectName + ''', ''Index ['+ObjectName+'] expected to be UNIQUE for the '+@v_sql_FullObjectName+' table'';' + @v_sql_EndOfLine		
									ELSE ''
								END
						, '')
		FROM #ObjectRelatedInformation

		--Add asserts for indexes
		IF	@v_DependentObjectsAssertsSQL IS NOT NULL AND LTRIM(RTRIM(@v_DependentObjectsAssertsSQL)) != '' AND @v_GenerateAssertsThatCheckTableIndexes = 1
		BEGIN
			SET @v_AssertsSQL = @v_AssertsSQL + @v_sql_EndOfLine + @v_sql_Tab + '/*Check Table Indexes*/' + @v_sql_EndOfLine + @v_DependentObjectsAssertsSQL 
			SET @v_Has_AssertsForIndexes = 1
			SET @v_DependentObjectsAssertsSQL = ''
		END
	END

	--**** PART 5 - Assemble the Unit Test ************************************************************************************************************************************************************
	IF LTRIM(RTRIM(@v_AssertsSQL)) != '' AND @v_AssertsSQL IS NOT NULL
	BEGIN 
		SET @v_UnitTestSQL = 
				@v_sql_USE_DATABASE 
				+ @v_sql_CommentSeparator 
				+ 'EXEC DBTD_DROP_PROC_IF_EXISTS '''+@v_TheUnitTestName+''', '''';' + @v_sql_EndOfLine
				+ 'GO' + @v_sql_EndOfLine + @v_sql_EndOfLine
				+ @v_sql_UnitTestCREATE + @v_TheUnitTestName
				+ @v_sql_UnitTestBEGIN	
				+ @v_AssertsSQL
				+ @v_sql_UnitTestEND	
		SET @v_UnitTestName = @v_TheUnitTestName
	END 
	ELSE BEGIN
		SET @v_UnitTestSQL = NULL
		SET @v_UnitTestName = NULL
	END
END
GO

--************************************************************************************************
--Release							Product Version
--SQL Server 2014 RTM				12.0.2000.80
--
--SQL Server 2012 Service Pack 2	11.0.5058.0
--SQL Server 2012 Service Pack 1	11.00.3000.00
--SQL Server 2012 RTM				11.00.2100.60
--
--SQL Server 2008 R2 Service Pack 3	10.50.6000.34
--SQL Server 2008 R2 Service Pack 2	10.50.4000.0
--SQL Server 2008 R2 Service Pack 1	10.50.2500.0
--SQL Server 2008 R2 RTM			10.50.1600.1
--
--SQL Server 2008 Service Pack 4	10.00.6000.29
--SQL Server 2008 Service Pack 3	10.00.5500.00
--SQL Server 2008 Service Pack 2	10.00.4000.00
--SQL Server 2008 Service Pack 1	10.00.2531.00
--SQL Server 2008 RTM				10.00.1600.22
CREATE FUNCTION DBTD_fnSQLServerMajorProductVersion()
RETURNS SMALLINT
WITH ENCRYPTION AS
BEGIN
	DECLARE @v_SQLServerVersion SMALLINT = CAST( LEFT( CAST( SERVERPROPERTY('ProductVersion') AS VARCHAR(50)), 2) AS SMALLINT)
	RETURN @v_SQLServerVersion;
END
GO
