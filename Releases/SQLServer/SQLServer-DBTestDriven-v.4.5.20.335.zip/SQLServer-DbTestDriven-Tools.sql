﻿/*
--************************************************************************************************
-- VERSION:	   DBTestDriven - SQL Server - Version 4.5.20.335
-- COPYRIGHT:  (c) 2011-2014 Job Continent, DBTestDriven Project by Alex Podlesny
-- http://www.dbtestdriven.com
--
-- NOTE: useful tools
--
--************************************************************************************************
*/

IF EXISTS (SELECT 1 FROM DBO.SYSOBJECTS WHERE ID = OBJECT_ID(N'[DBO].[DBTD_DROP_TABLE_IF_EXISTS]') AND OBJECTPROPERTY(ID, N'ISPROCEDURE') = 1)
	DROP PROCEDURE [DBO].[DBTD_DROP_TABLE_IF_EXISTS]
GO
IF EXISTS (SELECT 1 FROM DBO.SYSOBJECTS WHERE ID = OBJECT_ID(N'[DBO].[DBTD_DROP_VIEW_IF_EXISTS]') AND OBJECTPROPERTY(ID, N'ISPROCEDURE') = 1)
	DROP PROCEDURE [DBO].[DBTD_DROP_VIEW_IF_EXISTS]
GO
IF EXISTS (SELECT 1 FROM DBO.SYSOBJECTS WHERE ID = OBJECT_ID(N'[DBO].[DBTD_DROP_PROC_IF_EXISTS]') AND OBJECTPROPERTY(ID, N'ISPROCEDURE') = 1)
	DROP PROCEDURE [DBO].[DBTD_DROP_PROC_IF_EXISTS]
GO
IF EXISTS (SELECT 1 FROM DBO.SYSOBJECTS WHERE ID = OBJECT_ID(N'[DBO].[DBTD_DROP_SEQUENCE_IF_EXISTS]') AND OBJECTPROPERTY(ID, N'ISPROCEDURE') = 1)
	DROP PROCEDURE [DBO].[DBTD_DROP_SEQUENCE_IF_EXISTS]
GO
IF EXISTS (SELECT 1 FROM DBO.SYSOBJECTS WHERE ID = OBJECT_ID(N'[DBO].[DBTD_DROP_TRIGGER_IF_EXISTS]') AND OBJECTPROPERTY(ID, N'ISPROCEDURE') = 1)
	DROP PROCEDURE [DBO].[DBTD_DROP_TRIGGER_IF_EXISTS]
GO
IF EXISTS (SELECT 1 FROM DBO.SYSOBJECTS WHERE ID = OBJECT_ID(N'[DBO].[DBTD_DROP_INDEX_IF_EXISTS]') AND OBJECTPROPERTY(ID, N'ISPROCEDURE') = 1)
	DROP PROCEDURE [DBO].[DBTD_DROP_INDEX_IF_EXISTS]
GO
IF EXISTS (SELECT 1 FROM DBO.SYSOBJECTS WHERE ID = OBJECT_ID(N'[DBO].[DBTD_DROP_FUNC_IF_EXISTS]') AND OBJECTPROPERTY(ID, N'ISPROCEDURE') = 1)
	DROP PROCEDURE [DBO].[DBTD_DROP_FUNC_IF_EXISTS]
GO
IF EXISTS (SELECT 1 FROM DBO.SYSOBJECTS WHERE ID = OBJECT_ID(N'[DBO].[DBTD_DROP_SCHEMA_IF_EXISTS]') AND OBJECTPROPERTY(ID, N'ISPROCEDURE') = 1)
	DROP PROCEDURE [DBO].[DBTD_DROP_SCHEMA_IF_EXISTS]
GO
IF EXISTS (SELECT 1 FROM DBO.SYSOBJECTS WHERE ID = OBJECT_ID(N'[DBO].[DBTD_DROP_SYNONYM_IF_EXISTS]') AND OBJECTPROPERTY(ID, N'ISPROCEDURE') = 1)
	DROP PROCEDURE [DBO].[DBTD_DROP_SYNONYM_IF_EXISTS]
GO
IF EXISTS (SELECT 1 FROM DBO.SYSOBJECTS WHERE ID = OBJECT_ID(N'[DBO].[DBTD_SP_EXECUTESQL]') AND OBJECTPROPERTY(ID, N'ISPROCEDURE') = 1)
	DROP PROCEDURE [DBO].[DBTD_SP_EXECUTESQL]
GO
IF EXISTS (SELECT 1 FROM DBO.SYSOBJECTS WHERE ID = OBJECT_ID(N'[DBO].[DBTD_SPLIT_FOUR_PART_OBJECT_NAME]') AND OBJECTPROPERTY(ID, N'ISPROCEDURE') = 1)
	DROP PROCEDURE [DBO].[DBTD_SPLIT_FOUR_PART_OBJECT_NAME]
GO
IF EXISTS (SELECT 1 FROM DBO.SYSOBJECTS WHERE ID = OBJECT_ID(N'DBO.DBTD_GET_OBJECT_ID') AND OBJECTPROPERTY(ID, N'ISPROCEDURE') = 1)
	DROP PROCEDURE DBO.DBTD_GET_OBJECT_ID
GO
IF EXISTS (SELECT 1 FROM DBO.SYSOBJECTS WHERE ID = OBJECT_ID(N'[DBO].[DBTD_PREPARE_FOUR_PART_OBJECT_NAME]') AND OBJECTPROPERTY(ID, N'ISPROCEDURE') = 1)
	DROP PROCEDURE [DBO].[DBTD_PREPARE_FOUR_PART_OBJECT_NAME]
GO
IF EXISTS (SELECT 1 FROM DBO.SYSOBJECTS WHERE ID = OBJECT_ID(N'[DBO].[DBTD_SPLIT_STRING_TO_TABLE]'))
	DROP FUNCTION [DBO].[DBTD_SPLIT_STRING_TO_TABLE]
GO


--************************************************************************************************
CREATE PROCEDURE DBO.DBTD_SP_EXECUTESQL
(
	@v_TargetDatabase SYSNAME,	--Target database
	@v_SQLCode NVARCHAR(MAX)	--SQL Code that will be executed in the target database
)
WITH ENCRYPTION AS
BEGIN
	SET NOCOUNT ON;
	DECLARE @v_InterDBCode NVARCHAR(MAX)
	CREATE TABLE #DBTD_INTER_DB_SQL(
		SQLCode NVARCHAR(MAX)
	);
	INSERT INTO #DBTD_INTER_DB_SQL (SQLCode) VALUES (@v_SQLCode);
	IF OBJECT_ID('dbo.DBTD_TBL_LOG') IS NOT NULL
	BEGIN
		INSERT INTO dbo.DBTD_TBL_LOG 
			(EventType, EventSource, EventTime, [Message]) 
			VALUES ('INFO', 'DBTD_SP_EXECUTESQL', GETDATE(), @v_SQLCode);
	END

	SET @v_InterDBCode = 
		'
		DECLARE @v NVARCHAR(MAX); 
		SELECT @v = SQLCode FROM #DBTD_INTER_DB_SQL; 
		EXECUTE '+@v_TargetDatabase+'.dbo.sp_executesql @v;
		';

	EXECUTE dbo.sp_executesql @v_InterDBCode;

	DROP TABLE #DBTD_INTER_DB_SQL --explicity drop the table
END;
GO

--************************************************************************************************
--Function separates a v_Name string lile 'server.database.schema.object' into four distinct 
--object name parts: server, database, schema and object.
--NOTE: if @v_CorrectTempTablesLocation set to 1, procedure will:
--             - correct temp table location to be server.TEMPDB.dbo.#temptable, DEFAULT value is 1 
--             - uses DBO as default schema 
--INTERNAL: Do not use this function in your unit tests, procedure can be removed,
--          signature or procedure name can be changed at any release
CREATE PROCEDURE DBO.DBTD_SPLIT_FOUR_PART_OBJECT_NAME
(
	@v_Name		SYSNAME,				-- Fully qualified SQL name
	@v_Server	NVARCHAR(128) OUTPUT,
	@v_Database NVARCHAR(128) OUTPUT,
	@v_Schema	NVARCHAR(128) OUTPUT,
	@v_Object	NVARCHAR(128) OUTPUT,
	@v_CorrectedName SYSNAME OUTPUT,	
	@v_CorrectTempTablesLocation BIT = 1
)
WITH ENCRYPTION 
AS
BEGIN
	SET NOCOUNT ON;
	DECLARE @v_TmpStr VARCHAR(2000),
			@v_Separator CHAR(1) = '.',
			@v_NumberOfParts INT,
			@v_PartsCount INT = 0,
			@v_SeparatorIndex INT,
			@v_CurrentPart VARCHAR(255) = '',
			@v_Part1 VARCHAR(255) = '',
			@v_Part2 VARCHAR(255) = '',
			@v_Part3 VARCHAR(255) = '',
			@v_Part4 VARCHAR(255) = '',
			@v_TempObjectFlag BIT 

	SELECT @v_Server = '', @v_Database = '', @v_Schema = '', @v_Object = '';
	SET @v_TmpStr = @v_Name;
	SET @v_NumberOfParts = (LEN(@v_TmpStr) - LEN(REPLACE(@v_TmpStr, @v_Separator, ''))) + 1
	SET @v_TmpStr = LTRIM(RTRIM(@v_Name));

	SET @v_CorrectedName = @v_TmpStr -- at first use the same name for corrected name

	IF @v_NumberOfParts = 1 
	BEGIN 
		SET @v_Part1 = LTRIM(RTRIM(@v_TmpStr))
	END 
	ELSE BEGIN 
		WHILE 
			(@v_PartsCount < @v_NumberOfParts)				--no more string
			AND (CHARINDEX(@v_Separator, @v_TmpStr)) != 0	--no more parts
		BEGIN
			SET @v_PartsCount = @v_PartsCount + 1
			
			SET @v_SeparatorIndex = CHARINDEX(@v_Separator, @v_TmpStr);
			SET @v_CurrentPart = SUBSTRING (@v_TmpStr , 1, @v_SeparatorIndex -1 )
			SET @v_TmpStr = RIGHT(@v_TmpStr, LEN(@v_TmpStr)-@v_SeparatorIndex);
			
			IF @v_PartsCount = 1 BEGIN SET @v_Part1 = LTRIM(RTRIM(@v_CurrentPart)); SET @v_Part2 = LTRIM(RTRIM(@v_TmpStr)); END
			IF @v_PartsCount = 2 BEGIN SET @v_Part2 = LTRIM(RTRIM(@v_CurrentPart)); SET @v_Part3 = LTRIM(RTRIM(@v_TmpStr)); END
			IF @v_PartsCount = 3 BEGIN SET @v_Part3 = LTRIM(RTRIM(@v_CurrentPart)); SET @v_Part4 = LTRIM(RTRIM(@v_TmpStr)); END
		END
	END
	
	--select @v_Part1, @v_Part2, @v_Part3, @v_Part4	
	IF @v_NumberOfParts = 4 SELECT @v_Server = @v_Part1, @v_Database = @v_Part2, @v_Schema = @v_Part3, @v_Object = @v_Part4;
	IF @v_NumberOfParts = 3 SELECT @v_Database = @v_Part1, @v_Schema = @v_Part2, @v_Object = @v_Part3;
	IF @v_NumberOfParts = 2 SELECT @v_Schema = @v_Part1, @v_Object = @v_Part2;
	IF @v_NumberOfParts = 1 SELECT @v_Object = @v_Part1;

	--cleanup brackets
	SET @v_Server = REPLACE(REPLACE(@v_Server, ']', ''), '[', ''); 
	SET @v_Database = REPLACE(REPLACE(@v_Database, ']', ''), '[', ''); 
	SET @v_Schema = REPLACE(REPLACE(@v_Schema, ']', ''), '[', ''); 
	SET @v_Object = REPLACE(REPLACE(@v_Object, ']', ''), '[', ''); 

	IF LTRIM(RTRIM(@v_Schema)) = '' SET @v_Schema = 'dbo'; --default schema is DBO

	--correct temp DB settings 
	SET @v_TempObjectFlag = CASE WHEN charindex('#',@v_Object) != 0 THEN 1 ELSE 0 END;
	IF @v_CorrectTempTablesLocation = 1
		AND @v_TempObjectFlag = 1
	BEGIN 
		SET @v_Database = 'TEMPDB';
		SET @v_Schema = 'dbo';
	END 

	SET @v_Server = CASE WHEN @v_Server IS NULL OR @v_Server = '' THEN '' ELSE '['+@v_Server+']' END; 
	SET @v_Database = CASE WHEN @v_Database IS NULL OR @v_Database = '' THEN '' ELSE '['+@v_Database+']' END;
	SET @v_Schema = CASE WHEN @v_Schema IS NULL OR @v_Schema = '' THEN '' ELSE '['+@v_Schema+']' END;
	SET @v_Object = CASE WHEN @v_Object IS NULL OR @v_Object = '' THEN '' ELSE '['+@v_Object+']' END;

		-- reconstruct the name 
	SET @v_CorrectedName = 
			CASE WHEN @v_Server != '' THEN @v_Server + '.' ELSE '' END 
			+ CASE 
				WHEN @v_Database != '' THEN @v_Database + '.' 
				WHEN @v_Server != '' THEN '.'
				ELSE '' 
			END 
			+ CASE WHEN @v_Schema != '' THEN @v_Schema + '.' ELSE '' END --we will always have schema
			+ @v_Object;

END
GO

--************************************************************************************************
--Function prepares four part object name 'server.database.schema.object' base on the provided values
--INTERNAL: Do not use this function in your unit tests, procedure can be removed,
--          signature or procedure name can be changed at any release
CREATE PROCEDURE DBO.DBTD_PREPARE_FOUR_PART_OBJECT_NAME
(
	@v_Server	NVARCHAR(128),
	@v_Database NVARCHAR(128),
	@v_Schema	NVARCHAR(128),
	@v_Object	NVARCHAR(128),
	@v_FullName		SYSNAME OUTPUT,					-- Fully qualified SQL name
	@v_CorrectedName SYSNAME OUTPUT,	
	@v_CorrectTempTablesLocation BIT = 1
)
WITH ENCRYPTION 
AS
BEGIN
	SET NOCOUNT ON;
	DECLARE @v_TempObjectFlag BIT 

	--Cleanup brackets
	SET @v_Server = LTRIM(RTRIM(REPLACE(REPLACE(ISNULL(@v_Server,''), ']', ''), '[', ''))); 
	SET @v_Database = LTRIM(RTRIM(REPLACE(REPLACE(ISNULL(@v_Database,''), ']', ''), '[', ''))); 
	SET @v_Schema = LTRIM(RTRIM(REPLACE(REPLACE(ISNULL(@v_Schema,''), ']', ''), '[', ''))); 
	SET @v_Object = LTRIM(RTRIM(REPLACE(REPLACE(ISNULL(@v_Object,''), ']', ''), '[', ''))); 

	IF @v_Schema = '' SET @v_Schema = 'dbo'; --default schema is DBO

	--Correct temp DB settings 
	SET @v_TempObjectFlag = CASE WHEN charindex('#',@v_Object) != 0 THEN 1 ELSE 0 END;
	IF @v_CorrectTempTablesLocation = 1	AND @v_TempObjectFlag = 1
	BEGIN 
		SET @v_Database = 'TEMPDB';
		SET @v_Schema = 'dbo';
	END 

	SET @v_Server	= CASE WHEN @v_Server IS NULL OR @v_Server = '' THEN '' ELSE '['+@v_Server+']' END; 
	SET @v_Database = CASE WHEN @v_Database IS NULL OR @v_Database = '' THEN '' ELSE '['+@v_Database+']' END;
	SET @v_Schema	= CASE WHEN @v_Schema IS NULL OR @v_Schema = '' THEN '' ELSE '['+@v_Schema+']' END;
	SET @v_Object	= CASE WHEN @v_Object IS NULL OR @v_Object = '' THEN '' ELSE '['+@v_Object+']' END;

	--Reconstruct the name 
	SET @v_CorrectedName = 
			CASE WHEN @v_Server != '' THEN @v_Server + '.' ELSE '' END 
			+ CASE 
				WHEN @v_Database != '' THEN @v_Database + '.' 
				WHEN @v_Server != '' THEN '.'
				ELSE '' 
			END 
			+ CASE WHEN @v_Schema != '' THEN @v_Schema + '.' ELSE '' END --we will always have schema
			+ @v_Object;
	SET @v_FullName = REPLACE(REPLACE(@v_CorrectedName, ']', ''), '[', '');
END
GO

--************************************************************************************************
CREATE PROCEDURE DBO.DBTD_GET_OBJECT_ID
(
	@v_Object_Name SYSNAME,
	@v_Object_ID BIGINT OUTPUT
)
WITH ENCRYPTION AS 
BEGIN
	SET NOCOUNT ON;
	DECLARE @v_SQL NVARCHAR(MAX) = '',
			@v_Server VARCHAR(2000),
			@v_Database VARCHAR(2000),
			@v_Schema VARCHAR(2000),
			@v_CorrectedName VARCHAR(2000),
			@v_Object VARCHAR(2000),
			@v_ParmDefinition NVARCHAR(MAX) = N'@v_InternaltObjectID INT OUTPUT'

	EXEC DBTD_SPLIT_FOUR_PART_OBJECT_NAME 
		@v_Object_Name, 
		@v_Server = @v_Server OUTPUT, @v_Database = @v_Database OUTPUT, @v_Schema = @v_Schema OUTPUT, 
		@v_Object = @v_Object OUTPUT, @v_CorrectedName = @v_CorrectedName OUTPUT,
		@v_CorrectTempTablesLocation = 1;
	SET @v_Sql = 'SELECT @v_InternaltObjectID = OBJECT_ID ('''+@v_CorrectedName+'''); ';
	EXEC sp_executeSQL
		@v_Sql,
		@v_ParmDefinition,
		@v_InternaltObjectID = @v_Object_ID OUTPUT
END
GO

--************************************************************************************************
--NOTE: Object is supported in SQL Server 2012 
--      earlier version do not support SEQUENCE objects
CREATE PROCEDURE DBO.DBTD_DROP_SEQUENCE_IF_EXISTS
(
	@v_Object_Name	SYSNAME	--Sequence Name
)
WITH ENCRYPTION AS
BEGIN
	SET NOCOUNT ON;

	DECLARE @v_SQL NVARCHAR(255);
	DECLARE @v_Message VARCHAR(2000);

	SET @v_Message = 'Cannot drop "' + @v_Object_Name + '" sequence. Functionality is not supported for compatibility with earlier versions of SQL Server.';
	PRINT @v_Message;
	RETURN 0; 
	SELECT @@VERSION
	--BEGIN TRY 
	--	IF EXISTS (	SELECT 1 FROM SYS.SEQUENCES  
	--				WHERE name = OBJECT_ID(v_Object_Name))
	--	BEGIN
	--		SET @v_SQL = 'DROP SEQUENCE ' + v_Object_Name;
	--		EXECUTE sp_executesql @v_SQL;
	--		SET @v_Message = 'Sequence "' + @v_Object_Name + '" has been dropped.';
	--		PRINT @v_Message;
	--		RETURN 1; 
	--	END
	--	ELSE BEGIN 
	--		SET @v_Message = 'Cannot find sequence "' + v_Object_Name + '" ';
	--		PRINT @v_Message;
	--		RETURN 0; 
	--	END; 
	--END TRY
	--BEGIN CATCH
	--	SET @v_Message = 'Cannot drop "' + v_Object_Name + '" sequence ';
	--	PRINT @v_Message;
	--	RETURN 0; 
	--END CATCH 
END;
GO

--************************************************************************************************
CREATE PROCEDURE DBO.DBTD_DROP_TABLE_IF_EXISTS
(
	@v_Object_Name SYSNAME	--Table name 
)
WITH ENCRYPTION AS
BEGIN
	SET NOCOUNT ON;

	DECLARE @v_SQL NVARCHAR(MAX) = '',
			@v_Message VARCHAR(2000),
			@v_Server VARCHAR(2000),
			@v_Database VARCHAR(2000),
			@v_Schema VARCHAR(2000),
			@v_CorrectedName VARCHAR(2000),
			@v_Object VARCHAR(2000),
			@v_InternaltObjectID INT = NULL

	EXEC DBTD_SPLIT_FOUR_PART_OBJECT_NAME 
		@v_Object_Name, 
		@v_Server = @v_Server OUTPUT, @v_Database = @v_Database OUTPUT, @v_Schema = @v_Schema OUTPUT, 
		@v_Object = @v_Object OUTPUT, @v_CorrectedName = @v_CorrectedName OUTPUT,
		@v_CorrectTempTablesLocation = 1;

	BEGIN TRY 
		EXEC DBO.DBTD_GET_OBJECT_ID @v_CorrectedName, @v_Object_ID = @v_InternaltObjectID OUTPUT;

		IF (@v_InternaltObjectID IS NOT NULL)
		BEGIN
			SET @v_SQL = 'DROP TABLE ' + @v_Object_Name;

			EXEC DBO.DBTD_SP_EXECUTESQL	@v_Database, @v_SQL

			SET @v_Message = 'Table "' + @v_CorrectedName + '" has been dropped from ' + @v_Database + ' database.';
			PRINT @v_Message;
			RETURN 1; 
		END
		ELSE BEGIN 
			SET @v_Message = 'Cannot find table "' + @v_CorrectedName + '" ';
			PRINT @v_Message;
			RETURN 0; 
		END; 
	END TRY
	BEGIN CATCH
		SET @v_Message = 'Cannot drop "' + @v_CorrectedName + '" table. ' + ERROR_MESSAGE();
		PRINT @v_Message;
		RETURN 0; 
	END CATCH 
END;
GO

--************************************************************************************************
CREATE PROCEDURE DBO.DBTD_DROP_PROC_IF_EXISTS
(
	@v_Object_Name	SYSNAME,			-- Procedure name
	@v_Signature	VARCHAR(128) = ''	-- Reserved
)
WITH ENCRYPTION AS
BEGIN
	SET NOCOUNT ON;

	DECLARE @v_SQL NVARCHAR(MAX) = '',
			@v_Message VARCHAR(2000),
			@v_Server VARCHAR(2000),
			@v_Database VARCHAR(2000),
			@v_Schema VARCHAR(2000),
			@v_CorrectedName VARCHAR(2000),
			@v_Object VARCHAR(2000),
			@v_InternaltObjectID INT = NULL

	EXEC dbo.DBTD_SPLIT_FOUR_PART_OBJECT_NAME 
		@v_Object_Name, 
		@v_Server = @v_Server OUTPUT, @v_Database = @v_Database OUTPUT, @v_Schema = @v_Schema OUTPUT, 
		@v_Object = @v_Object OUTPUT, @v_CorrectedName = @v_CorrectedName OUTPUT,
		@v_CorrectTempTablesLocation = 1;
	 
	BEGIN TRY 
		EXEC DBO.DBTD_GET_OBJECT_ID @v_CorrectedName, @v_Object_ID = @v_InternaltObjectID OUTPUT;

		IF (@v_InternaltObjectID IS NOT NULL)
		BEGIN
			SET @v_SQL = 'DROP PROCEDURE ' + ISNULL( @v_Schema + '.', '') + @v_Object;

			EXEC DBO.DBTD_SP_EXECUTESQL	@v_Database, @v_SQL

			SET @v_Message = 'Stored Procedure "' + @v_CorrectedName + '" has been dropped from ' + @v_Database + ' database.';
			PRINT @v_Message;
			RETURN 1; 
		END
		ELSE BEGIN 
			SET @v_Message = 'Cannot find "' + @v_Object_Name + '" procedure';
			PRINT @v_Message;
			RETURN 0; 
		END; 
	END TRY
	BEGIN CATCH
		SET @v_Message = 'Cannot drop "' + @v_Object_Name + '" procedure. ' + ERROR_MESSAGE();
		PRINT @v_Message;
		RETURN 0; 
	END CATCH 
END;
GO

--************************************************************************************************
CREATE PROCEDURE DBO.DBTD_DROP_VIEW_IF_EXISTS
(
	@v_Object_Name	SYSNAME	--View Name
)
WITH ENCRYPTION AS
BEGIN
	SET NOCOUNT ON;

	DECLARE @v_SQL NVARCHAR(MAX) = '',
			@v_Message VARCHAR(2000),
			@v_Server VARCHAR(2000),
			@v_Database VARCHAR(2000),
			@v_Schema VARCHAR(2000),
			@v_CorrectedName VARCHAR(2000),
			@v_Object VARCHAR(2000),
			@v_InternaltObjectID INT = NULL
			
	EXEC DBTD_SPLIT_FOUR_PART_OBJECT_NAME 
		@v_Object_Name, 
		@v_Server = @v_Server OUTPUT, @v_Database = @v_Database OUTPUT, @v_Schema = @v_Schema OUTPUT, 
		@v_Object = @v_Object OUTPUT, @v_CorrectedName = @v_CorrectedName OUTPUT,
		@v_CorrectTempTablesLocation = 1;

	BEGIN TRY 
		EXEC DBO.DBTD_GET_OBJECT_ID @v_CorrectedName, @v_Object_ID = @v_InternaltObjectID OUTPUT;
			
		IF (@v_InternaltObjectID IS NOT NULL)
		BEGIN
			SET @v_SQL = 'DROP VIEW ' + ISNULL( @v_Schema + '.', '') + @v_Object;

			EXEC DBO.DBTD_SP_EXECUTESQL	@v_Database, @v_SQL

			SET @v_Message = 'View "' + @v_Object_Name + '" has been dropped from ' + @v_Database + 'database.';
			PRINT @v_Message;
			RETURN 1; 
		END
		ELSE BEGIN 
			SET @v_Message = 'Cannot find view "' + @v_Object_Name + '" ';
			PRINT @v_Message;
			RETURN 0; 
		END; 
	END TRY
	BEGIN CATCH
		SET @v_Message = 'Cannot drop "' + @v_Object_Name + '" view. ' + ERROR_MESSAGE();
		PRINT @v_Message;
		RETURN 0; 
	END CATCH 
END;
GO

--************************************************************************************************
CREATE PROCEDURE DBO.DBTD_DROP_FUNC_IF_EXISTS
(
	@v_Object_Name	SYSNAME,			-- Procedure name
	@v_Signature	VARCHAR(128) = ''	-- Reserved
)
WITH ENCRYPTION AS
BEGIN
	SET NOCOUNT ON;

	DECLARE @v_SQL NVARCHAR(MAX) = '',
			@v_Message VARCHAR(2000),
			@v_Server VARCHAR(2000),
			@v_Database VARCHAR(2000),
			@v_Schema VARCHAR(2000),
			@v_CorrectedName VARCHAR(2000),
			@v_Object VARCHAR(2000),
			@v_InternaltObjectID INT = NULL

	EXEC DBTD_SPLIT_FOUR_PART_OBJECT_NAME 
		@v_Object_Name, 
		@v_Server = @v_Server OUTPUT, @v_Database = @v_Database OUTPUT, @v_Schema = @v_Schema OUTPUT, 
		@v_Object = @v_Object OUTPUT, @v_CorrectedName = @v_CorrectedName OUTPUT,
		@v_CorrectTempTablesLocation = 1;

	BEGIN TRY 
		EXEC DBO.DBTD_GET_OBJECT_ID @v_CorrectedName, @v_Object_ID = @v_InternaltObjectID OUTPUT;

		IF (@v_InternaltObjectID IS NOT NULL)
		BEGIN
			SET @v_SQL = 'DROP FUNCTION ' + ISNULL( @v_Schema + '.', '') + @v_Object;

			EXEC DBO.DBTD_SP_EXECUTESQL	@v_Database, @v_SQL

			SET @v_Message = 'Function "' + @v_Object_Name + '" has been dropped from ' + @v_Database + ' database.';
			PRINT @v_Message;
			RETURN 1; 
		END
		ELSE BEGIN 
			SET @v_Message = 'Cannot find "' + @v_Object_Name + '" function';
			PRINT @v_Message;
			RETURN 0; 
		END; 
	END TRY
	BEGIN CATCH
		SET @v_Message = 'Cannot drop "' + @v_Object_Name + '" function. ' + ERROR_MESSAGE();
		PRINT @v_Message;
		RETURN 0; 
	END CATCH 
END;
GO

--************************************************************************************************
CREATE PROCEDURE DBO.DBTD_DROP_SCHEMA_IF_EXISTS
(
	@v_Object_Name	SYSNAME,
	@v_Database_Name NVARCHAR(128) = NULL --When null is specified then schema will be removed in the current context
)
WITH ENCRYPTION AS
BEGIN
	SET NOCOUNT ON;

	DECLARE @v_SQL NVARCHAR(255),
			@v_Message VARCHAR(2000),
			@v_InternalSchemaID INT = NULL,
			@v_ParmDefinition NVARCHAR(MAX) = N' @v_InternalSchemaID INT OUTPUT, @v_Object_Name NVARCHAR(255) '
	
	IF (LTRIM(RTRIM(@v_Database_Name)) = '') SET @v_Database_Name = DB_NAME();
	IF (@v_Database_Name IS NULL) SET @v_Database_Name = DB_NAME();

	BEGIN TRY 
		SET @v_SQL = ' SELECT @v_InternalSchemaID = schema_id FROM ' + @v_Database_Name + '.SYS.SCHEMAS WHERE NAME = UPPER(@v_Object_Name) '
		EXECUTE sp_executeSQL
				@v_Sql,
				@v_ParmDefinition,
				@v_InternalSchemaID = @v_InternalSchemaID OUTPUT,
				@v_Object_Name = @v_Object_Name

		IF (@v_InternalSchemaID IS NOT NULL)
		BEGIN
			SET @v_SQL = 'DROP SCHEMA ' + @v_Object_Name;

			EXEC DBO.DBTD_SP_EXECUTESQL	@v_Database_Name, @v_SQL

			SET @v_Message = 'Schema "' + @v_Object_Name + '" has been dropped from [' + @v_Database_Name + '] database.';
			PRINT @v_Message;
			RETURN 1; 
		END
		ELSE BEGIN 
			SET @v_Message = 'Cannot find "' + @v_Object_Name + '" schema in the [' + @v_Database_Name + '] database.';
			PRINT @v_Message;
			RETURN 0; 
		END; 
	END TRY
	BEGIN CATCH
		SET @v_Message = 'ERROR!!! Cannot drop "' + @v_Object_Name + '" schema. ' + ERROR_MESSAGE();
		PRINT @v_Message;
		RETURN 0; 
	END CATCH 
END;
GO

--************************************************************************************************
CREATE PROCEDURE DBO.DBTD_DROP_SYNONYM_IF_EXISTS
(
	@v_Object_Name	SYSNAME
)
WITH ENCRYPTION AS
BEGIN
	SET NOCOUNT ON;

	DECLARE @v_SQL NVARCHAR(MAX) = '',
			@v_Message VARCHAR(2000),
			@v_Server VARCHAR(2000),
			@v_Database VARCHAR(2000),
			@v_Schema VARCHAR(2000),
			@v_CorrectedName VARCHAR(2000),
			@v_Object VARCHAR(2000),
			@v_InternaltObjectID INT = NULL

	EXEC DBTD_SPLIT_FOUR_PART_OBJECT_NAME 
		@v_Object_Name, 
		@v_Server = @v_Server OUTPUT, @v_Database = @v_Database OUTPUT, @v_Schema = @v_Schema OUTPUT, 
		@v_Object = @v_Object OUTPUT, @v_CorrectedName = @v_CorrectedName OUTPUT,
		@v_CorrectTempTablesLocation = 1;

	BEGIN TRY 
		EXEC DBO.DBTD_GET_OBJECT_ID @v_CorrectedName, @v_Object_ID = @v_InternaltObjectID OUTPUT;

		IF (@v_InternaltObjectID IS NOT NULL)
		BEGIN
			SET @v_SQL = 'DROP SYNONYM ' + ISNULL( @v_Schema + '.', '') + @v_Object;

			EXEC DBO.DBTD_SP_EXECUTESQL	@v_Database, @v_SQL

			SET @v_Message = 'Synonym "' + @v_CorrectedName + '" has been dropped from ' + @v_Database + ' database.';
			PRINT @v_Message;
			RETURN 1; 
		END
		ELSE BEGIN 
			SET @v_Message = 'Cannot find "' + @v_CorrectedName + '" synonym in the ' + @v_Database + ' database.';
			PRINT @v_Message;
			RETURN 0; 
		END; 
	END TRY
	BEGIN CATCH
		SET @v_Message = 'ERROR!!! Cannot drop "' + @v_CorrectedName + '" synonym. ' + ERROR_MESSAGE();
		PRINT @v_Message;
		RETURN 0; 
	END CATCH 
END;
GO

--************************************************************************************************
CREATE PROCEDURE DBO.DBTD_DROP_TRIGGER_IF_EXISTS
(
	@v_Object_Name	SYSNAME	--Trigger Name
)
WITH ENCRYPTION AS
BEGIN
	SET NOCOUNT ON;

	DECLARE @v_SQL NVARCHAR(MAX) = '',
			@v_Message VARCHAR(2000),
			@v_Server VARCHAR(2000),
			@v_Database VARCHAR(2000),
			@v_Schema VARCHAR(2000),
			@v_CorrectedName VARCHAR(2000),
			@v_Object VARCHAR(2000),
			@v_InternaltObjectID INT = NULL

	EXEC DBTD_SPLIT_FOUR_PART_OBJECT_NAME 
		@v_Object_Name, 
		@v_Server = @v_Server OUTPUT, @v_Database = @v_Database OUTPUT, @v_Schema = @v_Schema OUTPUT, 
		@v_Object = @v_Object OUTPUT, @v_CorrectedName = @v_CorrectedName OUTPUT,
		@v_CorrectTempTablesLocation = 1;

	BEGIN TRY 
		EXEC DBO.DBTD_GET_OBJECT_ID @v_CorrectedName, @v_Object_ID = @v_InternaltObjectID OUTPUT;

		--IF  OBJECT_ID (@v_Object_Name, 'TR') IS NOT NULL --find if there is a trigger with such a name
		IF (@v_InternaltObjectID IS NOT NULL)
		BEGIN
			SET @v_SQL = 'DROP TRIGGER ' + ISNULL( @v_Schema + '.', '') + @v_Object;

			EXEC DBO.DBTD_SP_EXECUTESQL	@v_Database, @v_SQL
			
			SET @v_Message = 'Trigger "' + @v_CorrectedName + '" has been dropped in the ' + @v_Database + ' database.';
			PRINT @v_Message;
			RETURN 1; 
		END
		ELSE BEGIN 
			SET @v_Message = 'Cannot find trigger "' + @v_CorrectedName + '" ';
			PRINT @v_Message;
			RETURN 0; 
		END; 
	END TRY
	BEGIN CATCH
		SET @v_Message = 'Cannot drop "' + @v_CorrectedName + '" trigger. ' + ERROR_MESSAGE();
		PRINT @v_Message;
		RETURN 0; 
	END CATCH 
END;
GO

--************************************************************************************************
CREATE PROCEDURE DBO.DBTD_DROP_INDEX_IF_EXISTS
(
	@v_Index_Name	SYSNAME,	--Index Name
	@v_Object_Name	SYSNAME		--Object name (Table or View)
)
WITH ENCRYPTION AS
BEGIN
	SET NOCOUNT ON;

	SET NOCOUNT ON;

	DECLARE @v_SQL NVARCHAR(MAX) = '',
			@v_Message VARCHAR(2000),
			@v_Server VARCHAR(2000),
			@v_Database VARCHAR(2000),
			@v_Schema VARCHAR(2000),
			@v_CorrectedName VARCHAR(2000),
			@v_Object VARCHAR(2000),
			@v_Object_ID INT = NULL,
			@v_ParmDefinition NVARCHAR(MAX) = N' @v_InternalIndexID INT OUTPUT, @v_Index_Name NVARCHAR(255), @v_Object_ID INT ',
			@v_InternalIndexID INT


	EXEC DBTD_SPLIT_FOUR_PART_OBJECT_NAME 
		@v_Object_Name, 
		@v_Server = @v_Server OUTPUT, @v_Database = @v_Database OUTPUT, @v_Schema = @v_Schema OUTPUT, 
		@v_Object = @v_Object OUTPUT, @v_CorrectedName = @v_CorrectedName OUTPUT,
		@v_CorrectTempTablesLocation = 1;

	BEGIN TRY 
		EXEC DBO.DBTD_GET_OBJECT_ID @v_CorrectedName, @v_Object_ID = @v_Object_ID OUTPUT;

		SET @v_SQL = ' SELECT @v_InternalIndexID = I.index_id FROM ' +@v_Database+ '.SYS.INDEXES AS I INNER JOIN '+@v_Database+'.dbo.SYSOBJECTS AS O ON I.object_ID = O.ID
				    WHERE UPPER(I.NAME) = LTRIM(RTRIM(UPPER(@v_Index_Name))) AND O.id = @v_Object_ID '
		EXECUTE sp_executeSQL
				@v_Sql,
				@v_ParmDefinition,
				@v_InternalIndexID = @v_InternalIndexID OUTPUT,
				@v_Index_Name = @v_Index_Name,
				@v_Object_ID = @v_Object_ID

		IF (@v_InternalIndexID IS NOT NULL)
		BEGIN
			SET @v_SQL = 'DROP INDEX ' + @v_Index_Name + ' ON ' + @v_Object_Name;
			EXECUTE sp_executesql @v_SQL;
			SET @v_Message = 'Index [' + @v_Index_Name + '] has been dropped for ['+@v_Object_Name+'] object.';
			PRINT @v_Message;
			RETURN 1; 
		END
		ELSE BEGIN 
			SET @v_Message = 'Cannot find index [' + @v_Index_Name + '] that belongs to ['+@v_Object_Name+'] object.';
			PRINT @v_Message;
			RETURN 0; 
		END; 
	END TRY
	BEGIN CATCH
		SET @v_Message = 'Cannot drop [' + @v_Index_Name + '] index that belongs to ['+@v_Object_Name+'] object. ' + ERROR_MESSAGE();
		PRINT @v_Message;
		RETURN 0; 
	END CATCH 
END;
GO

--************************************************************************************************
CREATE FUNCTION DBO.DBTD_SPLIT_STRING_TO_TABLE 
(
	@v_String NVARCHAR(MAX), 
	@v_Delimeter VARCHAR(250) = ','
)
RETURNS @v_Strings TABLE ( [String] NVARCHAR(MAX) )
WITH ENCRYPTION AS
BEGIN
	DECLARE @v_Index INT = -1 
 
	WHILE (LEN(@v_String) > 0) 
	BEGIN  
		SET @v_Index = CHARINDEX(@v_Delimeter , @v_String)  

		IF (@v_Index = 0) AND (LEN(@v_String) >= 0)  
		BEGIN   
			INSERT INTO @v_Strings ([String]) VALUES (@v_String)
			BREAK;  
		END  

		IF (@v_Index > 1)  
		BEGIN   
			INSERT INTO @v_Strings ([String]) VALUES (LEFT(@v_String, @v_Index - 1))   
		END  

		SET @v_String = RIGHT(@v_String, (LEN(@v_String) - @v_Index)) 
	END
	RETURN;
END
GO

