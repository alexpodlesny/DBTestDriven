﻿/*
--************************************************************************************************
-- VERSION:	   DBTestDriven - SQL Server - Version 4.6.3.147
-- COPYRIGHT:  (c) 2011-2014 Job Continent, DBTestDriven Project by Alex Podlesny
-- http://www.dbtestdriven.com
--************************************************************************************************
*/

--************************************************************************************************
--CORE SCHEMA
IF NOT EXISTS (SELECT 1 FROM sys.schemas WHERE name = N'DBTD_INTERFACE')
BEGIN
	EXEC sys.sp_executesql N'CREATE SCHEMA DBTD_INTERFACE'
END
GO

--************************************************************************************************
--CORE TABLE
--note: not all test runners will use this table 
--this table is the communication media for actively running test, all data in this table is temporary  
--this table will be cleaned before each test run when DBTD_RUNTESTSUITE procedure iterates through the 
--available tests in the test suite. external test runners might not use this stored procedure
CREATE TABLE DBTD_TBL_ACTIVETEST(
	[Owner]		NVARCHAR(128) NULL,			--Reserved
	TestName	NVARCHAR(128) NULL,			
	IsError		BIT NOT NULL,				--indicates that active test had an error
	IsFailure	BIT NOT NULL,				--indicates that active test failed or not
	[Message]	NVARCHAR(MAX) NOT NULL		--latest message
)
GO 

--************************************************************************************************
--CORE TABLE 
--stores the current list of all tests.
--table is used by test runner(s)  
--to update the list run DBTD_REFRESH_TESTSLIST stored procedure
CREATE TABLE DBTD_TBL_TESTSLIST(
	[Owner]					NVARCHAR(128),
	TestName				SYSNAME, 
	Suite					VARCHAR(128),
	HasSetup				BIT CONSTRAINT DF_DBTD_TBL_TESTSLIST_HasSetup DEFAULT 0,
	HasTeardown				BIT CONSTRAINT DF_DBTD_TBL_TESTSLIST_HasTeardown DEFAULT 0,
	Ignore					BIT CONSTRAINT DF_DBTD_TBL_TESTSLIST_Ignore DEFAULT 0,
	IgnoreReason			VARCHAR(500),		--note: the reason why this test is ignored 
	SuiteSetupName			VARCHAR(128),			
	SuiteTeardownName		VARCHAR(128),			
	SuiteSetupRunOnce		BIT CONSTRAINT DF_DBTD_TBL_TESTSLIST_SuiteSetupRunOnce DEFAULT 0,			
	SuiteTeardownRunOnce	BIT CONSTRAINT DF_DBTD_TBL_TESTSLIST_SuiteTeardownRunOnce DEFAULT 0,			
	UseTransaction			BIT,
	CompatibilityLevel		INT
)
GO 

--************************************************************************************************
--CORE TABLE
--stores latest test results information for a given test
--while DBTD_TBL_TESTSLIST has most unit tests list this table might have old unit test information
--NOTE: it pay attention to the test start and stop time, this table might include 
--      information about older test that failed long time ago.
CREATE TABLE DBTD_TBL_TESTRESULT(
	TestName		SYSNAME,						--unit test (or test suite) name
	[Owner]			NVARCHAR(128),
	RunCount		INT,							--number if times test have run 
	StartTime		DATETIME NOT NULL ,				--last start time
	StopTime		DATETIME NULL ,					--last finish time
	IsError			BIT NULL,						--"1" if has errors
	IsFailure		BIT NULL,						--"1" if failed 
	[Status]		VARCHAR (50) NULL,				--SUCCESS, FAILURE, ERROR, etc.
	[Message]		NVARCHAR(MAX) NULL				--error, warning, failure or other message
)
GO 

--************************************************************************************************
--CORE TABLE
--stores latest detailed test results information
CREATE TABLE DBTD_TBL_TESTRESULT_DETAILS(	
	EventID						BIGINT IDENTITY,
	EventDate					DATETIME CONSTRAINT DF_DBTD_TBL_TESTRESULT_DETAILS_EventDate DEFAULT GETDATE(),
	ObjectId					BIGINT,				--The actual asserted object
	ObjectName					NVARCHAR(128),		
	ObjectDatabaseName			NVARCHAR(128),		
	ObjectSchemaName			NVARCHAR(128),		--RESERVED: 
	ObjectFullName				NVARCHAR(128),		--RESERVED: 
	ObjectType					NVARCHAR(128),		--Object Type description
	UnitTestName				NVARCHAR(128),		
	UnitTestRunID				BIGINT,
	CallingProcName				NVARCHAR(128),		--OBJECT_NAME(@@PROCID) 
	IsMSShipped					BIT,				--RESERVED: 
	Comments					NVARCHAR(500)
);
GO

--************************************************************************************************
--CORE TABLE
--stores list of code coverage exceptions
CREATE TABLE DBTD_TBL_CODE_COVERAGE_EXCEPTIONS(	
	CodeCoverageExceptionID		INT IDENTITY,
	CreateDate					DATETIME CONSTRAINT DF_DBTD_TBL_CODE_COVERAGE_EXCEPTIONS_CreateDate DEFAULT GETDATE(),
	ObjectName					NVARCHAR(128),		
	ObjectDatabaseName			NVARCHAR(128),		
	ObjectSchemaName			NVARCHAR(128),
	ObjectType					NVARCHAR(128),
	ExceptionDescription		NVARCHAR(500)
);
GO

--************************************************************************************************
--CORE TABLE
--Primary framework log table
CREATE TABLE DBTD_TBL_LOG(
	LogID		INT IDENTITY (1, 1) NOT NULL ,
	EventType	VARCHAR(50) NULL,	--INFO, ERROR, WARNING, DEBUG, CLEANUP REQUEST etc.
	EventSource NVARCHAR(128) NULL,	
	EventTime	DATETIME NULL CONSTRAINT DF_DBTD_TBL_LOG_EventTime DEFAULT GETDATE(),
	[Message]	NVARCHAR (MAX) NULL
)
GO 

--************************************************************************************************
--CORE TABLE
--stores information about STUBs, MOCKs and other pretended or faked object used in testing
CREATE TABLE DBTD_TBL_PRETEND_OBJECT(
	PretendID				INT IDENTITY (1, 1) NOT NULL ,
	ObjectID				INT,	 --Database object id used to identify pretend object
	Name					SYSNAME, --Name of the pretend object Stub or Mock StoredProcedure
	OriginalName			SYSNAME, --Name of the original procedure that were used to create pretend object
	CreatedTime				DATETIME,
	LastUsedTime			DATETIME, --Last Time object were used 

	ParamLogTableName		NVARCHAR(256),	--name of the parameter log table
	ParamLogTableSignature	NVARCHAR(MAX),	--SQL that creates parameter log table
	ParamLogTableColumns	NVARCHAR(MAX),	--list of parameter log table columns without IDENTITY LogID column (coma separated)
	ParamLogTableAllColumns	NVARCHAR(MAX),	--list of ALL parameter log table columns (coma separated)
	HasParameters			BIT,			--1 if pretend object has parameters
	ParamLogAssertTempTable NVARCHAR(MAX),	-- SQL that created the temp table needed for assert logic
	ParamLogAssertGetData	NVARCHAR(MAX)	-- SQL that pulls actual assert data
)
GO

--************************************************************************************************
--CORE TABLE
--stores information about pretended or faked object executions
CREATE TABLE DBTD_TBL_PRETEND_OBJECT_LOG(
	LogID			INT IDENTITY (1, 1) NOT NULL ,
	PretendID		INT,
	EventTime		DATETIME,
	UnitTestRunID	INT NULL,	--When run through framework this field will have unique UnitTestRunID
	[Message]		NVARCHAR(MAX)
)
GO

--************************************************************************************************
--CORE TABLE
--stores information about retended or faked object parameters if there is any 
CREATE TABLE DBTD_TBL_PRETEND_OBJECT_PARAM_LOG(
	LogID			INT IDENTITY (1, 1) NOT NULL ,
	ExecutionLogID	INT, --Is the related LogID from DBTD_TBL_PRETEND_OBJECT_LOG table 
	PretendID		INT,
	EventTime		DATETIME,
	ParamName		SYSNAME,
	ParamValue		NVARCHAR(MAX),
	UnitTestRunID	INT NULL	--When run through framework this field will have unique UnitTestRunID
)
GO

--************************************************************************************************
--CORE TABLE
--Framework access management
--By default this table have no records, this means that access is open everywhere
--If table have at list one record then rights to run unit tests on this server will be managed 
--by access rules defined in this table.
--Only ALLOWED servers will be able to use test runners, on all other servers framework test runners 
--will not run. 
--Note this measure does not prevent from manually executing stored procedures, please check 
--online help for more details.   
CREATE TABLE DBTD_TBL_SERVER_ACCESS(
	ServerName	VARCHAR(128) NOT NULL,
	Access		VARCHAR(50) NOT NULL --ALLOWED, DENIED
)
GO

--************************************************************************************************
--CORE TABLE
--UnitTestRunID management for manual runs outside of the framework.
--NOTE: makesure that UnitTest uses DBTD_UNIT_TEST to specify the suite
--TODO: consider renaming to DBTD_TBL_MANUAL_UNITTESTRUN_METADATA
CREATE TABLE DBTD_TBL_MANUAL_UNITTESTRUNID(
	UnitTestRunID	INT,
	UnitTestName	NVARCHAR(128) --RESERVED column. Do not use.
)
GO

--************************************************************************************************
--REPORTING 
--stores report parameter data, in particulat the suite name 
CREATE TABLE DBTD_TBL_RPTPARAM(
	ReportID	DATETIME  NULL,		--unique ID that identifies set of parameters	
	Value		VARCHAR(128) NULL	--parameter value
)
GO 

--************************************************************************************************
--INTERNAL CORE: Do not use this table in your unit tests, it can be removed or changed in future releases
CREATE TABLE DBTD_TBL_LoadStatisticsTable(
	FileID			INT IDENTITY,
	ExternalID 		VARCHAR(250),	--External ID 
	FullFileName	NVARCHAR(MAX),
	[FileName]		NVARCHAR(MAX),
	LoadTime		DATETIME CONSTRAINT DF_DBTD_TBL_LoadStatisticsTable_LoadTime DEFAULT GETDATE()
)
GO

--************************************************************************************************
--INTERNAL CORE: Do not use this table in your unit tests, it can be removed or changed in future releases
CREATE TYPE DBTD_ParameterListTableType AS TABLE(
	ParameterID			INT, 
	ParameterName		SYSNAME, 
	IsOutputParameter	BIT,
	NextParameterName	SYSNAME --for the last parameter in the list this value is set to AS
)
GO

--************************************************************************************************
--INTERNAL CORE: Do not use this table in your unit tests, it can be removed or changed in future releases
--TODO: planned to be removed post version 5.0
CREATE TYPE DBTD_ExpectedParameterValues AS TABLE(
	PretendObjectExecutionNumber INT, --number of the pretend object execution. Used to separate different calls and maike sure that they will be compared inorder.
	ParameterName				 SYSNAME, 
	ParameterValue				 NVARCHAR(MAX)
)
GO

--************************************************************************************************
--NOTE: view signatures might be different for different database engines
--CORE VIEW
--View provides list of availble data types and their known aliases 
CREATE VIEW DBTD_VW_DATATYPE
AS
SELECT
	A.ALIAS AS NAME, 
	T.NAME AS PARRENTNAME,
	T.user_type_id AS XUSERTYPE, --T.XUSERTYPE
	T.system_type_id AS XTYPE
FROM 
	(
	SELECT 'DECIMAL' TYPENAME, 'DEC' AS ALIAS
	UNION ALL SELECT 'REAL' TYPENAME, 'FLOAT' AS ALIAS
	UNION ALL SELECT 'FLOAT' TYPENAME, 'DOUBLE PRECISION' AS ALIAS
	UNION ALL SELECT 'CHAR' TYPENAME, 'CHARACTER' AS ALIAS
	UNION ALL SELECT 'NCHAR' TYPENAME, 'NATIONAL CHAR' AS ALIAS
	UNION ALL SELECT 'NCHAR' TYPENAME, 'NATIONAL CHARACTER' AS ALIAS
	UNION ALL SELECT 'VARCHAR' TYPENAME, 'CHARACTER VARYING' AS ALIAS
	UNION ALL SELECT 'VARCHAR' TYPENAME, 'CHAR VARYING' AS ALIAS
	UNION ALL SELECT 'NVARCHAR' TYPENAME, 'NATIONAL CHAR VARYING' AS ALIAS
	UNION ALL SELECT 'NVARCHAR' TYPENAME, 'NATIONAL CHARACTER VARYING' AS ALIAS
	UNION ALL SELECT 'NTEXT' TYPENAME, 'NATIONAL TEXT' AS ALIAS
	UNION ALL SELECT 'TIMESTAMP' TYPENAME, 'ROWVERSION' AS ALIAS
	) AS A
	INNER JOIN 
	SYS.TYPES AS T
	ON 
		UPPER(T.NAME) = UPPER(A.TYPENAME);
GO

--************************************************************************************************
--NOTE: Object is supported in SQL Server 2012 
--CORE OBJECT SQLSERVER 2012	
--note: not all databases utilize sequence, this object is DB specific 
--general DB Test Driven sequence that generated unique IDs for the framework
--CREATE SEQUENCE DBTD_SEQUENCE AS INTEGER
--	START WITH 1 
--	INCREMENT BY 1
--	MINVALUE 1 
--	NO MAXVALUE 
--	NO CYCLE;

--************************************************************************************************
-- CORE
-- saves the message with specified type and source in the log
-- used by native and external test runners 
CREATE PROCEDURE DBTD_LOG_MESSAGE_EXT 
(
	@v_Type		VARCHAR(50),	--Message type
	@v_Source	VARCHAR(128),	--Message source
	@v_Message	NVARCHAR(MAX)	--Message text 
)
WITH ENCRYPTION AS
BEGIN
	SET NOCOUNT ON;
	--Check if transaction is classified as an uncommittable transaction, in such cases request cannot perform any write operations until it rolls back the transaction.
	IF (XACT_STATE() = -1) RETURN;
	INSERT INTO DBTD_TBL_LOG
		(EventType, EventSource, EVENTTIME, [Message]) 
		VALUES( @v_Type, @v_Source, GETDATE(), @v_Message);
END
GO

--************************************************************************************************
-- CORE
-- Saves message with provided type into the log table.
-- used by native and external test runners 
CREATE PROCEDURE DBTD_LOG_MESSAGE 
(
	@v_Type		VARCHAR(10),	--message type
	@v_Message	NVARCHAR(MAX)	--message text 
)
WITH ENCRYPTION AS
BEGIN
	SET NOCOUNT ON;
	EXEC DBTD_LOG_MESSAGE_EXT @v_Type, NULL, @v_Message; 
END;
GO

--************************************************************************************************
--INTERNAL CORE procedure that saves state for Unit Test that is running or have run in the past 
--note: when NULL value is supplied then this column does not get updated in the table   
CREATE PROCEDURE DBTD_SaveState
(
	@v_TestName		SYSNAME,		--Unit Test
	@v_TestOwner	NVARCHAR(128),	--Test Owner
	@v_Status		VARCHAR(50),	--Status,  note: when NULL value is supplied then this column does not get updated in the table  
	@v_IsError		BIT,			--Error,   note: when NULL value is supplied then this column does not get updated in the table   
	@v_IsFailure	BIT,			--Failure, note: when NULL value is supplied then this column does not get updated in the table  
	@v_Message		NVARCHAR(MAX)	--Message
)
WITH ENCRYPTION AS
BEGIN 
	SET NOCOUNT ON;
	DECLARE @v_ProcName	NVARCHAR(128) = OBJECT_NAME(@@PROCID)
	DECLARE @v_TmpMessage NVARCHAR(MAX) = 'START - ' + @v_TestName;
	--If transaction is classified as an uncommittable transaction. The request cannot perform any write operations until it rolls back the transaction.
	IF (XACT_STATE() = -1) RETURN;
	
	EXEC DBTD_LOG_MESSAGE_EXT  'DEBUG', @v_ProcName, @v_TmpMessage;

	UPDATE	DBTD_TBL_TESTRESULT
	SET	StopTime = GETDATE(),
		IsError = CASE 
					WHEN @v_IsError IS NULL THEN IsError --Do not change state if null value provided
					ELSE @v_IsError --Set new state if it is not a null
				END,
		IsFailure = CASE
					WHEN @v_IsFailure IS NULL THEN IsFailure --Do not change state if null value provided
					ELSE @v_IsFailure --Set new state if it is not a null
				END,
		[Status] = CASE
					WHEN @v_Status IS NULL THEN Status --Do not change state if null value provided
					ELSE @v_Status --Set new state if it is not a null
				END,
		[Message] = @v_Message
	WHERE UPPER(TestName) = UPPER(@v_TestName); 

	UPDATE DBTD_TBL_ACTIVETEST
	SET IsError = CASE 
					WHEN @v_IsError IS NULL THEN IsError --do not change state if null provided
					ELSE @v_IsError --set new state if it is not a null
				END,
		IsFailure = CASE
					WHEN @v_IsFailure IS NULL THEN IsFailure --do not change state if null provided
					ELSE @v_IsFailure --set new state if it is not a null
				END,
		[Message] = @v_Message
	WHERE UPPER(TestName) = UPPER(@v_TestName);
	--SET @v_TmpMessage = 'FINISH - ' + @v_TestName;
	--EXEC DBTD_LOG_MESSAGE_EXT  'DEBUG', @v_ProcName, @v_TmpMessage;
END;
GO

--************************************************************************************************
--DROP PROCEDURE DBTD_ADD_CODE_COVERAGE_EXCEPTION
CREATE PROCEDURE DBTD_ADD_CODE_COVERAGE_EXCEPTION
(
	@v_ObjectName			SYSNAME,	--Object Name
	@v_ObjectDatabase		SYSNAME,	--Database to which this object belongs
	@v_ObjectSchema			SYSNAME,	--Schema Name
	@v_ExceptionDescription	NVARCHAR(500),
	@v_ObjectType			NVARCHAR(128) = NULL --OPTIONAL
)
WITH ENCRYPTION AS
BEGIN
	SET NOCOUNT ON;
	INSERT INTO DBTD_TBL_CODE_COVERAGE_EXCEPTIONS
		(ObjectName,ObjectDatabaseName,ObjectSchemaName,ObjectType,ExceptionDescription)
		VALUES
			(@v_ObjectName,@v_ObjectDatabase,@v_ObjectSchema,@v_ObjectType,@v_ExceptionDescription)
END
GO

--************************************************************************************************
-- INTERNAL: Do not use this function in your unit tests, procedure can be removed,
-- Caches test run details in the temporary cache table
--DROP PROCEDURE DBTD_CACHE_TESTRESULT_DETAILS
CREATE PROCEDURE DBTD_CACHE_TESTRESULT_DETAILS
(
	@v_ObjectName		SYSNAME,		--Object Name
	@v_ObjectDatabase	SYSNAME,		--Database to which this object belongs
	@v_ObjectFullName	SYSNAME,		--Full object name in following format db.schema.objectname
	@v_CallingProcName	SYSNAME,		--Name of the procedure that call this function
	@v_ObjectID			BIGINT,			--OPTIONAL: If not provided then it will be calculated base on the @v_ObjectFullName
	@v_ObjectSchema		NVARCHAR(128)	--OPTIONAL: Schema Name
)
WITH ENCRYPTION AS
BEGIN
	SET NOCOUNT ON;
	DECLARE @v_UnitTestName		NVARCHAR(128),
			@v_UnitTestRunID	BIGINT,
			@v_Comments			NVARCHAR(500) = '',
			@v_InternalObjectID BIGINT = OBJECT_ID(@v_ObjectFullName),
			@v_ObjectType		VARCHAR(50),
			@v_IsMSShipped		BIT = 0,
			@v_SQL				NVARCHAR(MAX)

	CREATE TABLE #Parameters(
		type_desc VARCHAR(500),
		is_ms_shipped BIT
	)

	IF @v_ObjectID != @v_InternalObjectID 
		OR @v_InternalObjectID IS NULL 
		OR @v_ObjectID IS NULL
	BEGIN
		SET @v_Comments	= '@v_ObjectID=' + ISNULL(CAST(@v_ObjectID AS VARCHAR(50)), 'NULL') 
			+ ', @v_InternalObjectID=' + ISNULL(CAST(@v_InternalObjectID AS VARCHAR(50)), 'NULL')
	END 

	EXEC DBTD_Get_UnitTestRunID @v_UnitTestRunID OUTPUT
	EXEC DBTD_Get_UnitTestName @v_UnitTestName OUTPUT
	
	IF @v_InternalObjectID IS NOT NULL
	BEGIN 
		SET @v_SQL = 
			'INSERT INTO #Parameters (type_desc, is_ms_shipped)
			SELECT TOP 1 type_desc, is_ms_shipped
			FROM ' + ISNULL( @v_ObjectDatabase+'.','') + 'sys.objects 
			WHERE object_id ' + ISNULL(' = ' + CAST(@v_InternalObjectID AS VARCHAR(50)), ' IS NULL')
	
		EXEC DBTD_SP_EXECUTESQL @v_ObjectDatabase, @v_SQL
	END
	ELSE BEGIN
		--use provided id
		SET @v_InternalObjectID = @v_ObjectID
	END

	IF NOT EXISTS(SELECT 1 FROM #Parameters)
	BEGIN
		IF REPLACE(REPLACE(UPPER(LTRIM(RTRIM(@v_ObjectSchema))),'[',''),']','') = 'SYS' 
			OR UPPER(LEFT(REPLACE(LTRIM(@v_ObjectName), '[', ''),3)) = 'SYS' 
		BEGIN
			SET @v_ObjectType = 'SYSTEM_OBJECT'
			SET @v_IsMSShipped = 1
		END
	END 
	ELSE BEGIN	
		SELECT 
			TOP 1
			@v_ObjectType = type_desc,
			@v_IsMSShipped = is_ms_shipped
		FROM #Parameters
	END
	
	IF OBJECT_ID('TEMPDB.dbo.#DBTD_CurrentTestResultsDetails_Cache') IS NOT NULL 
	BEGIN
		INSERT INTO #DBTD_CurrentTestResultsDetails_Cache
			(ObjectId,ObjectName,ObjectDatabaseName,ObjectSchemaName,ObjectFullName,UnitTestName,UnitTestRunID,CallingProcName,ObjectType,IsMSShipped,Comments)	
			VALUES ( 
				@v_InternalObjectID, 
				REPLACE(REPLACE(@v_ObjectName, ']', ''), '[',''), 
				REPLACE(REPLACE(@v_ObjectDatabase, ']', ''), '[',''), 
				REPLACE(REPLACE(@v_ObjectSchema, ']', ''), '[',''), 
				@v_ObjectFullName, 
				REPLACE(REPLACE(@v_UnitTestName, ']', ''), '[',''), 
				@v_UnitTestRunID, 
				@v_CallingProcName,
				@v_ObjectType,
				@v_IsMSShipped,
				@v_Comments	
				)
	END
	ELSE BEGIN
		INSERT INTO DBTD_TBL_TESTRESULT_DETAILS
			(ObjectId,ObjectName,ObjectDatabaseName,ObjectSchemaName,ObjectFullName,UnitTestName,UnitTestRunID,CallingProcName,ObjectType,IsMSShipped,Comments)	
			VALUES ( 
				@v_InternalObjectID, 
				REPLACE(REPLACE(@v_ObjectName, ']', ''), '[',''), 
				REPLACE(REPLACE(@v_ObjectDatabase, ']', ''), '[',''), 
				REPLACE(REPLACE(@v_ObjectSchema, ']', ''), '[',''), 
				@v_ObjectFullName, 
				REPLACE(REPLACE(@v_UnitTestName, ']', ''), '[',''), 
				@v_UnitTestRunID, 
				@v_CallingProcName,
				@v_ObjectType,
				@v_IsMSShipped,
				@v_Comments	
				)
	END
END;
GO

--************************************************************************************************
-- CORE
--refreshes DBTD_TBL_TESTSLIST table.
--procedure will refresh the list of all available unit tests in the database
--DROP PROC DBTD_REFRESH_TESTSLIST
CREATE PROCEDURE DBTD_REFRESH_TESTSLIST
WITH ENCRYPTION 
AS
BEGIN
	SET NOCOUNT ON;
	DECLARE @v_ProcName	NVARCHAR(128) = OBJECT_NAME(@@PROCID)
	DECLARE @v_Message NVARCHAR(MAX) = 'Running ' + @v_ProcName;
	CREATE TABLE #TestList (
		[Owner]					VARCHAR(128),
		TestName				VARCHAR(128),
		Suite					VARCHAR(128),
		HasSetup				BIT DEFAULT 0,
		HasTeardown				BIT DEFAULT 0,
		Ignore					BIT DEFAULT 0,
		IgnoreReason			VARCHAR(500),
		SuiteSetupName			VARCHAR(128),			
		SuiteTeardownName		VARCHAR(128),			
		SuiteSetupRunOnce		BIT DEFAULT 0,			
		SuiteTeardownRunOnce	BIT DEFAULT 0,			
		UseTransaction			BIT,
		Legacy					BIT,
		CompatibilityLevel		INT
	);
	EXEC DBTD_LOG_MESSAGE_EXT 'DEBUG', @v_ProcName, @v_Message;

	--(20): Get tests with NEW naming convention, save to #TestList
	--(21): Determine Unit Test Suites for all identified unit tetsts 
	INSERT INTO  #TestList 
		([Owner], TestName, Suite, SuiteSetupName, SuiteTeardownName, Legacy, Ignore, CompatibilityLevel)
		SELECT 
			[Owner], 
			TestName, 
			Suite, 
			'UT_'+Suite+'_SETUP' AS SuiteSetupName, 
			'UT_'+Suite+'_TEARDOWN' AS SuiteTeardownName, 
			Legacy,
			Ignore,
			CompatibilityLevel
		FROM (
			SELECT 
				U.Name AS 'Owner',
				O.Name AS TestName,
				dbo.DBTD_fnGetSuiteName(object_definition(C.object_id)) AS Suite,
				0 AS Legacy,
				0 AS Ignore, --do not ignore by default
				4 AS CompatibilityLevel --version 4
			FROM 
				sys.sql_modules AS C
				INNER JOIN sysobjects AS O
					ON O.id = C.object_id
				LEFT OUTER JOIN sysusers AS U
					ON O.uid = U.uid 	
			WHERE 
				UPPER(object_definition(C.object_id)) LIKE '%DBTD\_UNIT\_TEST%'  ESCAPE '\'
				AND O.name != 'DBTD_UNIT_TEST' 
				AND O.xtype = 'P'
			) AS N;

	--(30): Get tests with LEGACY naming convention and save to #TestList, mark them as legacy 
	--(31): Get setup/teardown with legacy naming convention
	INSERT INTO  #TestList 
		([Owner], TestName, Suite, HasSetup, HasTeardown, Ignore, SuiteSetupName, SuiteTeardownName, UseTransaction, Legacy, CompatibilityLevel)
		SELECT 
			DISTINCT
			[Owner], 
			FULL_NAME, 
			SUITE_NAME, 
			ISNULL(S.HAS_SETUP, 0) AS HAS_SETUP, 
			ISNULL(TR.HAS_TEARDOWN, 0) AS HAS_TEARDOWN, 
			ISNULL(I.IGNORED_TEST, 0) AS IGNORED_TEST,
			TTT.SUITE_SETUP_NAME,
			TTT.SUITE_TEARDOWN_NAME,
			NULL AS UseTransaction,
			1 AS Legacy,
			3 AS CompatibilityLevel -- version 3
		FROM
			(
			SELECT 
				[Owner],
				ID, 
				FULL_NAME, 
				SUITE_NAME, 
				'UT_'+SUITE_NAME+'_SETUP' AS SUITE_SETUP_NAME,
				'UT_'+SUITE_NAME+'_TEARDOWN' AS SUITE_TEARDOWN_NAME	
			FROM
				(
				SELECT DISTINCT	[Owner], ID, FULL_NAME, 
					CASE 
						WHEN (CHARINDEX('_',NO_PREFIX) != 0) 
							THEN SUBSTRING(NO_PREFIX, 1, CHARINDEX('_', NO_PREFIX) - 1) 
						ELSE NO_PREFIX 
					END AS SUITE_NAME
				FROM
					(
					SELECT DISTINCT U.NAME AS 'OWNER', O.ID, O.NAME AS FULL_NAME, SUBSTRING(O.NAME, 4, LEN(O.NAME)) AS NO_PREFIX	
					FROM sysobjects AS O
						LEFT OUTER JOIN sysusers AS U
							ON O.uid = U.uid 	
					WHERE O.xtype='P' 
						and O.name like 'UT\_%' ESCAPE '\'
					) AS T
				WHERE FULL_NAME != 'UT_SETUP'
					AND FULL_NAME != 'UT_TEARDOWN'
					AND FULL_NAME not like 'UT\_%\_SETUP' ESCAPE '\'
					AND FULL_NAME not like 'UT\_%\_TEARDOWN' ESCAPE '\'
				) AS TT
			WHERE 
				UPPER(FULL_NAME) NOT IN ( SELECT DISTINCT UPPER(TestName) FROM #TestList ) --skip already identified tests 
			) AS TTT
			LEFT OUTER JOIN 
			( 
			SELECT DISTINCT	ID, NAME AS SETUP_NAME, 1 AS HAS_SETUP 
			FROM sysobjects 
			WHERE NAME like 'UT\_%\_SETUP'  ESCAPE '\'
				AND xtype = 'P'
			) AS S
			ON TTT.SUITE_SETUP_NAME = S.SETUP_NAME
			LEFT OUTER JOIN 
			(
			SELECT DISTINCT ID, NAME AS TEARDOWN_NAME, 1 AS HAS_TEARDOWN 
			FROM sysobjects 
			WHERE NAME like 'UT\_%\_TEARDOWN' ESCAPE '\'
				AND xtype = 'P'
			) AS TR
			ON TTT.SUITE_TEARDOWN_NAME = TR.TEARDOWN_NAME
			LEFT OUTER JOIN
			( 
			SELECT DISTINCT object_id AS ID, object_name(object_id) AS IGNORED_TEST_NAME, 1 AS IGNORED_TEST 
			FROM sys.sql_modules AS C
			WHERE UPPER(object_definition(object_id)) LIKE '%DBTD\_IGNORE%'  ESCAPE '\'
			) AS I 
			ON TTT.ID = I.ID
		ORDER BY SUITE_NAME, FULL_NAME;

	--(40): Determine procedures marked as NON A UNIT TESTS and remove them from #TestList 
	SELECT 
		DISTINCT 
		O.ID,
		U.Name AS [Owner],
		UPPER(O.NAME) AS ProcName,
		0 AS IsATest
	INTO #TestListExcluded 
	FROM 
		sys.sql_modules AS C
		INNER JOIN sysobjects AS O
			ON O.id = C.object_id
		LEFT OUTER JOIN sysusers AS U
			ON O.uid = U.uid 	
	WHERE 
		UPPER(object_definition(C.object_id)) LIKE '%DBTD\_NOT\_A\_UNIT\_TEST%'  ESCAPE '\'
		AND O.name != 'DBTD_NOT_A_UNIT_TEST' 
		AND O.xtype = 'P';
	
	DELETE FROM #TestList
	WHERE 
		UPPER(TestName) IN (SELECT ProcName 
					 FROM #TestListExcluded);

	-- (50): Determine Ignored test that marked with DBTD IGNORE 
	WITH TestListIgnored AS (
		SELECT 
			DISTINCT 
			object_id AS ID, 
			UPPER(object_name(object_id)) AS IgnoredTestName, 
			'Test Ignored with DBTD'+'_'+'IGNORE Hint Procedure' AS IgnoreReason,
			1 AS IsIgnoredTest 
		FROM sys.sql_modules AS C
		WHERE UPPER(object_definition(object_id)) LIKE '%DBTD\_IGNORE%'  ESCAPE '\')
	UPDATE TL
	SET Ignore = I.IsIgnoredTest,
		IgnoreReason = I.IgnoreReason
	FROM 
		#TestList AS TL 
		INNER JOIN 
		TestListIgnored AS I
		ON 
			UPPER(TL.TestName) = UPPER(I.IgnoredTestName)
	WHERE 
		I.IsIgnoredTest = 1;

	--(60): Get setup/teardown with OLD naming convention 
	WITH 
		SetupList AS ( 
			SELECT DISTINCT	ID, NAME AS SETUP_NAME, 1 AS HAS_SETUP 
			FROM sysobjects 
			WHERE NAME like 'UT\_%\_SETUP'  ESCAPE '\' AND xtype = 'P'),
		TesrdownList AS (
			SELECT DISTINCT ID, NAME AS TEARDOWN_NAME, 1 AS HAS_TEARDOWN 
			FROM sysobjects 
			WHERE NAME like 'UT\_%\_TEARDOWN' ESCAPE '\' AND xtype = 'P')
	UPDATE TL
	SET 
		HasSetup = ISNULL(S.HAS_SETUP, 0), 
		HasTeardown = ISNULL(TR.HAS_TEARDOWN, 0)
	FROM #TestList AS TL
		LEFT OUTER JOIN SetupList AS S
			ON UPPER(TL.SuiteSetupName) = UPPER(S.SETUP_NAME)
		LEFT OUTER JOIN TesrdownList AS TR
			ON UPPER(TL.SuiteTeardownName) = UPPER(TR.TEARDOWN_NAME);

	-- (65): Get setup/teardown with NEW naming convention 
	--todo: comes in the next version 

	--(50): Determine UseTransactions and DoNotUseTransactions flags 
	WITH UseTransaction AS (
		SELECT 
			object_id AS ID, 
			object_name(object_id) AS TestName, 
			CASE
				WHEN dbo.DBTD_IS_USE_TRAN_SET(UPPER(object_definition(object_id))) = 1 THEN  1 --Use Transctions
				WHEN dbo.DBTD_IS_DO_NOT_USE_TRAN_SET (UPPER(object_definition(object_id))) = 1 THEN  0 --DO NOT Use Transactions
				ELSE NULL
			END AS UseTransaction
		FROM sys.sql_modules AS C)
	UPDATE Test
		SET Test.UseTransaction = T.UseTransaction
	FROM 
		#TestList AS Test
		LEFT OUTER JOIN 
		UseTransaction AS T
		ON Test.TestName = T.TestName
	WHERE 
		T.UseTransaction IS NOT NULL;

	--(70) Determine RunOnce setup/teardown conditions
	WITH RunOnce AS 
		(
		SELECT 
			object_name(object_id) AS Name,
			1 AS RunOnce
		FROM sys.sql_modules AS C
		WHERE 
			UPPER(object_definition(object_id)) LIKE '%DBTD\_RUN\_ONCE%'  ESCAPE '\'
			AND UPPER(object_name(object_id)) != 'DBTD_RUN_ONCE' 
		) /*RunOnce End*/
	UPDATE Test
		SET 
			SuiteSetupRunOnce = ISNULL(Setup.RunOnce,0),
			SuiteTeardownRunOnce = ISNULL(Teardown.RunOnce,0)
	FROM 
		#TestList AS Test
		LEFT OUTER JOIN 
		RunOnce AS Setup
			ON Test.SuiteSetupName = Setup.Name
		LEFT OUTER JOIN 
		RunOnce AS Teardown
			ON Test.SuiteTeardownName = Teardown.Name; 

	--(100): Save results
    DELETE FROM DBTD_TBL_TESTSLIST;
	INSERT INTO  DBTD_TBL_TESTSLIST ([Owner], TestName, Suite, HasSetup, HasTeardown, Ignore, IgnoreReason, SuiteSetupName, SuiteTeardownName, UseTransaction, CompatibilityLevel)
		SELECT [Owner], TestName, Suite, HasSetup, HasTeardown, Ignore, IgnoreReason, SuiteSetupName, SuiteTeardownName, UseTransaction, CompatibilityLevel
		FROM  #TestList 

	SET @v_Message = CAST(@@ROWCOUNT as varchar) + ' unit tests were found in the database';
	EXEC DBTD_LOG_MESSAGE_EXT 'DEBUG', @v_ProcName, @v_Message;
END
GO

--************************************************************************************************
--INTERNAL: Do not use this function in your unit tests, procedure can be removed,
--          signature or procedure name can be changed at any release
CREATE FUNCTION DBTD_fnReplaceLineBreaksAndTabs
(
	@v_TextBlock	NVARCHAR(MAX),
	@v_Replacement	NVARCHAR(50)
)
RETURNS NVARCHAR(MAX)
WITH ENCRYPTION AS
BEGIN
	DECLARE @v_TmpTextBlock NVARCHAR(MAX)

	SET @v_TmpTextBlock = REPLACE(@v_TextBlock,CHAR(13)+CHAR(10),'');--eleminate new line breaks
	SET @v_TmpTextBlock = REPLACE(@v_TmpTextBlock,CHAR(13),'');--eleminate new line breaks
	SET @v_TmpTextBlock = REPLACE(@v_TmpTextBlock,CHAR(10),'');--eleminate new line breaks
	SET @v_TmpTextBlock = REPLACE(@v_TmpTextBlock,CHAR(9),'');--eleminate tabs

	RETURN @v_TmpTextBlock;
END
GO

--************************************************************************************************
--INTERNAL: Do not use this function in your unit tests, procedure can be removed,
--          signature or procedure name can be changed at any release
--DROP FUNCTION DBTD_fnGetFullType
CREATE FUNCTION DBTD_fnGetFullType
(
	@v_Type		 SYSNAME,
	@v_PrecLenth INT,		-- Precision or Lenth
	@v_Scale	 INT
)
RETURNS SYSNAME
WITH ENCRYPTION AS
BEGIN
	DECLARE @v_PrecScale NVARCHAR(255),
			@v_TypePrecScale NVARCHAR(255),
			@v_is_user_defined BIT

	SELECT @v_is_user_defined = is_user_defined FROM sys.TYPES WHERE UPPER(Name) = UPPER(LTRIM(RTRIM(@v_Type)))

	SET @v_PrecScale = 
		CASE
			WHEN @v_is_user_defined = 1 THEN ''
			WHEN @v_Type IN ('BIT','BIGINT','REAL','INT','DATETIME','SMALLMONEY','MONEY','DATE','SMALLDATETIME','TINYINT','SMALLINT','GEOGRAPHY','GEOMETRY','SQL_VARIANT','XML','UNIQUEIDENTIFIER','SYSNAME','TEXT','NTEXT','TIMESTAMP','IMAGE','HIERARCHYID') THEN ''
			WHEN @v_Type IN ('TIME', 'DATETIME2', 'DATETIMEOFFSET') AND @v_Scale BETWEEN 0 AND 7 THEN '(' + cast(@v_Scale as varchar(50)) + ')'
			WHEN @v_Type IN ('TIME', 'DATETIME2', 'DATETIMEOFFSET') AND @v_Scale NOT BETWEEN 0 AND 7 THEN ''
			WHEN @v_Type IN ('NUMERIC','DECIMAL','DEC') AND (@v_PrecLenth NOT BETWEEN 1 AND 38) THEN '(18)' --use default for numeric 
			WHEN @v_Type IN ('NUMERIC','DECIMAL','DEC') AND (@v_PrecLenth BETWEEN 1 AND 38) 
				AND (@v_Scale IS NULL OR @v_Scale = 0) THEN '(' + cast(@v_PrecLenth as varchar(50)) + ')'
			WHEN @v_Type IN ('NUMERIC','DECIMAL','DEC') AND (@v_PrecLenth BETWEEN 1 AND 38) 
				AND (@v_Scale BETWEEN 0 AND @v_PrecLenth) THEN '(' + cast(@v_PrecLenth as varchar(50)) +',' + cast(@v_Scale as varchar(50)) + ')'
			WHEN @v_Type IN ('VARCHAR', 'CHAR VARYING', 'CHARACTER VARYING', 'NVARCHAR', 'NATIONAL CHAR VARYING', 'NATIONAL CHARACTER VARYING', 'VARBINARY','BINARY', 'CHAR', 'NCHAR') 
				AND (@v_PrecLenth > 8000 OR @v_PrecLenth <= -1) THEN '(max)'
			WHEN @v_Type IN ('VARCHAR', 'CHAR VARYING', 'CHARACTER VARYING', 'NVARCHAR', 'NATIONAL CHAR VARYING', 'NATIONAL CHARACTER VARYING', 'VARBINARY','BINARY', 'CHAR', 'NCHAR') 
				AND (@v_PrecLenth BETWEEN 1 AND 8000) THEN '(' + cast(@v_PrecLenth as varchar(50)) + ')'
			WHEN @v_Type IN ('VARCHAR', 'CHAR VARYING', 'CHARACTER VARYING', 'NVARCHAR', 'NATIONAL CHAR VARYING', 'NATIONAL CHARACTER VARYING', 'VARBINARY','BINARY', 'CHAR', 'NCHAR') 
				AND (@v_PrecLenth = 0 OR @v_PrecLenth IS NULL) THEN '(50)'

			WHEN @v_Type = 'FLOAT' AND @v_PrecLenth between 1 and 24 THEN '(24)'
			WHEN @v_Type = 'FLOAT' AND (@v_PrecLenth between 25 and 53 OR @v_PrecLenth IS NULL OR @v_PrecLenth = 0) THEN '(53)' --default value
			WHEN @v_PrecLenth IS NOT NULL AND @v_Scale IS NOT NULL THEN '(' + cast(@v_PrecLenth as varchar(50)) +',' + cast(@v_Scale as varchar(50)) + ')'
			WHEN @v_PrecLenth IS NOT NULL THEN '(' + cast(@v_PrecLenth as varchar(50)) + ')'
			ELSE ''
		END  
	SET @v_TypePrecScale = LTRIM(RTRIM(@v_Type)) + '' + @v_PrecScale
	RETURN @v_TypePrecScale;
END
GO

--************************************************************************************************
--INTERNAL: Do not use this function in your unit tests, procedure can be removed,
--          signature or procedure name can be changed at any release
--DROP FUNCTION DBTD_fnGetFullTypeByID
CREATE FUNCTION DBTD_fnGetFullTypeByID
(
	@v_SystemTypeID	INT,
	@v_PrecLenth	INT, -- Precision or Lenth
	@v_Scale		INT
)
RETURNS SYSNAME
WITH ENCRYPTION AS
BEGIN
	DECLARE @v_Type SYSNAME
	SELECT @v_Type = name FROM sys.TYPES WHERE user_type_id = UPPER(LTRIM(RTRIM(@v_SystemTypeID)))
	RETURN dbo.DBTD_fnGetFullType( @v_Type, @v_PrecLenth, @v_Scale)
END
GO

--************************************************************************************************
--CORE
--Function will determine suite name
--DROP FUNCTION DBTD_fnGetSuiteName
CREATE FUNCTION DBTD_fnGetSuiteName
(
	@v_ProcText NVARCHAR(MAX)
)
RETURNS VARCHAR(128)
WITH ENCRYPTION 
AS
BEGIN
	DECLARE @v_GenericSuiteName VARCHAR(128) = 'GenericUnitTests',
			@v_SuiteName VARCHAR(128) = '',
			@v_HintName VARCHAR(50) = 'DBTD_UNIT'+'_TEST',
			@v_HintLen INT,
			@v_Len INT,
			@v_Pattern VARCHAR(50),
			@v_Pattern2 VARCHAR(50) = '%''%',
			@v_SearchDepth INT = 500,
			@v_RawSuiteName VARCHAR(500);
	IF EXISTS( 
			SELECT *
			FROM (SELECT @v_ProcText AS v_ProcText) AS T
			WHERE v_ProcText LIKE '%DBTD\_UNIT\_TEST%' ESCAPE '\'
			)
	BEGIN
		SET @v_Pattern = '%'+@v_HintName+'%';
		SET @v_SuiteName = @v_GenericSuiteName;
		SET @v_HintLen = LEN(@v_HintName);

		--(1)find first occurance of the hint 
		SET @v_RawSuiteName = LTRIM(RTRIM(SUBSTRING(@v_ProcText, PATINDEX(@v_Pattern, @v_ProcText)+@v_HintLen, @v_SearchDepth)));
		--(2)clean up from tabs, new lines and spaces
		SET @v_RawSuiteName = dbo.DBTD_fnReplaceLineBreaksAndTabs( @v_RawSuiteName, '');
		SET @v_RawSuiteName = LTRIM(RTRIM(@v_RawSuiteName));--eleminate spaces
		
		IF (LEFT(@v_RawSuiteName,1) = '''')
		BEGIN
			--(3)first symbol is the single quotation mark 
			SET @v_RawSuiteName = SUBSTRING(@v_RawSuiteName, 2, @v_SearchDepth);
			--(4)get the name of suite
			SET @v_Len = CASE 
							WHEN (PATINDEX(@v_Pattern2, @v_RawSuiteName)-1) < 0 THEN 0 
							ELSE (PATINDEX(@v_Pattern2, @v_RawSuiteName)-1)
						 END;
			SET @v_SuiteName = LTRIM(RTRIM(SUBSTRING(@v_RawSuiteName, 1, @v_Len)));
		END 
		ELSE IF (UPPER(LEFT(@v_RawSuiteName,4)) = 'NULL')
		BEGIN
			--(3a) name of the suite is NULL
			SET @v_SuiteName = @v_GenericSuiteName;
		END IF (UPPER(LEFT(@v_RawSuiteName,4)) = '@')
		BEGIN
			--(3a) name of the suite is a variable that we cannot determine at the time 
			SET @v_SuiteName = @v_GenericSuiteName;
		END; 

		IF (@v_SuiteName IS NULL) OR (LTRIM(RTRIM(@v_SuiteName)) = '')
			SET @v_SuiteName = @v_GenericSuiteName;
	END
	RETURN @v_SuiteName;
END
GO

--************************************************************************************************
--CORE
--Function will determine if supplied procedure text contains use transaction hint
--DROP FUNCTION DBTD_IS_USE_TRAN_SET
CREATE FUNCTION DBTD_IS_USE_TRAN_SET
(
	@v_ProcText NVARCHAR(MAX)
)
RETURNS BIT
WITH ENCRYPTION 
AS
BEGIN
	DECLARE @v_Found BIT = 0;

	IF EXISTS( 
			SELECT *
			FROM (SELECT @v_ProcText AS v_ProcText) AS T
			WHERE v_ProcText LIKE '%DBTD\_USE\_TRANSACTION%' ESCAPE '\'
				OR v_ProcText LIKE '%DBTD\_CREATE\_MOCK\_PROCEDURE%' ESCAPE '\'
				OR v_ProcText LIKE '%DBTD\_CREATE\_STUB\_PROCEDURE%' ESCAPE '\'
			)
	BEGIN
		SET @v_Found = 1;
	END
	
	RETURN @v_Found;
END
GO

--************************************************************************************************
--CORE
--Function will determine if test runer allowed to run unit tests on a given server 
--note: do not use this function directly, call the "DBTD_INTERFACE.IS_SERVER_ACCESS_ALLOWED" instead
CREATE FUNCTION DBTD_IS_SERVER_ACCESS_ALLOWED()
RETURNS BIT
WITH ENCRYPTION 
AS
BEGIN
	--SET NOCOUNT ON;
	DECLARE @v_Allowed	BIT = 0,
			@v_Message	NVARCHAR(255),
			@v_AllowCount INT = 0,
			@v_DenyCount INT = 0

	IF EXISTS(SELECT TOP 1 * FROM DBTD_TBL_SERVER_ACCESS)
	BEGIN
		--access rules has been found
		SELECT @v_AllowCount = COUNT(*) 
		FROM DBTD_TBL_SERVER_ACCESS
		WHERE 
			@@servername like ServerName
			AND  Access = 'ALLOWED';

		SELECT @v_DenyCount = COUNT(*) 
		FROM DBTD_TBL_SERVER_ACCESS
		WHERE 
			@@servername like ServerName
			AND  Access != 'ALLOWED';
		
		SET @v_Allowed = 
				CASE
					WHEN @v_DenyCount != 0 THEN 0 -- Deny
					WHEN @v_AllowCount != 0 AND @v_DenyCount = 0 THEN 1 --Allow
					ELSE 0 -- Deny
				END;
		IF @v_Allowed = 1
			SET @v_Message = 'Access allowed';
			ELSE SET @v_Message = 'Access has been denied. Please check DBTD_TBL_SERVER_ACCESS for more information.';

	END 
	ELSE BEGIN 
		SET @v_Allowed = 1;
		SET @v_Message = 'No access rules have been found. Access allowed';
	END; 
	RETURN @v_Allowed;
END
GO

--************************************************************************************************
--CORE SYNONYM
--used to abstract DBTD_IS_SERVER_ACCESS_ALLOWED function 
CREATE SYNONYM DBTD_INTERFACE.IS_SERVER_ACCESS_ALLOWED FOR dbo.DBTD_IS_SERVER_ACCESS_ALLOWED;
GO

--************************************************************************************************
--CORE
--function will determine if supplied procedure text contains use transaction hint
CREATE FUNCTION DBTD_IS_DO_NOT_USE_TRAN_SET
(
	@v_ProcText NVARCHAR(MAX)
)
RETURNS BIT
WITH ENCRYPTION 
AS
BEGIN
	DECLARE @v_Found BIT = 0;

	IF EXISTS( 
			SELECT *
			FROM (SELECT @v_ProcText AS v_ProcText) AS T
			WHERE v_ProcText LIKE '%DBTD\_DO\_NOT\_USE\_TRANSACTION%' ESCAPE '\'
			)
	BEGIN
		SET @v_Found = 1;
	END
	
	RETURN @v_Found;
END
GO

--************************************************************************************************
--CORE
--note: used it to report errors in Unit Tests
--saves error into log table and raise the error to the parent process
--@v_ErrorID  >= 50000 - is the user error,  
--@v_ErrorID < 50000  - is the SQL Server error
CREATE PROCEDURE DBTD_ERROR 
(
	@v_ErrorID INTEGER
) 
WITH ENCRYPTION AS
BEGIN
	SET NOCOUNT ON;
	DECLARE @v_ProcName	NVARCHAR(128) = OBJECT_NAME(@@PROCID)
	DECLARE @v_Message	NVARCHAR(MAX) = 'Running ' + @v_ProcName,
			@v_TestName VARCHAR(128); 
	EXEC DBTD_LOG_MESSAGE_EXT 'DEBUG', @v_ProcName, @v_Message;

	SET @v_Message = 
		CASE
			WHEN @v_ErrorID >= 50000 THEN 'USER DEFINED ERROR ' + CAST( @v_ErrorID AS VARCHAR(50))	
			ELSE 'SQL SERVER ERROR ' + CAST( @v_ErrorID AS VARCHAR(50)) 
		END;
	
	SELECT TOP 1 @v_TestName = TestName FROM DBTD_TBL_ACTIVETEST;
	
	EXEC DBTD_SaveState 
		@v_TestName = @v_TestName,
		@v_TestOwner = NULL,		
		@v_Status = 'ERROR',		--Status,  note: when NULL value is supplied then this column does not get updated in the table  
		@v_IsError = 1,				--Error,   note: when NULL value is supplied then this column does not get updated in the table   
		@v_IsFailure = NULL,		--Failure, note: when NULL value is supplied then this column does not get updated in the table  
		@v_Message = @v_Message;
	
	EXEC DBTD_LOG_MESSAGE_EXT 'ERROR', @v_TestName, @v_Message;
	
	--Errors that have a severity of 10 or lower are considered warnings or informational messages, and are not handled by TRY�CATCH blocks. 
	IF EXISTS(SELECT 1 FROM (SELECT @v_Message  as P) as t WHERE t.P LIKE '%\%%' ESCAPE '\' )
	BEGIN
		SET @v_Message = REPLACE(@v_Message,'%','_') + ' (PLEASE NOTE that percent sigh has been replaced with underscore)'; --not ready to handle error message parameters at this time 
	END 
	RAISERROR (@v_Message,11,5);
END;
GO 

--************************************************************************************************
--CORE
--records failure message in the log and raises exception UP to the parent process
CREATE PROCEDURE DBTD_FAILURE 
(
	@v_Message NVARCHAR(MAX)
)
WITH ENCRYPTION AS
BEGIN
	SET NOCOUNT ON;
	DECLARE @v_ProcName	NVARCHAR(128) = OBJECT_NAME(@@PROCID)
	DECLARE @v_TempMessage	NVARCHAR(MAX) = 'Running ' + @v_ProcName
	DECLARE @v_TestName NVARCHAR(128);
	EXEC DBTD_LOG_MESSAGE_EXT 'DEBUG', @v_ProcName, @v_TempMessage;

	SELECT TOP 1 @v_TestName = TestName FROM DBTD_TBL_ACTIVETEST;

	EXEC DBTD_LOG_MESSAGE_EXT 'FAILURE', @v_TestName, @v_Message;

	EXEC DBTD_SaveState 
		@v_TestName = @v_TestName,
		@v_TestOwner = NULL,		
		@v_Status = 'FAILURE',	--Status,  note: when NULL value is supplied then this column does not get updated in the table  
		@v_IsError = NULL,		--Error,   note: when NULL value is supplied then this column does not get updated in the table   
		@v_IsFailure = 1,		--Failure, note: when NULL value is supplied then this column does not get updated in the table  
		@v_Message = @v_Message;

	--Errors that have a severity of 10 or lower are considered warnings or informational messages, and are not handled by TRY�CATCH blocks. 
	IF EXISTS(SELECT 1 FROM (SELECT @v_Message  as P) as t WHERE t.P LIKE '%\%%' ESCAPE '\' )
	BEGIN
		SET @v_Message = REPLACE(@v_Message,'%','_') + ' (PLEASE NOTE that percent sigh has been replaced with underscore)'; --not ready to handle error message parameters at this time 
	END 
	RAISERROR (@v_Message,11,6);
END;
GO

--************************************************************************************************
-- Assert procedure that takes SQL query, executes it and report failure if script succeeded  
CREATE PROCEDURE DBTD_ASSERT_WILL_FAIL 
(
	@v_SQL			NVARCHAR(MAX),
	@v_UserMessage	NVARCHAR(MAX)
)
WITH ENCRYPTION AS
BEGIN
	SET NOCOUNT ON;
	DECLARE @v_ProcName	NVARCHAR(128) = OBJECT_NAME(@@PROCID)
	DECLARE @v_IsFailed bit = 0, 
			@v_TestName NVARCHAR(128), 
			@v_Message	NVARCHAR(MAX) = 'Running ' + @v_ProcName,
			@v_Alt_ProcName NVARCHAR(128)  

	EXEC DBTD_LOG_MESSAGE_EXT 'DEBUG', @v_ProcName, @v_Message ;

	BEGIN TRY
		EXECUTE sp_executesql @v_SQL;
		SET @v_Message = ISNULL(@v_UserMessage + '. ', '') + 'SQL EXPECTED TO FAIL, but it did not.'; 
		EXEC DBTD_FAILURE @v_Message; 
	END TRY
	BEGIN CATCH
		SET @v_Message = 'Listed above SQL FAILED AS EXPECTED with error: ' +  CAST(ERROR_NUMBER() AS VARCHAR) + ' : ' + ERROR_MESSAGE();
		SET @v_Alt_ProcName = @v_ProcName + ' (1)'
		EXEC DBTD_LOG_MESSAGE_EXT 'INFO', @v_Alt_ProcName, @v_SQL;
		SET @v_Alt_ProcName = @v_ProcName + ' (2)'
		EXEC DBTD_LOG_MESSAGE_EXT 'INFO', @v_Alt_ProcName, @v_Message;

		--update status with the SUCCESS message in case when DBTD_ASSERT_WILL_FAIL 
		--runs to checks failure of a unit test that uses DBTD_FAILURE\DBTD_ERROR to report status
		SELECT TOP 1 @v_TestName = TestName FROM DBTD_TBL_ACTIVETEST;

		--EXEC DBTD_SaveState @v_TestName, NULL, NULL, 0, 0, @v_Message;
		EXEC DBTD_SaveState 
			@v_TestName = @v_TestName,
			@v_TestOwner = NULL,		
			@v_Status = NULL,	--Status,  note: when NULL value is supplied then this column does not get updated in the table  
			@v_IsError = 0,		
			@v_IsFailure = 0,	
			@v_Message = @v_Message;
	END CATCH
END;
GO

--************************************************************************************************
-- Assert procedure that takes SQL query, executes it and 
-- report failure if script failed
CREATE PROCEDURE DBTD_ASSERT_WILL_SUCCEED 
(
	@v_SQL			NVARCHAR(MAX),
	@v_UserMessage	NVARCHAR(MAX)
)
WITH ENCRYPTION AS
BEGIN
	SET NOCOUNT ON;
	DECLARE @v_ProcName	NVARCHAR(128) = OBJECT_NAME(@@PROCID)
	DECLARE @v_IsFailed bit = 0; 
	DECLARE @v_Message	NVARCHAR(MAX) = 'Running ' + @v_ProcName;
	EXEC DBTD_LOG_MESSAGE_EXT 'DEBUG', @v_ProcName, @v_Message ;

	BEGIN TRY
		EXECUTE sp_executesql @v_SQL;
		SET @v_IsFailed = 0;
		SET @v_Message = '';
	END TRY
	BEGIN CATCH
		SET @v_IsFailed = 1;
		SET @v_Message = 'FAILED WITH ERROR: ' +  CAST(ERROR_NUMBER() AS VARCHAR) + ' : ' + ERROR_MESSAGE();
	END CATCH

	IF (@v_IsFailed != 0)  
	BEGIN
		SET @v_Message = ISNULL(@v_UserMessage + '.', '') + 'Provided SQL EXPECTED TO SUCCEED, but it has ' + @v_Message; 
		EXEC DBTD_FAILURE @v_Message; 
	END;
END;
GO

--************************************************************************************************
-- Assert procedure that takes actual value, expected value, compares them for equality 
-- report failure if the not equal
CREATE PROCEDURE DBTD_ASSERT_ARE_EQUAL 
(
	@v_ActualValue		NVARCHAR(MAX), 
	@v_ExpectedValue	NVARCHAR(MAX), 
	@v_UserMessage		NVARCHAR(MAX)
)
WITH ENCRYPTION AS
BEGIN
	SET NOCOUNT ON;
	DECLARE @v_ProcName	NVARCHAR(128) = OBJECT_NAME(@@PROCID)
	DECLARE @v_Message NVARCHAR(MAX) = 'Running ' + @v_ProcName;
	EXEC DBTD_LOG_MESSAGE_EXT 'DEBUG', @v_ProcName, @v_Message ;

	IF	@v_ActualValue IS NULL
		OR @v_ExpectedValue IS NULL
		OR (@v_ActualValue != @v_ExpectedValue) 
	BEGIN
		SET @v_Message = ISNULL(@v_UserMessage + '.', '') 
			+ ' Actual value is NOT EQUAL Expected value. ' 
			+ ' EXPECTED: "' + ISNULL(@v_ExpectedValue,'NULL') + '"'
			+ ' ACTUAL: "' + ISNULL(@v_ActualValue,'NULL') + '"'; 
		EXEC DBTD_FAILURE @v_Message; 
	END;
END;
GO

--************************************************************************************************
CREATE PROCEDURE DBTD_ASSERT_STRING_CONTAINS
(
	@v_Pattern		NVARCHAR(MAX), --An expression that contains the string to be found. 
	@v_String		NVARCHAR(MAX), --String that is searched for the specified pattern
	@v_UserMessage	NVARCHAR(MAX)
)
WITH ENCRYPTION AS
BEGIN
	SET NOCOUNT ON;
	DECLARE @v_ProcName	NVARCHAR(128) = OBJECT_NAME(@@PROCID)
	DECLARE @v_Message NVARCHAR(MAX) = 'Running ' + @v_ProcName,
			@v_DetailResult BIT = 1
	EXEC DBTD_LOG_MESSAGE_EXT 'DEBUG', @v_ProcName, @v_Message ;

	IF	@v_Pattern IS NULL
		OR @v_String IS NULL
		OR NOT EXISTS( 
				SELECT * 
				FROM (SELECT @v_String AS v_String) AS S
				WHERE S.v_String LIKE '%'+@v_Pattern+'%'
				)
	BEGIN

		SET @v_DetailResult = dbo.DBTD_fnUseDetailCommentMessage()
		IF @v_DetailResult = 1 
		BEGIN
			SET @v_Message = ISNULL(@v_UserMessage + '.', '') 
				+ ' Could not find ' 
				+ ' PATTERN: "' + ISNULL(@v_Pattern,'NULL') + '"'
				+ ' in the STRING: "' + ISNULL(@v_String,'NULL') + '"'; 
		END
		ELSE BEGIN
			SET @v_Message = @v_UserMessage; 
		END 
		EXEC DBTD_FAILURE @v_Message; 
	END;
END;
GO

--************************************************************************************************
--Will NOT fail if pattern or string is set to NULL
--DROP PROC DBTD_ASSERT_STRING_NOT_CONTAIN
CREATE PROCEDURE DBTD_ASSERT_STRING_NOT_CONTAIN
(
	@v_Pattern		NVARCHAR(4000), --An expression that contains the string to be found. 
	@v_String		NVARCHAR(4000), --String that is searched for the specified pattern
	@v_UserMessage	NVARCHAR(MAX)
)
WITH ENCRYPTION AS
BEGIN
	SET NOCOUNT ON;
	DECLARE @v_ProcName	NVARCHAR(128) = OBJECT_NAME(@@PROCID)
	DECLARE @v_Message NVARCHAR(MAX) = 'Running ' + @v_ProcName;
	EXEC DBTD_LOG_MESSAGE_EXT 'DEBUG', @v_ProcName, @v_Message ;

	IF	@v_Pattern IS NOT NULL
		AND @v_String IS NOT NULL
		AND EXISTS( 
				SELECT * 
				FROM (SELECT @v_String AS v_String) AS S
				WHERE S.v_String LIKE '%'+@v_Pattern+'%'
				)
	BEGIN
		SET @v_Message = ISNULL(@v_UserMessage + '.', '')
			+ ' Could not find ' 
			+ ' PATTERN: "' + ISNULL(@v_Pattern,'NULL') + '"'
			+ ' in the STRING: "' + ISNULL(@v_String,'NULL') + '"'; 
		EXEC DBTD_FAILURE @v_Message; 
	END;
END;
GO

--************************************************************************************************
-- Assert procedure that takes actual and expected INT, BIGINT, TINYINT, or SMALLINT values, 
-- compares them for equality and report failure if they are not equal
-- Value range is from -2^63 (-9,223,372,036,854,775,808) to 2^63-1 (9,223,372,036,854,775,807)
CREATE PROCEDURE DBTD_ASSERT_INT_ARE_EQUAL 
(
	@v_ActualValue		BIGINT, 
	@v_ExpectedValue	BIGINT, 
	@v_UserMessage		NVARCHAR(MAX)
)
WITH ENCRYPTION AS
BEGIN
	SET NOCOUNT ON;
	DECLARE @v_ProcName	NVARCHAR(128) = OBJECT_NAME(@@PROCID)
	DECLARE @v_Message VARCHAR(MAX) = 'Running ' + @v_ProcName;
	EXEC DBTD_LOG_MESSAGE_EXT 'DEBUG', @v_ProcName, @v_Message ;

	IF	@v_ActualValue IS NULL
		OR @v_ExpectedValue IS NULL
		OR (@v_ActualValue != @v_ExpectedValue) 
	BEGIN
		SET @v_Message = ISNULL(@v_UserMessage + '.', '')
			+ ' Actual value is NOT EQUAL Expected value. ' 
			+ ' EXPECTED: ' + ISNULL(CAST(@v_ExpectedValue AS VARCHAR(MAX)),'NULL') 
			+ ' ACTUAL: ' + ISNULL(CAST(@v_ActualValue AS VARCHAR(MAX)),'NULL') ; 
		EXEC DBTD_FAILURE @v_Message; 
	END;
END;
GO

--************************************************************************************************
-- Assert procedure takes actual and expected MONEY or SMALLMONEY values, 
-- compares them for equality and report failure if they are not equal
-- Value range is from -922,337,203,685,477.5808 to 922,337,203,685,477.5807
CREATE PROCEDURE DBTD_ASSERT_MONEY_ARE_EQUAL 
(
	@v_ActualValue		MONEY, 
	@v_ExpectedValue	MONEY, 
	@v_UserMessage		NVARCHAR(MAX)
)
WITH ENCRYPTION AS
BEGIN
	SET NOCOUNT ON;
	DECLARE @v_ProcName	NVARCHAR(128) = OBJECT_NAME(@@PROCID)
	DECLARE @v_Message NVARCHAR(MAX) = 'Running ' + @v_ProcName;
	EXEC DBTD_LOG_MESSAGE_EXT 'DEBUG', @v_ProcName, @v_Message ;

	IF	@v_ActualValue IS NULL
		OR @v_ExpectedValue IS NULL
		OR (@v_ActualValue != @v_ExpectedValue) 
	BEGIN
		SET @v_Message = ISNULL(@v_UserMessage + '.', '')
			+ ' Actual value is NOT EQUAL Expected value. ' 
			+ ' EXPECTED: ' + ISNULL(CAST(@v_ExpectedValue AS VARCHAR(MAX)),'NULL') 
			+ ' ACTUAL: ' + ISNULL(CAST(@v_ActualValue AS VARCHAR(MAX)),'NULL') ; 
		EXEC DBTD_FAILURE @v_Message; 
	END;
END;
GO

--************************************************************************************************
-- Assert procedure that takes actual and expected FLOAT values, 
-- compares them for equality and report failure if they are not equal
-- Value range is from -1.79E+308 to -2.23E-308, 0 and 2.23E-308 to 1.79E+308
CREATE PROCEDURE DBTD_ASSERT_FLOAT_ARE_EQUAL 
(
	@v_ActualValue		FLOAT(53), 
	@v_ExpectedValue	FLOAT(53), 
	@v_UserMessage		NVARCHAR(MAX)
)
WITH ENCRYPTION AS
BEGIN
	SET NOCOUNT ON;
	DECLARE @v_ProcName	NVARCHAR(128) = OBJECT_NAME(@@PROCID)
	DECLARE @v_Message NVARCHAR(MAX) = 'Running ' + @v_ProcName;
	EXEC DBTD_LOG_MESSAGE_EXT 'DEBUG', @v_ProcName, @v_Message ;

	IF	@v_ActualValue IS NULL
		OR @v_ExpectedValue IS NULL
		OR (@v_ActualValue != @v_ExpectedValue) 
	BEGIN
		SET @v_Message = ISNULL(@v_UserMessage + '.', '')
			+ ' Actual value is NOT EQUAL Expected value. ' 
			+ ' EXPECTED: ' + ISNULL(CAST(@v_ExpectedValue AS VARCHAR(MAX)),'NULL') 
			+ ' ACTUAL: ' + ISNULL(CAST(@v_ActualValue AS VARCHAR(MAX)),'NULL') ; 
		EXEC DBTD_FAILURE @v_Message; 
	END;
END;
GO

--************************************************************************************************
-- Assert procedure that takes actual and expected DATE values, 
-- compares them for equality and report failure if they are not equal
CREATE PROCEDURE DBTD_ASSERT_DATE_ARE_EQUAL 
(
	@v_ActualValue		DATE, 
	@v_ExpectedValue	DATE, 
	@v_UserMessage		NVARCHAR(MAX)
)
WITH ENCRYPTION AS
BEGIN
	SET NOCOUNT ON;
	DECLARE @v_ProcName	NVARCHAR(128) = OBJECT_NAME(@@PROCID)
	DECLARE @v_Message NVARCHAR(MAX) = 'Running ' + @v_ProcName;
	EXEC DBTD_LOG_MESSAGE_EXT 'DEBUG', @v_ProcName, @v_Message ;

	IF	@v_ActualValue IS NULL
		OR @v_ExpectedValue IS NULL
		OR (@v_ActualValue != @v_ExpectedValue) 
	BEGIN
		SET @v_Message = ISNULL(@v_UserMessage + '.', '')
			+ ' Actual value is NOT EQUAL Expected value. ' 
			+ ' EXPECTED: ' + ISNULL(CAST(@v_ExpectedValue AS VARCHAR(MAX)),'NULL') 
			+ ' ACTUAL: ' + ISNULL(CAST(@v_ActualValue AS VARCHAR(MAX)),'NULL') ; 
		EXEC DBTD_FAILURE @v_Message; 
	END;
END;
GO

--************************************************************************************************
-- Assert procedure that takes actual and expected DATETIME values, 
-- compares them for equality and report failure if they are not equal
CREATE PROCEDURE DBTD_ASSERT_DATETIME_ARE_EQUAL 
(
	@v_ActualValue		DATETIME, 
	@v_ExpectedValue	DATETIME, 
	@v_UserMessage		NVARCHAR(MAX)
)
WITH ENCRYPTION AS
BEGIN
	SET NOCOUNT ON;
	DECLARE @v_ProcName	NVARCHAR(128) = OBJECT_NAME(@@PROCID)
	DECLARE @v_Message NVARCHAR(MAX) = 'Running ' + @v_ProcName;
	EXEC DBTD_LOG_MESSAGE_EXT 'DEBUG', @v_ProcName, @v_Message ;

	IF	@v_ActualValue IS NULL
		OR @v_ExpectedValue IS NULL
		OR (@v_ActualValue != @v_ExpectedValue) 
	BEGIN
		SET @v_Message = ISNULL(@v_UserMessage + '.', '')
			+ ' Actual value is NOT EQUAL Expected value. ' 
			+ ' EXPECTED: ' + ISNULL(CAST(@v_ExpectedValue AS VARCHAR(MAX)),'NULL') 
			+ ' ACTUAL: ' + ISNULL(CAST(@v_ActualValue AS VARCHAR(MAX)),'NULL') ; 
		EXEC DBTD_FAILURE @v_Message; 
	END;
END;
GO

--************************************************************************************************
-- Assert procedure that takes actual and expected HIERARCHYID values, 
-- compares them for equality and report failure if they are not equal
CREATE PROCEDURE DBTD_ASSERT_HIERARCHYID_ARE_EQUAL 
(
	@v_ActualValue		HIERARCHYID, 
	@v_ExpectedValue	HIERARCHYID, 
	@v_UserMessage		NVARCHAR(MAX)
)
WITH ENCRYPTION AS
BEGIN
	SET NOCOUNT ON;
	DECLARE @v_ProcName	NVARCHAR(128) = OBJECT_NAME(@@PROCID)
	DECLARE @v_Message NVARCHAR(MAX) = 'Running ' + @v_ProcName;
	EXEC DBTD_LOG_MESSAGE_EXT 'DEBUG', @v_ProcName, @v_Message ;

	IF	@v_ActualValue IS NULL
		OR @v_ExpectedValue IS NULL
		OR (@v_ActualValue != @v_ExpectedValue) 
	BEGIN
		SET @v_Message = ISNULL(@v_UserMessage + '.', '')
			+ ' Actual value is NOT EQUAL Expected value. ' 
			+ ' EXPECTED: ' + ISNULL(CAST(@v_ExpectedValue AS VARCHAR(MAX)),'NULL') 
			+ ' ACTUAL: ' + ISNULL(CAST(@v_ActualValue AS VARCHAR(MAX)),'NULL') ; 
		EXEC DBTD_FAILURE @v_Message; 
	END;
END;
GO

--************************************************************************************************
-- Assert procedure that takes actual and expected HIERARCHYID values, 
-- compares them for equality and report failure if they are not equal
CREATE PROCEDURE DBTD_ASSERT_SQLVARIANT_ARE_EQUAL 
(
	@v_ActualValue		SQL_VARIANT, 
	@v_ExpectedValue	SQL_VARIANT, 
	@v_UserMessage		NVARCHAR(MAX)
)
WITH ENCRYPTION AS
BEGIN
	SET NOCOUNT ON;
	DECLARE @v_ProcName	NVARCHAR(128) = OBJECT_NAME(@@PROCID)
	DECLARE @v_Message NVARCHAR(MAX) = 'Running ' + @v_ProcName;
	EXEC DBTD_LOG_MESSAGE_EXT 'DEBUG', @v_ProcName, @v_Message ;

	IF	@v_ActualValue IS NULL
		OR @v_ExpectedValue IS NULL
		OR (@v_ActualValue != @v_ExpectedValue) 
	BEGIN
		SET @v_Message = ISNULL(@v_UserMessage + '.', '')
			+ ' Actual value is NOT EQUAL Expected value. ' 
			+ ' EXPECTED: ' + ISNULL(CAST(@v_ExpectedValue AS VARCHAR(MAX)),'NULL') 
			+ ' ACTUAL: ' + ISNULL(CAST(@v_ActualValue AS VARCHAR(MAX)),'NULL') ; 
		EXEC DBTD_FAILURE @v_Message; 
	END;
END;
GO

--************************************************************************************************
-- Assert procedure that takes actual value, expected value, compares them for equality 
-- report failure if values are equal
CREATE PROCEDURE DBTD_ASSERT_ARE_NOT_EQUAL
(
	@v_ActualValue		NVARCHAR(MAX), 
	@v_ExpectedValue	NVARCHAR(MAX), 
	@v_UserMessage		NVARCHAR(MAX)
)
WITH ENCRYPTION AS
BEGIN
	SET NOCOUNT ON;
	DECLARE @v_ProcName	NVARCHAR(128) = OBJECT_NAME(@@PROCID)
	DECLARE @v_Message NVARCHAR(MAX) = 'Running ' + @v_ProcName;
	EXEC DBTD_LOG_MESSAGE_EXT 'DEBUG', @v_ProcName, @v_Message ;
	
	IF (@v_ActualValue = @v_ExpectedValue)  
	BEGIN
		SET @v_Message = ISNULL(@v_UserMessage + '.', '') 
			+ ' Actual value is EQUAL to Not Expected value. ' 
			+ ' NOT EXPECTED: ' + ISNULL(@v_ExpectedValue, 'NULL') 
			+ ' ACTUAL: ' + ISNULL(@v_ActualValue,'NULL') ; 
		EXEC DBTD_FAILURE @v_Message; 
	END;
END;
GO

--************************************************************************************************
-- Assert procedure that takes actual value, expected value, 
-- and checks that actual value is greater or equal then expected value 
-- report failure if values is equal or smaller
CREATE PROCEDURE DBTD_ASSERT_IS_LESS_OR_EQUAL 
(
	@v_ActualValue		DECIMAL(18,8),
	@v_ExpectedValue	DECIMAL(18,8),
	@v_UserMessage		NVARCHAR(MAX)
)
WITH ENCRYPTION AS
BEGIN
	SET NOCOUNT ON;
	DECLARE @v_ProcName	NVARCHAR(128) = OBJECT_NAME(@@PROCID)
	DECLARE @v_Message NVARCHAR(MAX) = 'Running ' + @v_ProcName;
	EXEC DBTD_LOG_MESSAGE_EXT 'DEBUG', @v_ProcName, @v_Message ;

	IF (@v_ActualValue > @v_ExpectedValue)  
	BEGIN
		SET @v_Message = ISNULL(@v_UserMessage + '.', '') 
			+ ' Actual value is NOT LESS OR EQUAL Expected value. ' 
			+ ' EXPECTED: ' + CAST(@v_ExpectedValue AS  VARCHAR(255))
			+ ' ACTUAL: ' + CAST(@v_ActualValue AS  VARCHAR(255)) ; 
		EXEC DBTD_FAILURE @v_Message; 
	END;
END;
GO

--************************************************************************************************
-- Assert procedure that takes actual value, expected value, 
-- and checks that actual value is greater than expected value 
-- report failure if values is equal or smaller
CREATE PROCEDURE DBTD_ASSERT_IS_GREATER 
(
	@v_ActualValue		DECIMAL(18,8),
	@v_ExpectedValue	DECIMAL(18,8),
	@v_UserMessage		NVARCHAR(MAX)
)
WITH ENCRYPTION AS
BEGIN
	SET NOCOUNT ON;
	DECLARE @v_ProcName	NVARCHAR(128) = OBJECT_NAME(@@PROCID)
	DECLARE @v_Message NVARCHAR(MAX) = 'Running ' + @v_ProcName;
	EXEC DBTD_LOG_MESSAGE_EXT 'DEBUG', @v_ProcName, @v_Message ;

	IF (@v_ActualValue <= @v_ExpectedValue) 
	BEGIN
		SET @v_Message = ISNULL(@v_UserMessage + '.', '') 
			+ ' Actual value is NOT GREATER then Expected value. ' 
			+ ' EXPECTED: ' + CAST(@v_ExpectedValue AS  VARCHAR(255))
			+ ' ACTUAL: ' + CAST(@v_ActualValue AS  VARCHAR(255)) ; 
		EXEC DBTD_FAILURE @v_Message; 
	END;
END;
GO

--************************************************************************************************
-- Assert procedure that takes actual DATETIME value, expected DATETIME value, 
-- and checks that actual DATETIME value is greater than expected DATETIME value 
-- report failure if values is equal or smaller
CREATE PROCEDURE DBTD_ASSERT_DATETIME_IS_GREATER 
(
	@v_ActualValue		DATETIME,
	@v_ExpectedValue	DATETIME,
	@v_UserMessage		NVARCHAR(MAX)
)
WITH ENCRYPTION AS
BEGIN
	SET NOCOUNT ON;
	DECLARE @v_ProcName	NVARCHAR(128) = OBJECT_NAME(@@PROCID)
	DECLARE @v_Message NVARCHAR(MAX) = 'Running ' + @v_ProcName;
	EXEC DBTD_LOG_MESSAGE_EXT 'DEBUG', @v_ProcName, @v_Message ;

	IF (@v_ActualValue <= @v_ExpectedValue)  
	BEGIN
		SET @v_Message = ISNULL(@v_UserMessage + '.', '') 
			+ ' Actual value is NOT GREATER then Expected value. ' 
			+ ' EXPECTED: ' + CAST(@v_ExpectedValue AS  VARCHAR(255))
			+ ' ACTUAL: ' + CAST(@v_ActualValue AS  VARCHAR(255)) ; 
		EXEC DBTD_FAILURE @v_Message; 
	END;
END;
GO

--************************************************************************************************
-- Assert procedure that takes actual DATETIME value, expected DATETIME value, 
-- and checks that actual DATETIME value is greater or equal then expected DATETIME value 
-- report failure if values is smaller
CREATE PROCEDURE DBTD_ASSERT_DATETIME_IS_GREATER_OR_EQUAL 
(
	@v_ActualValue		DATETIME,
	@v_ExpectedValue	DATETIME,
	@v_UserMessage		NVARCHAR(MAX)
)
WITH ENCRYPTION AS
BEGIN
	SET NOCOUNT ON;
	DECLARE @v_ProcName	NVARCHAR(128) = OBJECT_NAME(@@PROCID)
	DECLARE @v_Message NVARCHAR(MAX) = 'Running ' + @v_ProcName;
	EXEC DBTD_LOG_MESSAGE_EXT 'DEBUG', @v_ProcName, @v_Message ;

	IF (@v_ActualValue < @v_ExpectedValue)  
	BEGIN 
		SET @v_Message = ISNULL(@v_UserMessage + '.', '') 
			+ ' Actual value is NOT GREATER OR EQUAL to Expected value. ' 
			+ ' EXPECTED: ' + CAST(@v_ExpectedValue AS  VARCHAR(255))
			+ ' ACTUAL: ' + CAST(@v_ActualValue AS  VARCHAR(255)) ; 
		EXEC DBTD_FAILURE @v_Message; 
	END;
END;
GO

--************************************************************************************************
--checks if BIT value is true and reports failure if it is not
--note: TRUE is any number but 0
--      FALSE is 0
CREATE PROCEDURE DBTD_ASSERT_IS_TRUE 
(
	@v_ActualValue BIT,
	@v_UserMessage NVARCHAR(MAX)
)
WITH ENCRYPTION AS
BEGIN
	SET NOCOUNT ON;
	DECLARE @v_ProcName	NVARCHAR(128) = OBJECT_NAME(@@PROCID)
	DECLARE @v_Message NVARCHAR(MAX) = 'Running ' + @v_ProcName;
	EXEC DBTD_LOG_MESSAGE_EXT 'DEBUG', @v_ProcName, @v_Message ;

	IF (@v_ActualValue != 1 )  
	BEGIN 
		SET @v_Message = ISNULL(@v_UserMessage + '.', '') + ' Actual value is NOT TRUE.' 
		EXEC DBTD_FAILURE @v_Message; 
	END;
END;
GO

--************************************************************************************************
--checks that provided value is not null
CREATE PROCEDURE DBTD_ASSERT_IS_NOT_NULL
(
	@v_ActualValue NVARCHAR(4000),
	@v_UserMessage NVARCHAR(MAX)
)
WITH ENCRYPTION AS
BEGIN
	SET NOCOUNT ON;
	DECLARE @v_ProcName	NVARCHAR(128) = OBJECT_NAME(@@PROCID)
	DECLARE @v_Message NVARCHAR(MAX) = 'Running ' + @v_ProcName;
	EXEC DBTD_LOG_MESSAGE_EXT 'DEBUG', @v_ProcName, @v_Message ;

	IF (@v_ActualValue IS NULL )  
	BEGIN 
		SET @v_Message = ISNULL(@v_UserMessage + '.', '') + ' Actual value is NULL.' 
		EXEC DBTD_FAILURE @v_Message; 
	END;
END;
GO

--************************************************************************************************
--checks that provided value is not null or empty
CREATE PROCEDURE DBTD_ASSERT_IS_NOT_NULL_OR_EMPTY
(
	@v_ActualValue NVARCHAR(4000),
	@v_UserMessage NVARCHAR(MAX)
)
WITH ENCRYPTION AS
BEGIN
	SET NOCOUNT ON;
	DECLARE @v_ProcName	NVARCHAR(128) = OBJECT_NAME(@@PROCID)
	DECLARE @v_Message NVARCHAR(MAX) = 'Running ' + @v_ProcName;
	EXEC DBTD_LOG_MESSAGE_EXT 'DEBUG', @v_ProcName, @v_Message ;

	IF (@v_ActualValue IS NULL OR LTRIM(RTRIM(@v_ActualValue)) = '')  
	BEGIN 
		SET @v_Message = ISNULL(@v_UserMessage + '.', '') + ' Actual value is NULL or EMPTY.' 
		EXEC DBTD_FAILURE @v_Message; 
	END;
END;
GO

--************************************************************************************************
--checks that provided value is null
CREATE PROCEDURE DBTD_ASSERT_IS_NULL
(
	@v_ActualValue NVARCHAR(4000),
	@v_UserMessage NVARCHAR(MAX)
)
WITH ENCRYPTION AS
BEGIN
	SET NOCOUNT ON;
	DECLARE @v_ProcName	NVARCHAR(128) = OBJECT_NAME(@@PROCID)
	DECLARE @v_Message NVARCHAR(MAX) = 'Running ' + @v_ProcName;
	EXEC DBTD_LOG_MESSAGE_EXT 'DEBUG', @v_ProcName, @v_Message ;

	IF (@v_ActualValue IS NOT NULL)  
	BEGIN 
		SET @v_Message = ISNULL(@v_UserMessage + '.', '') + ' Actual value is NOT NULL.' 
		EXEC DBTD_FAILURE @v_Message; 
	END;
END;
GO

--************************************************************************************************
--checks that provided value is null or empty
CREATE PROCEDURE DBTD_ASSERT_IS_NULL_OR_EMPTY
(
	@v_ActualValue NVARCHAR(4000),
	@v_UserMessage NVARCHAR(MAX)
)
WITH ENCRYPTION AS
BEGIN
	SET NOCOUNT ON;
	DECLARE @v_ProcName	NVARCHAR(128) = OBJECT_NAME(@@PROCID)
	DECLARE @v_Message NVARCHAR(MAX) = 'Running ' + @v_ProcName;
	EXEC DBTD_LOG_MESSAGE_EXT 'DEBUG', @v_ProcName, @v_Message ;

	IF (@v_ActualValue IS NOT NULL AND LTRIM(RTRIM(@v_ActualValue)) != '')  
	BEGIN 
		SET @v_Message = ISNULL(@v_UserMessage + '.', '') + ' Actual value is NOT NULL or NOT EMPTY.' 
		EXEC DBTD_FAILURE @v_Message; 
	END;
END;
GO

--************************************************************************************************
--CORE HINT
--Identifies a Unit Test, Setup or Teardown stored procedures that belongs to a given Test Suite.
--Note: DO NOT USE VARIABLES AFTER HINT NAME, instead just type the name of thE suite like you will do any other string constant ''
--Note: Unit Test can belong only to one test suite, 
--      while Setup and Teardown procedures can belong to multiple test suites.  
--Note: If Suite Name set to be NULL, EMPTY string, or value of a variable then such test will be placed under GenericUnitTests suite 
--Note: Legacy naming convention "UT_SuiteName_TestName" is inforced the same way as before and take presedence.
--      over test suite assignment done by DBTD_UNIT_TEST procedure.
CREATE PROCEDURE DBTD_UNIT_TEST  
( 
	@v_TestSuite SYSNAME,	--Name of the Unit Test Suite
	@v_TestName	 NVARCHAR(128) = NULL --OPTIONAL: Reserverd for internal use only
)
WITH ENCRYPTION AS
BEGIN
	SET NOCOUNT ON;
	DECLARE @v_ProcName	NVARCHAR(128) = OBJECT_NAME(@@PROCID)
	DECLARE @v_Message NVARCHAR(MAX) = 'Suite: ' + ISNULL(@v_TestSuite,'NULL') + ' Running hint procedure:' + @v_ProcName;
	EXEC DBTD_LOG_MESSAGE_EXT 'DEBUG', @v_ProcName, @v_Message ;

	--remove all values from the manual table
	DELETE FROM DBTD_TBL_MANUAL_UNITTESTRUNID;

	IF  OBJECT_ID('tempdb.dbo.#DBTD_CurrentUnitTestRunID') IS NULL 
	BEGIN
		INSERT INTO DBTD_TBL_MANUAL_UNITTESTRUNID
			(UnitTestRunID, UnitTestName)
			VALUES (ROUND(RAND() * 10000000, 0) * -1, @v_TestName);
	END
END;
GO

--************************************************************************************************
--CORE HINT
--For compatebility reasons serves as an identifier of a NON Unit Test stored procedures 
--that are named using older naming convention UT_SuiteName_TestName.
--Note: Legacy naming convention "UT_SuiteName_TestName" is inforced the same way as before and take presedence.
--      over test suite assignment done by DBTD_UNIT_TEST procedure
--Note: if both DBTD_UNIT_TEST and DBTD_NOT_A_UNIT_TEST procedures used in the unit test then 
--      DBTD_NOT_A_UNIT_TEST will 
CREATE PROCEDURE DBTD_NOT_A_UNIT_TEST
( 
	@v_Message	NVARCHAR(MAX) = 'This is not a unit test'	--Message 
)
WITH ENCRYPTION AS
BEGIN
	SET NOCOUNT ON;
	DECLARE @v_TmpMessage NVARCHAR(MAX) = '%THIS IS NOT A UNIT TEST';
END;
GO

--************************************************************************************************
--CORE HINT
--procedure itself does nothing, however if it is found anywhere in the body of the unit test procedure code 
--then execution of the test will be ignored all together
CREATE PROCEDURE DBTD_IGNORE
( 
	@v_Message NVARCHAR(MAX) = 'This uni test will be ignored' --Message 
)
WITH ENCRYPTION AS
BEGIN
	SET NOCOUNT ON;
	DECLARE @v_ProcName	NVARCHAR(128) = OBJECT_NAME(@@PROCID)
	DECLARE @v_TempMessage NVARCHAR(MAX) = 'Running ' + @v_ProcName + ' with message ' + ISNULL(@v_Message,'NULL');
	EXEC DBTD_LOG_MESSAGE_EXT 'INFO', @v_ProcName, @v_TempMessage ;
END;
GO

--************************************************************************************************
--CORE HINT
--if this procedure is found anywhere in the body of the suite setup or teardown then setup will execute ONLY ONCE 
--once per suite and will not execute for the each test same will happen with teardown procedure. 
CREATE PROCEDURE DBTD_RUN_ONCE 
( 
	@v_Message	NVARCHAR(MAX) = 'This procedure will only run once'	--Message 
)
WITH ENCRYPTION AS
BEGIN
	SET NOCOUNT ON;
	DECLARE @v_ProcName	NVARCHAR(128) = OBJECT_NAME(@@PROCID)
	DECLARE @v_TempMessage NVARCHAR(MAX) = 'Running ' + @v_ProcName + ' Hint Procedure';
	EXEC DBTD_LOG_MESSAGE_EXT 'DEBUG', @v_ProcName, @v_TempMessage ;

	SET @v_Message = 'EXEC ' + @v_ProcName + ' with message: ' + ISNULL(@v_Message, 'NULL');
	EXEC DBTD_LOG_MESSAGE_EXT 'INFO', @v_ProcName, @v_Message;
END;
GO

--************************************************************************************************
--CORE HINT
--if this procedure is found anywhere in the body of the unit test then test will be wrapped into 
--a transaction that will be rolled back at the end of the test and will return database in to a 
--pre-test state 
CREATE PROCEDURE DBTD_USE_TRANSACTION 
( 
	@v_Message	NVARCHAR(MAX) = 'Transactions will be used'	--Message 
)
WITH ENCRYPTION AS
BEGIN
	SET NOCOUNT ON;
	DECLARE @v_ProcName	NVARCHAR(128) = OBJECT_NAME(@@PROCID)
	DECLARE @v_TempMessage NVARCHAR(MAX) = 'Running ' + @v_ProcName + ' Hint Procedure with message: ' + ISNULL(@v_Message, 'NULL');
	EXEC DBTD_LOG_MESSAGE_EXT 'DEBUG', @v_ProcName, @v_TempMessage ;
END;
GO

--************************************************************************************************
--CORE HINT
--if this procedure is found anywhere in the body of the unit test then test will be wrapped into 
--a transaction that will be rolled back at the end of the test and will return database in to a 
--pre-test state 
CREATE PROCEDURE DBTD_DO_NOT_USE_TRANSACTION 
( 
	@v_Message	NVARCHAR(MAX) = 'Transaction will not be used'	--Message 
)
WITH ENCRYPTION AS
BEGIN
	SET NOCOUNT ON;
	DECLARE @v_ProcName	NVARCHAR(128) = OBJECT_NAME(@@PROCID)
	DECLARE @v_TempMessage NVARCHAR(MAX) = 'Running ' + @v_ProcName + ' Hint Procedure with message: ' + ISNULL(@v_Message, 'NULL');
	EXEC DBTD_LOG_MESSAGE_EXT 'DEBUG', @v_ProcName, @v_TempMessage ;
END;
GO

--************************************************************************************************
--INTERNAL: Do not use this procedure in your unit tests, procedure can be removed,
--          signature or procedure name can be changed at any release
--DROP FUNCTION DBTD_fnUseDetailCommentMessage
CREATE FUNCTION DBTD_fnUseDetailCommentMessage()
RETURNS BIT
WITH ENCRYPTION AS 
BEGIN
	DECLARE @v_UseDetailCommentMessage BIT = 1,
			@v_Object_ID BIGINT = OBJECT_ID('tempdb.dbo.#DBTD_DoNotUseDetailCommentMessage')
	IF @v_Object_ID  IS NOT NULL 
	BEGIN
		SET @v_UseDetailCommentMessage = 0
	END
	RETURN @v_UseDetailCommentMessage
END;
GO

--************************************************************************************************
--INTERNAL: Do not use this procedure in your unit tests, procedure can be removed,
--          signature or procedure name can be changed at any release
--DROP FUNCTION DBTD_fnRemoveFirstLineComment
CREATE FUNCTION DBTD_fnRemoveFirstLineComment
(
	@v_TextBlock NVARCHAR(MAX)
)
RETURNS NVARCHAR(MAX)
WITH ENCRYPTION AS 
BEGIN
	DECLARE @v_Pattern		NVARCHAR(10) = '%--%'
	DECLARE @v_ReturnValue	NVARCHAR(MAX) = @v_TextBlock,
			@v_OpenIndex	BIGINT = PATINDEX(@v_Pattern,@v_TextBlock),
			@v_CloseIndexA	BIGINT,
			@v_CloseIndexB	BIGINT,
			@v_CloseIndexC	BIGINT,
			@v_TextBlockLen	BIGINT = LEN(@v_TextBlock),
			@v_NewBlockLeft	NVARCHAR(MAX),
			@v_NewBlockRight NVARCHAR(MAX)
	DECLARE @v_CloseIndex	BIGINT = @v_OpenIndex --closes the same place it oppens by default 
	
	IF @v_OpenIndex != 0 AND @v_TextBlock IS NOT NULL
	BEGIN
		SET @v_NewBlockLeft = ISNULL(SUBSTRING(@v_TextBlock,1,@v_OpenIndex-1), '')  
		SET @v_NewBlockRight = ISNULL(SUBSTRING(@v_TextBlock,@v_OpenIndex,@v_TextBlockLen), '')  

		SET @v_CloseIndexA = PATINDEX('%'+CHAR(13)+CHAR(10)+'%',@v_NewBlockRight)
		SET	@v_CloseIndexB = PATINDEX('%'+CHAR(13)+'%',@v_NewBlockRight)
		SET	@v_CloseIndexC = PATINDEX('%'+CHAR(10)+'%',@v_NewBlockRight)			

		IF @v_CloseIndexA = 0 AND @v_CloseIndexB = 0 AND @v_CloseIndexC = 0 SET @v_CloseIndex = @v_TextBlockLen + 1 --closing all up it is all comment
			ELSE IF @v_CloseIndexA != 0 
					AND @v_CloseIndexA <= (CASE WHEN @v_CloseIndexB = 0 THEN @v_TextBlockLen ELSE @v_CloseIndexB END) 
					AND @v_CloseIndexA <= (CASE WHEN @v_CloseIndexC = 0 THEN @v_TextBlockLen ELSE @v_CloseIndexC END)  
					SET @v_CloseIndex = @v_CloseIndexA
			ELSE IF @v_CloseIndexB != 0 
					AND @v_CloseIndexB <  (CASE WHEN @v_CloseIndexA = 0 THEN @v_TextBlockLen ELSE @v_CloseIndexA END) 
					AND @v_CloseIndexB <  (CASE WHEN @v_CloseIndexC = 0 THEN @v_TextBlockLen ELSE @v_CloseIndexC END)  
					SET @v_CloseIndex = @v_CloseIndexB
			ELSE IF @v_CloseIndexC != 0 
					AND @v_CloseIndexC <  (CASE WHEN @v_CloseIndexA = 0 THEN @v_TextBlockLen ELSE @v_CloseIndexA END) 
					AND @v_CloseIndexC <  (CASE WHEN @v_CloseIndexB = 0 THEN @v_TextBlockLen ELSE @v_CloseIndexB END)  
					SET @v_CloseIndex = @v_CloseIndexC
			
		SET @v_NewBlockRight = ISNULL(SUBSTRING(@v_NewBlockRight,@v_CloseIndex,@v_TextBlockLen), '');  
		SET @v_ReturnValue = @v_NewBlockLeft + @v_NewBlockRight;
	END
	RETURN @v_ReturnValue;		
END 
GO 

--************************************************************************************************
--INTERNAL: Do not use this procedure in your unit tests, procedure can be removed,
--          signature or procedure name can be changed at any release
CREATE FUNCTION DBTD_fnRemoveFirstBlockComment
(
	@v_TextBlock NVARCHAR(MAX)
)
RETURNS NVARCHAR(MAX)
WITH ENCRYPTION AS 
BEGIN
	DECLARE @v_OpenPattern	NVARCHAR(10) = '%/*%',
			@v_ClosePattern	NVARCHAR(10) = '%*/%'
	DECLARE @v_ReturnValue	NVARCHAR(MAX) = @v_TextBlock,
			@v_CurrentIndex	BIGINT,
			@v_OpenIndex	BIGINT = PATINDEX(@v_OpenPattern,@v_TextBlock),
			@v_TextBlockLen	BIGINT = LEN(@v_TextBlock),
			@v_OpenCount	INT = 0,
			@v_CloseCount	INT = 0,
			@v_NewBlockLeft	NVARCHAR(MAX),
			@v_NewBlockRight NVARCHAR(MAX)
	DECLARE @v_CloseIndex	BIGINT = @v_OpenIndex --closes the same place it oppens by default 
	
	IF @v_OpenIndex != 0 AND @v_TextBlock IS NOT NULL
	BEGIN
		SET @v_NewBlockLeft = ISNULL(SUBSTRING(@v_TextBlock,1,@v_OpenIndex-1), '')  
		SET @v_CurrentIndex	= @v_OpenIndex;
		SET @v_NewBlockRight = @v_TextBlock;
		
		WHILE (@v_CurrentIndex < @v_TextBlockLen)
			AND (@v_OpenIndex != 0 OR @v_CloseIndex != 0) 	
		BEGIN
			SET @v_NewBlockRight = ISNULL(SUBSTRING(@v_NewBlockRight,@v_CurrentIndex,@v_TextBlockLen), '')  
			SET @v_CurrentIndex = 1
			SET @v_OpenIndex = PATINDEX(@v_OpenPattern,@v_NewBlockRight)
			SET @v_CloseIndex = PATINDEX(@v_ClosePattern,@v_NewBlockRight)

			IF @v_OpenIndex = 1 
			BEGIN 
				SET @v_CurrentIndex = @v_CurrentIndex + 2;
				SET @v_OpenCount = @v_OpenCount + 1
			END
			ELSE IF @v_CloseIndex = 1 
				BEGIN
					SET @v_CurrentIndex = @v_CurrentIndex + 2;
					SET @v_CloseCount = @v_CloseCount + 1
				END
				ELSE IF @v_OpenIndex = 0 AND @v_CloseIndex = 0
					BEGIN 
						--could not find closing tag
						SET @v_NewBlockRight = ''; 
						BREAK;	
					END
					ELSE SET @v_CurrentIndex = @v_CurrentIndex + 1;

			IF (@v_OpenCount = @v_CloseCount) 
			BEGIN
				SET @v_NewBlockRight = ISNULL(SUBSTRING(@v_NewBlockRight,@v_CurrentIndex,@v_TextBlockLen), '')  
				BREAK;
			END
		END
		SET @v_ReturnValue = @v_NewBlockLeft + @v_NewBlockRight;
	END
	RETURN @v_ReturnValue;		
END 
GO 

--************************************************************************************************
--INTERNAL: Do not use this procedure in your unit tests, procedure can be removed,
--          signature or procedure name can be changed at any release
CREATE FUNCTION DBTD_fnGetEndOfStringIndexForTheFirstString
(
	@v_TextBlock NVARCHAR(MAX)
)
RETURNS BIGINT
WITH ENCRYPTION AS 
BEGIN
	--Returns the ending position of the first string predicate in a specified text bloc, the index will point 
	--to the closing single quote. 
	--If string predicate not found returns 0 (zero)
	--If beginnig of string found but the end is not then returns 0 (zero);
	DECLARE @v_QuoteIdentifier	NVARCHAR(5) = '''',
			@v_TextBlockLen		BIGINT = LEN(@v_TextBlock)
	
	DECLARE @v_EndOfStringIndex	BIGINT = 0,
			@v_BeginOfStringIndex BIGINT = CHARINDEX( @v_QuoteIdentifier, @v_TextBlock), --Get beggining of the string predicate
			@v_CurrentIndex		INT = 0,
			@v_NewBlockLeft		NVARCHAR(MAX),
			@v_NewBlockRight	NVARCHAR(MAX),
			@v_PrevChar			NCHAR(1) = NULL,
			@v_CurrentChar		NCHAR(1),
			@v_NextChar			NCHAR(1),
			@v_StringStarted	BIT = 0,
			@v_StringEnded		BIT = 0,
			@v_DoubleQuoteStarted BIT = 0,
			@v_Step			VARCHAR(50) = '';
	
	--Check that we have anything to process
	IF @v_BeginOfStringIndex IS NULL OR @v_BeginOfStringIndex = 0 RETURN 0; 
	
	--Get beggining of the string predicate
	SET @v_CurrentChar = SUBSTRING ( @v_TextBlock, @v_BeginOfStringIndex, 1)
	SET @v_CurrentIndex = @v_BeginOfStringIndex; 

	--Read char by char until the end of text block
	WHILE (@v_CurrentIndex < @v_TextBlockLen)
	BEGIN
		SET @v_Step = 'START';
		SET @v_CurrentIndex = @v_CurrentIndex + 1;	--get next char to work with
		SET @v_PrevChar = @v_CurrentChar; 
		SET @v_CurrentChar = SUBSTRING ( @v_TextBlock, @v_CurrentIndex, 1);
		SET @v_NextChar = SUBSTRING ( @v_TextBlock, @v_CurrentIndex + 1, 1);
		 -- Double Quote Start begining of the string ***********************************
		IF	@v_CurrentChar = @v_QuoteIdentifier 
			AND @v_PrevChar = @v_QuoteIdentifier 
			AND @v_NextChar = @v_QuoteIdentifier 
			AND @v_DoubleQuoteStarted = 0
			AND (@v_CurrentIndex - 1) = @v_BeginOfStringIndex --string just started
		BEGIN
			SET @v_DoubleQuoteStarted = 1;
			SET @v_Step = @v_Step + '-A';
			CONTINUE;
		END
		 -- Double Quote Ended because it started in the prior step *********************
		IF	@v_DoubleQuoteStarted = 1 
			--AND @v_CurrentChar = @v_QuoteIdentifier 
			AND @v_PrevChar = @v_QuoteIdentifier 
		BEGIN
			SET @v_DoubleQuoteStarted = 0;
			SET @v_Step = @v_Step + '-B';
			CONTINUE;
		END
		 -- Double Quote Start inside of the string *************************************
		IF	@v_CurrentChar = @v_QuoteIdentifier 
			AND @v_PrevChar = @v_QuoteIdentifier 
			AND @v_DoubleQuoteStarted = 0
			AND (@v_CurrentIndex - 1) != @v_BeginOfStringIndex --inside the string
		BEGIN
			SET @v_DoubleQuoteStarted = 1;
			SET @v_Step = @v_Step + '-C';
			CONTINUE;
		END
		-- We ended up with NO MORE DATA ************************************************
		IF	@v_CurrentIndex >= @v_TextBlockLen 
		BEGIN 
			--if we have not set double quote before then it is the closing of the string
			IF	@v_CurrentChar = @v_QuoteIdentifier 
				AND @v_DoubleQuoteStarted = 0 
			BEGIN
				SET @v_StringEnded = 1; 
				SET @v_Step = @v_Step + '-D';
			END
			--on the ELSE side we could not close the string because there is double 
			--quoted identifier that is started already, 
			--or string is mailformed by now.
			BREAK; 
		END 
		-- Char is not a quote, and we are done   ***************************************
		IF	@v_CurrentChar != @v_QuoteIdentifier 
			AND @v_PrevChar = @v_QuoteIdentifier 
			AND @v_DoubleQuoteStarted = 0
		BEGIN
			IF 	@v_StringStarted = 0
			BEGIN
				SET @v_StringStarted = 1;
				SET @v_Step = @v_Step + '-E1';
				CONTINUE;
			END 
			ELSE BEGIN
				SET @v_StringEnded = 1; 
				SET @v_Step = @v_Step + '-E2';
				BREAK; 
			END
		END
		SET @v_Step = @v_Step + '-SPIN';
	END
	
	IF @v_StringEnded = 1 
	BEGIN
		IF @v_CurrentChar != @v_QuoteIdentifier 
			SET @v_EndOfStringIndex = @v_CurrentIndex - 1
			ELSE SET @v_EndOfStringIndex = @v_CurrentIndex
	END
	ELSE SET @v_EndOfStringIndex = 0;

	RETURN @v_EndOfStringIndex;
END 
GO 

--************************************************************************************************
--INTERNAL: Do not use this procedure in your unit tests, procedure can be removed,
--          signature or procedure name can be changed at any release
--Anilizes data int he text block and determines who is the before text block
CREATE FUNCTION DBTD_fnWhoIsFirst
(
	@v_TextBlock			NVARCHAR(MAX),
	@v_Search				NVARCHAR(255),
	@v_ConsiderStrings		BIT = 1,
	@v_ConsiderAssignment	BIT = 1, -- "=" a value assignment operator
	@v_ConsiderRoundBrackets BIT = 0 -- "(" is the openning bracket
)
RETURNS VARCHAR(50)
WITH ENCRYPTION AS
BEGIN
	DECLARE @v_SearchString NVARCHAR(255) = '%'+@v_Search+'%'
	IF @v_Search IS NULL OR LTRIM(RTRIM(@v_Search)) = '' RETURN 'NONE';

	DECLARE @v_Line INT = PATINDEX ( '%--%' , @v_TextBlock ),
			@v_Block INT = PATINDEX ( '%/*%' , @v_TextBlock ),
			@v_String INT = PATINDEX ( '%''%' , @v_TextBlock ),
			@v_SearchIndex INT = PATINDEX ( @v_SearchString, @v_TextBlock ), 
			@v_ValueAssignment INT = PATINDEX ( '%=%', @v_TextBlock ), 
			@v_RoundBrackets INT = PATINDEX ( '%(%' , @v_TextBlock ),
			@v_Result VARCHAR(50) = 'NONE',
			@v_BigNumber INT = 1000000;
	IF @v_Line = 0 SET @v_Line = NULL;
	IF @v_Block = 0 SET @v_Block = NULL;
	IF @v_String = 0 SET @v_String = NULL;
	IF @v_SearchIndex = 0 SET @v_SearchIndex = NULL;
	IF @v_ValueAssignment = 0 SET @v_ValueAssignment = NULL;
	IF @v_RoundBrackets = 0 SET @v_RoundBrackets = NULL;

	SELECT @v_Result = CASE 
						WHEN @v_Line IS NOT NULL 
							AND @v_Line < ISNULL(@v_Block,@v_BigNumber) 
							AND @v_Line < ISNULL(@v_SearchIndex,@v_BigNumber)  
							AND (@v_ConsiderStrings = 0 OR (@v_ConsiderStrings = 1 AND @v_Line < ISNULL(@v_String, @v_BigNumber)))
							AND (@v_ConsiderAssignment = 0 OR (@v_ConsiderAssignment = 1 AND @v_Line < ISNULL(@v_ValueAssignment,@v_BigNumber)))
							AND (@v_ConsiderRoundBrackets = 0 OR (@v_ConsiderRoundBrackets = 1 AND @v_Line < ISNULL(@v_RoundBrackets,@v_BigNumber)))
							THEN 'LINE' --line comment is the first
						WHEN @v_Block IS NOT NULL 
							AND @v_Block < ISNULL(@v_Line,@v_BigNumber) 
							AND @v_Block < ISNULL(@v_SearchIndex,@v_BigNumber) 
							AND (@v_ConsiderStrings = 0 OR (@v_ConsiderStrings = 1 AND @v_Block < ISNULL(@v_String, @v_BigNumber)))
							AND (@v_ConsiderAssignment = 0 OR (@v_ConsiderAssignment = 1 AND @v_Block < ISNULL(@v_ValueAssignment,@v_BigNumber)))
							AND (@v_ConsiderRoundBrackets = 0 OR (@v_ConsiderRoundBrackets = 1 AND @v_Block < ISNULL(@v_RoundBrackets,@v_BigNumber)))
							THEN 'BLOCK' --block comment is the first
						WHEN @v_SearchIndex IS NOT NULL 
							AND @v_SearchIndex < ISNULL(@v_Block,@v_BigNumber) 
							AND @v_SearchIndex < ISNULL(@v_Line,@v_BigNumber) 
							AND (@v_ConsiderStrings = 0 OR (@v_ConsiderStrings = 1 AND @v_SearchIndex < ISNULL(@v_String, @v_BigNumber)))
							AND (@v_ConsiderAssignment = 0 OR (@v_ConsiderAssignment = 1 AND @v_SearchIndex < ISNULL(@v_ValueAssignment,@v_BigNumber)))
							AND (@v_ConsiderRoundBrackets = 0 OR (@v_ConsiderRoundBrackets = 1 AND @v_SearchIndex < ISNULL(@v_RoundBrackets,@v_BigNumber)))
							THEN @v_Search --'CREATE' --the privided search string is the first
						WHEN @v_ConsiderStrings = 1
							AND @v_String IS NOT NULL
							AND @v_String < ISNULL(@v_Line,@v_BigNumber) 
							AND @v_String < ISNULL(@v_Block,@v_BigNumber) 
							AND @v_String < ISNULL(@v_SearchIndex,@v_BigNumber) 
							AND (@v_ConsiderAssignment = 0 OR (@v_ConsiderAssignment = 1 AND @v_String < ISNULL(@v_ValueAssignment,@v_BigNumber)))
							AND (@v_ConsiderRoundBrackets = 0 OR (@v_ConsiderRoundBrackets = 1 AND @v_String < ISNULL(@v_RoundBrackets,@v_BigNumber)))
							THEN 'STRING' --the string predicate is the first	
						WHEN @v_ConsiderAssignment = 1
							AND @v_ValueAssignment IS NOT NULL
							AND @v_ValueAssignment < ISNULL(@v_Line,@v_BigNumber) 
							AND @v_ValueAssignment < ISNULL(@v_Block,@v_BigNumber) 
							AND @v_ValueAssignment < ISNULL(@v_SearchIndex,@v_BigNumber) 
							AND (@v_ConsiderStrings = 0 OR (@v_ConsiderStrings = 1 AND @v_ValueAssignment < ISNULL(@v_String, @v_BigNumber)))
							AND (@v_ConsiderRoundBrackets = 0 OR (@v_ConsiderRoundBrackets = 1 AND @v_ValueAssignment < ISNULL(@v_RoundBrackets,@v_BigNumber)))
							THEN 'VALUEASSIGNMENT' -- ther value assignment is the first					
						WHEN @v_ConsiderRoundBrackets = 1 
							AND @v_RoundBrackets IS NOT NULL
							AND @v_RoundBrackets < ISNULL(@v_Line,@v_BigNumber) 
							AND @v_RoundBrackets < ISNULL(@v_Block,@v_BigNumber) 
							AND @v_RoundBrackets < ISNULL(@v_SearchIndex,@v_BigNumber) 
							AND (@v_ConsiderStrings = 0 OR (@v_ConsiderStrings = 1 AND @v_RoundBrackets < ISNULL(@v_String, @v_BigNumber)))
							AND (@v_ConsiderAssignment = 0 OR (@v_ConsiderAssignment = 1 AND @v_RoundBrackets < ISNULL(@v_ValueAssignment,@v_BigNumber)))
							THEN 'ROUNDBRACKETS' --round brackets is the first
						ELSE 'NONE'
					END

	RETURN @v_Result;
END
GO 

--************************************************************************************************
--INTERNAL: Do not use this procedure in your unit tests, procedure can be removed,
--          signature or procedure name can be changed at any release
--DROP FUNCTION DBTD_fnRemoveCommentsBeforeGivenString
CREATE FUNCTION DBTD_fnRemoveCommentsBeforeGivenString
(
	@v_TextBlock	NVARCHAR(MAX),
	@v_GivenString	NVARCHAR(250)
)
RETURNS NVARCHAR(MAX)
WITH ENCRYPTION AS
BEGIN
	--Find out who is the first
	DECLARE @v_First VARCHAR(50),
			@v_WorkBlock NVARCHAR(MAX),
			@v_Iterations INT = 0,
			@v_MaxIterations INT = 1000,
			@v_Left NVARCHAR(MAX) = '',
			@v_Right NVARCHAR(MAX) = @v_TextBlock,
			@v_StringEnd INT
	
	--Remove unrelated comments before the given string @v_GivenString
	--Consider strings as well 
	WHILE @v_Iterations < @v_MaxIterations
	BEGIN
		SET @v_Iterations = @v_Iterations + 1; --move iterations forward at the beginning 
		SET @v_First = dbo.DBTD_fnWhoIsFirst(@v_Right, @v_GivenString, 1, 0, 0);
		IF @v_First = @v_GivenString BREAK; --all removed
		IF @v_First = 'LINE' 
			SET @v_Right = dbo.DBTD_fnRemoveFirstLineComment(@v_Right);
		IF @v_First = 'BLOCK' 
			SET @v_Right = dbo.DBTD_fnRemoveFirstBlockComment(@v_Right);
		IF @v_First = 'STRING'
		BEGIN 
			SET @v_StringEnd = dbo.DBTD_fnGetEndOfStringIndexForTheFirstString(@v_Right);
			SET @v_Left = @v_Left + SUBSTRING(@v_Right, 1, @v_StringEnd);
			SET @v_Right = SUBSTRING(@v_Right, @v_StringEnd + 1, LEN(@v_Right));
		END 
	END; 

	SET @v_WorkBlock = @v_Left + @v_Right;
	RETURN @v_WorkBlock;
END
GO 

--************************************************************************************************
--INTERNAL: Do not use this procedure in your unit tests, procedure can be removed,
--          signature or procedure name can be changed at any release
--DROP FUNCTION DBTD_fnRemoveClosingBracket
CREATE FUNCTION DBTD_fnRemoveClosingBracket
(
	@v_TextBlock		NVARCHAR(MAX),
	@v_IsOpeningBraket	BIT	--TRUE when oppening bracket is present 
)
RETURNS NVARCHAR(MAX)
WITH ENCRYPTION AS
BEGIN
	DECLARE @v_Bracket NVARCHAR(MAX) = ')',
			@v_MaxIterations INT = 4000,
			@v_Iterations INT = 0,
			@v_Left NVARCHAR(MAX) = '',
			@v_Right VARCHAR(5) = '',
			@v_WorkBlock NVARCHAR(MAX) = LTRIM(RTRIM(@v_TextBlock)),
			@v_Found BIT = 0
	DECLARE @v_TheIndex BIGINT = CHARINDEX(@v_Bracket,@v_TextBlock), 
			@v_WorkBlockLen BIGINT = LEN(@v_WorkBlock)

	IF (@v_IsOpeningBraket != 1) RETURN @v_TextBlock; --return without any processing
	IF (@v_TheIndex IS NULL OR @v_TheIndex = 0) RETURN @v_TextBlock; --return without any processing

	WHILE (@v_Iterations < @v_MaxIterations	AND @v_Found = 0 AND LEN(@v_WorkBlock) > 0)
	BEGIN
		SET @v_Right = SUBSTRING(@v_WorkBlock,@v_WorkBlockLen-@v_Iterations, 1)
		IF @v_Right = @v_Bracket 
		BEGIN
			SET @v_Found = 1
			SET @v_WorkBlock = SUBSTRING(@v_WorkBlock,0,@v_WorkBlockLen-@v_Iterations)
		END
		SET @v_Iterations = @v_Iterations + 1; --move iterations forward 
	END; 
	IF @v_Found = 1 RETURN @v_WorkBlock;
	RETURN @v_TextBlock;
END
GO

--************************************************************************************************
--INTERNAL: Do not use this procedure in your unit tests, procedure can be removed,
--          signature or procedure name can be changed at any release
CREATE FUNCTION DBTD_fnGetDefaultValue
(
	@v_TextBlock			NVARCHAR(MAX),
	@v_ParameterName		SYSNAME,
	@v_NextParameterName	SYSNAME --for the last parameter (or only one parameter) this value should be set to 'AS' 
)
RETURNS NVARCHAR(MAX)
WITH ENCRYPTION AS
BEGIN
	DECLARE @v_StartIndex INT,
			@v_EndOfString INT,
			@v_FirstElement NVARCHAR(256),
			@v_DefaultValue NVARCHAR(MAX) = '',
			@v_MaxIterations INT = 1000,
			@v_Iterations INT = 0,
			@v_Left NVARCHAR(MAX) = '',
			@v_Right NVARCHAR(MAX) = '',
			@v_WorkBlock NVARCHAR(MAX)

	--NOTE: there should be no comments or strings before the first item in the block, which is the @v_ParameterName
	--      next parameter should follow correctly after parameter
	SET @v_StartIndex = PATINDEX('%'+@v_ParameterName+'%', @v_TextBlock) + LEN(@v_ParameterName);
	SET @v_WorkBlock = SUBSTRING(@v_TextBlock, @v_StartIndex + 1, LEN(@v_TextBlock));

	WHILE @v_Iterations < @v_MaxIterations
	BEGIN
		SET @v_Iterations = @v_Iterations + 1; --move iterations forward at the beginning 
		SET @v_FirstElement = dbo.DBTD_fnWhoIsFirst( @v_WorkBlock, @v_NextParameterName, 1, 1, 0);
	
		IF (@v_FirstElement = 'LINE' OR @v_FirstElement = 'BLOCK')
		BEGIN
			--NOTE: this should happen only once
			SET @v_WorkBlock = dbo.DBTD_fnRemoveCommentsBeforeGivenString (@v_WorkBlock, @v_NextParameterName)
			CONTINUE; --removed the comments, now lets try again
		END			
		
		IF ( @v_FirstElement = @v_NextParameterName)
		BEGIN 
			--NOTE: we have no default, so lets just return the type
			SET @v_StartIndex = PATINDEX('%'+@v_NextParameterName+'%', @v_WorkBlock)
			SET @v_DefaultValue = SUBSTRING(@v_WorkBlock, 0, @v_StartIndex);
			BREAK;
		END 

		IF (@v_FirstElement = 'VALUEASSIGNMENT')
		BEGIN
			--At this point all we have is the type and an assignment, that is what we will try to return 
			SET @v_StartIndex = PATINDEX('%=%', @v_WorkBlock)
			SET @v_Left = SUBSTRING(@v_WorkBlock, 0, @v_StartIndex + 1);
			SET @v_WorkBlock = SUBSTRING(@v_WorkBlock, @v_StartIndex + 1, LEN(@v_WorkBlock));
			
			WHILE @v_Iterations < @v_MaxIterations
			BEGIN
				SET @v_Iterations = @v_Iterations + 1; --Move iteration forward at the beginning 
				--Lets check if we have any string values 
				SET @v_FirstElement = dbo.DBTD_fnWhoIsFirst( @v_WorkBlock, @v_NextParameterName, 1, 1, 0);
			
				IF (@v_FirstElement = 'LINE' OR @v_FirstElement = 'BLOCK')
				BEGIN
					SET @v_WorkBlock = dbo.DBTD_fnRemoveCommentsBeforeGivenString (@v_WorkBlock, @v_NextParameterName)
					CONTINUE; --removed the comments, now lets try again
				END	
				IF (@v_FirstElement = 'STRING')
				BEGIN
					SET @v_EndOfString = dbo.DBTD_fnGetEndOfStringIndexForTheFirstString(@v_WorkBlock)	
					SET @v_Left = @v_Left + SUBSTRING(@v_WorkBlock, 0, @v_EndOfString+1);
					----lets get the wrapper now 
					SET @v_WorkBlock = SUBSTRING(@v_WorkBlock, @v_EndOfString + 1, LEN(@v_WorkBlock));
				END
				IF (@v_FirstElement = @v_NextParameterName)
				BEGIN
					--NOTE: we have no default, so lets just return the type
					SET @v_StartIndex = PATINDEX('%'+@v_NextParameterName+'%', @v_WorkBlock)
					SET @v_Right = SUBSTRING(@v_WorkBlock, 0, @v_StartIndex);
				END
			END; 

			SET @v_DefaultValue = @v_Left + @v_Right;
			BREAK;
		END			
	END; 

	RETURN @v_DefaultValue;
END
GO

--************************************************************************************************
--INTERNAL: Do not use this procedure in your unit tests, procedure can be removed,
--          signature or procedure name can be changed at any release
--DROP PROCEDURE DBTD_GET_ParameterList
CREATE PROCEDURE DBTD_GET_ParameterList
(
	@v_ProcName SYSNAME 
)
WITH ENCRYPTION AS
BEGIN
	SET NOCOUNT ON; 
	DECLARE @v_ThisProcName	NVARCHAR(128) = OBJECT_NAME(@@PROCID)
	DECLARE @v_Message NVARCHAR(MAX) = 'Running ' + @v_ThisProcName;
	EXEC DBTD_LOG_MESSAGE_EXT 'DEBUG', @v_ThisProcName, @v_Message;

	DECLARE @v_Server		VARCHAR(2000),
			@v_Database		VARCHAR(2000),
			@v_Schema		VARCHAR(2000),
			@v_Object		VARCHAR(2000),
			@v_CorrectedName VARCHAR(2000),
			@v_SQL			NVARCHAR(MAX)

	EXEC DBTD_SPLIT_FOUR_PART_OBJECT_NAME 
		@v_ProcName, 
		@v_Server = @v_Server OUTPUT, @v_Database = @v_Database OUTPUT, @v_Schema = @v_Schema OUTPUT, 
		@v_Object = @v_Object OUTPUT, @v_CorrectedName = @v_CorrectedName OUTPUT,
		@v_CorrectTempTablesLocation = 1;

	SELECT @v_SQL = 
		'SELECT f.Parameter_ID AS ParameterID, f.Name AS ParameterName, f.Is_Output AS IsOutputParameter, ISNULL( l.Name, ''AS'') AS NextParameterName
		FROM ' + CASE WHEN @v_Database IS NOT NULL AND @v_Database != '' THEN @v_Database + '.' ELSE '' END + 'sys.parameters AS f
			LEFT OUTER JOIN ' + CASE WHEN @v_Database IS NOT NULL AND @v_Database != '' THEN @v_Database + '.' ELSE '' END + 'sys.parameters AS l
			ON f.Parameter_ID = (l.Parameter_ID-1)
			AND f.[Object_ID]  = l.[Object_ID] 
		WHERE f.Name != '''' AND f.[Object_ID] = OBJECT_ID(''' + @v_CorrectedName + ''')
		ORDER BY f.Parameter_ID ;'; 
	EXEC DBTD_SP_EXECUTESQL @v_Database, @v_SQL;
END
GO 

--************************************************************************************************
--INTERNAL: Do not use this procedure in your unit tests, procedure can be removed,
--          signature or procedure name can be changed at any release
--DROP PROCEDURE DBTD_GET_ParameterLogTable
CREATE PROCEDURE DBTD_GET_ParameterLogTable
(
	@v_ProcName SYSNAME,
	@v_ParameterLogTableName NVARCHAR(MAX) OUTPUT,		-- Name of the table
	@v_ParameterLogTableSignature NVARCHAR(MAX) OUTPUT, -- SQL to create table
	@v_ParameterLogTableColumns NVARCHAR(MAX) OUTPUT,	-- Coma separated list of columns WITHOUT the identity column
	@v_ParameterLogTableAllColumns NVARCHAR(MAX) OUTPUT,-- Coma separated list of ALL columns
	@v_ProcHasParameters BIT OUTPUT,					-- 0 if pretend object does not have any parameters
	@v_ParameterLogAssertTempTable NVARCHAR(MAX) OUTPUT,-- SQL that created the temp table needed for assert logic
	@v_ParameterLogAssertGetData NVARCHAR(MAX) OUTPUT	-- SQL that pulls actual assert data
)
WITH ENCRYPTION AS
BEGIN
	SET NOCOUNT ON; 
	DECLARE @v_Server			VARCHAR(2000),
			@v_Database			VARCHAR(2000),
			@v_Schema			VARCHAR(2000),
			@v_Object			VARCHAR(2000),
			@v_CorrectedName	VARCHAR(2000),
			@v_FrameworkColumns	NVARCHAR(MAX) = '',
			@v_FrameworkColumnsSignature NVARCHAR(MAX) = '',
			@v_SQL				NVARCHAR(MAX),
			@v_Delim			VARCHAR(5) = '',
			@v_ObjectID			INT,
			@v_DefaultSignature NVARCHAR(500) = 'LogID INT IDENTITY (1,1) NOT NULL,ExecutionLogID INT,PretendID INT,EventTime DATETIME,UnitTestRunID INT NULL',
			@v_DefaultColumns	NVARCHAR(500) = 'ExecutionLogID,PretendID,EventTime,UnitTestRunID',
			@v_AssertTempTable	NVARCHAR(MAX),
			@v_AssertGetData	NVARCHAR(MAX)
	DECLARE @v_ThisProcName	NVARCHAR(128) = OBJECT_NAME(@@PROCID)
	DECLARE @v_Message NVARCHAR(MAX) = 'Running ' + @v_ThisProcName;
	EXEC DBTD_LOG_MESSAGE_EXT 'DEBUG', @v_ThisProcName, @v_Message;
	
	CREATE TABLE #ProcParameters(
		[object_id]		INT, 
		Name			SYSNAME,
		user_type_id	INT, 
		[Precision]		TINYINT, 
		Scale			TINYINT, 
		Parameter_id	INT ,
		max_length		SMALLINT
	);

	--ExecutionLogID	INT, --Is the related LogID from DBTD_TBL_PRETEND_OBJECT_LOG table 
	--UnitTestRunID	INT NULL'	--When run through framework this field will have unique UnitTestRunID
	SET @v_ProcHasParameters = 0

	EXEC DBTD_SPLIT_FOUR_PART_OBJECT_NAME 
		@v_ProcName, 
		@v_Server = @v_Server OUTPUT, @v_Database = @v_Database OUTPUT, @v_Schema = @v_Schema OUTPUT, 
		@v_Object = @v_Object OUTPUT, @v_CorrectedName = @v_CorrectedName OUTPUT,
		@v_CorrectTempTablesLocation = 1;

	EXEC DBTD_GET_OBJECT_ID @v_CorrectedName, @v_ObjectID OUTPUT

	IF @v_ParameterLogTableName IS NULL
		OR LTRIM(RTRIM(@v_ParameterLogTableName)) = ''
		OR OBJECT_ID(@v_ParameterLogTableName) IS NOT NULL
	BEGIN
		--SET @v_ParameterLogTableName = '[DBTD_'+RIGHT(ISNULL(@v_Database+'_','')+ISNULL(@v_Schema+'_','')+ISNULL(@v_Object+'_',''),128)+'_PARAM_LOG]'
		SET @v_ParameterLogTableName = '[DBTD_TBL_PretendID_'+REPLACE(CAST( NEWID() AS VARCHAR(50)),'-','')+'_PARAM_LOG]'
	END

	SET @v_SQL = 'INSERT INTO #ProcParameters ([object_id], Name, user_type_id, [Precision], Scale, parameter_id, max_length)
		SELECT	C.object_id, C.Name, C.user_type_id, C.[Precision], C.Scale, C.parameter_id, C.max_length
		FROM SYS.PARAMETERS AS C 
		WHERE C.object_id = ' + CAST(@v_ObjectID AS VARCHAR(50))

	EXEC DBTD_SP_EXECUTESQL @v_Database, @v_SQL

	SELECT	@v_FrameworkColumnsSignature = COALESCE(@v_FrameworkColumnsSignature, '', '') 
				+ @v_Delim + '['+C.Name+'] ' 
				+ dbo.DBTD_fnGetFullTypeByID(C.user_type_id, 
										CASE 
											WHEN C.user_type_id IN (
																	167,	--varchar
																	175,	--char
																	231,	--nvarchar	
																	173,	--binary			
																	239,	--nchar					
																	165		--varbinary		
																	) THEN C.max_length
											ELSE C.[Precision]
										END, C.Scale),
			@v_FrameworkColumns = COALESCE(@v_FrameworkColumns,'','') 
				+ @v_Delim + '['+C.Name+']',
			@v_Delim = ','
	FROM #ProcParameters AS C
	--WHERE C.object_id = @v_ObjectID 
	ORDER BY C.parameter_id asc

	IF EXISTS(SELECT * FROM #ProcParameters WHERE [object_id] = @v_ObjectID)
	BEGIN
		SET @v_ProcHasParameters = 1

		SET @v_AssertTempTable = 'ALTER TABLE #v_ActualParameterValues ADD ' +@v_FrameworkColumnsSignature
		SET @v_AssertGetData = ' INSERT INTO #v_ActualParameterValues (ExecutionNumber, UnitTestRunID, '+@v_FrameworkColumns+') '
								+ ' SELECT DENSE_RANK() OVER (ORDER BY PL.LogID ASC) AS ExecutionNumber,'
								+ ' @v_UnitTestRunID AS UnitTestRunID,'
								+ @v_FrameworkColumns
								+ ' FROM DBTD_TBL_PRETEND_OBJECT AS P'
								+ '	INNER JOIN DBTD_TBL_PRETEND_OBJECT_LOG AS PL'
								+ '		ON PL.PretendID = P.PretendID'
								+ '		AND (PL.[Message] = ''STARTING to run MOCK'' OR PL.[Message] = ''STARTING to run STUB'')'
								+ '	INNER JOIN ' + @v_ParameterLogTableName + ' AS PPL'
								+ '		ON PPL.PretendID = P.PretendID'
								+ '		AND PPL.PretendID = PL.PretendID'
								+ '		AND PPL.UnitTestRunID = PL.UnitTestRunID'
								+ '		AND PPL.ExecutionLogID = PL.LogID'
								+ '     AND PPL.UnitTestRunID = @v_UnitTestRunID'
								+ ' WHERE P.ObjectID = @v_Object_ID AND PPL.UnitTestRunID = @v_UnitTestRunID' 

		SET @v_FrameworkColumnsSignature = @v_DefaultSignature + ',' + @v_FrameworkColumnsSignature
		SET @v_FrameworkColumns = @v_DefaultColumns + ',' + @v_FrameworkColumns
	END
	ELSE BEGIN
		SET @v_FrameworkColumnsSignature = @v_DefaultSignature --'LogID INT IDENTITY (1,1) NOT NULL,ExecutionLogID INT,PretendID INT,EventTime DATETIME,UnitTestRunID INT NULL'
		SET @v_FrameworkColumns = @v_DefaultColumns --'ExecutionLogID,PretendID,EventTime,UnitTestRunID'
		SET @v_AssertTempTable = ' '
		SET @v_AssertGetData = ' ' 
	END

	SET @v_FrameworkColumnsSignature = 'CREATE TABLE '+ @v_ParameterLogTableName +'('+@v_FrameworkColumnsSignature + '); '

	SET @v_ParameterLogAssertTempTable = @v_AssertTempTable
	SET @v_ParameterLogAssertGetData = @v_AssertGetData
	SET @v_ParameterLogTableColumns = @v_FrameworkColumns
	SET @v_ParameterLogTableAllColumns = 'LogID,'+@v_FrameworkColumns
	SET @v_ParameterLogTableSignature = @v_FrameworkColumnsSignature
END
GO 

--************************************************************************************************
--INTERNAL: Do not use this function in your unit tests, procedure can be removed,
--          signature or procedure name can be changed at any release
--DROP FUNCTION DBTD_fnGetProcedureSignature
CREATE FUNCTION DBTD_fnGetProcedureSignature
(
	@v_ProcName SYSNAME,	--This is just a object name or scema_name.object_name format
	@v_TextBlock NVARCHAR(MAX),
	@v_ParameterList DBTD_ParameterListTableType READONLY,
	@v_ProcNameSubstitute NVARCHAR(128) = NULL --This value should be in the scema_name.object_name format
)
RETURNS NVARCHAR(MAX)
WITH ENCRYPTION AS
BEGIN
	DECLARE @v_First VARCHAR(50),
			@v_IsDoneProcessing BIT = 0,
			@v_WorkBlock NVARCHAR(MAX) = @v_TextBlock,
			@v_LeftBlock NVARCHAR(MAX),
			@v_RightBlock NVARCHAR(MAX),
			@v_TypeAndValue NVARCHAR(MAX),
			@v_Iterations INT = 0,
			@v_MaxIterations INT = 1000,
			@v_ParamName SYSNAME, 
			@v_NextParamName SYSNAME, 
			@v_ParameterSortOrder INT, 
			@v_IsOutput	BIT,
			@v_IsFirstParam BIT = 1,
			@v_OpenRoundBrackets BIT = 0,
			@v_FirstElement VARCHAR(50) = 'NONE'

	--Remove unrelated comments before CREATE
	SET @v_WorkBlock = dbo.DBTD_fnRemoveCommentsBeforeGivenString(@v_WorkBlock, 'CREATE');

	--Remove unrelated comments before PROC NAME
	SET @v_WorkBlock = dbo.DBTD_fnRemoveCommentsBeforeGivenString(@v_WorkBlock, @v_procName);

	--prepare new text
	SET @v_LeftBlock = 'CREATE PROCEDURE ' + CASE 
												WHEN @v_ProcNameSubstitute IS NOT NULL THEN @v_ProcNameSubstitute 
												ELSE @v_procName 
											END + ' '

	DECLARE SProc_Param_Cursor CURSOR FOR 
		SELECT ParameterID, ParameterName, IsOutputParameter, NextParameterName
		FROM @v_ParameterList
		ORDER BY ParameterID

	OPEN SProc_Param_Cursor

	FETCH NEXT FROM SProc_Param_Cursor
		INTO @v_ParameterSortOrder, @v_ParamName, @v_IsOutput, @v_NextParamName

	WHILE (@@FETCH_STATUS = 0 AND @v_Iterations < @v_MaxIterations)
	BEGIN
		SET @v_Iterations = @v_Iterations + 1; --move iterations forward at the beginning 
		--Remove unrelated comments before NEXT parameter
		SET @v_WorkBlock = dbo.DBTD_fnRemoveCommentsBeforeGivenString(@v_WorkBlock, @v_NextParamName);
		IF (@v_IsFirstParam = 1)
		BEGIN
			SET @v_FirstElement = dbo.DBTD_fnWhoIsFirst( @v_WorkBlock, @v_ParamName, 1, 1, 1);
			IF @v_FirstElement = 'ROUNDBRACKETS'
			BEGIN
				SET @v_OpenRoundBrackets = 1;
			END
		END

		--Get default value
		SET @v_TypeAndValue = dbo.DBTD_fnGetDefaultValue( @v_WorkBlock, @v_ParamName, @v_NextParamName)
		SET @v_LeftBlock = @v_LeftBlock + @v_ParamName + ' ' + @v_TypeAndValue	
		
		SET @v_IsFirstParam = 0;
		FETCH NEXT FROM SProc_Param_Cursor
		INTO @v_ParameterSortOrder, @v_ParamName, @v_IsOutput, @v_NextParamName
	END 
	CLOSE SProc_Param_Cursor;
	DEALLOCATE Sproc_Param_Cursor;

	--remove closing brakets if there are any found
	SET @v_LeftBlock = dbo.DBTD_fnRemoveClosingBracket ( @v_LeftBlock, @v_OpenRoundBrackets );
	
	RETURN @v_LeftBlock;
END
GO 

--************************************************************************************************
CREATE PROCEDURE DBTD_GET_UnitTestRunID
(
	@v_UnitTestRunID INT OUTPUT
)
WITH ENCRYPTION AS
BEGIN
	DECLARE @v_ProcName	NVARCHAR(128) = OBJECT_NAME(@@PROCID)
	DECLARE @v_Message NVARCHAR(MAX) = 'Running ' + @v_ProcName;
	EXEC DBTD_LOG_MESSAGE_EXT 'DEBUG', @v_ProcName, @v_Message;

	IF  OBJECT_ID('tempdb.dbo.#DBTD_CurrentUnitTestRunID') IS NOT NULL 
	BEGIN
		SELECT @v_UnitTestRunID = UnitTestRunID FROM #DBTD_CurrentUnitTestRunID
	END 
	ELSE BEGIN
		--This case happens only when UTs are executed manually,
		--to separate manual runs from automated we use random negative IDs 
		SELECT @v_UnitTestRunID = UnitTestRunID FROM DBTD_TBL_MANUAL_UNITTESTRUNID
		IF (@v_UnitTestRunID IS NULL )
		BEGIN
			SET @v_UnitTestRunID = ROUND(RAND() * 10000000, 0) * -1;
		END
	END
END
GO 

--************************************************************************************************
CREATE PROCEDURE DBTD_GET_UnitTestName
(
	@v_UnitTestName NVARCHAR(128) OUTPUT
)
WITH ENCRYPTION AS
BEGIN
	DECLARE @v_ProcName	NVARCHAR(128) = OBJECT_NAME(@@PROCID)
	DECLARE @v_Message NVARCHAR(MAX) = 'Running ' + @v_ProcName;
	EXEC DBTD_LOG_MESSAGE_EXT 'DEBUG', @v_ProcName, @v_Message;

	IF  OBJECT_ID('tempdb.dbo.#DBTD_CurrentUnitTestRunID') IS NOT NULL 
	BEGIN
		SELECT @v_UnitTestName = UnitTestName FROM #DBTD_CurrentUnitTestRunID
	END 
	ELSE BEGIN
		--This case happens only when UTs are executed manually,
		--to separate manual runs from automated we use random negative IDs 
		SELECT @v_UnitTestName = UnitTestName FROM DBTD_TBL_MANUAL_UNITTESTRUNID
		IF (@v_UnitTestName IS NULL )
		BEGIN
			SET @v_UnitTestName = 'UnknownManualRun'
		END
	END
END
GO 

--************************************************************************************************
CREATE FUNCTION DBTD_fnGetPretendObjectID
(
	@v_PretendObjectName SYSNAME --four parts, fully qualified database object name
)
RETURNS INT
WITH ENCRYPTION AS
BEGIN
	DECLARE	@v_PretendID INT = NULL,
			@v_ObjectID INT = OBJECT_ID(@v_PretendObjectName);

	SELECT @v_PretendID = PretendID
	FROM DBTD_TBL_PRETEND_OBJECT
	WHERE ObjectID = @v_ObjectID

	RETURN @v_PretendID;
END
GO 

--************************************************************************************************
--looks through object definitions for search predicate 
--returns NULL if not found
--returns comma separated list of objects when found, also
--returns list of all the objects inthe TEMPDB.dbo.#DefinitionSearchResult table it is exist at the time of the procedure run
--empty search string return nothing
--NOTE: could not use table type varible for now because it is not supported
--NOTE: this procedure can be quite slow
--NOTE: does not search though encrypted objects
--DROP PROC DBTD_SEARCH_ObjectsDefinition
CREATE PROCEDURE DBTD_SEARCH_ObjectsDefinition
(
	@v_TargetDB			SYSNAME,  
	@v_SearchString		NVARCHAR(MAX),
	@v_Exclude			NVARCHAR(MAX) = 'DBTD_%,UTT_%,UT_%', --By Default excludes DBTD objects, Unit Tests and Unit Tests Tools. Commaseparated list of exlusion expressions
	@v_CleanOldDefinitionSearchResult BIT = 1, --defalt value is 1, set it to 0 if you would like to preserve result that already stored in the #DefinitionSearchResult
	@v_SearchResult		NVARCHAR(MAX) OUTPUT
)
WITH ENCRYPTION AS
BEGIN
	SET NOCOUNT ON;
	DECLARE @v_ProcName	NVARCHAR(128) = OBJECT_NAME(@@PROCID)
	DECLARE @v_Message NVARCHAR(MAX) = 'Running ' + @v_ProcName;
	EXEC DBTD_LOG_MESSAGE_EXT 'DEBUG', @v_ProcName, @v_Message;

	DECLARE @v_CurrentDB	SYSNAME = DB_NAME(),
			@v_SQL			NVARCHAR(MAX),
			@v_ObjectList	NVARCHAR(MAX)

	CREATE TABLE #NewDefinitionSearchResult
	(
		[Object_ID]	INT, 
		ObjectName	VARCHAR(500),	--Full object name with database and schema prefix		
		[Type]		VARCHAR(50),
		Name		SYSNAME,		--Just an object name
		SearchString NVARCHAR(MAX)
	);

	IF @v_CleanOldDefinitionSearchResult = 1 DELETE FROM #DefinitionSearchResult


	IF LTRIM(RTRIM(@v_SearchString)) != ''
	BEGIN  
		CREATE TABLE #ExlusionCriteria
		(
			IsExcluded BIT,
			ExcludeExpression NVARCHAR(MAX)
		)
		INSERT INTO #ExlusionCriteria
			(IsExcluded, ExcludeExpression)
			SELECT 1 AS IsExcluded, String AS Expression FROM DBO.DBTD_SPLIT_STRING_TO_TABLE ( @v_Exclude, ',')

		SET @v_SQL = 'INSERT INTO #NewDefinitionSearchResult ([Object_ID], ObjectName,[Type],Name)'			
				+ ' SELECT [object_id], '''+@v_TargetDB+'.''+s.Name+''.''+o.Name AS [ObjectName], o.[Type], o.[Name]'
				+ ' FROM '+@v_TargetDB+'.sys.objects AS o '
				+ ' 	INNER JOIN '+@v_TargetDB+'.sys.schemas AS s '
				+ '			ON o.schema_id = s.schema_id '
				+ ' 	LEFT OUTER JOIN #ExlusionCriteria AS e '
				+ '			ON o.Name LIKE e.ExcludeExpression '
				+ ' WHERE OBJECT_DEFINITION([object_id]) LIKE '''+@v_SearchString+''' '
				+ '		AND e.IsExcluded IS NULL'

		EXEC DBTD_LOG_MESSAGE_EXT 'DEBUG', 'DBTD_SEARCH_ObjectsDefinition', @v_SQL

		EXEC DBTestDriven.dbo.DBTD_SP_EXECUTESQL @v_TargetDB, @v_SQL 

		SELECT @v_ObjectList = COALESCE(@v_ObjectList+', ' ,'') + r.ObjectName
		FROM #NewDefinitionSearchResult AS r
		ORDER BY r.[Type], r.[Name] 

		UPDATE #NewDefinitionSearchResult SET SearchString = @v_SearchString;

		IF OBJECT_ID('TEMPDB.dbo.#DefinitionSearchResult') IS NOT NULL
		BEGIN
			INSERT INTO #DefinitionSearchResult
				([Object_ID],ObjectName,[Type], Name, SearchString)
				SELECT [Object_ID],ObjectName,[Type], Name, SearchString 
				FROM #NewDefinitionSearchResult
		END
	END

	SET @v_SearchResult	= CASE 
				WHEN @v_ObjectList IS NULL OR LTRIM(RTRIM(@v_ObjectList)) = '' THEN NULL --'No items match search criteria'
				ELSE @v_ObjectList --'Found search string in following objects: ' 
			END 
END
GO 

--************************************************************************************************
-- Checks that table has expected number of records base on supplied condition
CREATE PROCEDURE DBTD_ASSERT_IS_EXPECTED_COUNT 
(
	@v_ExpectedValue	BIGINT,			--Expected number of records 
	@v_TableName		SYSNAME,		--Table name 
	@v_Condition		NVARCHAR(MAX),	--Condition
	@v_UserMessage		NVARCHAR(MAX)	--User message
)
WITH ENCRYPTION AS
BEGIN
	SET NOCOUNT ON;
	DECLARE @v_SQL				NVARCHAR(MAX),
			@v_ActualValue		BIGINT,
			@v_ParmDefinition	NVARCHAR(MAX) = N' @v_ActualCount BIGINT OUTPUT ',
			@v_ActualCount		BIGINT,
			@v_Server			VARCHAR(2000),
			@v_Database			VARCHAR(2000),
			@v_Schema			VARCHAR(2000),
			@v_Object			VARCHAR(2000),
			@v_ObjectID			BIGINT,
			@v_CorrectedName	VARCHAR(2000),
			@v_ProcName	NVARCHAR(128) = OBJECT_NAME(@@PROCID)
	DECLARE @v_Message NVARCHAR(MAX) = 'Running ' + @v_ProcName;
	EXEC DBTD_LOG_MESSAGE_EXT 'DEBUG', @v_ProcName, @v_Message;

	EXEC DBTD_SPLIT_FOUR_PART_OBJECT_NAME 
		@v_TableName, 
		@v_Server = @v_Server OUTPUT, @v_Database = @v_Database OUTPUT, @v_Schema = @v_Schema OUTPUT, 
		@v_Object = @v_Object OUTPUT, @v_CorrectedName = @v_CorrectedName OUTPUT,
		@v_CorrectTempTablesLocation = 1;
	SET @v_ObjectID = OBJECT_ID(@v_CorrectedName)
	EXEC DBTD_CACHE_TESTRESULT_DETAILS @v_ObjectName = @v_Object, @v_ObjectDatabase = @v_Database, @v_ObjectFullName = @v_CorrectedName, @v_CallingProcName = @v_ProcName,@v_ObjectID = @v_ObjectID, @v_ObjectSchema = @v_Schema

	SET @v_SQL = 'SELECT @v_ActualCount = COUNT(1) FROM ' + @v_CorrectedName; 
	IF ((@v_Condition IS NOT NULL) AND (RTRIM(LTRIM(@v_Condition)) != '')) 
	BEGIN 
		SET @v_SQL = @v_SQL + ' WHERE ' + @v_Condition;
	END;

	EXEC sp_executeSQL
		@v_SQL,
		@v_ParmDefinition,
		@v_ActualCount = @v_ActualCount OUTPUT

	SET @v_ActualValue = ISNULL(@v_ActualCount,0) 

	IF (@v_ActualValue != @v_ExpectedValue )  BEGIN 
		SET @v_Message = ISNULL(@v_UserMessage + '.', '') 
			+ ' Actual value is NOT EQUAL to Expected value. ' 
			+ ' EXPECTED: ' + CAST(@v_ExpectedValue AS  VARCHAR(255))
			+ ' ACTUAL: ' + CAST(@v_ActualValue AS  VARCHAR(255)) 
			+ ' For SQL query: ' + @v_SQL; 
		EXEC DBTD_FAILURE @v_Message; 
	END;
END;
GO

--************************************************************************************************
-- Checks that table does not have expected number of records base on supplied condition
--DROP PROC DBTD_ASSERT_IS_NOT_EXPECTED_COUNT 
CREATE PROCEDURE DBTD_ASSERT_IS_NOT_EXPECTED_COUNT 
(
	@v_NotExpectedValue BIGINT,
	@v_TableName		SYSNAME,			
	@v_Condition		NVARCHAR(MAX),
	@v_UserMessage		NVARCHAR(MAX)
)
WITH ENCRYPTION AS
BEGIN
	SET NOCOUNT ON;
	DECLARE @v_ActualValue BIGINT,
			@v_SQL		NVARCHAR(MAX),
			@v_ParmDefinition NVARCHAR(2000),
			@v_Server			VARCHAR(2000),
			@v_Database			VARCHAR(2000),
			@v_Schema			VARCHAR(2000),
			@v_Object			VARCHAR(2000),
			@v_ObjectID			BIGINT,
			@v_CorrectedName	VARCHAR(2000),
			@v_ProcName	NVARCHAR(128) = OBJECT_NAME(@@PROCID)
	DECLARE @v_Message NVARCHAR(MAX) = 'Running ' + @v_ProcName;
	EXEC DBTD_LOG_MESSAGE_EXT 'DEBUG', @v_ProcName, @v_Message;

	EXEC DBTD_SPLIT_FOUR_PART_OBJECT_NAME 
		@v_TableName, 
		@v_Server = @v_Server OUTPUT, @v_Database = @v_Database OUTPUT, @v_Schema = @v_Schema OUTPUT, 
		@v_Object = @v_Object OUTPUT, @v_CorrectedName = @v_CorrectedName OUTPUT,
		@v_CorrectTempTablesLocation = 1;
	SET @v_ObjectID = OBJECT_ID(@v_CorrectedName)
	EXEC DBTD_CACHE_TESTRESULT_DETAILS @v_ObjectName = @v_Object, @v_ObjectDatabase = @v_Database, @v_ObjectFullName = @v_CorrectedName, @v_CallingProcName = @v_ProcName,@v_ObjectID = @v_ObjectID, @v_ObjectSchema = @v_Schema

	SET @v_ParmDefinition = '@v_ActualValue_Internal BIGINT OUTPUT'
	SET @v_SQL = 'SELECT @v_ActualValue_Internal = COUNT(1)  FROM ' + @v_CorrectedName + ' ';  
	IF ((@v_Condition IS NOT NULL) AND (RTRIM(LTRIM(@v_Condition)) != '')) BEGIN 
		SET @v_SQL = @v_SQL + ' WHERE ' + @v_Condition;
	END;
	SET @v_SQL = @v_SQL+ ';';
	--EXEC DBTD_LOG_MESSAGE_EXT 'DEBUG', 'DBTD_ASSERT_IS_NOT_EXPECTED_COUNT', @v_SQL ;
	EXECUTE sp_executesql @v_SQL, @v_ParmDefinition, @v_ActualValue_Internal = @v_ActualValue OUTPUT;

	IF (@v_ActualValue = @v_NotExpectedValue )  
	BEGIN 
		SET @v_Message = ISNULL(@v_UserMessage + '.', '') 
			+ ' Actual value is EQUAL to Not-Expected value. ' 
			+ ' NOT EXPECTED: ' + CAST(@v_NotExpectedValue AS  VARCHAR(255))
			+ ' ACTUAL: ' + CAST(@v_ActualValue AS  VARCHAR(255)) ; 
		EXEC DBTD_FAILURE @v_Message; 
	END;
END;
GO


--************************************************************************************************
--Assert checks that table is NOT empty and has records 
CREATE PROCEDURE DBTD_ASSERT_TABLE_HAS_RECORDS 
(
	@v_TableName	SYSNAME,		--Table name  
	@v_UserMessage	NVARCHAR(MAX)	--User message
)
WITH ENCRYPTION AS
BEGIN
	SET NOCOUNT ON;
	DECLARE @v_ProcName	NVARCHAR(128) = OBJECT_NAME(@@PROCID)
	DECLARE @v_Message NVARCHAR(MAX) = 'Running ' + @v_ProcName;
	EXEC DBTD_LOG_MESSAGE_EXT 'DEBUG', @v_ProcName, @v_Message;
	--run test
	EXEC DBTD_ASSERT_IS_NOT_EXPECTED_COUNT 0, @v_TableName, '', @v_UserMessage;
END;
GO

--************************************************************************************************
--checks that table is empty and has no records 
CREATE PROCEDURE DBTD_ASSERT_TABLE_HAS_NO_RECORDS 
(
	@v_TableName	SYSNAME,		--table name 
	@v_UserMessage	NVARCHAR(MAX)	--user message
)
WITH ENCRYPTION AS
BEGIN
	SET NOCOUNT ON;
	DECLARE @v_ProcName	NVARCHAR(128) = OBJECT_NAME(@@PROCID)
	DECLARE @v_Message NVARCHAR(MAX) = 'Running ' + @v_ProcName;
	EXEC DBTD_LOG_MESSAGE_EXT 'DEBUG', @v_ProcName, @v_Message;
	--run test
	EXEC DBTD_ASSERT_IS_EXPECTED_COUNT 0, @v_TableName, '', @v_UserMessage;
END;
GO

--************************************************************************************************
--verifies that fuction do exists in the database
--DROP PROCEDURE DBTD_ASSERT_FUNC_EXISTS
CREATE PROCEDURE DBTD_ASSERT_FUNC_EXISTS
(
	@v_FuncName		SYSNAME,		--Function name
	@v_UserMessage	NVARCHAR(MAX)	--User message
)
WITH ENCRYPTION AS
BEGIN
	SET NOCOUNT ON;
	DECLARE @v_Server		VARCHAR(2000),
			@v_Database		VARCHAR(2000),
			@v_Schema		VARCHAR(2000),
			@v_CorrectedName VARCHAR(2000),
			@v_Object		VARCHAR(2000),
			@v_ObjectID		BIGINT,
			@v_FullSysObjectName NVARCHAR(128) = '',
			@v_Condition	NVARCHAR(MAX) = ''
	DECLARE @v_ProcName	NVARCHAR(128) = OBJECT_NAME(@@PROCID)
	DECLARE @v_Message NVARCHAR(MAX) = 'Running ' + @v_ProcName;
	EXEC DBTD_LOG_MESSAGE_EXT 'DEBUG', @v_ProcName, @v_Message;

	EXEC DBTD_SPLIT_FOUR_PART_OBJECT_NAME 
		@v_FuncName, 
		@v_Server = @v_Server OUTPUT, @v_Database = @v_Database OUTPUT, @v_Schema = @v_Schema OUTPUT, 
		@v_Object = @v_Object OUTPUT, @v_CorrectedName = @v_CorrectedName OUTPUT,
		@v_CorrectTempTablesLocation = 1;

	SET @v_ObjectID = OBJECT_ID(@v_CorrectedName)
	EXEC DBTD_CACHE_TESTRESULT_DETAILS @v_ObjectName = @v_Object, @v_ObjectDatabase = @v_Database, @v_ObjectFullName = @v_CorrectedName, @v_CallingProcName = @v_ProcName,@v_ObjectID = @v_ObjectID, @v_ObjectSchema = @v_Schema

	SET @v_Message = ISNULL(@v_UserMessage + '.', '') + ' Cannot find Function "' + LTRIM(RTRIM(UPPER(@v_FuncName))) + '"' ; 
	SET @v_FullSysObjectName = CASE WHEN @v_Database IS NOT NULL AND @v_Database != '' THEN @v_Database + '.' ELSE '' END + 'SYS.OBJECTS';
	SET @v_Condition = 'OBJECT_ID = OBJECT_ID(LTRIM(RTRIM(UPPER(N''' + @v_CorrectedName +'''))) ) AND TYPE IN (''TF'',''FN'',''FS'',''FT'',''AF'',''IF'') ';

	EXEC DBTD_ASSERT_IS_NOT_EXPECTED_COUNT 0, @v_FullSysObjectName, @v_Condition, @v_Message
END;
GO

--************************************************************************************************
--verifies that function does not exists in the database
--DROP PROCEDURE DBTD_ASSERT_FUNC_NOT_EXISTS
CREATE PROCEDURE DBTD_ASSERT_FUNC_NOT_EXISTS
(
	@v_FuncName		SYSNAME,		--Function name  
	@v_UserMessage	NVARCHAR(MAX)	--User message
)
WITH ENCRYPTION AS
BEGIN
	SET NOCOUNT ON;
	DECLARE @v_Server	VARCHAR(2000),
			@v_Database VARCHAR(2000),
			@v_Schema	VARCHAR(2000),
			@v_Object	VARCHAR(2000),
			@v_ObjectID	BIGINT,
			@v_CorrectedName VARCHAR(2000),
			@v_FullSysObjectName NVARCHAR(128) = '',
			@v_Condition NVARCHAR(MAX) = ''
	DECLARE @v_ProcName	NVARCHAR(128) = OBJECT_NAME(@@PROCID)
	DECLARE @v_Message	NVARCHAR(MAX) = 'Running ' + @v_ProcName;
	EXEC DBTD_LOG_MESSAGE_EXT 'DEBUG', @v_ProcName, @v_Message;

	EXEC DBTD_SPLIT_FOUR_PART_OBJECT_NAME 
		@v_FuncName, 
		@v_Server = @v_Server OUTPUT, @v_Database = @v_Database OUTPUT, @v_Schema = @v_Schema OUTPUT, @v_Object = @v_Object OUTPUT, 
		@v_CorrectedName = @v_CorrectedName OUTPUT,
		@v_CorrectTempTablesLocation = 1;

	SET @v_ObjectID = OBJECT_ID(@v_CorrectedName)
	EXEC DBTD_CACHE_TESTRESULT_DETAILS @v_ObjectName = @v_Object, @v_ObjectDatabase = @v_Database, @v_ObjectFullName = @v_CorrectedName, @v_CallingProcName = @v_ProcName,@v_ObjectID = @v_ObjectID, @v_ObjectSchema = @v_Schema

	SET @v_Message = @v_UserMessage + ' Unexpected Function "' + LTRIM(RTRIM(UPPER(@v_FuncName))) + '" found in the database' ; 

	SET @v_FullSysObjectName = CASE WHEN @v_Database IS NOT NULL AND @v_Database != '' THEN @v_Database + '.' ELSE '' END + 'SYS.OBJECTS';
	SET @v_Condition = 'OBJECT_ID = OBJECT_ID(LTRIM(RTRIM(UPPER(N''' + @v_CorrectedName +'''))) ) AND TYPE IN (''TF'',''FN'',''FS'',''FT'',''AF'',''IF'') ';

	EXEC DBTD_ASSERT_IS_EXPECTED_COUNT 0, @v_FullSysObjectName, @v_Condition, @v_Message;
END;
GO

--************************************************************************************************
--verifies that SYNONYM do exists in the database
CREATE PROCEDURE DBTD_ASSERT_SYNONYM_EXISTS
(
	@v_SunonymName	SYSNAME,		--Sunonym name  
	@v_UserMessage	NVARCHAR(MAX)	--user message
)
WITH ENCRYPTION AS
BEGIN
	SET NOCOUNT ON;
	DECLARE @v_Server	VARCHAR(2000),
			@v_Database VARCHAR(2000),
			@v_Schema	VARCHAR(2000),
			@v_CorrectedName VARCHAR(2000),
			@v_Object	VARCHAR(2000),
			@v_ObjectID	BIGINT,
			@v_FullSysObjectName NVARCHAR(128) = '',
			@v_Condition NVARCHAR(MAX) = ''
	DECLARE @v_ProcName	NVARCHAR(128) = OBJECT_NAME(@@PROCID)
	DECLARE @v_Message NVARCHAR(MAX) = 'Running ' + @v_ProcName;
	EXEC DBTD_LOG_MESSAGE_EXT 'DEBUG', @v_ProcName, @v_Message;

	EXEC DBTD_SPLIT_FOUR_PART_OBJECT_NAME 
		@v_SunonymName, 
		@v_Server = @v_Server OUTPUT, @v_Database = @v_Database OUTPUT, @v_Schema = @v_Schema OUTPUT, 
		@v_Object = @v_Object OUTPUT, @v_CorrectedName = @v_CorrectedName OUTPUT,
		@v_CorrectTempTablesLocation = 1;

	SET @v_ObjectID = OBJECT_ID(@v_CorrectedName)
	EXEC DBTD_CACHE_TESTRESULT_DETAILS @v_ObjectName = @v_Object, @v_ObjectDatabase = @v_Database, @v_ObjectFullName = @v_CorrectedName, @v_CallingProcName = @v_ProcName,@v_ObjectID = @v_ObjectID, @v_ObjectSchema = @v_Schema

	SET @v_Message = ISNULL(@v_UserMessage + '.', '') + ' Cannot find Sunonym "' + LTRIM(RTRIM(UPPER(@v_SunonymName))) + '"' ; 

	SET @v_FullSysObjectName = CASE WHEN @v_Database IS NOT NULL AND @v_Database != '' THEN @v_Database + '.' ELSE '' END + 'SYS.OBJECTS';
	SET @v_Condition = 'OBJECT_ID = OBJECT_ID(LTRIM(RTRIM(UPPER(N''' + @v_CorrectedName +'''))) ) AND TYPE = ''SN''';

	EXEC DBTD_ASSERT_IS_NOT_EXPECTED_COUNT 0, @v_FullSysObjectName, @v_Condition, @v_Message
END;
GO

--************************************************************************************************
--verifies that Sunonym does not exists in the database
CREATE PROCEDURE DBTD_ASSERT_SYNONYM_NOT_EXISTS
(
	@v_SunonymName	SYSNAME,		--Synonym name
	@v_UserMessage	NVARCHAR(MAX)	--user message
)
WITH ENCRYPTION AS
BEGIN
	SET NOCOUNT ON;
	DECLARE @v_Server VARCHAR(2000),
			@v_Database VARCHAR(2000),
			@v_Schema VARCHAR(2000),
			@v_Object VARCHAR(2000),
			@v_CorrectedName VARCHAR(2000),
			@v_FullSysObjectName NVARCHAR(128) = '',
			@v_Condition NVARCHAR(MAX) = ''
	DECLARE @v_ProcName	NVARCHAR(128) = OBJECT_NAME(@@PROCID)
	DECLARE @v_Message NVARCHAR(MAX) = 'Running ' + @v_ProcName;
	EXEC DBTD_LOG_MESSAGE_EXT 'DEBUG', @v_ProcName, @v_Message;

	EXEC DBTD_SPLIT_FOUR_PART_OBJECT_NAME 
		@v_SunonymName, 
		@v_Server = @v_Server OUTPUT, @v_Database = @v_Database OUTPUT, @v_Schema = @v_Schema OUTPUT, @v_Object = @v_Object OUTPUT, 
		@v_CorrectedName = @v_CorrectedName OUTPUT,
		@v_CorrectTempTablesLocation = 1;

	EXEC DBTD_CACHE_TESTRESULT_DETAILS @v_ObjectName = @v_Object, @v_ObjectDatabase = @v_Database, @v_ObjectFullName = @v_CorrectedName, @v_CallingProcName = @v_ProcName, @v_ObjectID = NULL, @v_ObjectSchema = @v_Schema

	SET @v_Message = ISNULL(@v_UserMessage + '.', '') + ' Unexpected Sunonym "' + LTRIM(RTRIM(UPPER(@v_SunonymName))) + '" found in the database' ; 

	SET @v_FullSysObjectName = CASE WHEN @v_Database IS NOT NULL AND @v_Database != '' THEN @v_Database + '.' ELSE '' END + 'SYS.OBJECTS';
	SET @v_Condition = 'OBJECT_ID = OBJECT_ID(LTRIM(RTRIM(UPPER(N''' + @v_CorrectedName +'''))) ) AND TYPE = ''SN''';

	EXEC DBTD_ASSERT_IS_EXPECTED_COUNT 0, @v_FullSysObjectName, @v_Condition, @v_Message;
END;
GO


--************************************************************************************************
--verifies that stored procedure do exists in the database
CREATE PROCEDURE DBTD_ASSERT_PROC_EXISTS
(
	@v_ProcName		SYSNAME,		--proc name  
	@v_UserMessage	NVARCHAR(MAX)	--user message
)
WITH ENCRYPTION AS
BEGIN
	SET NOCOUNT ON;
	DECLARE @v_Server VARCHAR(2000),
			@v_Database VARCHAR(2000),
			@v_Schema VARCHAR(2000),
			@v_CorrectedName VARCHAR(2000),
			@v_Object VARCHAR(2000),
			@v_FullSysObjectName NVARCHAR(128) = '',
			@v_Condition NVARCHAR(MAX) = ''
	DECLARE @v_ThisProcName	NVARCHAR(128) = OBJECT_NAME(@@PROCID)
	DECLARE @v_Message NVARCHAR(MAX) = 'Running ' + @v_ThisProcName;
	EXEC DBTD_LOG_MESSAGE_EXT 'DEBUG', @v_ThisProcName, @v_Message;

	EXEC DBTD_SPLIT_FOUR_PART_OBJECT_NAME 
		@v_ProcName, 
		@v_Server = @v_Server OUTPUT, @v_Database = @v_Database OUTPUT, @v_Schema = @v_Schema OUTPUT, 
		@v_Object = @v_Object OUTPUT, @v_CorrectedName = @v_CorrectedName OUTPUT,
		@v_CorrectTempTablesLocation = 1;

	EXEC DBTD_CACHE_TESTRESULT_DETAILS @v_ObjectName = @v_Object, @v_ObjectDatabase = @v_Database, @v_ObjectFullName = @v_CorrectedName, @v_CallingProcName = @v_ProcName, @v_ObjectID = NULL, @v_ObjectSchema = @v_Schema

	SET @v_Message = ISNULL(@v_UserMessage + '.', '') + ' Cannot find Stored Procedure "' + LTRIM(RTRIM(UPPER(@v_ProcName))) + '"' ; 

	SET @v_FullSysObjectName = CASE WHEN @v_Database IS NOT NULL AND @v_Database != '' THEN @v_Database + '.' ELSE '' END + 'SYS.OBJECTS';
	SET @v_Condition = 'OBJECT_ID = OBJECT_ID(LTRIM(RTRIM(UPPER(N''' + @v_CorrectedName +'''))) ) AND TYPE = ''P''';

	EXEC DBTD_ASSERT_IS_NOT_EXPECTED_COUNT 0, @v_FullSysObjectName, @v_Condition, @v_Message
END;
GO

--************************************************************************************************
--verifies that stored procedure does not exists in the database
CREATE PROCEDURE DBTD_ASSERT_PROC_NOT_EXISTS
(
	@v_ProcName		SYSNAME,		--proc name  
	@v_UserMessage	NVARCHAR(MAX)	--user message
)
WITH ENCRYPTION AS
BEGIN
	SET NOCOUNT ON;
	DECLARE @v_Server VARCHAR(2000),
			@v_Database VARCHAR(2000),
			@v_Schema VARCHAR(2000),
			@v_Object VARCHAR(2000),
			@v_CorrectedName VARCHAR(2000),
			@v_FullSysObjectName NVARCHAR(128) = '',
			@v_Condition NVARCHAR(MAX) = ''
	DECLARE @v_ThisProcName	NVARCHAR(128) = OBJECT_NAME(@@PROCID)
	DECLARE @v_Message NVARCHAR(MAX) = 'Running ' + @v_ThisProcName;
	EXEC DBTD_LOG_MESSAGE_EXT 'DEBUG', @v_ThisProcName, @v_Message;

	EXEC DBTD_SPLIT_FOUR_PART_OBJECT_NAME 
		@v_ProcName, 
		@v_Server = @v_Server OUTPUT, @v_Database = @v_Database OUTPUT, @v_Schema = @v_Schema OUTPUT, @v_Object = @v_Object OUTPUT, 
		@v_CorrectedName = @v_CorrectedName OUTPUT,
		@v_CorrectTempTablesLocation = 1;

	EXEC DBTD_CACHE_TESTRESULT_DETAILS @v_ObjectName = @v_Object, @v_ObjectDatabase = @v_Database, @v_ObjectFullName = @v_CorrectedName, @v_CallingProcName = @v_ProcName, @v_ObjectID = NULL, @v_ObjectSchema = @v_Schema

	SET @v_Message = ISNULL(@v_UserMessage + '.', '') + ' Unexpected Stored Procedure "' + LTRIM(RTRIM(UPPER(@v_ProcName))) + '" found in the database' ; 

	SET @v_FullSysObjectName = CASE WHEN @v_Database IS NOT NULL AND @v_Database != '' THEN @v_Database + '.' ELSE '' END + 'SYS.OBJECTS';
	SET @v_Condition = 'OBJECT_ID = OBJECT_ID(LTRIM(RTRIM(UPPER(N''' + @v_CorrectedName +'''))) ) AND TYPE = ''P''';

	EXEC DBTD_ASSERT_IS_EXPECTED_COUNT 0, @v_FullSysObjectName, @v_Condition, @v_Message;
END;
GO

--************************************************************************************************
--verifies that table do exists in the database
CREATE PROCEDURE DBTD_ASSERT_TABLE_EXISTS
(
	@v_TableName	SYSNAME,		--table name 
	@v_UserMessage	NVARCHAR(MAX)	--user message
)
WITH ENCRYPTION AS
BEGIN
	SET NOCOUNT ON;
	DECLARE @v_Server			VARCHAR(2000),
			@v_Database			VARCHAR(2000),
			@v_Schema			VARCHAR(2000),
			@v_Object			VARCHAR(2000),
			@v_ObjectID			BIGINT,
			@v_CorrectedName	VARCHAR(2000),
			@v_FullSysObjectName NVARCHAR(128) = '',
			@v_Condition		NVARCHAR(MAX) = ''
	DECLARE @v_ProcName	NVARCHAR(128) = OBJECT_NAME(@@PROCID)
	DECLARE @v_Message NVARCHAR(MAX) = 'Running ' + @v_ProcName;
	EXEC DBTD_LOG_MESSAGE_EXT 'DEBUG', @v_ProcName, @v_Message;

	EXEC DBTD_SPLIT_FOUR_PART_OBJECT_NAME 
		@v_TableName, 
		@v_Server = @v_Server OUTPUT, @v_Database = @v_Database OUTPUT, @v_Schema = @v_Schema OUTPUT, 
		@v_Object = @v_Object OUTPUT, @v_CorrectedName = @v_CorrectedName OUTPUT,
		@v_CorrectTempTablesLocation = 1;

	SET @v_ObjectID = OBJECT_ID(@v_CorrectedName)
	EXEC DBTD_CACHE_TESTRESULT_DETAILS @v_ObjectName = @v_Object, @v_ObjectDatabase	= @v_Database, @v_ObjectFullName = @v_CorrectedName, @v_CallingProcName	= @v_ProcName, @v_ObjectID = @v_ObjectID, @v_ObjectSchema = @v_Schema

	SET @v_Message = ISNULL(@v_UserMessage + '.', '') + ' Cannot find TABLE "' + LTRIM(RTRIM(UPPER(@v_TableName))) + '"' ; 

	SET @v_FullSysObjectName = CASE WHEN @v_Database IS NOT NULL AND @v_Database != '' THEN @v_Database + '.' ELSE '' END + 'SYS.OBJECTS';
	SET @v_Condition = 'OBJECT_ID = OBJECT_ID(LTRIM(RTRIM(UPPER(N''' + @v_CorrectedName +'''))) ) AND TYPE = ''U''';

	EXEC DBTD_ASSERT_IS_NOT_EXPECTED_COUNT 0, @v_FullSysObjectName, @v_Condition, @v_Message;
END;
GO

--************************************************************************************************
--verifies that object do exists in the database
CREATE PROCEDURE DBTD_ASSERT_OBJECT_EXISTS
(
	@v_ObjectName	SYSNAME,		--object name 
	@v_UserMessage	NVARCHAR(MAX)	--user message
)
WITH ENCRYPTION AS
BEGIN
	SET NOCOUNT ON;
	DECLARE @v_ProcName	NVARCHAR(128) = OBJECT_NAME(@@PROCID)
	DECLARE @v_Message NVARCHAR(MAX) = 'Running ' + @v_ProcName,
			@v_ObjectID BIGINT = OBJECT_ID(@v_ObjectName)
	DECLARE @v_Server VARCHAR(2000),
			@v_Database VARCHAR(2000),
			@v_Schema VARCHAR(2000),
			@v_Object VARCHAR(2000),
			@v_CorrectedName VARCHAR(2000),
			@v_FullSysObjectName NVARCHAR(128) = ''
	EXEC DBTD_LOG_MESSAGE_EXT 'DEBUG', @v_ProcName, @v_Message;
	
	EXEC DBTD_SPLIT_FOUR_PART_OBJECT_NAME 
		@v_ObjectName, 
		@v_Server = @v_Server OUTPUT, @v_Database = @v_Database OUTPUT, @v_Schema = @v_Schema OUTPUT, 
		@v_Object = @v_Object OUTPUT, @v_CorrectedName = @v_CorrectedName OUTPUT,
		@v_CorrectTempTablesLocation = 1

	EXEC DBTD_CACHE_TESTRESULT_DETAILS @v_ObjectName = @v_Object, @v_ObjectDatabase = @v_Database, @v_ObjectFullName = @v_CorrectedName, @v_CallingProcName = @v_ProcName, @v_ObjectID = NULL, @v_ObjectSchema = @v_Schema

	IF @v_ObjectID IS NULL
	BEGIN
		SET @v_Message = ISNULL(@v_UserMessage + '.', '') 
			+ ' Cannot Fing object "' + LTRIM(RTRIM(UPPER(@v_CorrectedName))) + '" in the ' + UPPER(@v_Database) + ' database'; 
		EXEC DBTD_FAILURE @v_Message; 
	END;	
END;
GO

--************************************************************************************************
--verifies that object do exists in the database
CREATE PROCEDURE DBTD_ASSERT_OBJECT_NOT_EXISTS
(
	@v_ObjectName	SYSNAME,		--object name 
	@v_UserMessage	NVARCHAR(MAX)	--user message
)
WITH ENCRYPTION AS
BEGIN
	SET NOCOUNT ON;
	DECLARE @v_ProcName	NVARCHAR(128) = OBJECT_NAME(@@PROCID)
	DECLARE @v_Message NVARCHAR(MAX) = 'Running ' + @v_ProcName,
			@v_ObjectID BIGINT = OBJECT_ID(@v_ObjectName)
	DECLARE @v_Server VARCHAR(2000),
			@v_Database VARCHAR(2000),
			@v_Schema VARCHAR(2000),
			@v_Object VARCHAR(2000),
			@v_CorrectedName VARCHAR(2000),
			@v_FullSysObjectName NVARCHAR(128) = ''
	EXEC DBTD_LOG_MESSAGE_EXT 'DEBUG', @v_ProcName, @v_Message ;
	
	EXEC DBTD_SPLIT_FOUR_PART_OBJECT_NAME 
		@v_ObjectName, 
		@v_Server = @v_Server OUTPUT, @v_Database = @v_Database OUTPUT, @v_Schema = @v_Schema OUTPUT, 
		@v_Object = @v_Object OUTPUT, @v_CorrectedName = @v_CorrectedName OUTPUT,
		@v_CorrectTempTablesLocation = 1;

	EXEC DBTD_CACHE_TESTRESULT_DETAILS @v_ObjectName = @v_Object, @v_ObjectDatabase = @v_Database, @v_ObjectFullName = @v_CorrectedName, @v_CallingProcName = @v_ProcName, @v_ObjectID = NULL, @v_ObjectSchema = @v_Schema

	IF @v_ObjectID IS NOT NULL
	BEGIN
		SET @v_Message = ISNULL(@v_UserMessage + '.', '') 
			+ ' Unexpected object "' + LTRIM(RTRIM(UPPER(@v_CorrectedName))) + '" found in the ' + UPPER(@v_Database) + ' database'; 
		EXEC DBTD_FAILURE @v_Message; 
	END;	
END;
GO

--************************************************************************************************
--verifies that table does not exists in the database
CREATE PROCEDURE DBTD_ASSERT_TABLE_NOT_EXISTS
(
	@v_TableName	SYSNAME,		--table name  
	@v_UserMessage	NVARCHAR(MAX)	--user message
)
WITH ENCRYPTION AS
BEGIN
	SET NOCOUNT ON;
	DECLARE @v_Server VARCHAR(2000),
			@v_Database VARCHAR(2000),
			@v_Schema VARCHAR(2000),
			@v_Object VARCHAR(2000),
			@v_CorrectedName VARCHAR(2000),
			@v_FullSysObjectName NVARCHAR(128) = '',
			@v_Condition NVARCHAR(MAX) = ''
	DECLARE @v_ProcName	NVARCHAR(128) = OBJECT_NAME(@@PROCID)
	DECLARE @v_Message NVARCHAR(MAX) = 'Running ' + @v_ProcName;
	EXEC DBTD_LOG_MESSAGE_EXT 'DEBUG', @v_ProcName, @v_Message;

	EXEC DBTD_SPLIT_FOUR_PART_OBJECT_NAME 
		@v_TableName, 
		@v_Server = @v_Server OUTPUT, @v_Database = @v_Database OUTPUT, @v_Schema = @v_Schema OUTPUT, 
		@v_Object = @v_Object OUTPUT, @v_CorrectedName = @v_CorrectedName OUTPUT,
		@v_CorrectTempTablesLocation = 1;

	EXEC DBTD_CACHE_TESTRESULT_DETAILS @v_ObjectName = @v_Object, @v_ObjectDatabase = @v_Database, @v_ObjectFullName = @v_CorrectedName, @v_CallingProcName = @v_ProcName, @v_ObjectID = NULL, @v_ObjectSchema = @v_Schema

	SET @v_Message = ISNULL(@v_UserMessage + '.', '') + ' Unexpected TABLE "' + LTRIM(RTRIM(UPPER(@v_TableName))) + '" found in the database.' ; 

	SET @v_FullSysObjectName = CASE WHEN @v_Database IS NOT NULL AND @v_Database != '' THEN @v_Database + '.' ELSE '' END + 'SYS.OBJECTS';
	SET @v_Condition = 'OBJECT_ID = OBJECT_ID(LTRIM(RTRIM(UPPER(N''' + @v_CorrectedName +'''))) ) AND TYPE = ''U''';

	EXEC DBTD_ASSERT_IS_EXPECTED_COUNT 0, @v_FullSysObjectName, @v_Condition, @v_Message;
END;
GO

--************************************************************************************************
--verifies that view do exists in the database
CREATE PROCEDURE DBTD_ASSERT_VIEW_EXISTS
(
	@v_ViewName		SYSNAME,		--view name 
	@v_UserMessage	NVARCHAR(MAX)	--user message
)
WITH ENCRYPTION AS
BEGIN
	SET NOCOUNT ON;
	DECLARE @v_Server VARCHAR(2000),
			@v_Database VARCHAR(2000),
			@v_Schema VARCHAR(2000),
			@v_Object VARCHAR(2000),
			@v_CorrectedName VARCHAR(2000),
			@v_FullSysObjectName NVARCHAR(128) = '',
			@v_Condition NVARCHAR(MAX) = ''
	DECLARE @v_ProcName	NVARCHAR(128) = OBJECT_NAME(@@PROCID)
	DECLARE @v_Message NVARCHAR(MAX) = 'Running ' + @v_ProcName;
	EXEC DBTD_LOG_MESSAGE_EXT 'DEBUG', @v_ProcName, @v_Message;

	EXEC DBTD_SPLIT_FOUR_PART_OBJECT_NAME 
		@v_ViewName, 
		@v_Server = @v_Server OUTPUT, @v_Database = @v_Database OUTPUT, @v_Schema = @v_Schema OUTPUT, 
		@v_Object = @v_Object OUTPUT, @v_CorrectedName = @v_CorrectedName OUTPUT,
		@v_CorrectTempTablesLocation = 1;

	EXEC DBTD_CACHE_TESTRESULT_DETAILS @v_ObjectName = @v_Object, @v_ObjectDatabase = @v_Database, @v_ObjectFullName = @v_CorrectedName, @v_CallingProcName = @v_ProcName, @v_ObjectID = NULL, @v_ObjectSchema = @v_Schema

	SET @v_Message = ISNULL(@v_UserMessage + '.', '') + ' Cannot find VIEW "' + LTRIM(RTRIM(UPPER(@v_ViewName))) + '"' ; 

	SET @v_FullSysObjectName = CASE WHEN @v_Database IS NOT NULL AND @v_Database != '' THEN @v_Database + '.' ELSE '' END + 'SYS.OBJECTS';
	SET @v_Condition = 'OBJECT_ID = OBJECT_ID(LTRIM(RTRIM(UPPER(N''' + @v_CorrectedName +'''))) ) AND TYPE = ''V''';

	EXEC DBTD_ASSERT_IS_NOT_EXPECTED_COUNT 0, @v_FullSysObjectName, @v_Condition, @v_Message;
END;
GO

--************************************************************************************************
--verifies that view does not exists in the database
CREATE PROCEDURE DBTD_ASSERT_VIEW_NOT_EXISTS
(
	@v_ViewName		SYSNAME,		--View name 
	@v_UserMessage	NVARCHAR(MAX)	--User message
)
WITH ENCRYPTION AS
BEGIN
	SET NOCOUNT ON;
	DECLARE @v_Server VARCHAR(2000),
			@v_Database VARCHAR(2000),
			@v_Schema VARCHAR(2000),
			@v_Object VARCHAR(2000),
			@v_CorrectedName VARCHAR(2000),
			@v_FullSysObjectName NVARCHAR(128) = '',
			@v_Condition NVARCHAR(MAX) = ''
	DECLARE @v_ProcName	NVARCHAR(128) = OBJECT_NAME(@@PROCID)
	DECLARE @v_Message NVARCHAR(MAX) = 'Running ' + @v_ProcName;
	EXEC DBTD_LOG_MESSAGE_EXT 'DEBUG', @v_ProcName, @v_Message;

	EXEC DBTD_SPLIT_FOUR_PART_OBJECT_NAME 
		@v_ViewName, 
		@v_Server = @v_Server OUTPUT, @v_Database = @v_Database OUTPUT, @v_Schema = @v_Schema OUTPUT, 
		@v_Object = @v_Object OUTPUT, @v_CorrectedName = @v_CorrectedName OUTPUT,
		@v_CorrectTempTablesLocation = 1;

	EXEC DBTD_CACHE_TESTRESULT_DETAILS @v_ObjectName = @v_Object, @v_ObjectDatabase = @v_Database, @v_ObjectFullName = @v_CorrectedName, @v_CallingProcName = @v_ProcName, @v_ObjectID = NULL, @v_ObjectSchema = @v_Schema

	SET @v_Message = ISNULL(@v_UserMessage + '.', '') + ' Unexpected VIEW "' + LTRIM(RTRIM(UPPER(@v_ViewName))) + '" found in the database.' ; 

	SET @v_FullSysObjectName = CASE WHEN @v_Database IS NOT NULL AND @v_Database != '' THEN @v_Database + '.' ELSE '' END + 'SYS.OBJECTS';
	SET @v_Condition = 'OBJECT_ID = OBJECT_ID(LTRIM(RTRIM(UPPER(N''' + @v_CorrectedName +'''))) ) AND TYPE = ''V''';

	EXEC DBTD_ASSERT_IS_EXPECTED_COUNT 0, @v_FullSysObjectName, @v_Condition, @v_Message;
END;
GO

--************************************************************************************************
--verifies that view or table does exists in the database
CREATE PROCEDURE DBTD_ASSERT_TABLE_OR_VIEW_EXISTS
(
	@v_ObjectName	SYSNAME,		--table or view name  
	@v_UserMessage	NVARCHAR(MAX)	--user message
)
WITH ENCRYPTION AS
BEGIN
	SET NOCOUNT ON;
	DECLARE @v_Server VARCHAR(2000),
			@v_Database VARCHAR(2000),
			@v_Schema VARCHAR(2000),
			@v_Object VARCHAR(2000),
			@v_CorrectedName VARCHAR(2000),
			@v_FullSysObjectName NVARCHAR(128) = '',
			@v_Condition NVARCHAR(MAX) = ''
	DECLARE @v_ProcName	NVARCHAR(128) = OBJECT_NAME(@@PROCID)
	DECLARE @v_Message NVARCHAR(MAX) = 'Running ' + @v_ProcName;
	EXEC DBTD_LOG_MESSAGE_EXT 'DEBUG', @v_ProcName, @v_Message;

	EXEC DBTD_SPLIT_FOUR_PART_OBJECT_NAME 
		@v_ObjectName, 
		@v_Server = @v_Server OUTPUT, @v_Database = @v_Database OUTPUT, @v_Schema = @v_Schema OUTPUT, 
		@v_Object = @v_Object OUTPUT, @v_CorrectedName = @v_CorrectedName OUTPUT,
		@v_CorrectTempTablesLocation = 1;

	EXEC DBTD_CACHE_TESTRESULT_DETAILS @v_ObjectName = @v_Object, @v_ObjectDatabase = @v_Database, @v_ObjectFullName = @v_CorrectedName, @v_CallingProcName = @v_ProcName, @v_ObjectID = NULL, @v_ObjectSchema = @v_Schema

	SET @v_Message = ISNULL(@v_UserMessage + '.', '') + ' Cannot find neither VIEW nor TABLE with name "' + LTRIM(RTRIM(UPPER(@v_ObjectName))) + '" in the database.' ; 

	SET @v_FullSysObjectName = CASE WHEN @v_Database IS NOT NULL AND @v_Database != '' THEN @v_Database + '.' ELSE '' END + 'SYS.OBJECTS';
	SET @v_Condition = 'OBJECT_ID = OBJECT_ID(LTRIM(RTRIM(UPPER(N''' + @v_CorrectedName +'''))) ) AND TYPE IN (''V'', ''U'')';

	EXEC DBTD_ASSERT_IS_NOT_EXPECTED_COUNT 0, @v_FullSysObjectName, @v_Condition, @v_Message;
END;
GO

--************************************************************************************************
-- Checks that column EXISTS in the exhisting table or view.  
CREATE PROCEDURE DBTD_ASSERT_COLUMN_EXISTS
(
	@v_ObjectName	SYSNAME,		--Table or View name
	@v_ColumnName	SYSNAME,		--Column Name 
	@v_UserMessage	NVARCHAR(MAX)	--User message
)
WITH ENCRYPTION AS
BEGIN
	SET NOCOUNT ON;
	DECLARE @v_Server VARCHAR(2000),
			@v_Database VARCHAR(2000),
			@v_Schema VARCHAR(2000),
			@v_Object VARCHAR(2000),
			@v_CorrectedName VARCHAR(2000),
			@v_FullSysObjectName NVARCHAR(128) = '',
			@v_Condition NVARCHAR(MAX) = ''
	DECLARE @v_ProcName	NVARCHAR(128) = OBJECT_NAME(@@PROCID)
	DECLARE @v_Message NVARCHAR(MAX) = 'Running ' + @v_ProcName;
	EXEC DBTD_LOG_MESSAGE_EXT 'DEBUG', @v_ProcName, @v_Message;

	--first check that table even exists 
	EXEC DBTD_ASSERT_TABLE_OR_VIEW_EXISTS @v_ObjectName, @v_UserMessage;
	
	EXEC DBTD_SPLIT_FOUR_PART_OBJECT_NAME 
		@v_ObjectName, 
		@v_Server = @v_Server OUTPUT, @v_Database = @v_Database OUTPUT, @v_Schema = @v_Schema OUTPUT, 
		@v_Object = @v_Object OUTPUT, @v_CorrectedName = @v_CorrectedName OUTPUT,
		@v_CorrectTempTablesLocation = 1;

	SET @v_Message = ISNULL(@v_UserMessage + '.', '') + ' Object ' + LTRIM(RTRIM(UPPER(@v_CorrectedName))) + ' does not have ['+ LTRIM(RTRIM(UPPER(@v_ColumnName))) +'] column.' ; 

	SET @v_FullSysObjectName = CASE WHEN @v_Database IS NOT NULL AND @v_Database != '' THEN @v_Database + '.' ELSE '' END + 'dbo.SYSCOLUMNS';
	SET @v_Condition = 'ID = OBJECT_ID(LTRIM(RTRIM(UPPER(N''' + @v_CorrectedName +'''))) ) AND NAME = LTRIM(RTRIM(UPPER(''' + @v_ColumnName + ''')))';

	EXEC DBTD_ASSERT_IS_NOT_EXPECTED_COUNT 0, @v_FullSysObjectName, @v_Condition, @v_Message;
END;
GO

--************************************************************************************************
-- Checks that column DOES NOT EXISTS in the existing table or view 
-- will fail if table does not exist
CREATE PROCEDURE DBTD_ASSERT_COLUMN_NOT_EXISTS
(
	@v_ObjectName	SYSNAME,		--Table or View name
	@v_ColumnName	SYSNAME,		--Column Name
	@v_UserMessage	NVARCHAR(MAX)	--User message
)
WITH ENCRYPTION AS
BEGIN
	SET NOCOUNT ON;
	DECLARE @v_Server VARCHAR(2000),
			@v_Database VARCHAR(2000),
			@v_Schema VARCHAR(2000),
			@v_Object VARCHAR(2000),
			@v_CorrectedName VARCHAR(2000),
			@v_FullSysObjectName NVARCHAR(128) = '',
			@v_Condition NVARCHAR(MAX) = ''
	DECLARE @v_ProcName	NVARCHAR(128) = OBJECT_NAME(@@PROCID)
	DECLARE @v_Message NVARCHAR(MAX) = 'Running ' + @v_ProcName;
	EXEC DBTD_LOG_MESSAGE_EXT 'DEBUG', @v_ProcName, @v_Message;

	--first check that table even exists 
	EXEC DBTD_ASSERT_TABLE_OR_VIEW_EXISTS @v_ObjectName, @v_UserMessage;

	EXEC DBTD_SPLIT_FOUR_PART_OBJECT_NAME 
		@v_ObjectName, 
		@v_Server = @v_Server OUTPUT, @v_Database = @v_Database OUTPUT, @v_Schema = @v_Schema OUTPUT, 
		@v_Object = @v_Object OUTPUT, @v_CorrectedName = @v_CorrectedName OUTPUT,
		@v_CorrectTempTablesLocation = 1;

	SET @v_Message = ISNULL(@v_UserMessage + '.', '') + ' Object ' + LTRIM(RTRIM(UPPER(@v_ObjectName))) + ' have unexpected ['+ LTRIM(RTRIM(UPPER(@v_ColumnName))) +'] column.' ; 

	SET @v_FullSysObjectName = CASE WHEN @v_Database IS NOT NULL AND @v_Database != '' THEN @v_Database + '.' ELSE '' END + 'dbo.SYSCOLUMNS';
	SET @v_Condition = 'ID = OBJECT_ID(LTRIM(RTRIM(UPPER(N''' + @v_CorrectedName +'''))) ) AND NAME = LTRIM(RTRIM(UPPER(''' + @v_ColumnName + ''')))';

	EXEC DBTD_ASSERT_IS_EXPECTED_COUNT 0, @v_FullSysObjectName, @v_Condition, @v_Message;
END;
GO

--************************************************************************************************
-- Checks that column is nullable in the existing table or view 
-- will fail if corresponding view or table cannot be found
CREATE PROCEDURE DBTD_ASSERT_COLUMN_IS_NULLABLE
(
	@v_ObjectName	SYSNAME,		--Table or View name
	@v_ColumnName	SYSNAME,		--Column Name
	@v_UserMessage	NVARCHAR(MAX)	--User message
)
WITH ENCRYPTION AS
BEGIN
	SET NOCOUNT ON;
	DECLARE @v_ProcName	NVARCHAR(128) = OBJECT_NAME(@@PROCID)
	DECLARE @v_Message NVARCHAR(MAX) = 'Running ' + @v_ProcName;
	EXEC DBTD_LOG_MESSAGE_EXT 'DEBUG', @v_ProcName, @v_Message;

	DECLARE @v_Server VARCHAR(2000),
			@v_Database VARCHAR(2000),
			@v_Schema VARCHAR(2000),
			@v_Object VARCHAR(2000),
			@v_CorrectedName VARCHAR(2000),
			@v_FullSysObjectName NVARCHAR(128) = '',
			@v_Condition NVARCHAR(MAX) = ''

	--first check that columns exists 
	EXEC DBTD_ASSERT_COLUMN_EXISTS @v_ObjectName, @v_ColumnName, @v_UserMessage;

	EXEC DBTD_SPLIT_FOUR_PART_OBJECT_NAME 
		@v_ObjectName, 
		@v_Server = @v_Server OUTPUT, @v_Database = @v_Database OUTPUT, @v_Schema = @v_Schema OUTPUT, 
		@v_Object = @v_Object OUTPUT, @v_CorrectedName = @v_CorrectedName OUTPUT,
		@v_CorrectTempTablesLocation = 1;

	SET @v_Message = ISNULL(@v_UserMessage + '.', '') + ' "'+ LTRIM(RTRIM(UPPER(@v_ColumnName))) +'" column is NOT nullable in the "' + LTRIM(RTRIM(UPPER(@v_ObjectName))) + '" object.' ; 

	SET @v_FullSysObjectName = CASE WHEN @v_Database IS NOT NULL AND @v_Database != '' THEN @v_Database + '.' ELSE '' END + 'dbo.SYSCOLUMNS';
	SET @v_Condition = ' ID = OBJECT_ID(LTRIM(RTRIM(UPPER(N''' + @v_CorrectedName +'''))) ) AND ISNULLABLE = 1 ';

	EXEC DBTD_ASSERT_IS_NOT_EXPECTED_COUNT 0, @v_FullSysObjectName, @v_Condition, @v_Message;
END;
GO

--************************************************************************************************
-- Checks that column is NOT nullable in the existing table or view 
-- Will fail if corresponding view or table cannot be found
CREATE PROCEDURE DBTD_ASSERT_COLUMN_IS_NOT_NULLABLE
(
	@v_ObjectName	SYSNAME,		--Table or View name
	@v_ColumnName	SYSNAME,		--Column Name
	@v_UserMessage	NVARCHAR(MAX)	--User message
)
WITH ENCRYPTION AS
BEGIN
	SET NOCOUNT ON;
	DECLARE @v_Server VARCHAR(2000),
			@v_Database VARCHAR(2000),
			@v_Schema VARCHAR(2000),
			@v_CorrectedName VARCHAR(2000),
			@v_Object VARCHAR(2000),
			@v_FullSysObjectName NVARCHAR(128) = '',
			@v_Condition NVARCHAR(2000) = ''
	DECLARE @v_ProcName	NVARCHAR(128) = OBJECT_NAME(@@PROCID)
	DECLARE @v_Message NVARCHAR(MAX) = 'Running ' + @v_ProcName;
	EXEC DBTD_LOG_MESSAGE_EXT 'DEBUG', @v_ProcName, @v_Message;

	--first check that columns exists 
	EXEC DBTD_ASSERT_COLUMN_EXISTS @v_ObjectName, @v_ColumnName, @v_UserMessage;

	EXEC DBTD_SPLIT_FOUR_PART_OBJECT_NAME 
		@v_ObjectName, 
		@v_Server = @v_Server OUTPUT, @v_Database = @v_Database OUTPUT, @v_Schema = @v_Schema OUTPUT, 
		@v_Object = @v_Object OUTPUT, @v_CorrectedName = @v_CorrectedName OUTPUT,
		@v_CorrectTempTablesLocation = 1;

	SET @v_Message = ISNULL(@v_UserMessage + '.', '') + ' "'+ LTRIM(RTRIM(UPPER(@v_ColumnName))) +'" column is nullable in the "' + LTRIM(RTRIM(UPPER(@v_ObjectName))) + '" object.' ; 

	SET @v_FullSysObjectName = CASE WHEN @v_Database IS NOT NULL AND @v_Database != '' THEN @v_Database + '.' ELSE '' END + 'dbo.SYSCOLUMNS';
	SET @v_Condition = 'ID = OBJECT_ID(LTRIM(RTRIM(UPPER(N''' + @v_CorrectedName  +'''))) ) AND ISNULLABLE = 0 ';

	EXEC DBTD_ASSERT_IS_NOT_EXPECTED_COUNT 0, @v_FullSysObjectName, @v_Condition, @v_Message;
END;
GO

--************************************************************************************************
-- Checks that column is NOT nullable in the existing table or view 
-- Will fail if corresponding view or table cannot be found
CREATE PROCEDURE DBTD_ASSERT_DEFAULT_CONSTRAINT
(
	@v_DefaultConstrant				SYSNAME,		--Default Constrant Name 
	@v_TableName					SYSNAME,		--Table name, supports four part object name server.database.schema.object
	@v_DefaultConstrantDefinition	NVARCHAR(MAX),	--SQL expression that defines default constraint. NOTE: integers wrapped in (())
	@v_UserMessage					NVARCHAR(MAX)	--User message
)
WITH ENCRYPTION AS
BEGIN
	SET NOCOUNT ON; 
	DECLARE @v_SQL				NVARCHAR(MAX),
			@v_ParmDefinition	NVARCHAR(MAX) = N' @v_DefinitionValue NVARCHAR(MAX), @v_ActualValue NVARCHAR(MAX) OUTPUT ',
			@v_ActualValue		NVARCHAR(MAX),
			@v_Server			VARCHAR(2000),
			@v_Database			VARCHAR(2000),
			@v_Schema			VARCHAR(2000),
			@v_CorrectedName	VARCHAR(2000),
			@v_Object			VARCHAR(2000),
			@v_ObjectID			INT,
			@v_DefaultConstrantID INT,
			@v_FullDefaultConstrantName NVARCHAR(128) = '',
			@v_FullSysObjectName NVARCHAR(128) = '',
			@v_Condition		NVARCHAR(2000) = ''
	DECLARE @v_ProcName			NVARCHAR(128) = OBJECT_NAME(@@PROCID)
	DECLARE @v_Message			NVARCHAR(MAX) = 'Running ' + @v_ProcName;

	EXEC DBTD_LOG_MESSAGE_EXT 'DEBUG', @v_ProcName, @v_Message;

	EXEC DBTD_SPLIT_FOUR_PART_OBJECT_NAME 
		@v_TableName, 
		@v_Server = @v_Server OUTPUT, @v_Database = @v_Database OUTPUT, @v_Schema = @v_Schema OUTPUT, 
		@v_Object = @v_Object OUTPUT, @v_CorrectedName = @v_CorrectedName OUTPUT,
		@v_CorrectTempTablesLocation = 1;

	SET @v_ObjectID = OBJECT_ID(@v_CorrectedName)
	EXEC DBTD_CACHE_TESTRESULT_DETAILS @v_ObjectName = @v_Object, @v_ObjectDatabase	= @v_Database, @v_ObjectFullName = @v_CorrectedName, @v_CallingProcName	= @v_ProcName, @v_ObjectID = @v_ObjectID, @v_ObjectSchema = @v_Schema
	EXEC DBTD_ASSERT_TABLE_EXISTS @v_CorrectedName, @v_UserMessage;

	SET @v_FullDefaultConstrantName = 
		CASE WHEN @v_Database IS NOT NULL AND @v_Database != '' THEN @v_Database + '.' ELSE '' END 
		+ CASE WHEN @v_Schema IS NOT NULL AND @v_Schema != '' THEN @v_Schema + '.' ELSE 'dbo.' END 
		+ @v_DefaultConstrant;
	SET @v_DefaultConstrantID = OBJECT_ID(@v_FullDefaultConstrantName)
	EXEC DBTD_CACHE_TESTRESULT_DETAILS @v_ObjectName = @v_DefaultConstrant, @v_ObjectDatabase = @v_Database, @v_ObjectFullName = @v_FullDefaultConstrantName, @v_CallingProcName	= @v_ProcName, @v_ObjectID = @v_DefaultConstrantID, @v_ObjectSchema = @v_Schema

	SET @v_Message = ISNULL(@v_UserMessage + '.', '') + ' "'+ LTRIM(RTRIM(UPPER(@v_DefaultConstrant))) +'" default constrant is not defined for "' + LTRIM(RTRIM(UPPER(@v_CorrectedName))) + '" object.'; 
	SET @v_FullSysObjectName = CASE WHEN @v_Database IS NOT NULL AND @v_Database != '' THEN @v_Database + '.' ELSE '' END + 'sys.objects';
	SET @v_Condition = 'parent_object_id = '+CAST(@v_ObjectID AS VARCHAR(50))
		+ ' AND object_id = '+CAST(@v_DefaultConstrantID AS VARCHAR(50))
	EXEC DBTD_ASSERT_IS_NOT_EXPECTED_COUNT 0, @v_FullSysObjectName, @v_Condition, @v_Message;

	SET @v_Message = ISNULL(@v_UserMessage + '.', '') + ' Default Constraint "'+ LTRIM(RTRIM(UPPER(@v_DefaultConstrant))) +'" has UNEXPECTED VALUE.'; 
	SET @v_FullSysObjectName = CASE WHEN @v_Database IS NOT NULL AND @v_Database != '' THEN @v_Database + '.' ELSE '' END + 'sys.default_constraints';
	SET @v_SQL = 
		'SELECT @v_ActualValue = definition FROM ' + @v_FullSysObjectName 
		+ ' WHERE parent_object_id = '+CAST(@v_ObjectID AS VARCHAR(50)) 
		+ ' AND object_id = '+CAST(@v_DefaultConstrantID AS VARCHAR(50))

	EXEC sp_executeSQL
		@v_SQL,
		@v_ParmDefinition,
		@v_DefinitionValue = @v_DefaultConstrantDefinition,
		@v_ActualValue = @v_ActualValue OUTPUT

	EXEC DBTD_ASSERT_ARE_EQUAL @v_ActualValue, @v_DefaultConstrantDefinition, @v_Message
END;
GO

--************************************************************************************************
-- Will fail if column with given type and precision cannot be found in the table or view
--DROP PROCEDURE DBTD_ASSERT_COLUMN_TYPE_AND_PRECISION
CREATE PROCEDURE DBTD_ASSERT_COLUMN_TYPE_AND_PRECISION
(
	@v_ObjectName		SYSNAME,		--Table or View name
	@v_ColumnName		SYSNAME,		--Column Name
	@v_ColumnType		NVARCHAR(255),	--Column Type
	@v_ColumnPrecScale	NVARCHAR(255),	--Column precision and scale
	@v_UserMessage		NVARCHAR(MAX)	--User message
)
WITH ENCRYPTION AS
BEGIN
	SET NOCOUNT ON;
	DECLARE @v_ParmDefinition NVARCHAR(MAX) = N'@v_InternalCount INT OUTPUT, @v_ObjectName NVARCHAR(255), @v_ColumnName NVARCHAR(255), @v_ColumnType NVARCHAR(255), @v_ColumnPrecScale NVARCHAR(255) ',
			@v_Sql		NVARCHAR(MAX) = '',
			@v_Server	NVARCHAR(2000),
			@v_Database NVARCHAR(2000),
			@v_Schema	NVARCHAR(2000),
			@v_Object	NVARCHAR(2000),
			@v_CorrectedName VARCHAR(2000),
			@v_InternalCount INT = 0

	DECLARE @v_ProcName	NVARCHAR(128) = OBJECT_NAME(@@PROCID)
	DECLARE @v_Message NVARCHAR(MAX) = 'Running ' + @v_ProcName;
	EXEC DBTD_LOG_MESSAGE_EXT 'DEBUG', @v_ProcName, @v_Message;

	--first check that columns exists 
	EXEC DBTD_ASSERT_COLUMN_EXISTS @v_ObjectName, @v_ColumnName, @v_UserMessage;

	EXEC DBTD_SPLIT_FOUR_PART_OBJECT_NAME 
		@v_ObjectName, 
		@v_Server = @v_Server OUTPUT, 
		@v_Database = @v_Database OUTPUT, 
		@v_Schema = @v_Schema OUTPUT, 
		@v_Object = @v_Object OUTPUT, 
		@v_CorrectedName = @v_CorrectedName OUTPUT,
		@v_CorrectTempTablesLocation = 1;

	SET @v_ColumnPrecScale = REPLACE(@v_ColumnPrecScale, ' ', ''); 


	SET @v_Sql = 
	'SELECT @v_InternalCount = COUNT(*) FROM (
		SELECT 
			CASE
				WHEN TypeName IN (''TIME'', ''DATETIME2'', ''DATETIMEOFFSET'') AND ColScale BETWEEN 0 AND 7 THEN ''('' + cast(ColScale as varchar(50)) + '')''				
				WHEN TypeName IN (''NUMERIC'',''DECIMAL'',''DEC'') AND (DataTypePrecision like ''%,0)'') THEN SUBSTRING(DataTypePrecision, 0, PATINDEX ( ''%,%'', DataTypePrecision)) + '')''
				WHEN TYPENAME IN (''VARCHAR'', ''CHAR VARYING'', ''CHARACTER VARYING'', ''NVARCHAR'', ''NATIONAL CHAR VARYING'', ''NATIONAL CHARACTER VARYING'', ''VARBINARY'') AND (DataTypePrecision like ''(-1)'') THEN ''(max)''
				ELSE DataTypePrecision	
			END AS PrecisionEquivalent,
			CASE
				WHEN p_ColumnType = ''FLOAT'' AND REPLACE(REPLACE(p_ColumnPrecScale, ''('',''''),'')'','''') between 1 and 24 THEN ''(24)''
				WHEN p_ColumnType = ''FLOAT'' AND REPLACE(REPLACE(p_ColumnPrecScale, ''('',''''),'')'','''') between 25 and 53 THEN ''(53)''
				ELSE p_ColumnPrecScale	
			END AS p_PrecisionEquivalent,
			A.* 
		FROM (SELECT 
				LTRIM(RTRIM(UPPER(@v_ObjectName)))	AS p_ObjectName,
				LTRIM(RTRIM(UPPER(@v_ColumnName))) AS p_ColumnName,
				LTRIM(RTRIM(UPPER(@v_ColumnType))) AS p_ColumnType,
				@v_ColumnPrecScale AS p_ColumnPrecScale,
				C.ID AS ObjectID,
				O.Name AS ObjectName,
				C.name AS ColumnName, 
				T.name AS TypeName,
				C.prec AS ColPrecision,
				C.scale AS ColScale,
				''(''+CAST(C.prec AS VARCHAR(50))+ISNULL('',''+CAST(C.scale AS VARCHAR(50)),'''')+'')'' AS DataTypePrecision,
				C.* 
			FROM '+CASE WHEN @v_Database IS NOT NULL AND @v_Database != '' THEN @v_Database+'.' ELSE '' END + 'dbo.SYSCOLUMNS AS C
				INNER JOIN (SELECT name, xusertype FROM '+CASE WHEN @v_Database IS NOT NULL AND @v_Database != '' THEN @v_Database+'.' ELSE '' END + 'dbo.SYSTYPES
							UNION 
							SELECT name, xusertype FROM DBTD_VW_DATATYPE ) AS T
					ON C.xusertype = T.xusertype
				INNER JOIN '+CASE WHEN @v_Database IS NOT NULL AND @v_Database != '' THEN @v_Database+'.' ELSE '' END + 'dbo.SYSOBJECTS AS O
					ON C.ID = O.ID
			WHERE O.ID = OBJECT_ID(@v_ObjectName)
			) AS A
		) AS B	
	WHERE ObjectID = OBJECT_ID(p_ObjectName)
		AND UPPER(ColumnName) = p_ColumnName
		AND UPPER(TypeName) = p_ColumnType
		AND (p_ColumnPrecScale = '''' OR p_ColumnPrecScale = DataTypePrecision OR p_ColumnPrecScale = PrecisionEquivalent OR p_PrecisionEquivalent = DataTypePrecision OR p_PrecisionEquivalent = PrecisionEquivalent)';
			
	EXECUTE sp_executeSQL
			@v_Sql,
			@v_ParmDefinition,
			@v_InternalCount=@v_InternalCount OUTPUT,
			@v_ObjectName=@v_CorrectedName, 
			@v_ColumnName=@v_ColumnName,
			@v_ColumnType=@v_ColumnType, 
			@v_ColumnPrecScale=@v_ColumnPrecScale;


	IF	(@v_InternalCount IS NULL OR @v_InternalCount <= 0)
	BEGIN
		SET @v_Message = ISNULL(@v_UserMessage + '.', '') 
			+ ' "' + LTRIM(RTRIM(UPPER(@v_ObjectName))) + '" object does not have "'
			+ LTRIM(RTRIM(UPPER(@v_ColumnName))) +'" column with "' 
			+ LTRIM(RTRIM(UPPER(@v_ColumnType))) +'" data type' ; 			 
		
		IF (@v_ColumnPrecScale != '' AND @v_ColumnPrecScale IS NOT NULL) 
		BEGIN
			SET @v_Message = @v_Message + ', and provided precision and scale ' + @v_ColumnPrecScale;
		END;

		EXEC DBTD_FAILURE @v_Message; 
	END;
END;
GO

--************************************************************************************************
-- Checks column data type is of the expected data type in the existing table
-- Will fail if corresponding view or table cannot be found
CREATE PROCEDURE DBTD_ASSERT_COLUMN_TYPE
(
	@v_ObjectName	SYSNAME,		--Table or View name
	@v_ColumnName	SYSNAME,		--Column Name
	@v_ColumnType	NVARCHAR(255),	--Column Type
	@v_UserMessage	NVARCHAR(MAX)	--User message
)
WITH ENCRYPTION AS
BEGIN
	SET NOCOUNT ON;
	DECLARE @v_ProcName	NVARCHAR(128) = OBJECT_NAME(@@PROCID)
	DECLARE @v_Message NVARCHAR(MAX) = 'Running ' + @v_ProcName;
	EXEC DBTD_LOG_MESSAGE_EXT 'DEBUG', @v_ProcName, @v_Message;
	--note: precision is ommitted 
	EXEC DBTD_ASSERT_COLUMN_TYPE_AND_PRECISION @v_ObjectName, @v_ColumnName, @v_ColumnType, '', @v_UserMessage;
END;
GO

--************************************************************************************************
--checks that values in the collumn is unique (or distinct) 
--DROP PROC DBTD_ASSERT_IS_COLUMN_VALUE_UNIQUE
CREATE PROCEDURE DBTD_ASSERT_IS_COLUMN_VALUE_UNIQUE
(
	@v_TableName		SYSNAME,		--Table name
	@v_ColumnName		SYSNAME,		--Column that should have unique\distinct values only
	@v_UserMessage		NVARCHAR(MAX)	--User message
)
WITH ENCRYPTION AS
BEGIN
	SET NOCOUNT ON;
	DECLARE @v_ProcName	NVARCHAR(128) = OBJECT_NAME(@@PROCID)
	DECLARE @v_Message NVARCHAR(MAX) = 'Running ' + @v_ProcName;
	EXEC DBTD_LOG_MESSAGE_EXT 'DEBUG', @v_ProcName, @v_Message;

	DECLARE @v_Server			VARCHAR(2000),
			@v_Database			VARCHAR(2000),
			@v_Schema			VARCHAR(2000),
			@v_CorrectedName	VARCHAR(2000),
			@v_Object			VARCHAR(2000),
			@v_ActualValue		BIGINT,
			@v_ColValue			NVARCHAR(MAX),
			@v_ExpectedValue	BIGINT,
			@v_SQL				NVARCHAR(MAX),
			@v_ParmDefinition	NVARCHAR(2000) = '@v_ActualValue_Internal BIGINT OUTPUT, @v_ColValue_Internal NVARCHAR(MAX) OUTPUT';

	EXEC DBTD_SPLIT_FOUR_PART_OBJECT_NAME 
		@v_TableName, 
		@v_Server = @v_Server OUTPUT, 
		@v_Database = @v_Database OUTPUT, 
		@v_Schema = @v_Schema OUTPUT, 
		@v_Object = @v_Object OUTPUT, 
		@v_CorrectedName = @v_CorrectedName OUTPUT,
		@v_CorrectTempTablesLocation = 1;

	SET @v_Message = 'Could not find ' + ISNULL(UPPER(@v_ColumnName), 'NULL') + ' in the ' + ISNULL(UPPER(@v_CorrectedName), 'NULL')
	EXEC DBTD_ASSERT_COLUMN_EXISTS @v_CorrectedName, @v_ColumnName, ''

	SET @v_SQL = 'SELECT @v_ActualValue_Internal = CT, @v_ColValue_Internal = CAST(COL_NM AS NVARCHAR(MAX)) FROM (SELECT ' + @v_ColumnName + ' AS COL_NM, COUNT(1) AS CT FROM ' 
	         + @v_CorrectedName + ' AS Y GROUP BY ' +@v_ColumnName + ') AS Z WHERE CT > 1 '; 

	EXEC DBTD_LOG_MESSAGE_EXT 'DEBUG', 'DBTD_ASSERT_IS_COL_VALUE_UNIQUE', @v_SQL;

	EXECUTE sp_executesql @v_SQL, @v_ParmDefinition, @v_ActualValue_Internal = @v_ActualValue OUTPUT, @v_ColValue_Internal = @v_ColValue OUTPUT;

	IF (@v_ActualValue IS NOT NULL AND @v_ActualValue > 1) 
	BEGIN
		SET @v_Message = ISNULL(@v_UserMessage + '.', '') 
			+ ' Duplicate values "' + LEFT(LTRIM(RTRIM(@v_ColValue)), 500)
			+'" are found in the "' + @v_CorrectedName 
			+ '" table "' + @v_ColumnName + '" column.';  
		EXEC DBTD_FAILURE @v_Message; 
	END;
END;
GO

--************************************************************************************************
--checks that column have a given value at list in one row of a given table 
CREATE PROCEDURE DBTD_ASSERT_COLUMN_HAVE_VALUE
(
	@v_TableName		SYSNAME,		--Table name
	@v_ColumnName		SYSNAME,		--Column that will be checked for a value
	@v_Value			NVARCHAR(4000),	--Asserted value
	@v_ValueDataType	NVARCHAR(255),	--Value data type
	@v_UserMessage		NVARCHAR(MAX)	--User message
)
WITH ENCRYPTION AS
BEGIN
	SET NOCOUNT ON;
	DECLARE @v_ProcName	NVARCHAR(128) = OBJECT_NAME(@@PROCID)
	DECLARE @v_Message NVARCHAR(MAX) = 'Running ' + @v_ProcName;
	EXEC DBTD_LOG_MESSAGE_EXT 'DEBUG', @v_ProcName, @v_Message;

	DECLARE @v_ActualValue	VARCHAR(50),
			@v_SQL			NVARCHAR(2000),
			@v_ParmDefinition NVARCHAR(2000);

	SET @v_Message = 'Could not find ' + ISNULL(UPPER(@v_ColumnName), 'NULL') + ' in the ' + ISNULL(UPPER(@v_TableName), 'NULL')
	EXEC DBTD_ASSERT_COLUMN_EXISTS @v_TableName, @v_ColumnName, @v_Message

	SET @v_ParmDefinition = '@v_ActualValue_Internal NVARCHAR(4000) OUTPUT'
	SET @v_SQL = 'SELECT @v_ActualValue_Internal = CAST(' + @v_ColumnName + ' AS NVARCHAR(4000))  FROM ' 
	         + @v_TableName + ' WHERE ' + @v_ColumnName + ' = CAST(''' + @v_Value + ''' AS ' + @v_ValueDataType + '); '; 
	EXECUTE sp_executesql @v_SQL, @v_ParmDefinition, @v_ActualValue_Internal = @v_ActualValue OUTPUT;

	IF (@v_ActualValue IS NULL)  
	BEGIN
		SET @v_Message = ISNULL(@v_UserMessage, '') 
			+ ' Expected values "' + ISNULL(@v_Value, 'NULL')
			+ '" of "' + ISNULL(@v_ValueDataType, 'NULL') + '" type '
			+ ' were NOT found in the "' + @v_TableName 
			+ '" table "' + @v_ColumnName + '" column.';  
		EXEC DBTD_FAILURE @v_Message; 
	END;
END;
GO

--************************************************************************************************
--checks that column have a NULL at list in one row of a given table 
CREATE PROCEDURE DBTD_ASSERT_COLUMN_HAVE_NULLS
(
	@v_TableName		SYSNAME,		--Table name
	@v_ColumnName		SYSNAME,		--Column that will be checked for a value
	@v_UserMessage		NVARCHAR(MAX)	--User message
)
WITH ENCRYPTION AS
BEGIN
	SET NOCOUNT ON;
	DECLARE @v_ActualValue	INT = NULL,
			@v_SQL			NVARCHAR(MAX),
			@v_ParmDefinition NVARCHAR(2000) = '@v_ActualValue_Internal INT OUTPUT';
	DECLARE @v_ProcName	NVARCHAR(128) = OBJECT_NAME(@@PROCID)
	DECLARE @v_Message NVARCHAR(MAX) = 'Running ' + @v_ProcName;
	EXEC DBTD_LOG_MESSAGE_EXT 'DEBUG', @v_ProcName, @v_Message;

	SET @v_Message = 'Could not find ' + ISNULL(UPPER(@v_ColumnName), 'NULL') + ' in the ' + ISNULL(UPPER(@v_TableName), 'NULL')
	EXEC DBTD_ASSERT_COLUMN_EXISTS @v_TableName, @v_ColumnName, @v_Message

	SET @v_SQL = 'SELECT @v_ActualValue_Internal = COUNT(1) AS CT FROM ' + @v_TableName + ' WHERE ' + @v_ColumnName + ' IS NULL '; 
	EXECUTE sp_executesql @v_SQL, @v_ParmDefinition, @v_ActualValue_Internal = @v_ActualValue OUTPUT;

	IF (@v_ActualValue IS NULL) OR (@v_ActualValue = 0 )
	BEGIN
		SET @v_Message = ISNULL(@v_UserMessage + '.', '') 
			+ ' Cannot find NULL values in the "' + @v_TableName 
			+ '" table.';  
		EXEC DBTD_FAILURE @v_Message; 
	END;
END;
GO

--************************************************************************************************
--checks that column does not have any NULLs given table 
CREATE PROCEDURE DBTD_ASSERT_COLUMN_HAS_NO_NULLS
(
	@v_TableName		SYSNAME,		--Table name
	@v_ColumnName		SYSNAME,		--Column that will be checked for a value
	@v_UserMessage		NVARCHAR(MAX)	--User message
)
WITH ENCRYPTION AS
BEGIN
	SET NOCOUNT ON;
	DECLARE @v_ActualValue	VARCHAR(50),
			@v_SQL			NVARCHAR(MAX),
			@v_ParmDefinition NVARCHAR(2000) = '@v_ActualValue_Internal INT OUTPUT';
	DECLARE @v_ProcName	NVARCHAR(128) = OBJECT_NAME(@@PROCID)
	DECLARE @v_Message NVARCHAR(MAX) = 'Running ' + @v_ProcName;
	EXEC DBTD_LOG_MESSAGE_EXT 'DEBUG', @v_ProcName, @v_Message;

	SET @v_Message = 'Could not find ' + ISNULL(UPPER(@v_ColumnName), 'NULL') + ' in the ' + ISNULL(UPPER(@v_TableName), 'NULL')
	EXEC DBTD_ASSERT_COLUMN_EXISTS @v_TableName, @v_ColumnName, @v_Message

	SET @v_SQL = 'SELECT @v_ActualValue_Internal = COUNT(1) FROM ' + @v_TableName + ' WHERE ' + @v_ColumnName + ' IS NULL '; 
	EXECUTE sp_executesql @v_SQL, @v_ParmDefinition, @v_ActualValue_Internal = @v_ActualValue OUTPUT;

	IF (@v_ActualValue IS NOT NULL) AND @v_ActualValue > 0
	BEGIN
		SET @v_Message = ISNULL(@v_UserMessage + '.', '') 
			+ ' Found NULL values in the "' + @v_TableName 
			+ '" table.';  
		EXEC DBTD_FAILURE @v_Message; 
	END;
END;
GO

--************************************************************************************************
--checks that column have a given value at list in one row of a given table 
CREATE PROCEDURE DBTD_ASSERT_COLUMN_HAS_NO_VALUE
(
	@v_TableName		SYSNAME,		--Table name
	@v_ColumnName		SYSNAME,		--Column that will be checked for a value
	@v_Value			NVARCHAR(4000),	--Asserted value
	@v_ValueDataType	NVARCHAR(255),	--Value data type
	@v_UserMessage		NVARCHAR(MAX)	--User message
)
WITH ENCRYPTION AS
BEGIN
	SET NOCOUNT ON;
	DECLARE @v_ActualValue	VARCHAR(50),
			@v_SQL			NVARCHAR(MAX),
			@v_ParmDefinition NVARCHAR(2000) = '@v_ActualValue_Internal INT OUTPUT';
	DECLARE @v_ProcName	NVARCHAR(128) = OBJECT_NAME(@@PROCID)
	DECLARE @v_Message NVARCHAR(MAX) = 'Running ' + @v_ProcName;
	EXEC DBTD_LOG_MESSAGE_EXT 'DEBUG', @v_ProcName, @v_Message;

	SET @v_Message = 'Could not find ' + ISNULL(UPPER(@v_ColumnName), 'NULL') + ' in the ' + ISNULL(UPPER(@v_TableName), 'NULL')
	EXEC DBTD_ASSERT_COLUMN_EXISTS @v_TableName, @v_ColumnName, @v_Message

	SET @v_SQL = 'SELECT @v_ActualValue_Internal = COUNT(1) FROM ' + @v_TableName + ' WHERE ' + @v_ColumnName + ' = CAST('''+@v_Value+''' AS '+@v_ValueDataType+')'; 
	EXEC DBTD_LOG_MESSAGE_EXT 'DEBUG', @v_ProcName, @v_SQL;
	EXECUTE sp_executesql @v_SQL, @v_ParmDefinition, @v_ActualValue_Internal = @v_ActualValue OUTPUT;

	IF (@v_ActualValue IS NOT NULL) AND @v_ActualValue > 0 
	BEGIN
		SET @v_Message = ISNULL(@v_UserMessage + '.', '') 
			+ ' NOT Expected values "'+@v_Value
			+ '" of "' +@v_ValueDataType+ '" type '
			+ ' has been found in the "' + @v_TableName 
			+ '" table "' + @v_ColumnName + '" column.';  
		EXEC DBTD_FAILURE @v_Message; 
	END;
END;
GO

--************************************************************************************************
--Checks that both tables have same number of rows
CREATE PROCEDURE DBTD_ASSERT_SAME_NUMBER_OF_ROWS
(
	@v_TableNameA	SYSNAME,		--Name of the first table 
	@v_TableNameB	SYSNAME,		--Name of the second table 
	@v_UserMessage	NVARCHAR(MAX)	--User message
)
WITH ENCRYPTION AS
BEGIN
	DECLARE @v_SQL NVARCHAR(MAX),
			@v_Value1 BIGINT, 
			@v_Value2 BIGINT,
			@v_ParmDefinition NVARCHAR(2000) = '@v_Value1_Internal BIGINT OUTPUT, @v_Value2_Internal BIGINT OUTPUT';
	DECLARE @v_ProcName	NVARCHAR(128) = OBJECT_NAME(@@PROCID)
	DECLARE @v_Message NVARCHAR(MAX) = 'Running ' + @v_ProcName;
	EXEC DBTD_LOG_MESSAGE_EXT 'DEBUG', @v_ProcName, @v_Message;

	SET @v_SQL = ' SELECT @v_Value1_Internal = (SELECT COUNT(1) FROM ' + @v_TableNameA + '), @v_Value2_Internal = (SELECT COUNT(1) FROM ' + @v_TableNameB + ') '; 
	EXECUTE sp_executesql @v_SQL, @v_ParmDefinition, @v_Value1_Internal = @v_Value1 OUTPUT, @v_Value2_Internal = @v_Value2 OUTPUT;

	IF (@v_Value1 != @v_Value1)  
	BEGIN
		SELECT @v_Message = ISNULL(@v_UserMessage + '.', '') 
			+ ' Tables have different number of rows: '
			+ @v_TableNameA + ' has ' + cast(@v_Value1 as varchar(50)) + ' rows'
			+ ' while  '
			+ @v_TableNameB + ' has ' + cast(@v_Value2 as varchar(50)) + ' rows';  
		EXEC DBTD_FAILURE @v_Message ; 
	END;
END;
GO

--************************************************************************************************
--checks that user exists in database
CREATE PROCEDURE DBTD_ASSERT_USER_EXISTS
(
	@v_UserName		SYSNAME,		--user name 
	@v_UserMessage	NVARCHAR(MAX)	--User message
)
WITH ENCRYPTION AS
BEGIN
	SET NOCOUNT ON;
	DECLARE @v_ProcName	NVARCHAR(128) = OBJECT_NAME(@@PROCID)
	DECLARE @v_Message NVARCHAR(MAX) = 'Running ' + @v_ProcName;
	EXEC DBTD_LOG_MESSAGE_EXT 'DEBUG', @v_ProcName, @v_Message;

	--note: reconsider to use: SELECT NAME, * FROM SYSUSERS WHERE ISSQLUSER = 1;
	IF NOT EXISTS (	SELECT * 
					FROM SYS.DATABASE_PRINCIPALS 
					WHERE 
						TYPE = 'S'	
						AND UPPER(NAME) = UPPER(LTRIM(RTRIM(@v_UserName)))
				)
	BEGIN
		SET @v_Message = ISNULL(@v_UserMessage + '.', '') 
			+ ' Cannot find User with name "' + LTRIM(RTRIM(UPPER(@v_UserName))) + '"' ; 
		EXEC DBTD_FAILURE @v_Message; 
	END;	
END;
GO

--************************************************************************************************
--checks that role exists in database
CREATE PROCEDURE DBTD_ASSERT_ROLE_EXISTS
(
	@v_RoleName		SYSNAME,		--Role name 
	@v_UserMessage	NVARCHAR(MAX)	--User message
)
WITH ENCRYPTION AS
BEGIN
	SET NOCOUNT ON;
	DECLARE @v_ProcName	NVARCHAR(128) = OBJECT_NAME(@@PROCID)
	DECLARE @v_Message NVARCHAR(MAX) = 'Running ' + @v_ProcName;
	EXEC DBTD_LOG_MESSAGE_EXT 'DEBUG', @v_ProcName, @v_Message;

	--note: reconsider to use: select name, * from sysusers where issqlrole = 1;
	IF NOT EXISTS (	SELECT * 
					FROM SYS.DATABASE_PRINCIPALS 
					WHERE 
						TYPE = 'R'	
						AND UPPER(NAME) = UPPER(LTRIM(RTRIM(@v_RoleName)))
				)
	BEGIN
		SET @v_Message = ISNULL(@v_UserMessage + '.', '') 
			+ ' Cannot find Role with name "' + LTRIM(RTRIM(UPPER(@v_RoleName))) + '"' ; 
		EXEC DBTD_FAILURE @v_Message; 
	END;	
END;
GO

--************************************************************************************************
--checks that login exists in database
CREATE PROCEDURE DBTD_ASSERT_LOGIN_EXISTS
(
	@v_LoginName	SYSNAME,		--Login name 
	@v_UserMessage	NVARCHAR(MAX)	--User message
)
WITH ENCRYPTION AS
BEGIN
	SET NOCOUNT ON;
	DECLARE @v_ProcName	NVARCHAR(128) = OBJECT_NAME(@@PROCID)
	DECLARE @v_Message NVARCHAR(MAX) = 'Running ' + @v_ProcName;
	EXEC DBTD_LOG_MESSAGE_EXT 'DEBUG', @v_ProcName, @v_Message;

	IF NOT EXISTS (	SELECT * 
					FROM SYSUSERS 
					WHERE 
						ISLOGIN = 1
						AND UPPER(NAME) = UPPER(LTRIM(RTRIM(@v_LoginName)))
				)
	BEGIN
		SET @v_Message = ISNULL(@v_UserMessage + '.', '') 
			+ ' Cannot find Login with name "' + LTRIM(RTRIM(UPPER(@v_LoginName))) + '"' ; 
		EXEC DBTD_FAILURE @v_Message; 
	END;	
END;
GO

--************************************************************************************************
--checks that database exists on the server
CREATE PROCEDURE DBTD_ASSERT_DB_EXISTS
(
	@v_DatabaseName	SYSNAME,		--Database name 
	@v_UserMessage	NVARCHAR(MAX)	--User message
)
WITH ENCRYPTION AS
BEGIN
	SET NOCOUNT ON;
	DECLARE @v_ProcName	NVARCHAR(128) = OBJECT_NAME(@@PROCID)
	DECLARE @v_Message NVARCHAR(MAX) = 'Running ' + @v_ProcName;
	EXEC DBTD_LOG_MESSAGE_EXT 'DEBUG', @v_ProcName, @v_Message;

	IF NOT EXISTS (	SELECT * 
					FROM SYS.DATABASES
					WHERE 
						UPPER(NAME) = UPPER(LTRIM(RTRIM(@v_DatabaseName)))
				)
	BEGIN
		SET @v_Message = ISNULL(@v_UserMessage + '.', '') 
			+ ' Cannot find database with name "' + LTRIM(RTRIM(UPPER(@v_DatabaseName))) + '"' ; 
		EXEC DBTD_FAILURE @v_Message; 
	END;	
END;
GO

--************************************************************************************************
--checks that trigger exists on the server
--DROP PROCEDURE DBTD_ASSERT_TRIGGER_EXISTS
CREATE PROCEDURE DBTD_ASSERT_TRIGGER_EXISTS
(
	@v_TriggerName	SYSNAME,		--Trigger name 
	@v_UserMessage	NVARCHAR(MAX)	--User message
)
WITH ENCRYPTION AS
BEGIN
	SET NOCOUNT ON;
	DECLARE @v_ProcName	NVARCHAR(128) = OBJECT_NAME(@@PROCID)
	DECLARE @v_Message NVARCHAR(MAX) = 'Running ' + @v_ProcName;
	EXEC DBTD_LOG_MESSAGE_EXT 'DEBUG', @v_ProcName, @v_Message;

	DECLARE @v_Server VARCHAR(2000),
			@v_Database VARCHAR(2000),
			@v_Schema VARCHAR(2000),
			@v_Object VARCHAR(2000),
			@v_CorrectedName VARCHAR(2000)

	EXEC DBTD_SPLIT_FOUR_PART_OBJECT_NAME 
		@v_TriggerName, 
		@v_Server = @v_Server OUTPUT, @v_Database = @v_Database OUTPUT, @v_Schema = @v_Schema OUTPUT, 
		@v_Object = @v_Object OUTPUT, @v_CorrectedName = @v_CorrectedName OUTPUT,
		@v_CorrectTempTablesLocation = 1;

	IF OBJECT_ID(@v_TriggerName) IS NULL
	BEGIN
		SET @v_Message = ISNULL(@v_UserMessage + '.', '') 
			+ ' Cannot find trigger "' + LTRIM(RTRIM(UPPER(@v_CorrectedName))) + '"' + ISNULL(' in the '+ @v_Database +' database', '') ; 
		EXEC DBTD_FAILURE @v_Message; 
	END;	
END;
GO

--************************************************************************************************
--checks that user does not exists in database
CREATE PROCEDURE DBTD_ASSERT_USER_NOT_EXISTS
(
	@v_UserName		SYSNAME,		--user name 
	@v_UserMessage	NVARCHAR(MAX)	--User message
)
WITH ENCRYPTION AS
BEGIN
	SET NOCOUNT ON;
	DECLARE @v_ProcName	NVARCHAR(128) = OBJECT_NAME(@@PROCID)
	DECLARE @v_Message NVARCHAR(MAX) = 'Running ' + @v_ProcName;
	EXEC DBTD_LOG_MESSAGE_EXT 'DEBUG', @v_ProcName, @v_Message;

	--note: reconsider to use: SELECT NAME, * FROM SYSUSERS WHERE ISSQLUSER = 1;
	IF EXISTS (	SELECT * 
					FROM SYS.DATABASE_PRINCIPALS 
					WHERE 
						TYPE = 'S'	
						AND UPPER(NAME) = UPPER(LTRIM(RTRIM(@v_UserName)))
				)
	BEGIN
		SET @v_Message = ISNULL(@v_UserMessage + '.', '') 
			+ ' Found user with name "' + LTRIM(RTRIM(UPPER(@v_UserName))) + '", when it is not expected to be present in the database' ; 
		EXEC DBTD_FAILURE @v_Message; 
	END;	
END;
GO

--************************************************************************************************
--checks that role does not exists in database
CREATE PROCEDURE DBTD_ASSERT_ROLE_NOT_EXISTS
(
	@v_RoleName		SYSNAME,		--Role name 
	@v_UserMessage	NVARCHAR(MAX)	--User message
)
WITH ENCRYPTION AS
BEGIN
	SET NOCOUNT ON;
	DECLARE @v_ProcName	NVARCHAR(128) = OBJECT_NAME(@@PROCID)
	DECLARE @v_Message NVARCHAR(MAX) = 'Running ' + @v_ProcName;
	EXEC DBTD_LOG_MESSAGE_EXT 'DEBUG', @v_ProcName, @v_Message;

	--note: reconsider to use: select name, * from sysusers where issqlrole = 1;
	IF EXISTS (	SELECT * 
					FROM SYS.DATABASE_PRINCIPALS 
					WHERE 
						TYPE = 'R'	
						AND UPPER(NAME) = UPPER(LTRIM(RTRIM(@v_RoleName)))
				)
	BEGIN
		SET @v_Message = ISNULL(@v_UserMessage + '.', '') 
			+ ' Found Role with name "' + LTRIM(RTRIM(UPPER(@v_RoleName))) + '", when it is not expected to be present in the database' ; 
		EXEC DBTD_FAILURE @v_Message; 
	END;	
END;
GO

--************************************************************************************************
--checks that login does not exists in database
CREATE PROCEDURE DBTD_ASSERT_LOGIN_NOT_EXISTS
(
	@v_LoginName	SYSNAME,		--Login name 
	@v_UserMessage	NVARCHAR(MAX)	--User message
)
WITH ENCRYPTION AS
BEGIN
	SET NOCOUNT ON;
	DECLARE @v_ProcName	NVARCHAR(128) = OBJECT_NAME(@@PROCID)
	DECLARE @v_Message NVARCHAR(MAX) = 'Running ' + @v_ProcName;
	EXEC DBTD_LOG_MESSAGE_EXT 'DEBUG', @v_ProcName, @v_Message;

	IF EXISTS (	SELECT * 
					FROM SYSUSERS 
					WHERE 
						ISLOGIN = 1
						AND UPPER(NAME) = UPPER(LTRIM(RTRIM(@v_LoginName)))
				)
	BEGIN
		SET @v_Message = ISNULL(@v_UserMessage + '.', '') 
			+ ' Found Login with name "' + LTRIM(RTRIM(UPPER(@v_LoginName))) + '", when it is not expected to be present in the database' ; 
		EXEC DBTD_FAILURE @v_Message; 
	END;	
END;
GO

--************************************************************************************************
--checks that database does not exists on the server
CREATE PROCEDURE DBTD_ASSERT_DB_NOT_EXISTS
(
	@v_DatabaseName	SYSNAME,		--Database name 
	@v_UserMessage NVARCHAR(MAX)	--User message
)
WITH ENCRYPTION AS
BEGIN
	SET NOCOUNT ON;
	DECLARE @v_ProcName	NVARCHAR(128) = OBJECT_NAME(@@PROCID)
	DECLARE @v_Message NVARCHAR(MAX) = 'Running ' + @v_ProcName;
	EXEC DBTD_LOG_MESSAGE_EXT 'DEBUG', @v_ProcName, @v_Message;

	IF EXISTS (	SELECT * 
					FROM SYS.DATABASES
					WHERE 
						UPPER(NAME) = UPPER(LTRIM(RTRIM(@v_DatabaseName)))
				)
	BEGIN
		SET @v_Message = ISNULL(@v_UserMessage + '.', '') 
			+ ' Found database with name "' + LTRIM(RTRIM(UPPER(@v_DatabaseName))) + '", when it is not expected to be present' ; 
		EXEC DBTD_FAILURE @v_Message; 
	END;	
END;
GO

--************************************************************************************************
--checks that trigger does not exists on the server
--DROP PROCEDURE DBTD_ASSERT_TRIGGER_NOT_EXISTS
CREATE PROCEDURE DBTD_ASSERT_TRIGGER_NOT_EXISTS
(
	@v_TriggerName	SYSNAME,		--Trigger name 
	@v_UserMessage	NVARCHAR(MAX)	--User message
)
WITH ENCRYPTION AS
BEGIN
	SET NOCOUNT ON;
	DECLARE @v_ProcName	NVARCHAR(128) = OBJECT_NAME(@@PROCID)
	DECLARE @v_Message NVARCHAR(MAX) = 'Running ' + @v_ProcName;
	DECLARE @v_ObjectID BIGINT = OBJECT_ID(@v_TriggerName)
	DECLARE @v_Server VARCHAR(2000),
			@v_Database VARCHAR(2000),
			@v_Schema VARCHAR(2000),
			@v_Object VARCHAR(2000),
			@v_CorrectedName VARCHAR(2000),
			@v_FullSysObjectName NVARCHAR(128) = ''
	EXEC DBTD_LOG_MESSAGE_EXT 'DEBUG', @v_ProcName, @v_Message;
	
	EXEC DBTD_SPLIT_FOUR_PART_OBJECT_NAME 
		@v_TriggerName, 
		@v_Server = @v_Server OUTPUT, @v_Database = @v_Database OUTPUT, @v_Schema = @v_Schema OUTPUT, 
		@v_Object = @v_Object OUTPUT, @v_CorrectedName = @v_CorrectedName OUTPUT,
		@v_CorrectTempTablesLocation = 1;

	IF @v_ObjectID IS NOT NULL
	BEGIN
		SET @v_Message = ISNULL(@v_UserMessage + '.', '') 
			+ ' Found trigger "' + LTRIM(RTRIM(UPPER(@v_CorrectedName))) + '", when it is NOT EXPECTED to be present in the database ' + @v_Database ; 
		EXEC DBTD_FAILURE @v_Message; 
	END;	
END;
GO

--************************************************************************************************
--checks that index defined for a given object (table or view) exist in database 
--DROP PROCEDURE DBTD_ASSERT_INDEX_EXISTS
CREATE PROCEDURE DBTD_ASSERT_INDEX_EXISTS
(
	@v_IndexName	SYSNAME,		--Index name 
	@v_ObjectName	SYSNAME,		--Object name (table or view)
	@v_UserMessage	NVARCHAR(MAX)	--User message
)
WITH ENCRYPTION AS
BEGIN
	SET NOCOUNT ON;
	DECLARE @v_ProcName	NVARCHAR(128) = OBJECT_NAME(@@PROCID),
			@v_ObjectID BIGINT = OBJECT_ID(@v_ObjectName),
			@v_Server VARCHAR(2000),
			@v_Database VARCHAR(2000),
			@v_Schema VARCHAR(2000),
			@v_CorrectedName VARCHAR(2000),
			@v_Object VARCHAR(2000),
			@v_SQL NVARCHAR(MAX) = ''
	DECLARE @v_Message	NVARCHAR(MAX) = 'Running ' + @v_ProcName
	EXEC DBTD_LOG_MESSAGE_EXT 'DEBUG', @v_ProcName, @v_Message ;

	CREATE TABLE #tmp_result_DBTD_ASSERT_INDEX_EXISTS(
		index_id BIGINT
	)

	EXEC DBTD_SPLIT_FOUR_PART_OBJECT_NAME 
		@v_ObjectName, 
		@v_Server = @v_Server OUTPUT, @v_Database = @v_Database OUTPUT, @v_Schema = @v_Schema OUTPUT, 
		@v_Object = @v_Object OUTPUT, @v_CorrectedName = @v_CorrectedName OUTPUT,
		@v_CorrectTempTablesLocation = 1;

	IF @v_ObjectID IS NULL
	BEGIN
		SET @v_Message = ISNULL(@v_UserMessage, '') 
			+ ' Unable to verify index existence. Cannot find object ['+ISNULL(@v_ObjectName,'NULL')+'] in the ['+@v_Database+'] database'; 
		EXEC DBTD_FAILURE @v_Message; 		
	END

	SET @v_SQL = 
		'INSERT INTO #tmp_result_DBTD_ASSERT_INDEX_EXISTS(index_id)
		SELECT index_id 
		FROM '+@v_Database+'.SYS.INDEXES 
		WHERE object_id = ' + CAST(@v_ObjectID AS VARCHAR(50))
		+ ' AND name = ''' + ISNULL(@v_IndexName, 'NULL') + ''''

	EXEC DBTD_SP_EXECUTESQL @v_Database, @v_SQL

	IF NOT EXISTS (	SELECT 1 FROM  #tmp_result_DBTD_ASSERT_INDEX_EXISTS)
	BEGIN
		SET @v_Message = ISNULL(@v_UserMessage, '') 
			+ ' Cannot find index [' + @v_IndexName + '] that belongs to '+UPPER(@v_CorrectedName)+' object.'; 
		EXEC DBTD_FAILURE @v_Message; 
	END;	
END;
GO

--************************************************************************************************
--checks that index has not been defined for a given object (table or view)
--DROP PROCEDURE DBTD_ASSERT_INDEX_NOT_EXISTS
CREATE PROCEDURE DBTD_ASSERT_INDEX_NOT_EXISTS
(
	@v_IndexName	SYSNAME,		--Index name 
	@v_ObjectName	SYSNAME,		--Object name (table or view)
	@v_UserMessage	NVARCHAR(MAX)	--User message
)
WITH ENCRYPTION AS
BEGIN
	SET NOCOUNT ON;
	DECLARE @v_ProcName	NVARCHAR(128) = OBJECT_NAME(@@PROCID),
			@v_ObjectID BIGINT = OBJECT_ID(@v_ObjectName),
			@v_Server VARCHAR(2000),
			@v_Database VARCHAR(2000),
			@v_Schema VARCHAR(2000),
			@v_CorrectedName VARCHAR(2000),
			@v_Object VARCHAR(2000),
			@v_SQL NVARCHAR(MAX) = ''
	DECLARE @v_Message	NVARCHAR(MAX) = 'Running ' + @v_ProcName
	EXEC DBTD_LOG_MESSAGE_EXT 'DEBUG', @v_ProcName, @v_Message ;

	CREATE TABLE #tmp_result_DBTD_ASSERT_INDEX_NOT_EXISTS(
		index_id BIGINT
	)

	EXEC DBTD_SPLIT_FOUR_PART_OBJECT_NAME 
		@v_ObjectName, 
		@v_Server = @v_Server OUTPUT, @v_Database = @v_Database OUTPUT, @v_Schema = @v_Schema OUTPUT, 
		@v_Object = @v_Object OUTPUT, @v_CorrectedName = @v_CorrectedName OUTPUT,
		@v_CorrectTempTablesLocation = 1;

	IF @v_ObjectID IS NULL
	BEGIN
		SET @v_Message = ISNULL(@v_UserMessage, '') 
			+ ' Unable to verify index. Cannot find object ['+ISNULL(@v_ObjectName,'NULL')+'] in the ['+@v_Database+'] database'; 
		EXEC DBTD_FAILURE @v_Message; 		
	END

	SET @v_SQL = 
		'INSERT INTO #tmp_result_DBTD_ASSERT_INDEX_NOT_EXISTS(index_id)
		SELECT index_id 
		FROM '+@v_Database+'.SYS.INDEXES 
		WHERE object_id = ' + CAST(@v_ObjectID AS VARCHAR(50))
		+ ' AND name = ''' + ISNULL(@v_IndexName, 'NULL') + ''''

	EXEC DBTD_SP_EXECUTESQL @v_Database, @v_SQL

	IF EXISTS (	SELECT 1 FROM  #tmp_result_DBTD_ASSERT_INDEX_NOT_EXISTS)
	BEGIN
		SET @v_Message = ISNULL(@v_UserMessage, '') 
			+ ' Found index [' + @v_IndexName + '] that belongs to '+UPPER(@v_CorrectedName)+' object.'; 
		EXEC DBTD_FAILURE @v_Message; 
	END;	
END;
GO

--************************************************************************************************
--checks that clustered index has been defined for a given object (table or view)
--DROP  PROCEDURE DBTD_ASSERT_INDEX_CLUSTERED
CREATE PROCEDURE DBTD_ASSERT_INDEX_CLUSTERED
(
	@v_IndexName	SYSNAME,		--Index name 
	@v_ObjectName	SYSNAME,		--Object name (table or view)
	@v_UserMessage	NVARCHAR(MAX)	--User message
)
WITH ENCRYPTION AS
BEGIN
	SET NOCOUNT ON;
	DECLARE @v_ProcName	NVARCHAR(128) = OBJECT_NAME(@@PROCID),
			@v_ObjectID BIGINT = OBJECT_ID(@v_ObjectName),
			@v_Server VARCHAR(2000),
			@v_Database VARCHAR(2000),
			@v_Schema VARCHAR(2000),
			@v_CorrectedName VARCHAR(2000),
			@v_Object VARCHAR(2000),
			@v_SQL NVARCHAR(MAX) = ''
	DECLARE @v_Message	NVARCHAR(MAX) = 'Running ' + @v_ProcName
	EXEC DBTD_LOG_MESSAGE_EXT 'DEBUG', @v_ProcName, @v_Message ;

	CREATE TABLE #tmp_result_DBTD_ASSERT_INDEX_CLUSTERED(
		index_id BIGINT
	)

	EXEC DBTD_SPLIT_FOUR_PART_OBJECT_NAME 
		@v_ObjectName, 
		@v_Server = @v_Server OUTPUT, @v_Database = @v_Database OUTPUT, @v_Schema = @v_Schema OUTPUT, 
		@v_Object = @v_Object OUTPUT, @v_CorrectedName = @v_CorrectedName OUTPUT,
		@v_CorrectTempTablesLocation = 1;

	IF @v_ObjectID IS NULL
	BEGIN
		SET @v_Message = ISNULL(@v_UserMessage, '') 
			+ ' Unable to verify index existence. Cannot find object ['+ISNULL(@v_ObjectName,'NULL')+'] in the ['+@v_Database+'] database'; 
		EXEC DBTD_FAILURE @v_Message; 		
	END

	SET @v_SQL = 
		'INSERT INTO #tmp_result_DBTD_ASSERT_INDEX_CLUSTERED(index_id)
		SELECT index_id 
		FROM '+@v_Database+'.SYS.INDEXES 
		WHERE object_id = ' + CAST(@v_ObjectID AS VARCHAR(50))
		+ ' AND name = ''' + ISNULL(@v_IndexName, 'NULL') + ''''
		+ ' AND type_desc = ''CLUSTERED'''
	EXEC DBTD_SP_EXECUTESQL @v_Database, @v_SQL

	IF NOT EXISTS (	SELECT 1 FROM  #tmp_result_DBTD_ASSERT_INDEX_CLUSTERED)
	BEGIN
		SET @v_Message = ISNULL(@v_UserMessage, '') 
			+ ' Cannot find CLUSTERED index [' + @v_IndexName + '] that belongs to '+UPPER(@v_CorrectedName)+' object.'; 
		EXEC DBTD_FAILURE @v_Message; 
	END;	
END;
GO

--************************************************************************************************
--checks that clustered index has not been defined for a given object (table or view)
--DROP PROCEDURE DBTD_ASSERT_INDEX_NOT_CLUSTERED
CREATE PROCEDURE DBTD_ASSERT_INDEX_NOT_CLUSTERED
(
	@v_IndexName	SYSNAME,		--Index name 
	@v_ObjectName	SYSNAME,		--Object name (table or view)
	@v_UserMessage	NVARCHAR(MAX)	--User message
)
WITH ENCRYPTION AS
BEGIN
	SET NOCOUNT ON;
	DECLARE @v_ProcName	NVARCHAR(128) = OBJECT_NAME(@@PROCID),
			@v_ObjectID BIGINT = OBJECT_ID(@v_ObjectName),
			@v_Server VARCHAR(2000),
			@v_Database VARCHAR(2000),
			@v_Schema VARCHAR(2000),
			@v_CorrectedName VARCHAR(2000),
			@v_Object VARCHAR(2000),
			@v_SQL NVARCHAR(MAX) = ''
	DECLARE @v_Message	NVARCHAR(MAX) = 'Running ' + @v_ProcName
	EXEC DBTD_LOG_MESSAGE_EXT 'DEBUG', @v_ProcName, @v_Message ;

	CREATE TABLE #tmp_result_DBTD_ASSERT_INDEX_NOT_CLUSTERED(
		index_id BIGINT
	)

	EXEC DBTD_SPLIT_FOUR_PART_OBJECT_NAME 
		@v_ObjectName, 
		@v_Server = @v_Server OUTPUT, @v_Database = @v_Database OUTPUT, @v_Schema = @v_Schema OUTPUT, 
		@v_Object = @v_Object OUTPUT, @v_CorrectedName = @v_CorrectedName OUTPUT,
		@v_CorrectTempTablesLocation = 1;

	IF @v_ObjectID IS NULL
	BEGIN
		SET @v_Message = ISNULL(@v_UserMessage, '') 
			+ ' Unable to verify index existence. Cannot find object ['+ISNULL(@v_ObjectName,'NULL')+'] in the ['+@v_Database+'] database'; 
		EXEC DBTD_FAILURE @v_Message; 		
	END

	SET @v_SQL = 
		'INSERT INTO #tmp_result_DBTD_ASSERT_INDEX_NOT_CLUSTERED(index_id)
		SELECT index_id 
		FROM '+@v_Database+'.SYS.INDEXES 
		WHERE object_id = ' + CAST(@v_ObjectID AS VARCHAR(50))
		+ ' AND name = ''' + ISNULL(@v_IndexName, 'NULL') + ''''
		+ ' AND type_desc = ''CLUSTERED'''
	EXEC DBTD_SP_EXECUTESQL @v_Database, @v_SQL

	IF EXISTS (	SELECT 1 FROM  #tmp_result_DBTD_ASSERT_INDEX_NOT_CLUSTERED)
	BEGIN
		SET @v_Message = ISNULL(@v_UserMessage, '') 
			+ ' Found CLUSTERED index [' + @v_IndexName + '] that belongs to ['+UPPER(@v_CorrectedName)+'] object, however it should not be CLUSTERED.'; 
		EXEC DBTD_FAILURE @v_Message; 
	END;
END;
GO

--************************************************************************************************
--checks that UNIQUE index has been defined for a given object (table or view)
CREATE PROCEDURE DBTD_ASSERT_INDEX_UNIQUE
(
	@v_IndexName	SYSNAME,		--Index name 
	@v_ObjectName	SYSNAME,		--Object name (table or view)
	@v_UserMessage	NVARCHAR(MAX)	--User message
)
WITH ENCRYPTION AS
BEGIN
	SET NOCOUNT ON;
	DECLARE @v_ProcName	NVARCHAR(128) = OBJECT_NAME(@@PROCID),
			@v_ObjectID BIGINT = OBJECT_ID(@v_ObjectName),
			@v_Server VARCHAR(2000),
			@v_Database VARCHAR(2000),
			@v_Schema VARCHAR(2000),
			@v_CorrectedName VARCHAR(2000),
			@v_Object VARCHAR(2000),
			@v_SQL NVARCHAR(MAX) = ''
	DECLARE @v_Message	NVARCHAR(MAX) = 'Running ' + @v_ProcName
	EXEC DBTD_LOG_MESSAGE_EXT 'DEBUG', @v_ProcName, @v_Message ;

	CREATE TABLE #tmp_result_DBTD_ASSERT_INDEX_UNIQUE(
		index_id BIGINT
	)

	EXEC DBTD_SPLIT_FOUR_PART_OBJECT_NAME 
		@v_ObjectName, 
		@v_Server = @v_Server OUTPUT, @v_Database = @v_Database OUTPUT, @v_Schema = @v_Schema OUTPUT, 
		@v_Object = @v_Object OUTPUT, @v_CorrectedName = @v_CorrectedName OUTPUT,
		@v_CorrectTempTablesLocation = 1;

	IF @v_ObjectID IS NULL
	BEGIN
		SET @v_Message = ISNULL(@v_UserMessage, '') 
			+ ' Unable to verify index existence. Cannot find object ['+ISNULL(@v_ObjectName,'NULL')+'] in the ['+@v_Database+'] database'; 
		EXEC DBTD_FAILURE @v_Message; 		
	END

	SET @v_SQL = 
		'INSERT INTO #tmp_result_DBTD_ASSERT_INDEX_UNIQUE(index_id)
		SELECT index_id 
		FROM '+@v_Database+'.SYS.INDEXES 
		WHERE object_id = ' + CAST(@v_ObjectID AS VARCHAR(50))
		+ ' AND name = ''' + ISNULL(@v_IndexName, 'NULL') + ''''
		+ ' AND is_unique = 1'
	EXEC DBTD_SP_EXECUTESQL @v_Database, @v_SQL

	IF NOT EXISTS (	SELECT 1 FROM  #tmp_result_DBTD_ASSERT_INDEX_UNIQUE)
	BEGIN
		SET @v_Message = ISNULL(@v_UserMessage, '') 
			+ ' Cannot find UNIQUE index [' + @v_IndexName + '] that belongs to '+@v_CorrectedName+' object.'; 
		EXEC DBTD_FAILURE @v_Message; 
	END;
END;
GO

--************************************************************************************************
--checks that UNIQUE index has been defined for a given object (table or view)
--DROP PROCEDURE DBTD_ASSERT_INDEX_NOT_UNIQUE
CREATE PROCEDURE DBTD_ASSERT_INDEX_NOT_UNIQUE
(
	@v_IndexName	SYSNAME,		--Index name 
	@v_ObjectName	SYSNAME,		--Object name (table or view)
	@v_UserMessage	NVARCHAR(MAX)	--User message
)
WITH ENCRYPTION AS
BEGIN
	SET NOCOUNT ON;
	DECLARE @v_ProcName	NVARCHAR(128) = OBJECT_NAME(@@PROCID),
			@v_ObjectID BIGINT = OBJECT_ID(@v_ObjectName),
			@v_Server VARCHAR(2000),
			@v_Database VARCHAR(2000),
			@v_Schema VARCHAR(2000),
			@v_CorrectedName VARCHAR(2000),
			@v_Object VARCHAR(2000),
			@v_SQL NVARCHAR(MAX) = ''
	DECLARE @v_Message	NVARCHAR(MAX) = 'Running ' + @v_ProcName
	EXEC DBTD_LOG_MESSAGE_EXT 'DEBUG', @v_ProcName, @v_Message ;

	CREATE TABLE #tmp_result_DBTD_ASSERT_INDEX_UNIQUE(
		index_id BIGINT
	)

	EXEC DBTD_SPLIT_FOUR_PART_OBJECT_NAME 
		@v_ObjectName, 
		@v_Server = @v_Server OUTPUT, @v_Database = @v_Database OUTPUT, @v_Schema = @v_Schema OUTPUT, 
		@v_Object = @v_Object OUTPUT, @v_CorrectedName = @v_CorrectedName OUTPUT,
		@v_CorrectTempTablesLocation = 1;

	IF @v_ObjectID IS NULL
	BEGIN
		SET @v_Message = ISNULL(@v_UserMessage, '') 
			+ ' Unable to verify index existence. Cannot find object ['+ISNULL(@v_ObjectName,'NULL')+'] in the ['+@v_Database+'] database'; 
		EXEC DBTD_FAILURE @v_Message; 		
	END

	SET @v_SQL = 
		'INSERT INTO #tmp_result_DBTD_ASSERT_INDEX_UNIQUE(index_id)
		SELECT index_id 
		FROM '+@v_Database+'.SYS.INDEXES 
		WHERE object_id = ' + CAST(@v_ObjectID AS VARCHAR(50))
		+ ' AND name = ''' + ISNULL(@v_IndexName, 'NULL') + ''''
		+ ' AND is_unique = 0'
	EXEC DBTD_SP_EXECUTESQL @v_Database, @v_SQL

	IF NOT EXISTS (	SELECT 1 FROM  #tmp_result_DBTD_ASSERT_INDEX_UNIQUE)
	BEGIN
		SET @v_Message = ISNULL(@v_UserMessage, '') 
			+ ' Cannot find NOT UNIQUE index [' + @v_IndexName + '] that belongs to '+@v_CorrectedName+' object.'; 
		EXEC DBTD_FAILURE @v_Message; 
	END;
END;
GO

--************************************************************************************************
--INTERNAL: Do not use this function in your unit tests, procedure can be removed,
--          signature or procedure name can be changed at any release
--NOTE: Returns list of columns in the specified table
--DROP PROCEDURE DBTD_GET_COLUMN_LIST
CREATE PROCEDURE DBTD_GET_COLUMN_LIST
(
	@v_Database		VARCHAR(128),	--Database Name
	@v_Schema		VARCHAR(128),	--Schema 
	@v_ObjectName	SYSNAME,		--Name of the table or view
	@v_ColumnsList	NVARCHAR(MAX)	= '' OUTPUT,	--List of columns OUTPUT parameter
	@v_OrderBy		VARCHAR(50)		= 'NAME'		-- 'ColID'
)
WITH ENCRYPTION 
AS
BEGIN 
	SET NOCOUNT ON;
	DECLARE @v_ProcName	NVARCHAR(128) = OBJECT_NAME(@@PROCID)
	DECLARE @v_Message NVARCHAR(MAX) = 'Running ' + @v_ProcName;
	EXEC DBTD_LOG_MESSAGE_EXT 'DEBUG', @v_ProcName, @v_Message;

	DECLARE @v_SQL			NVARCHAR(MAX),
			@v_FullName		NVARCHAR(256),					-- Fully qualified SQL name
			@v_CorrectedName_A NVARCHAR(256),
			@v_Name		SYSNAME,				-- Fully qualified SQL name
			@v_Server_A	NVARCHAR(128),
			@v_Database_A NVARCHAR(128),
			@v_Schema_A	NVARCHAR(128),
			@v_Object_A	NVARCHAR(128),
			@v_CorrectedName_B NVARCHAR(256)

	CREATE TABLE #Result(ColumnList NVARCHAR(MAX)); 

	EXEC DBTD_PREPARE_FOUR_PART_OBJECT_NAME
		@v_Server = NULL,
		@v_Database = @v_Database,
		@v_Schema = @v_Schema,
		@v_Object = @v_ObjectName,
		@v_FullName	= @v_FullName OUTPUT,
		@v_CorrectedName = @v_CorrectedName_A OUTPUT	

	EXEC DBTD_SPLIT_FOUR_PART_OBJECT_NAME 
			@v_Name		= @v_CorrectedName_A,				
			@v_Server	= @v_Server_A OUTPUT,
			@v_Database = @v_Database_A OUTPUT,
			@v_Schema	= @v_Schema_A OUTPUT,
			@v_Object	= @v_Object_A OUTPUT,
			@v_CorrectedName = @v_CorrectedName_B OUTPUT,
			@v_CorrectTempTablesLocation = 1;

	SET @v_SQL = 'DECLARE @v_Delim NVARCHAR(10) = '''', @v_ListStr_Internal NVARCHAR(MAX) = ''''; '		
		+ ' SELECT @v_ListStr_Internal =  COALESCE( @v_ListStr_Internal, '''', '''') + @v_Delim + ''['' + C.NAME + '']'', @v_Delim='','' '
		+ ' FROM ' + CASE 
						WHEN @v_Database_A IS NULL OR LTRIM(RTRIM(@v_Database_A)) = '' THEN ''
						ELSE @v_Database_A + '.'
					END
		 + 'SYS.COLUMNS AS C '
		+ ' WHERE C.object_ID = OBJECT_ID('''+@v_CorrectedName_A+''')'
		+ CASE 
			WHEN @v_OrderBy = 'ColID' THEN ' ORDER BY c.column_id;'
			ELSE ' ORDER BY C.NAME;'
		 END
		+ 'INSERT INTO #Result(ColumnList) VALUES(@v_ListStr_Internal)'
	EXEC DBTD_SP_EXECUTESQL @v_Database_A, @v_SQL

	SELECT TOP 1 @v_ColumnsList = ISNULL(ColumnList, '') FROM #Result
	RETURN;
END 
GO

--************************************************************************************************
--Compare table columns, numbers or frows and check that values in all roiws are the same
--NOTE: When you compare rows for determining distinct values, two NULL values are considered equal
--NOTE: Columnns are ordered alphabetically
CREATE PROCEDURE DBTD_ASSERT_TABLES_ARE_EQUAL
(
	@v_ActualObjDatabase	VARCHAR(128),	--Database Name for the Actual object
	@v_ActualObjSchema		VARCHAR(128),	--Schema  for the Actual object
	@v_ActualObjName		VARCHAR(128),	--Name of the Actual table or view

	@v_ExpectedObjDatabase	VARCHAR(128),	--Database Name for the Expected object
	@v_ExpectedObjSchema	VARCHAR(128),	--Schema for the Expected object
	@v_ExpectedObjName		VARCHAR(128),	--Name of the Expected table or view

	@v_UserMessage			NVARCHAR(MAX)	--User message
)
WITH ENCRYPTION 
AS
BEGIN
	SET NOCOUNT ON;
	DECLARE @v_ProcName	NVARCHAR(128) = OBJECT_NAME(@@PROCID)
	DECLARE @v_Message NVARCHAR(MAX) = 'Running ' + @v_ProcName;
	EXEC DBTD_LOG_MESSAGE_EXT 'DEBUG', @v_ProcName, @v_Message;

	DECLARE @v_ActualValue	BIGINT,
			@v_ExpectedValue BIGINT,
			@v_ColumnListLeftTable varchar(MAX),
			@v_ColumnListRightTable varchar(MAX),
			@v_LeftTable	varchar(128),
			@v_RightTable	varchar(128),
			@v_LeftTableExt	varchar(128),
			@v_RightTableExt varchar(128),
			@v_SQL			NVARCHAR(MAX),
			@v_ParmDefinition NVARCHAR(2000)  = '@v_ActualValue_Internal INT OUTPUT' 
	
	IF	@v_ActualObjName IS NULL
		OR @v_ExpectedObjName IS NULL
		OR LTRIM(RTRIM(@v_ActualObjName)) = ''
		OR LTRIM(RTRIM(@v_ExpectedObjName)) = ''
	BEGIN
		EXEC DBTD_FAILURE 'Parameters are not supplied';
		RETURN;
	END

	SET @v_LeftTable = 
			CASE 
				WHEN @v_ActualObjDatabase IS NULL THEN ''
				WHEN LTRIM(RTRIM(@v_ActualObjDatabase)) != '' THEN LTRIM(RTRIM(@v_ActualObjDatabase)) + '.' 
				ELSE ''
			END
			+ CASE 
				WHEN @v_ActualObjSchema IS NULL THEN 'dbo.'
				WHEN LTRIM(RTRIM(@v_ActualObjSchema)) != '' THEN LTRIM(RTRIM(@v_ActualObjSchema)) + '.' 
				ELSE ''
			END
			+ @v_ActualObjName;

	SET @v_RightTable = 
			CASE 
				WHEN @v_ExpectedObjDatabase IS NULL THEN ''
				WHEN LTRIM(RTRIM(@v_ExpectedObjDatabase)) != '' THEN LTRIM(RTRIM(@v_ExpectedObjDatabase)) + '.' 
				ELSE ''
			END
			+ CASE 
				WHEN @v_ExpectedObjSchema IS NULL THEN 'dbo.'
				WHEN LTRIM(RTRIM(@v_ExpectedObjSchema)) != '' THEN LTRIM(RTRIM(@v_ExpectedObjSchema)) + '.' 
				ELSE ''
			END	
			+ @v_ExpectedObjName;

	--skip TEMPDB database prefix 
	if UPPER(LTRIM(RTRIM(@v_ActualObjDatabase))) = 'TEMPDB'
	BEGIN
		SET @v_LeftTableExt = ISNULL(@v_ActualObjSchema, 'dbo') + '.' + @v_ActualObjName;
	END
	ELSE 
		SET @v_LeftTableExt = @v_LeftTable;

	if UPPER(LTRIM(RTRIM(@v_ExpectedObjDatabase))) = 'TEMPDB'
	BEGIN
		SET @v_RightTableExt = ISNULL(@v_ExpectedObjSchema, 'dbo') + '.' + @v_ExpectedObjName;
	END
	ELSE 
		SET @v_RightTableExt = @v_RightTable;

	EXEC dbo.DBTD_GET_COLUMN_LIST @v_ExpectedObjDatabase,@v_ExpectedObjSchema,@v_ExpectedObjName, @v_ColumnsList = @v_ColumnListRightTable OUTPUT;
	EXEC dbo.DBTD_GET_COLUMN_LIST @v_ActualObjDatabase,@v_ActualObjSchema,@v_ActualObjName, @v_ColumnsList = @v_ColumnListLeftTable OUTPUT;

	--A - check columns -------------------------------------
	SET @v_Message = ISNULL(@v_UserMessage + '.', '') + ' Checking table columns signatures for "' + @v_LeftTable + '" and "' +@v_RightTable + '" tables.'; 
	EXEC dbo.DBTD_ASSERT_ARE_EQUAL @v_ColumnListRightTable, @v_ColumnListLeftTable, @v_Message;
	
	--B - check number of rows ------------------------------
	SET @v_Message = ISNULL(@v_UserMessage + '.', '') + ' Checking number of rows.'
	EXEC DBTD_ASSERT_SAME_NUMBER_OF_ROWS @v_LeftTableExt, @v_RightTableExt, @v_Message;

	--C - Compare values in rows
	SELECT @v_SQL =
		' SELECT @v_ActualValue_Internal = COUNT(1) FROM ('
		+ ' (SELECT ' + @v_ColumnListLeftTable + ' FROM ' + @v_LeftTableExt + ' AS LT ' 
		+ ' EXCEPT SELECT ' + @v_ColumnListRightTable + ' FROM ' + @v_RightTableExt + ' RT ) '
		+ ' UNION ( '
		+ ' SELECT ' + @v_ColumnListRightTable + ' FROM ' + @v_RightTableExt + ' AS LT1 '
		+ ' EXCEPT SELECT ' + @v_ColumnListLeftTable + ' FROM ' + @v_LeftTableExt + ' AS RT1 )	) AS D'

	EXECUTE sp_executesql @v_SQL, @v_ParmDefinition, @v_ActualValue_Internal = @v_ActualValue OUTPUT;

	SET @v_ActualValue = ISNULL(@v_ActualValue,0) 
	SET @v_ExpectedValue = 0; --There should be no differences  
	SET @v_Message = ISNULL(@v_UserMessage + ':', '') + @v_LeftTable + ' and ' + @v_RightTable + ' have ' + CAST(@v_ActualValue AS VARCHAR(50)) + ' different records.';
	EXEC dbo.DBTD_ASSERT_ARE_EQUAL @v_ActualValue, @v_ExpectedValue, @v_Message;
END
GO

--************************************************************************************************
--Compare table columns, numbers of rows and check that values in all rows are the same
--Note: When you compare rows for determining distinct values, two NULL values are considered equal
--Note: Columns are ordered alphabetically
--DROP PROCEDURE DBTD_ASSERT_ROWSETS_ARE_EQUAL
CREATE PROCEDURE DBTD_ASSERT_ROWSETS_ARE_EQUAL
(
	@v_ActualObjDatabase	VARCHAR(128),	--Database Name for the Actual object
	@v_ActualObjSchema		VARCHAR(128),	--Schema  for the Actual object
	@v_ActualObjName		VARCHAR(128),	--Name of the Actual table or view

	@v_ExpectedObjDatabase	VARCHAR(128),	--Database Name for the Expected object
	@v_ExpectedObjSchema	VARCHAR(128),	--Schema for the Expected object
	@v_ExpectedObjName		VARCHAR(128),	--Name of the Expected table or view

	@v_CompareOption		VARCHAR(128),	--compare option: USE ACTUAL COLUMNS, USE EXPECTED COLUMNS

	@v_UserMessage			NVARCHAR(MAX)	--User message
)
WITH ENCRYPTION 
AS
BEGIN
	SET NOCOUNT ON;
	DECLARE @v_ProcName	NVARCHAR(128) = OBJECT_NAME(@@PROCID)
	DECLARE @v_Message NVARCHAR(MAX) = 'Running ' + @v_ProcName;
	EXEC DBTD_LOG_MESSAGE_EXT 'DEBUG', @v_ProcName, @v_Message;

	DECLARE @v_ActualValue BIGINT,
			@v_ExpectedValue BIGINT,
			@v_ColumnListToCompare VARCHAR(MAX),
			@v_LeftTable varchar(128),
			@v_RightTable varchar(128),
			@v_LeftTableExt varchar(128),
			@v_RightTableExt varchar(128),
			@v_SQL NVARCHAR(MAX),
			@v_ParmDefinition NVARCHAR(2000) = ' @v_ActualValue_Internal BIGINT OUTPUT ';

	SET @v_Message = ''
	
	IF	@v_ActualObjName IS NULL
		OR @v_ExpectedObjName IS NULL
		OR LTRIM(RTRIM(@v_ActualObjName)) = ''
		OR LTRIM(RTRIM(@v_ExpectedObjName)) = ''
	BEGIN
		EXEC DBTD_FAILURE 'Parameters are not supplied';
		RETURN;
	END

	SET @v_LeftTable = 
			CASE 
				WHEN @v_ActualObjDatabase IS NULL THEN ''
				WHEN LTRIM(RTRIM(@v_ActualObjDatabase)) != '' THEN LTRIM(RTRIM(@v_ActualObjDatabase)) + '.' 
				ELSE ''
			END
			+ CASE 
				WHEN @v_ActualObjSchema IS NULL THEN 'dbo.'
				WHEN LTRIM(RTRIM(@v_ActualObjSchema)) != '' THEN LTRIM(RTRIM(@v_ActualObjSchema)) + '.' 
				ELSE ''
			END
			+ @v_ActualObjName;

	SET @v_RightTable = 
			CASE 
				WHEN @v_ExpectedObjDatabase IS NULL THEN ''
				WHEN LTRIM(RTRIM(@v_ExpectedObjDatabase)) != '' THEN LTRIM(RTRIM(@v_ExpectedObjDatabase)) + '.' 
				ELSE ''
			END
			+ CASE 
				WHEN @v_ExpectedObjSchema IS NULL THEN 'dbo.'
				WHEN LTRIM(RTRIM(@v_ExpectedObjSchema)) != '' THEN LTRIM(RTRIM(@v_ExpectedObjSchema)) + '.' 
				ELSE ''
			END	
			+ @v_ExpectedObjName;

	--skip TEMPDB database prefix 
	if UPPER(LTRIM(RTRIM(@v_ActualObjDatabase))) = 'TEMPDB'
	BEGIN
		SET @v_LeftTableExt = ISNULL(@v_ActualObjSchema, 'dbo') + '.' + @v_ActualObjName;
	END
	ELSE 
		SET @v_LeftTableExt = @v_LeftTable;

	if UPPER(LTRIM(RTRIM(@v_ExpectedObjDatabase))) = 'TEMPDB'
	BEGIN
		SET @v_RightTableExt = ISNULL(@v_ExpectedObjSchema, 'dbo') + '.' + @v_ExpectedObjName;
	END
	ELSE 
		SET @v_RightTableExt = @v_RightTable;

	IF (LTRIM(RTRIM(UPPER(@v_CompareOption))) = 'USE ACTUAL COLUMNS') 
	BEGIN
		--USE COLUMNS from ACTUAL as the base for comparison
		EXEC dbo.DBTD_GET_COLUMN_LIST @v_ActualObjDatabase, @v_ActualObjSchema, @v_ActualObjName, @v_ColumnsList = @v_ColumnListToCompare OUTPUT
	END
	ELSE BEGIN
		--USE COLUMNS from EXPECTED as the base for comparison
		EXEC dbo.DBTD_GET_COLUMN_LIST @v_ExpectedObjDatabase, @v_ExpectedObjSchema, @v_ExpectedObjName, @v_ColumnsList = @v_ColumnListToCompare OUTPUT
	END;
	
	--B - check number of rows ------------------------------
	SET @v_Message = @v_LeftTableExt + ' and ' + @v_RightTableExt + ' recordsets should have same number of rows.';
	EXEC DBTD_ASSERT_SAME_NUMBER_OF_ROWS @v_LeftTableExt, @v_RightTableExt, @v_Message;

	--C - Compare values in rows
	SELECT @v_SQL =
		' SELECT @v_ActualValue_Internal = COUNT(*) '
		+ ' FROM ('
		+ '     (SELECT ' + @v_ColumnListToCompare + ' FROM ' + @v_LeftTableExt + ' AS LT EXCEPT SELECT ' + @v_ColumnListToCompare + ' FROM ' + @v_RightTableExt + ' RT) '
		+ '     UNION '
		+ '     (SELECT ' + @v_ColumnListToCompare + ' FROM ' + @v_RightTableExt + ' AS LT1 EXCEPT  SELECT ' + @v_ColumnListToCompare + ' FROM ' + @v_LeftTableExt + ' AS RT1) '
		+ '     ) AS D'
		
	EXECUTE sp_executesql @v_SQL, @v_ParmDefinition, @v_ActualValue_Internal = @v_ActualValue OUTPUT;

	SET @v_ActualValue = ISNULL(@v_ActualValue,0) 
	SET @v_ExpectedValue = 0; --there should be no differences  
	SET @v_Message = ISNULL(@v_UserMessage + '. ', '') + @v_LeftTable + ' and ' + @v_RightTable + ' have ' + CAST(@v_ActualValue AS VARCHAR(50)) + ' different records.';
	EXEC dbo.DBTD_ASSERT_ARE_EQUAL @v_ActualValue, @v_ExpectedValue, @v_Message;
END
GO

--************************************************************************************************
--returns object definition if it is available
CREATE PROCEDURE DBTD_GET_Object_Definition
	@v_ProcName				SYSNAME,
	@v_Object_Definition	NVARCHAR(MAX) OUTPUT
WITH ENCRYPTION AS
BEGIN
	SET NOCOUNT ON;
	DECLARE @v_ThisProcName	NVARCHAR(128) = OBJECT_NAME(@@PROCID)
	DECLARE @v_Message NVARCHAR(MAX) = 'Running ' + @v_ThisProcName;
	EXEC DBTD_LOG_MESSAGE_EXT 'DEBUG', @v_ThisProcName, @v_Message;

	DECLARE @v_SQL				NVARCHAR(MAX) = '',
			@v_PretendProc_Server			VARCHAR(200),
			@v_PretendProc_Database			VARCHAR(200),
			@v_PretendProc_Schema			VARCHAR(200),
			@v_PretendProc_Object			VARCHAR(200),
			@v_PretendProc_CorrectedName	VARCHAR(200)

	CREATE TABLE #DBTD_TextBlock (
		TextBlock NVARCHAR(MAX) 
	)

	--Identify and correct names 
	EXEC DBTD_SPLIT_FOUR_PART_OBJECT_NAME 
		@v_ProcName, 
		@v_Server	= @v_PretendProc_Server OUTPUT, 
		@v_Database = @v_PretendProc_Database OUTPUT, 
		@v_Schema	= @v_PretendProc_Schema OUTPUT, 
		@v_Object	= @v_PretendProc_Object OUTPUT, 
		@v_CorrectedName = @v_PretendProc_CorrectedName OUTPUT,
		@v_CorrectTempTablesLocation = 1;

	SET @v_SQL = 'INSERT INTO #DBTD_TextBlock (TextBlock) SELECT OBJECT_DEFINITION(OBJECT_ID(''' + @v_PretendProc_CorrectedName+''')) AS TextBlock'
	EXEC DBTD_SP_EXECUTESQL @v_PretendProc_Database, @v_SQL
	SELECT @v_Object_Definition = TextBlock FROM #DBTD_TextBlock;
END
GO

--************************************************************************************************
CREATE PROCEDURE DBTD_ASSERT_MOCK_EXISTS
	@v_PrependObjectName SYSNAME,		--The name of the MOCK procedure
	@v_UserMessage		 NVARCHAR(MAX)	--User message
WITH ENCRYPTION AS
BEGIN
	SET NOCOUNT ON;
	DECLARE @v_Object_ID	BIGINT = NULL,
			@v_Proc_Server	VARCHAR(200),
			@v_Proc_Database VARCHAR(200),
			@v_Proc_Schema	VARCHAR(200),
			@v_Proc_Object	VARCHAR(200),
			@v_Proc_CorrectedName VARCHAR(200),
			@v_TextBlock	NVARCHAR(MAX),
			@v_DBDT_CodeSignature VARCHAR(250) = 'STARTING EXECUTION OF ARTIFICIAL PRETEND OBJECT FOR'
	DECLARE @v_ProcName	NVARCHAR(128) = OBJECT_NAME(@@PROCID)
	DECLARE @v_Message NVARCHAR(MAX) = 'Running ' + @v_ProcName;
	EXEC DBTD_LOG_MESSAGE_EXT 'DEBUG', @v_ProcName, @v_Message;
	SET @v_Message = '';

	--Identify and correct names 
	EXEC DBTD_SPLIT_FOUR_PART_OBJECT_NAME 
		@v_PrependObjectName, 
		@v_Server = @v_Proc_Server OUTPUT, @v_Database = @v_Proc_Database OUTPUT, @v_Schema = @v_Proc_Schema OUTPUT, 
		@v_Object = @v_Proc_Object OUTPUT, @v_CorrectedName = @v_Proc_CorrectedName OUTPUT,
		@v_CorrectTempTablesLocation = 1;

	--Check that procedure exists before moving forward
	SET @v_Message = @v_Proc_CorrectedName + ' - MOCK DOES NOT EXIST - Procedure DOES NOT EXISTS in the database. ' + ISNULL(@v_UserMessage, '')
	EXEC DBTD_ASSERT_PROC_EXISTS @v_Proc_CorrectedName, @v_Message

	--Find an object ID and Definition code
	EXEC DBO.DBTD_GET_OBJECT_ID @v_Object_Name = @v_Proc_CorrectedName, @v_Object_ID = @v_Object_ID OUTPUT
	EXEC DBTD_GET_Object_Definition @v_ProcName	= @v_Proc_CorrectedName, @v_Object_Definition = @v_TextBlock OUTPUT

	SET @v_Message = @v_Proc_CorrectedName + ' - MOCK DOES NOT EXIST - This procedure did NOT AUTOMATICALLY CREATED BY DBTD FRAMEWORK. ' + ISNULL(@v_UserMessage, '')
	IF OBJECT_ID('tempdb.dbo.#DBTD_DoNotUseDetailCommentMessage') IS NULL 
	BEGIN
		CREATE TABLE #DBTD_DoNotUseDetailCommentMessage(A INT);
	END
	EXEC DBTD_ASSERT_STRING_CONTAINS @v_DBDT_CodeSignature, @v_TextBlock, @v_Message 

	SET @v_Message = @v_Proc_CorrectedName + ' - MOCK DOES NOT EXIST - This procedure did NOT REGISTERED as valid MOCK Object. ' + ISNULL(@v_UserMessage, '')
	EXEC DBTD_ASSERT_COLUMN_HAVE_VALUE 'DBTD_TBL_PRETEND_OBJECT', 'ObjectID', @v_Object_ID, 'BIGINT', @v_Message
END
GO

--************************************************************************************************
CREATE PROCEDURE DBTD_ASSERT_STUB_EXISTS
	@v_PrependObjectName SYSNAME,		--The name of the STUB (pretend\fake) procedure
	@v_UserMessage		 NVARCHAR(MAX)	--User message
WITH ENCRYPTION AS
BEGIN
	SET NOCOUNT ON;
	DECLARE @v_ProcName	NVARCHAR(128) = OBJECT_NAME(@@PROCID)
	DECLARE @v_Message NVARCHAR(MAX) = 'Running ' + @v_ProcName;
	EXEC DBTD_LOG_MESSAGE_EXT 'DEBUG', @v_ProcName, @v_Message;
	--run assertion
	EXEC DBTD_ASSERT_MOCK_EXISTS @v_PrependObjectName, @v_UserMessage
END
GO

--************************************************************************************************
--DROP PROCEDURE DBTD_ASSERT_MOCK_NOT_EXISTS
CREATE PROCEDURE DBTD_ASSERT_MOCK_NOT_EXISTS
	@v_PrependObjectName SYSNAME,		--The name of the MOCK procedure
	@v_UserMessage		 NVARCHAR(MAX)	--User message
WITH ENCRYPTION AS
BEGIN
	SET NOCOUNT ON;
	DECLARE @v_ProcName	NVARCHAR(128) = OBJECT_NAME(@@PROCID)
	DECLARE @v_Message NVARCHAR(MAX) = 'Running ' + @v_ProcName;
	EXEC DBTD_LOG_MESSAGE_EXT 'DEBUG', @v_ProcName, @v_Message;
	SET @v_Message = ''

	DECLARE @v_Object_ID	BIGINT = NULL,
			@v_Proc_Server	VARCHAR(200),
			@v_Proc_Database VARCHAR(200),
			@v_Proc_Schema	VARCHAR(200),
			@v_Proc_Object	VARCHAR(200),
			@v_Proc_CorrectedName VARCHAR(200),
			@v_TextBlock	NVARCHAR(MAX),
			@v_DBDT_CodeSignature VARCHAR(250) = 'STARTING EXECUTION OF ARTIFICIAL PRETEND OBJECT FOR'

	--Identify and correct names 
	EXEC DBTD_SPLIT_FOUR_PART_OBJECT_NAME 
		@v_PrependObjectName, 
		@v_Server = @v_Proc_Server OUTPUT, @v_Database = @v_Proc_Database OUTPUT, @v_Schema = @v_Proc_Schema OUTPUT, 
		@v_Object = @v_Proc_Object OUTPUT, @v_CorrectedName = @v_Proc_CorrectedName OUTPUT,
		@v_CorrectTempTablesLocation = 1;

	--Find an object ID and Definition code
	EXEC DBO.DBTD_GET_OBJECT_ID @v_Object_Name = @v_Proc_CorrectedName, @v_Object_ID = @v_Object_ID OUTPUT
	EXEC DBTD_GET_Object_Definition @v_ProcName	= @v_Proc_CorrectedName, @v_Object_Definition = @v_TextBlock OUTPUT

	IF @v_Object_ID IS NOT NULL
	BEGIN
		SET @v_Message = @v_Proc_CorrectedName + ' - MOCK EXIST - This procedure REGISTERED as valid MOCK Object. ' + ISNULL(@v_UserMessage , '')
		EXEC DBTD_ASSERT_COLUMN_HAS_NO_VALUE 'DBTD_TBL_PRETEND_OBJECT', 'ObjectID', @v_Object_ID, 'BIGINT', @v_Message
	END

	IF @v_TextBlock IS NOT NULL
	BEGIN 
		SET @v_Message = @v_Proc_CorrectedName + ' - POTENTIAL MOCK EXIST - This procedure were created AUTOMATICALLY BY FRAMEWORK. ' + ISNULL(@v_UserMessage, '')
		EXEC DBTD_ASSERT_STRING_NOT_CONTAIN @v_DBDT_CodeSignature, @v_TextBlock, @v_Message 
	END
END
GO

--************************************************************************************************
--DROP PROCEDURE DBTD_ASSERT_STUB_NOT_EXISTS
CREATE PROCEDURE DBTD_ASSERT_STUB_NOT_EXISTS
	@v_PrependObjectName SYSNAME,		--The name of the STUB procedure
	@v_UserMessage		 NVARCHAR(MAX)	--User message
WITH ENCRYPTION AS
BEGIN
	SET NOCOUNT ON;
	DECLARE @v_ProcName	NVARCHAR(128) = OBJECT_NAME(@@PROCID)
	DECLARE @v_Message NVARCHAR(MAX) = 'Running ' + @v_ProcName;
	EXEC DBTD_LOG_MESSAGE_EXT 'DEBUG', @v_ProcName, @v_Message;

	EXEC DBTD_ASSERT_MOCK_NOT_EXISTS @v_PrependObjectName, @v_UserMessage
END
GO

--************************************************************************************************
--INTERNAL: Do not use this function in your unit tests, procedure can be removed,
--          signature or procedure name can be changed at any release
--DROP PROCEDURE DBTD_GET_PretendObjectNumberOfCalls
CREATE PROCEDURE DBTD_GET_PretendObjectNumberOfCalls
(
	@v_PrependObjectName SYSNAME, --The name of the pretend object
	@v_UnitTestRunID INT,		 
	@v_NumberOfCalls INT OUTPUT
)
WITH ENCRYPTION AS
BEGIN
	SET NOCOUNT ON;
	DECLARE @v_Object_ID	 BIGINT = NULL,
			@v_Proc_Server	 VARCHAR(200),
			@v_Proc_Database VARCHAR(200),
			@v_Proc_Schema	 VARCHAR(200),
			@v_Proc_Object	 VARCHAR(200),
			@v_Proc_CorrectedName VARCHAR(200)
	DECLARE @v_ProcName	NVARCHAR(128) = OBJECT_NAME(@@PROCID)
	DECLARE @v_Message NVARCHAR(MAX) = 'Running ' + @v_ProcName;
	EXEC DBTD_LOG_MESSAGE_EXT 'DEBUG', @v_ProcName, @v_Message;

	--Identify and correct names 
	EXEC DBTD_SPLIT_FOUR_PART_OBJECT_NAME 
		@v_PrependObjectName, 
		@v_Server = @v_Proc_Server OUTPUT, @v_Database = @v_Proc_Database OUTPUT, @v_Schema = @v_Proc_Schema OUTPUT, 
		@v_Object = @v_Proc_Object OUTPUT, @v_CorrectedName = @v_Proc_CorrectedName OUTPUT,
		@v_CorrectTempTablesLocation = 1;

	--Find an object ID
	EXEC DBO.DBTD_GET_OBJECT_ID @v_Object_Name = @v_Proc_CorrectedName, @v_Object_ID = @v_Object_ID OUTPUT

	SELECT @v_NumberOfCalls = COUNT(1) 
	FROM DBTD_TBL_PRETEND_OBJECT_LOG AS PL
		INNER JOIN DBTD_TBL_PRETEND_OBJECT AS P
			ON PL.PretendID = P.PretendID
			AND ([Message] = 'STARTING to run MOCK' 
				 OR [Message] = 'STARTING to run STUB')
	WHERE @v_Object_ID = P.ObjectID
		AND PL.UnitTestRunID = @v_UnitTestRunID
END
GO

--************************************************************************************************
--INTERNAL: Do not use this function in your unit tests, procedure can be removed,
--          signature or procedure name can be changed at any release
--DROP PROCEDURE DBTD_GET_PretendObjectNumberOfCallsWithParam
CREATE PROCEDURE DBTD_GET_PretendObjectNumberOfCallsWithParam
(
	@v_PrependObjectName SYSNAME,		--The name of the pretend object
	@v_ParameterName	 SYSNAME,		
	@v_ParameterValue	 NVARCHAR(MAX),	--NULL means NULL, NULL = NULL
	@v_UnitTestRunID	 INT,		 
	@v_NumberOfCalls	 INT OUTPUT
)
WITH ENCRYPTION AS
BEGIN
	SET NOCOUNT ON;
	DECLARE @v_Object_ID	 BIGINT = NULL,
			@v_Proc_Server	 VARCHAR(200),
			@v_Proc_Database VARCHAR(200),
			@v_Proc_Schema	 VARCHAR(200),
			@v_Proc_Object	 VARCHAR(200),
			@v_Proc_CorrectedName VARCHAR(200)
	DECLARE @v_ProcName	NVARCHAR(128) = OBJECT_NAME(@@PROCID)
	DECLARE @v_Message NVARCHAR(MAX) = 'Running ' + @v_ProcName;
	EXEC DBTD_LOG_MESSAGE_EXT 'DEBUG', @v_ProcName, @v_Message;

	--Identify and correct names 
	EXEC DBTD_SPLIT_FOUR_PART_OBJECT_NAME 
		@v_PrependObjectName, 
		@v_Server = @v_Proc_Server OUTPUT, @v_Database = @v_Proc_Database OUTPUT, @v_Schema = @v_Proc_Schema OUTPUT, 
		@v_Object = @v_Proc_Object OUTPUT, @v_CorrectedName = @v_Proc_CorrectedName OUTPUT,
		@v_CorrectTempTablesLocation = 1;

	--Find an object ID
	EXEC DBO.DBTD_GET_OBJECT_ID @v_Object_Name = @v_Proc_CorrectedName, @v_Object_ID = @v_Object_ID OUTPUT

	SELECT @v_NumberOfCalls = COUNT(1) 
	--SELECT * 
	FROM DBTD_TBL_PRETEND_OBJECT_PARAM_LOG AS PPL
		INNER JOIN DBTD_TBL_PRETEND_OBJECT AS P
			ON PPL.PretendID = P.PretendID
			AND P.ObjectID = @v_Object_ID
			AND PPL.UnitTestRunID = @v_UnitTestRunID
	WHERE PPL.ParamName = @v_ParameterName
		AND ((@v_ParameterValue IS NOT NULL AND PPL.ParamValue = @v_ParameterValue)
			 OR (@v_ParameterValue IS NULL AND PPL.ParamValue IS NULL)) --NULL = NULL
END
GO

--************************************************************************************************
--DROP PROCEDURE DBTD_ASSERT_MOCK_CALLED_WITH_PARAM
CREATE PROCEDURE DBTD_ASSERT_MOCK_CALLED_WITH_PARAM
	@v_PrependObjectName SYSNAME,		--The name of the MOCK procedure
	@v_ParameterName	 SYSNAME, 
	@v_ParameterValue	 NVARCHAR(MAX),	--NULL means NULL, NULL = NULL
	@v_NumberOfCalls	 INT = NULL,	--If NULL then any call
	@v_UserMessage		 NVARCHAR(MAX)	--User message
WITH ENCRYPTION AS
BEGIN
	SET NOCOUNT ON;
	DECLARE @v_ProcName	NVARCHAR(128) = OBJECT_NAME(@@PROCID)
	DECLARE @v_Message NVARCHAR(MAX) = 'Running ' + @v_ProcName;
	EXEC DBTD_LOG_MESSAGE_EXT 'DEBUG', @v_ProcName, @v_Message;
	SET @v_Message = ''

	DECLARE @v_NumberOfCalls_ACTUAL	INT = NULL,
			@v_UnitTestRunID INT

	EXEC dbo.DBTD_GET_UnitTestRunID @v_UnitTestRunID = @v_UnitTestRunID OUTPUT;

	--Check that we are dealing with the mock
	SET @v_Message = ' ' + ISNULL(@v_UserMessage, '')
	EXEC DBTD_ASSERT_MOCK_EXISTS @v_PrependObjectName, @v_Message

	EXEC DBTD_GET_PretendObjectNumberOfCallsWithParam @v_PrependObjectName, @v_ParameterName, @v_ParameterValue, @v_UnitTestRunID, @v_NumberOfCalls_ACTUAL OUTPUT

	SET @v_NumberOfCalls_ACTUAL = ISNULL(@v_NumberOfCalls_ACTUAL, 0);

	IF (@v_NumberOfCalls IS NULL AND @v_NumberOfCalls_ACTUAL <= 0)
		OR (@v_NumberOfCalls != @v_NumberOfCalls_ACTUAL)
	BEGIN
		SET @v_Message = ISNULL(@v_UserMessage + '.', '') 
			+ ' UnitTestRunID: [' + CAST(@v_UnitTestRunID AS VARCHAR(50)) + ']'
			+ ' For PARAMETER: [' + @v_ParameterName + ']'
			+ ' with VALUE: [' + ISNULL(@v_ParameterValue,'NULL') + ']'
			+ ' Unexpected Number Of Calls for '
			+ ' EXPECTED: ' + ISNULL(CAST(@v_NumberOfCalls AS VARCHAR(50)),'ANY Number Of Calls') 
			+ ' ACTUAL: ' + ISNULL(CAST(@v_NumberOfCalls_ACTUAL AS VARCHAR(50)),'NULL') ; 
		EXEC DBTD_FAILURE @v_Message; 
	END
END
GO

--************************************************************************************************
--DROP PROCEDURE DBTD_ASSERT_STUB_CALLED_WITH_PARAM
CREATE PROCEDURE DBTD_ASSERT_STUB_CALLED_WITH_PARAM
	@v_PrependObjectName SYSNAME,		--The name of the MOCK procedure
	@v_ParameterName	 SYSNAME, 
	@v_ParameterValue	 NVARCHAR(MAX),	--NULL means NULL, NULL = NULL
	@v_NumberOfCalls	 INT = NULL,	--If NULL then any call
	@v_UserMessage		 NVARCHAR(MAX)	--User message
WITH ENCRYPTION AS
BEGIN
	SET NOCOUNT ON;
	DECLARE @v_ProcName	NVARCHAR(128) = OBJECT_NAME(@@PROCID)
	DECLARE @v_Message NVARCHAR(MAX) = 'Running ' + @v_ProcName;
	EXEC DBTD_LOG_MESSAGE_EXT 'DEBUG', @v_ProcName, @v_Message;

	EXEC DBTD_ASSERT_MOCK_CALLED_WITH_PARAM
		@v_PrependObjectName,
		@v_ParameterName,
		@v_ParameterValue,
		@v_NumberOfCalls,
		@v_UserMessage;
END;
GO

--************************************************************************************************
--CREATE TABLE #v_ExpectedParameterValues (
--	PretendObjectExecutionNumber INT, --number of the pretend object execution. Used to separate different calls and maike sure that they will be compared in order.
--	ParameterName				 SYSNAME, 
--	ParameterValue				 NVARCHAR(MAX)
--)
--DROP PROCEDURE DBTD_ASSERT_MOCK_CALLED_WITH_PARAMS
CREATE PROCEDURE DBTD_ASSERT_MOCK_CALLED_WITH_PARAMS
	@v_PrependObjectName		SYSNAME,	--The name of the MOCK procedure
	@v_ExpectedParameterValues	SYSNAME,	--Name of the table (preferably temporary table) that have collection of expected parameter values
	@v_Debug					BIT = 0,	--When Set to 1 it will output the actual and expected parameter values
	@v_UserMessage				NVARCHAR(MAX)	--User message
WITH ENCRYPTION AS
BEGIN
	SET NOCOUNT ON;
	DECLARE @v_ProcName	NVARCHAR(128) = OBJECT_NAME(@@PROCID)
	DECLARE @v_Message NVARCHAR(MAX) = 'Running ' + @v_ProcName;
	EXEC DBTD_LOG_MESSAGE_EXT 'DEBUG', @v_ProcName, @v_Message;

	DECLARE @v_SQL		NVARCHAR(MAX),
			@v_UnitTestRunID INT,
			@v_ExpectedParameterValues_Server		VARCHAR(2000),
			@v_ExpectedParameterValues_Database	VARCHAR(2000),
			@v_ExpectedParameterValues_Schema		VARCHAR(2000),
			@v_ExpectedParameterValues_Object		VARCHAR(2000),
			@v_ExpectedParameterValues_CorrectedName VARCHAR(2000),
			@v_Object_ID	 BIGINT = NULL,
			@v_Proc_Server	 VARCHAR(200),
			@v_Proc_Database VARCHAR(200),
			@v_Proc_Schema	 VARCHAR(200),
			@v_Proc_Object	 VARCHAR(200),
			@v_Proc_CorrectedName VARCHAR(200),
			@v_ParameterLogAssertTempTable	NVARCHAR(MAX),
			@v_ParameterLogAssertGetData	NVARCHAR(MAX),
			@v_HasParameters BIT = 0
	SET @v_Message = ''

	CREATE TABLE #v_ActualParameterValues ( ExecutionNumber INT, UnitTestRunID INT );

	EXEC dbo.DBTD_GET_UnitTestRunID @v_UnitTestRunID = @v_UnitTestRunID OUTPUT;

	--Check that we are dealing with the mock
	SET @v_Message = ' ' + ISNULL(@v_UserMessage, '')
	EXEC DBTD_ASSERT_MOCK_EXISTS @v_PrependObjectName, @v_Message

	--Identify and correct names 
	EXEC DBTD_SPLIT_FOUR_PART_OBJECT_NAME 
		@v_ExpectedParameterValues, 
		@v_Server = @v_ExpectedParameterValues_Server OUTPUT, @v_Database = @v_ExpectedParameterValues_Database OUTPUT, @v_Schema = @v_ExpectedParameterValues_Schema OUTPUT, 
		@v_Object = @v_ExpectedParameterValues_Object OUTPUT, @v_CorrectedName = @v_ExpectedParameterValues_CorrectedName OUTPUT,
		@v_CorrectTempTablesLocation = 1;

	--Identify and correct names 
	EXEC DBTD_SPLIT_FOUR_PART_OBJECT_NAME 
		@v_PrependObjectName, 
		@v_Server = @v_Proc_Server OUTPUT, @v_Database = @v_Proc_Database OUTPUT, @v_Schema = @v_Proc_Schema OUTPUT, 
		@v_Object = @v_Proc_Object OUTPUT, @v_CorrectedName = @v_Proc_CorrectedName OUTPUT,
		@v_CorrectTempTablesLocation = 1;

	--Find an object ID
	EXEC DBO.DBTD_GET_OBJECT_ID @v_Object_Name = @v_Proc_CorrectedName, @v_Object_ID = @v_Object_ID OUTPUT

	SELECT @v_ParameterLogAssertTempTable = p.ParamLogAssertTempTable,
		@v_ParameterLogAssertGetData = p.ParamLogAssertGetData,
		@v_HasParameters = p.HasParameters 
	FROM DBTD_TBL_PRETEND_OBJECT p
	WHERE p.ObjectID = @v_Object_ID

	IF @v_HasParameters = 1
	BEGIN
		EXEC sp_executesql @v_ParameterLogAssertTempTable --Create temp table
		EXEC sp_executesql @v_ParameterLogAssertGetData, 
			N'@v_Object_ID INT, @v_UnitTestRunID INT', 
			@v_Object_ID = @v_Object_ID, 
			@v_UnitTestRunID = @v_UnitTestRunID

		IF @v_Debug = 1
		BEGIN
			SET @v_SQL = 'SELECT ''#v_ExpectedParameterValues'' AS DataSource, * FROM ' + @v_ExpectedParameterValues
			EXEC sp_executesql @v_SQL
			SELECT '#v_ActualParameterValues' AS DataSource, * FROM #v_ActualParameterValues
		END

		SET @v_Message = ISNULL(@v_UserMessage + '.', '') 
					+ '. Assert procedure DBTD_ASSERT_MOCK_CALLED_WITH_PARAMS '
					+ ' FOUND ISSUES for UnitTestRunID: [' + CAST(@v_UnitTestRunID AS VARCHAR(50)) + ']'
					+ ' and PARAMETER VALUES located in: [' + @v_ExpectedParameterValues_CorrectedName + ']'

		EXEC DBTD_ASSERT_ROWSETS_ARE_EQUAL
			'', '', '#v_ActualParameterValues', 
			@v_ExpectedParameterValues_Database, @v_ExpectedParameterValues_Schema, @v_ExpectedParameterValues_Object, 
			'USE EXPECTED COLUMNS', 
			@v_Message;
	END 
	ELSE BEGIN
		SET @v_Message = 'WARNING: ' + @v_PrependObjectName + ' procedure have no parameters'
		PRINT @v_Message 
		EXEC DBTD_LOG_MESSAGE_EXT 'INFO', 'DBTD_ASSERT_MOCK_CALLED_WITH_PARAMS', @v_Message
	END
END
GO

--************************************************************************************************
--CREATE TABLE #v_ExpectedParameterValues (
--	PretendObjectExecutionNumber INT, --number of the pretend object execution. Used to separate different calls and maike sure that they will be compared in order.
--	ParameterName				 SYSNAME, 
--	ParameterValue				 NVARCHAR(MAX)
--)
--DROP PROCEDURE DBTD_ASSERT_STUB_CALLED_WITH_PARAMS
CREATE PROCEDURE DBTD_ASSERT_STUB_CALLED_WITH_PARAMS
	@v_PrependObjectName		SYSNAME,	--The name of the MOCK procedure
	@v_ExpectedParameterValues	SYSNAME,	--Name of the table (preferably temporary table) that have collection of expected parameter values
	@v_Debug					BIT = 0,	--When Set to 1 it will output the actual and expected parameter values
	@v_UserMessage				NVARCHAR(MAX)	--User message
WITH ENCRYPTION AS
BEGIN
	SET NOCOUNT ON;
	DECLARE @v_ProcName	NVARCHAR(128) = OBJECT_NAME(@@PROCID)
	DECLARE @v_Message NVARCHAR(MAX) = 'Running ' + @v_ProcName;
	EXEC DBTD_LOG_MESSAGE_EXT 'DEBUG', @v_ProcName, @v_Message;

	EXEC DBTD_ASSERT_MOCK_CALLED_WITH_PARAMS
		@v_PrependObjectName,
		@v_ExpectedParameterValues,
		@v_Debug,
		@v_UserMessage
END;
GO

--************************************************************************************************
--DROP PROCEDURE DBTD_ASSERT_MOCK_NOT_CALLED_WITH_PARAM
CREATE PROCEDURE DBTD_ASSERT_MOCK_NOT_CALLED_WITH_PARAM
	@v_PrependObjectName SYSNAME,		--The name of the MOCK procedure
	@v_ParameterName	 SYSNAME, 
	@v_ParameterValue	 NVARCHAR(MAX),	--NULL means NULL, NULL = NULL
	@v_UserMessage		 NVARCHAR(MAX)	--User message
WITH ENCRYPTION AS
BEGIN
	SET NOCOUNT ON;
	DECLARE @v_ProcName	NVARCHAR(128) = OBJECT_NAME(@@PROCID)
	DECLARE @v_Message NVARCHAR(MAX) = 'Running ' + @v_ProcName;
	EXEC DBTD_LOG_MESSAGE_EXT 'DEBUG', @v_ProcName, @v_Message;

	EXEC DBTD_ASSERT_MOCK_CALLED_WITH_PARAM
		@v_PrependObjectName,
		@v_ParameterName,	
		@v_ParameterValue,	
		0,	--@v_NumberOfCalls
		@v_UserMessage		
END
GO

--************************************************************************************************
--DROP PROCEDURE DBTD_ASSERT_STUB_NOT_CALLED_WITH_PARAM
CREATE PROCEDURE DBTD_ASSERT_STUB_NOT_CALLED_WITH_PARAM
	@v_PrependObjectName SYSNAME,		--The name of the STUB procedure
	@v_ParameterName	 SYSNAME, 
	@v_ParameterValue	 NVARCHAR(MAX),	--NULL means NULL, NULL = NULL
	@v_UserMessage		 NVARCHAR(MAX)	--User message
WITH ENCRYPTION AS
BEGIN
	SET NOCOUNT ON;
	DECLARE @v_ProcName	NVARCHAR(128) = OBJECT_NAME(@@PROCID)
	DECLARE @v_Message NVARCHAR(MAX) = 'Running ' + @v_ProcName;
	EXEC DBTD_LOG_MESSAGE_EXT 'DEBUG', @v_ProcName, @v_Message;

	EXEC DBTD_ASSERT_STUB_CALLED_WITH_PARAM
		@v_PrependObjectName,
		@v_ParameterName,	
		@v_ParameterValue,	
		0,	--@v_NumberOfCalls
		@v_UserMessage		
END
GO

--************************************************************************************************
--DROP PROCEDURE DBTD_ASSERT_MOCK_NUMBER_OF_CALLS
CREATE PROCEDURE DBTD_ASSERT_MOCK_NUMBER_OF_CALLS
	@v_PrependObjectName SYSNAME,		--The name of the MOCK procedure
	@v_NumberOfCalls	 INT,			--If null then any call
	@v_UserMessage		 NVARCHAR(MAX)	--User message
WITH ENCRYPTION AS
BEGIN
	SET NOCOUNT ON;
	DECLARE @v_NumberOfCalls_ACTUAL	INT = NULL,
			@v_UnitTestRunID INT
	DECLARE @v_ProcName	NVARCHAR(128) = OBJECT_NAME(@@PROCID)
	DECLARE @v_Message NVARCHAR(MAX) = 'Running ' + @v_ProcName;
	EXEC DBTD_LOG_MESSAGE_EXT 'DEBUG', @v_ProcName, @v_Message;

	EXEC dbo.DBTD_GET_UnitTestRunID @v_UnitTestRunID = @v_UnitTestRunID OUTPUT;

	--Check that we are dealing with the mock
	SET @v_Message = ' ' + ISNULL(@v_UserMessage, '')
	EXEC DBTD_ASSERT_MOCK_EXISTS @v_PrependObjectName, @v_Message

	EXEC DBTD_GET_PretendObjectNumberOfCalls @v_PrependObjectName, @v_UnitTestRunID, @v_NumberOfCalls_ACTUAL OUTPUT
	SET @v_NumberOfCalls_ACTUAL = ISNULL(@v_NumberOfCalls_ACTUAL, 0);

	IF (@v_NumberOfCalls IS NULL AND @v_NumberOfCalls_ACTUAL <= 0)
		OR (@v_NumberOfCalls != @v_NumberOfCalls_ACTUAL)
	BEGIN
		SET @v_Message = @v_UserMessage 
			+ ' Unexpected Number Of Calls - '
			+ ' EXPECTED: ' + ISNULL(CAST(@v_NumberOfCalls AS VARCHAR(50)),'ANY Number Of Calls') 
			+ ' ACTUAL: ' + ISNULL(CAST(@v_NumberOfCalls_ACTUAL AS VARCHAR(50)),'NULL') ; 
		EXEC DBTD_FAILURE @v_Message; 
	END
END
GO

--************************************************************************************************
--DROP PROCEDURE DBTD_ASSERT_STUB_NUMBER_OF_CALLS
CREATE PROCEDURE DBTD_ASSERT_STUB_NUMBER_OF_CALLS
	@v_PrependObjectName SYSNAME,		--The name of the STUB procedure
	@v_NumberOfCalls	 INT,			--If null then any call
	@v_UserMessage		 NVARCHAR(MAX)	--User message
WITH ENCRYPTION AS
BEGIN
	SET NOCOUNT ON;
	DECLARE @v_ProcName	NVARCHAR(128) = OBJECT_NAME(@@PROCID)
	DECLARE @v_Message NVARCHAR(MAX) = 'Running ' + @v_ProcName;
	EXEC DBTD_LOG_MESSAGE_EXT 'DEBUG', @v_ProcName, @v_Message;

	EXEC DBTD_ASSERT_MOCK_NUMBER_OF_CALLS @v_PrependObjectName, @v_NumberOfCalls, @v_UserMessage
END
GO

--************************************************************************************************
CREATE PROCEDURE DBTD_ASSERT_MOCK_CALLED_MORE_THAN
	@v_PrependObjectName SYSNAME,		--The name of the MOCK procedure
	@v_NumberOfCalls	 INT,			--If null then any call
	@v_UserMessage		 NVARCHAR(MAX)	--User message
WITH ENCRYPTION AS
BEGIN
	SET NOCOUNT ON;
	DECLARE @v_NumberOfCalls_ACTUAL	INT = NULL,
			@v_UnitTestRunID INT
	DECLARE @v_ProcName	NVARCHAR(128) = OBJECT_NAME(@@PROCID)
	DECLARE @v_Message NVARCHAR(MAX) = 'Running ' + @v_ProcName;
	EXEC DBTD_LOG_MESSAGE_EXT 'DEBUG', @v_ProcName, @v_Message;

	EXEC dbo.DBTD_GET_UnitTestRunID @v_UnitTestRunID = @v_UnitTestRunID OUTPUT;

	--Check that we are dealing with the mock
	SET @v_Message = ' ' + ISNULL(@v_UserMessage, '')
	EXEC DBTD_ASSERT_MOCK_EXISTS @v_PrependObjectName, @v_Message

	EXEC DBTD_GET_PretendObjectNumberOfCalls @v_PrependObjectName, @v_UnitTestRunID, @v_NumberOfCalls_ACTUAL OUTPUT
	SET @v_NumberOfCalls_ACTUAL = ISNULL(@v_NumberOfCalls_ACTUAL, 0);

	IF (@v_NumberOfCalls IS NULL AND @v_NumberOfCalls_ACTUAL <= 0)
		OR (@v_NumberOfCalls >= @v_NumberOfCalls_ACTUAL)
	BEGIN
		SET @v_Message = ISNULL(@v_UserMessage + '.', '') 
			+ ' Unexpected Number Of Calls - '
			+ ' EXPECTED MORE THAN: ' + ISNULL(CAST(@v_NumberOfCalls AS VARCHAR(50)),'ANY Number Of Calls') 
			+ ' ACTUAL: ' + ISNULL(CAST(@v_NumberOfCalls_ACTUAL AS VARCHAR(50)),'NULL') ; 
		EXEC DBTD_FAILURE @v_Message; 
	END
END
GO

--************************************************************************************************
CREATE PROCEDURE DBTD_ASSERT_STUB_CALLED_MORE_THAN
	@v_PrependObjectName SYSNAME,		--The name of the MOCK procedure
	@v_NumberOfCalls	 INT,			--If null then any call
	@v_UserMessage		 NVARCHAR(MAX)	--User message
WITH ENCRYPTION AS
BEGIN
	SET NOCOUNT ON;
	DECLARE @v_ProcName	NVARCHAR(128) = OBJECT_NAME(@@PROCID)
	DECLARE @v_Message NVARCHAR(MAX) = 'Running ' + @v_ProcName;
	EXEC DBTD_LOG_MESSAGE_EXT 'DEBUG', @v_ProcName, @v_Message;

	EXEC DBTD_ASSERT_MOCK_CALLED_MORE_THAN @v_PrependObjectName, @v_NumberOfCalls, @v_UserMessage
END
GO

--************************************************************************************************
CREATE PROCEDURE DBTD_ASSERT_MOCK_CALLED
	@v_PrependObjectName SYSNAME,		--The name of the MOCK procedure
	@v_UserMessage		 NVARCHAR(MAX)	--User message
WITH ENCRYPTION AS
BEGIN
	SET NOCOUNT ON;
	DECLARE @v_ProcName	NVARCHAR(128) = OBJECT_NAME(@@PROCID)
	DECLARE @v_Message NVARCHAR(MAX) = 'Running ' + @v_ProcName;
	EXEC DBTD_LOG_MESSAGE_EXT 'DEBUG', @v_ProcName, @v_Message;

	EXEC DBTD_ASSERT_MOCK_NUMBER_OF_CALLS @v_PrependObjectName = @v_PrependObjectName, @v_NumberOfCalls	= NULL, @v_UserMessage = @v_UserMessage 
END
GO

--************************************************************************************************
CREATE PROCEDURE DBTD_ASSERT_STUB_CALLED
	@v_PrependObjectName SYSNAME,		--The name of the STUB procedure
	@v_UserMessage		 NVARCHAR(MAX)	--User message
WITH ENCRYPTION AS
BEGIN
	SET NOCOUNT ON;
	DECLARE @v_ProcName	NVARCHAR(128) = OBJECT_NAME(@@PROCID)
	DECLARE @v_Message NVARCHAR(MAX) = 'Running ' + @v_ProcName;
	EXEC DBTD_LOG_MESSAGE_EXT 'DEBUG', @v_ProcName, @v_Message;

	EXEC DBTD_ASSERT_STUB_NUMBER_OF_CALLS @v_PrependObjectName = @v_PrependObjectName, @v_NumberOfCalls	= NULL, @v_UserMessage = @v_UserMessage 
END
GO

--************************************************************************************************
--DROP PROCEDURE DBTD_ASSERT_MOCK_NOT_CALLED
CREATE PROCEDURE DBTD_ASSERT_MOCK_NOT_CALLED
	@v_PrependObjectName SYSNAME,		--The name of the MOCK procedure
	@v_UserMessage		 NVARCHAR(MAX)	--User message
WITH ENCRYPTION AS
BEGIN
	SET NOCOUNT ON;
	DECLARE @v_ProcName	NVARCHAR(128) = OBJECT_NAME(@@PROCID)
	DECLARE @v_Message NVARCHAR(MAX) = 'Running ' + @v_ProcName;
	EXEC DBTD_LOG_MESSAGE_EXT 'DEBUG', @v_ProcName, @v_Message;

	EXEC DBTD_ASSERT_MOCK_NUMBER_OF_CALLS @v_PrependObjectName = @v_PrependObjectName, @v_NumberOfCalls	= 0, @v_UserMessage = @v_UserMessage 
END
GO

--************************************************************************************************
--DROP PROCEDURE DBTD_ASSERT_STUB_NOT_CALLED
CREATE PROCEDURE DBTD_ASSERT_STUB_NOT_CALLED
	@v_PrependObjectName SYSNAME,		--The name of the STUB procedure
	@v_UserMessage		 NVARCHAR(MAX)	--User message
WITH ENCRYPTION AS
BEGIN
	SET NOCOUNT ON;
	DECLARE @v_ProcName	NVARCHAR(128) = OBJECT_NAME(@@PROCID)
	DECLARE @v_Message NVARCHAR(MAX) = 'Running ' + @v_ProcName;
	EXEC DBTD_LOG_MESSAGE_EXT 'DEBUG', @v_ProcName, @v_Message;

	EXEC DBTD_ASSERT_MOCK_NUMBER_OF_CALLS @v_PrependObjectName = @v_PrependObjectName, @v_NumberOfCalls	= 0, @v_UserMessage = @v_UserMessage 
END
GO

--************************************************************************************************
CREATE PROCEDURE DBTD_ASSERT_MOCK_CALLED_LESS_THAN
	@v_PrependObjectName SYSNAME,		--The name of the MOCK procedure
	@v_NumberOfCalls	 INT,			--If null then any call
	@v_UserMessage		 NVARCHAR(MAX)	--User message
WITH ENCRYPTION AS
BEGIN
	SET NOCOUNT ON;
	DECLARE @v_NumberOfCalls_ACTUAL	INT = NULL,
			@v_UnitTestRunID INT
	DECLARE @v_ProcName	NVARCHAR(128) = OBJECT_NAME(@@PROCID)
	DECLARE @v_Message NVARCHAR(MAX) = 'Running ' + @v_ProcName;
	EXEC DBTD_LOG_MESSAGE_EXT 'DEBUG', @v_ProcName, @v_Message;

	EXEC dbo.DBTD_GET_UnitTestRunID @v_UnitTestRunID = @v_UnitTestRunID OUTPUT;

	--Check that we are dealing with the mock
	SET @v_Message = ' ' + ISNULL(@v_UserMessage, '')
	EXEC DBTD_ASSERT_MOCK_EXISTS @v_PrependObjectName, @v_Message

	EXEC DBTD_GET_PretendObjectNumberOfCalls @v_PrependObjectName, @v_UnitTestRunID, @v_NumberOfCalls_ACTUAL OUTPUT
	SET @v_NumberOfCalls_ACTUAL = ISNULL(@v_NumberOfCalls_ACTUAL, 0);

	IF (@v_NumberOfCalls IS NULL AND @v_NumberOfCalls_ACTUAL <= 0)
		OR (@v_NumberOfCalls <= @v_NumberOfCalls_ACTUAL)
	BEGIN
		SET @v_Message = ISNULL(@v_UserMessage + '.', '') 
			+ ' Unexpected Number Of Calls - '
			+ ' EXPECTED LESS THAN: ' + ISNULL(CAST(@v_NumberOfCalls AS VARCHAR(50)),'ANY Number Of Calls') 
			+ ' ACTUAL: ' + ISNULL(CAST(@v_NumberOfCalls_ACTUAL AS VARCHAR(50)),'NULL') ; 
		EXEC DBTD_FAILURE @v_Message; 
	END
END
GO

--************************************************************************************************
CREATE PROCEDURE DBTD_ASSERT_STUB_CALLED_LESS_THAN
	@v_PrependObjectName SYSNAME,		--The name of the MOCK procedure
	@v_NumberOfCalls	 INT,			--If null then any call
	@v_UserMessage		 NVARCHAR(MAX)	--User message
WITH ENCRYPTION AS
BEGIN
	SET NOCOUNT ON;
	DECLARE @v_ProcName	NVARCHAR(128) = OBJECT_NAME(@@PROCID)
	DECLARE @v_Message NVARCHAR(MAX) = 'Running ' + @v_ProcName;
	EXEC DBTD_LOG_MESSAGE_EXT 'DEBUG', @v_ProcName, @v_Message;

	EXEC DBTD_ASSERT_MOCK_CALLED_LESS_THAN @v_PrependObjectName, @v_NumberOfCalls, @v_UserMessage
END
GO

--************************************************************************************************
--Stub Procedures:
--	+ have different name then original procedures 
--  + have same signatuare as original stored procedures 
--  + run only predefined SQL Code
--  + record information about each procedure calls, such as parameters.
--  + fails when procedure with the same name already exist
CREATE PROCEDURE DBTD_CREATE_STUB_PROCEDURE
(
	@v_StubProcName		SYSNAME, --The name of the STUB procedure that will be created base on the same signatuare as in the @v_OriginalProcName. This can be fully qualified name with database.schema.object 
	@v_OriginalProcName SYSNAME, --The name of the original procedure, the signature of this stored provedure will be used to create this Stub store dproc. This can be fully qualified name with database.schema.object 
	@v_StubSQL			NVARCHAR(MAX) = NULL --Is a Unicode string that contains a Transact-SQL statement or batch. NULL is default, means that extra code will not be executed besides framework logging  
)
WITH ENCRYPTION AS
BEGIN
	SET NOCOUNT ON;
	DECLARE @v_TextBlock		NVARCHAR(MAX),
			@v_SQL NVARCHAR(MAX) = '',
			@v_ParameterList AS DBTD_ParameterListTableType,	
			@v_ProcSignature	NVARCHAR(MAX),
			@v_PretendID		INT,
			@v_NewLine			VARCHAR(50) = CHAR(13)+CHAR(10),
			@v_BEGIN_StoredProc NVARCHAR(MAX), 
			@v_END_StoredProc	NVARCHAR(MAX) = ' END ', 
			@v_UnitTestRunID	INT,
			@v_DBTD_Database	VARCHAR(128) = DB_NAME(), 
			@v_ParamName		NVARCHAR(128),
			@v_Object_ID		BIGINT = NULL,

			@v_StubProc_Server			VARCHAR(2000),
			@v_StubProc_Database		VARCHAR(2000),
			@v_StubProc_Schema			VARCHAR(2000),
			@v_StubProc_Object			VARCHAR(2000),
			@v_StubProc_CorrectedName	VARCHAR(2000),
			@v_StubProc_CREATEName		VARCHAR(2000), --schema plus the name

			@v_OriginalProc_Server		VARCHAR(2000),
			@v_OriginalProc_Database	VARCHAR(2000),
			@v_OriginalProc_Schema		VARCHAR(2000),
			@v_OriginalProc_Object		VARCHAR(2000),
			@v_OriginalProc_CorrectedName	VARCHAR(2000),
			@v_FinalStubSQLCode				NVARCHAR(MAX),

			@v_ParameterLogTableName		NVARCHAR(MAX),
			@v_ParameterLogTableSignature	NVARCHAR(MAX),
			@v_ParameterLogTableColumns		NVARCHAR(MAX),
			@v_ParameterLogTableAllColumns	NVARCHAR(MAX),
			@v_ParamLogging					NVARCHAR(MAX),
			@v_ProcHasParameters			BIT = 0,
			@v_ParameterLogAssertTempTable NVARCHAR(MAX),
			@v_ParameterLogAssertGetData NVARCHAR(MAX)

	DECLARE @v_ThisProcName	NVARCHAR(128) = OBJECT_NAME(@@PROCID)
	DECLARE @v_Message NVARCHAR(MAX) = 'Running ' + @v_ThisProcName;
	EXEC DBTD_LOG_MESSAGE_EXT 'DEBUG', @v_ThisProcName, @v_Message;

	SET @v_Message = @v_StubProcName + ' Procedure already EXISTS in the database. Cannot create another STUB with the same name'

	CREATE TABLE #DBTD_TextBlock (
		TextBlock NVARCHAR(MAX) 
	);

	--Identify and correct names 
	EXEC DBTD_SPLIT_FOUR_PART_OBJECT_NAME 
		@v_StubProcName, 
		@v_Server = @v_StubProc_Server OUTPUT, @v_Database = @v_StubProc_Database OUTPUT, @v_Schema = @v_StubProc_Schema OUTPUT, 
		@v_Object = @v_StubProc_Object OUTPUT, @v_CorrectedName = @v_StubProc_CorrectedName OUTPUT,
		@v_CorrectTempTablesLocation = 1;
	EXEC DBTD_SPLIT_FOUR_PART_OBJECT_NAME 
		@v_OriginalProcName, 
		@v_Server = @v_OriginalProc_Server OUTPUT, @v_Database = @v_OriginalProc_Database OUTPUT, @v_Schema = @v_OriginalProc_Schema OUTPUT, 
		@v_Object = @v_OriginalProc_Object OUTPUT, @v_CorrectedName = @v_OriginalProc_CorrectedName OUTPUT,
		@v_CorrectTempTablesLocation = 1;

	--Check that procedure exists before moving forward
	EXEC DBTD_ASSERT_PROC_NOT_EXISTS @v_StubProc_CorrectedName, @v_Message
	
	BEGIN TRY	
		--Prepare procedure signature
		SET @v_StubProc_CREATEName = ISNULL(@v_StubProc_Schema + '.','') + @v_StubProc_Object;
		EXEC DBTD_GET_Object_Definition @v_ProcName	= @v_OriginalProc_CorrectedName, @v_Object_Definition = @v_TextBlock OUTPUT


		INSERT INTO @v_ParameterList 
			(ParameterID,ParameterName,IsOutputParameter,NextParameterName)
			EXEC DBTD_GET_ParameterList @v_OriginalProc_CorrectedName;

		SET @v_ProcSignature = dbo.DBTD_fnGetProcedureSignature( @v_OriginalProc_Object, @v_TextBlock, @v_ParameterList, @v_StubProc_CREATEName);

		--Register new object
		INSERT INTO DBTD_TBL_PRETEND_OBJECT
			(Name,OriginalName,CreatedTime,LastUsedTime)
			VALUES ( @v_StubProc_CorrectedName, @v_OriginalProc_CorrectedName, GETDATE(), NULL);
		SET @v_PretendID = @@IDENTITY;

		SET @v_ParameterLogTableName = '[DBTD_TBL_PretendID_'+REPLACE(CAST( @v_PretendID AS VARCHAR(50)),'-','')+'_PARAM_LOG]'
		EXEC DBTD_GET_ParameterLogTable
			@v_ProcName = @v_OriginalProc_CorrectedName,
			@v_ParameterLogTableName		= @v_ParameterLogTableName OUTPUT,	
			@v_ParameterLogTableSignature	= @v_ParameterLogTableSignature OUTPUT, 
			@v_ParameterLogTableColumns		= @v_ParameterLogTableColumns OUTPUT,	
			@v_ParameterLogTableAllColumns	= @v_ParameterLogTableAllColumns OUTPUT,
			@v_ProcHasParameters			= @v_ProcHasParameters OUTPUT,
			@v_ParameterLogAssertTempTable	= @v_ParameterLogAssertTempTable OUTPUT,
			@v_ParameterLogAssertGetData	= @v_ParameterLogAssertGetData OUTPUT


		UPDATE DBTD_TBL_PRETEND_OBJECT
		SET ParamLogTableName		= @v_ParameterLogTableName,		
			ParamLogTableSignature	= @v_ParameterLogTableSignature,
			ParamLogTableColumns	= @v_ParameterLogTableColumns,	
			ParamLogTableAllColumns	= @v_ParameterLogTableAllColumns,
			HasParameters			= @v_ProcHasParameters,
			ParamLogAssertTempTable	= @v_ParameterLogAssertTempTable,
			ParamLogAssertGetData	= @v_ParameterLogAssertGetData	
		FROM DBTD_TBL_PRETEND_OBJECT
		WHERE PretendID = @v_PretendID

		--Populate Code 
		SET @v_BEGIN_StoredProc = @v_NewLine + ' AS BEGIN ' + @v_NewLine + 'SET NOCOUNT ON; ' + @v_NewLine;

		--(A) Ge3t Unit Test Run ID
		SET @v_BEGIN_StoredProc = @v_BEGIN_StoredProc 
			+ @v_NewLine + ' DECLARE @v_UnitTestRunID_ORIG INT = NULL, @v_UnitTestRunID VARCHAR(50), @v_ExecutionLogID INT; '
			+ @v_NewLine + ' EXEC '+ISNULL(@v_DBTD_Database+'.','')+'dbo.DBTD_LOG_MESSAGE_EXT ''INFO'', '''+@v_StubProc_CorrectedName+''', ''STARTING EXECUTION OF ARTIFICIAL PRETEND OBJECT FOR ORIGINAL PROC: ['+@v_OriginalProc_CorrectedName+']'''
			+ @v_NewLine + ' EXEC '+ISNULL(@v_DBTD_Database+'.','')+'dbo.DBTD_GET_UnitTestRunID @v_UnitTestRunID = @v_UnitTestRunID_ORIG OUTPUT; '
			+ @v_NewLine + ' SET @v_UnitTestRunID = CAST( @v_UnitTestRunID_ORIG AS VARCHAR(50));'

		--(A2) SQL to log the record 
		SET @v_BEGIN_StoredProc = @v_BEGIN_StoredProc + @v_NewLine + ' INSERT INTO '+ISNULL(@v_DBTD_Database+'.','')+'dbo.DBTD_TBL_PRETEND_OBJECT_LOG '
			+ ' (PretendID,EventTime,UnitTestRunID,[Message]) '
			+ @v_NewLine + ' VALUES ( '
			+ CAST(@v_PretendID AS VARCHAR(50)) + ', GETDATE(), '
			+ ' @v_UnitTestRunID, ''STARTING to run STUB'' '
			+ ' ); ' 
			+ @v_NewLine
			+ 'SET @v_ExecutionLogID = SCOPE_IDENTITY()'
			+ @v_NewLine

		SET @v_ParamLogging = 'INSERT INTO '+ISNULL(@v_DBTD_Database+'.','')+'dbo.'+@v_ParameterLogTableName+'('+@v_ParameterLogTableColumns+') '
							+' VALUES (@v_ExecutionLogID,'+CAST(@v_PretendID AS VARCHAR(50))+',GETDATE(),@v_UnitTestRunID'

		--(B) Log parameter values
		DECLARE DBTD_STUB_PARAM_CURSOR CURSOR 
			FOR SELECT ParameterName FROM @v_ParameterList;
		OPEN DBTD_STUB_PARAM_CURSOR;
		FETCH NEXT FROM DBTD_STUB_PARAM_CURSOR INTO @v_ParamName;
		WHILE @@FETCH_STATUS = 0
		BEGIN
			--In the cursor populate the list of log values
			SET @v_BEGIN_StoredProc = @v_BEGIN_StoredProc + @v_NewLine + ' INSERT INTO '+ISNULL(@v_DBTD_Database+'.','')+'dbo.DBTD_TBL_PRETEND_OBJECT_PARAM_LOG '
				+' (PretendID,EventTime,ParamName,ParamValue,UnitTestRunID, ExecutionLogID) '
				+ @v_NewLine + ' VALUES ( '
				+ CAST(@v_PretendID AS VARCHAR(50)) + ', GETDATE(), '
				+ ' ''' + @v_ParamName + ''', '
				--+ 'ISNULL(CAST('+@v_ParamName+' AS NVARCHAR(MAX)), ''NULL''), @v_UnitTestRunID ); ' + @v_NewLine;
				+ 'CAST('+@v_ParamName+' AS NVARCHAR(MAX)), @v_UnitTestRunID, @v_ExecutionLogID ); ' + @v_NewLine;
	
			SET @v_ParamLogging = @v_ParamLogging + ',' + @v_ParamName

			FETCH NEXT FROM DBTD_STUB_PARAM_CURSOR INTO @v_ParamName;
		END
		CLOSE DBTD_STUB_PARAM_CURSOR;
		DEALLOCATE DBTD_STUB_PARAM_CURSOR;

		SET @v_ParamLogging = @v_ParamLogging + ' );'
		IF @v_ProcHasParameters = 1 
		BEGIN
			SET @v_BEGIN_StoredProc = @v_BEGIN_StoredProc + @v_NewLine +  @v_ParamLogging
		END

		--(B1) Update last used time
		SET @v_BEGIN_StoredProc = @v_BEGIN_StoredProc + @v_NewLine + 
			+ ' UPDATE '+ISNULL(@v_DBTD_Database+'.','')+'dbo.DBTD_TBL_PRETEND_OBJECT SET LastUsedTime = GETDATE() WHERE PretendID = ' 
			+ CAST(@v_PretendID AS VARCHAR(50)) + '; ' + @v_NewLine
		--(C) incorporate client code
		SET @v_BEGIN_StoredProc= @v_BEGIN_StoredProc + @v_NewLine + ISNULL( @v_StubSQL, '') + ' ' + @v_NewLine
		--Close the stored procedure text and execute the code in the target DB
		SET @v_FinalStubSQLCode = @v_ProcSignature + @v_NewLine + @v_BEGIN_StoredProc + @v_NewLine + @v_END_StoredProc;
		EXEC DBO.DBTD_SP_EXECUTESQL
			@v_TargetDatabase = @v_StubProc_Database,
			@v_SQLCode = @v_FinalStubSQLCode;
		--Now create parameter log table
		EXEC sp_executesql @v_ParameterLogTableSignature;

		--Find an object ID and update metadata
		EXEC DBO.DBTD_GET_OBJECT_ID
			@v_Object_Name = @v_StubProc_CorrectedName,
			@v_Object_ID = @v_Object_ID OUTPUT

		UPDATE DBTD_TBL_PRETEND_OBJECT
		SET ObjectID = @v_Object_ID
		WHERE  PretendID = @v_PretendID;
	END TRY 
	BEGIN CATCH
		SET @v_Message = 'FATAL ERROR: ' +  CAST(ERROR_NUMBER() AS VARCHAR) + ' : ' + ERROR_MESSAGE();
		EXEC DBTD_LOG_MESSAGE_EXT 'ERROR', @v_ThisProcName, @v_Message
		SET @v_Message = 'ERROR: UNABLE TO CREATE PRETEND OBJECT (MOCK or STUB) FOR: ' + @v_StubProcName
		EXEC DBTD_FAILURE @v_Message
	END CATCH;	
END
GO

--************************************************************************************************
--Mock Procedures:
--  + fails if original procedure does not exists
--	- have the same name as the original procedure 
--  + have same signatuare as original stored procedures 
--  + run BEFORE, INSTEAD-OF or ORIGINAL, and AFTER sql code
--  - record information about each procedure calls, such as parameters.
--DROP PROCEDURE DBTD_CREATE_MOCK_PROCEDURE
CREATE PROCEDURE DBTD_CREATE_MOCK_PROCEDURE
	@v_ProcName		SYSNAME, 
	@v_BeforeSQL	NVARCHAR(MAX) = NULL,
	@v_InsteadOfSQL NVARCHAR(MAX) = NULL,	--Use 'RUN ORIGINAL CODE' value to execute original code
	@v_AfterSQL		NVARCHAR(MAX) = NULL
WITH ENCRYPTION AS
BEGIN
	SET NOCOUNT ON;
	DECLARE @v_TextBlock		NVARCHAR(MAX),
			@v_SQL				NVARCHAR(MAX) = '',
			@v_ParameterCallSQL	NVARCHAR(MAX) = '',
			@v_ParameterCallDelimeter	NVARCHAR(5) = '',
			@v_ParameterList	AS DBTD_ParameterListTableType,	
			@v_ProcSignature	NVARCHAR(MAX),
			@v_PretendID		INT,
			@v_NewLine			VARCHAR(50) = CHAR(13)+CHAR(10),
			@v_BEGIN_StoredProc NVARCHAR(MAX), 
			@v_END_StoredProc	NVARCHAR(MAX) = ' END ', 
			@v_DBTD_Database	VARCHAR(128) = DB_NAME(), 
			@v_ParamName		NVARCHAR(128),
			@v_ObjectID			BIGINT = NULL,
			@v_IsOutputParameter	BIT = 0,

			@v_PretendProc_Server			VARCHAR(2000),
			@v_PretendProc_Database			VARCHAR(2000),
			@v_PretendProc_Schema			VARCHAR(2000),
			@v_PretendProc_Object			VARCHAR(2000),
			@v_PretendProc_CorrectedName	VARCHAR(2000),
			@v_PretendProc_SubstituteName	VARCHAR(2000), --schema plus the name

			@v_OriginalProc_Object			VARCHAR(2000),
			@v_OriginalProc_FullName		VARCHAR(2000),
			@v_OriginalProc_CorrectedName	VARCHAR(2000),
			@v_FinalSQLCode					NVARCHAR(MAX),

			@v_ParameterLogTableName		NVARCHAR(MAX),
			@v_ParameterLogTableSignature	NVARCHAR(MAX),
			@v_ParameterLogTableColumns		NVARCHAR(MAX),
			@v_ParameterLogTableAllColumns	NVARCHAR(MAX),
			@v_ParamLogging					NVARCHAR(MAX),
			@v_ProcHasParameters			BIT = 0,
			@v_ParameterLogAssertTempTable NVARCHAR(MAX),
			@v_ParameterLogAssertGetData NVARCHAR(MAX)

	DECLARE @v_ThisProcName	NVARCHAR(128) = OBJECT_NAME(@@PROCID)
	DECLARE @v_Message NVARCHAR(MAX) = 'Running ' + @v_ThisProcName;
	EXEC DBTD_LOG_MESSAGE_EXT 'DEBUG', @v_ThisProcName, @v_Message;

	SET @v_Message = @v_ProcName + ' Procedure DOES NOT EXISTS in the database. Cannot create MOCK object'

	CREATE TABLE #DBTD_TextBlock (
		TextBlock NVARCHAR(MAX) 
	)

	--Identify and correct names 
	EXEC DBTD_SPLIT_FOUR_PART_OBJECT_NAME 
		@v_ProcName, 
		@v_Server	= @v_PretendProc_Server OUTPUT, 
		@v_Database = @v_PretendProc_Database OUTPUT, 
		@v_Schema	= @v_PretendProc_Schema OUTPUT, 
		@v_Object	= @v_PretendProc_Object OUTPUT, 
		@v_CorrectedName = @v_PretendProc_CorrectedName OUTPUT,
		@v_CorrectTempTablesLocation = 1;

	--Original sproc will exists and will be renamed
	SET @v_OriginalProc_Object = LEFT(REPLACE(REPLACE(@v_PretendProc_Object, ']', ''), '[', ''), 80)  + '_' + REPLACE(CAST(NEWID() AS VARCHAR(50)), '-', '')

	EXEC DBO.DBTD_PREPARE_FOUR_PART_OBJECT_NAME
		@v_Server	= @v_PretendProc_Server,
		@v_Database = @v_PretendProc_Database,
		@v_Schema	= @v_PretendProc_Schema,
		@v_Object	= @v_OriginalProc_Object,
		@v_FullName	= @v_OriginalProc_FullName OUTPUT,					
		@v_CorrectedName = @v_OriginalProc_CorrectedName OUTPUT,	
		@v_CorrectTempTablesLocation = 1

	--Check that procedure exists before moving forward
	EXEC DBTD_ASSERT_PROC_EXISTS @v_PretendProc_CorrectedName, @v_Message

	BEGIN TRY
		--Prepare procedure signature
		EXEC DBTD_GET_Object_Definition @v_ProcName	= @v_PretendProc_CorrectedName, @v_Object_Definition = @v_TextBlock OUTPUT

		INSERT INTO @v_ParameterList 
			(ParameterID,ParameterName,IsOutputParameter,NextParameterName)
			EXEC DBTD_GET_ParameterList @v_PretendProc_CorrectedName;
		SET @v_PretendProc_SubstituteName = ISNULL(@v_PretendProc_Schema + '.','') + @v_PretendProc_Object
		SET @v_ProcSignature = dbo.DBTD_fnGetProcedureSignature( @v_PretendProc_Object, @v_TextBlock, @v_ParameterList, @v_PretendProc_SubstituteName);

		--Register new object
		INSERT INTO DBTD_TBL_PRETEND_OBJECT
			(Name,OriginalName,CreatedTime,LastUsedTime)
			VALUES ( @v_PretendProc_CorrectedName, @v_OriginalProc_CorrectedName, GETDATE(), NULL);
		SET @v_PretendID = @@IDENTITY;

		SET @v_ParameterLogTableName = '[DBTD_TBL_PretendID_'+REPLACE(CAST( @v_PretendID AS VARCHAR(50)),'-','')+'_PARAM_LOG]'
		EXEC DBTD_GET_ParameterLogTable
			@v_ProcName = @v_PretendProc_CorrectedName,
			@v_ParameterLogTableName		= @v_ParameterLogTableName OUTPUT,	
			@v_ParameterLogTableSignature	= @v_ParameterLogTableSignature OUTPUT, 
			@v_ParameterLogTableColumns		= @v_ParameterLogTableColumns OUTPUT,	
			@v_ParameterLogTableAllColumns	= @v_ParameterLogTableAllColumns OUTPUT,
			@v_ProcHasParameters			= @v_ProcHasParameters OUTPUT,
			@v_ParameterLogAssertTempTable	= @v_ParameterLogAssertTempTable OUTPUT,
			@v_ParameterLogAssertGetData	= @v_ParameterLogAssertGetData OUTPUT

		UPDATE DBTD_TBL_PRETEND_OBJECT
		SET ParamLogTableName		= @v_ParameterLogTableName,		
			ParamLogTableSignature	= @v_ParameterLogTableSignature,
			ParamLogTableColumns	= @v_ParameterLogTableColumns,	
			ParamLogTableAllColumns	= @v_ParameterLogTableAllColumns,
			HasParameters			= @v_ProcHasParameters,
			ParamLogAssertTempTable	= @v_ParameterLogAssertTempTable,
			ParamLogAssertGetData	= @v_ParameterLogAssertGetData	
		FROM DBTD_TBL_PRETEND_OBJECT
		WHERE PretendID = @v_PretendID

		--Populate Code 
		SET @v_BEGIN_StoredProc = @v_NewLine + ' AS BEGIN ' + @v_NewLine + 'SET NOCOUNT ON; ' + @v_NewLine;

		--(A) Get Unit Test Run ID
		SET @v_BEGIN_StoredProc = @v_BEGIN_StoredProc 
			+ @v_NewLine + ' DECLARE @v_UnitTestRunID_ORIG INT = NULL, @v_UnitTestRunID VARCHAR(50), @v_ExecutionLogID INT; '
			+ @v_NewLine + ' EXEC '+ISNULL(@v_DBTD_Database+'.','')+'dbo.DBTD_LOG_MESSAGE_EXT ''INFO'', '''+@v_PretendProc_CorrectedName+''', ''STARTING EXECUTION OF ARTIFICIAL PRETEND OBJECT FOR ORIGINAL PROC THAT WAS RENAMED TO: ['+@v_OriginalProc_CorrectedName+']'''
			+ @v_NewLine + ' EXEC '+ISNULL(@v_DBTD_Database+'.','')+'dbo.DBTD_GET_UnitTestRunID @v_UnitTestRunID = @v_UnitTestRunID_ORIG OUTPUT; '
			+ @v_NewLine + ' SET @v_UnitTestRunID = CAST( @v_UnitTestRunID_ORIG AS VARCHAR(50));'

		--(A2) SQL to log the record 
		SET @v_BEGIN_StoredProc = @v_BEGIN_StoredProc + @v_NewLine + ' INSERT INTO '+ISNULL(@v_DBTD_Database+'.','')+'dbo.DBTD_TBL_PRETEND_OBJECT_LOG '
			+ ' (PretendID,EventTime,UnitTestRunID,[Message]) '
			+ @v_NewLine + ' VALUES ( '
			+ CAST(@v_PretendID AS VARCHAR(50)) + ', GETDATE(), '
			+ ' @v_UnitTestRunID, ''STARTING to run MOCK'' '
			+ ' ); ' 
			+ @v_NewLine 
			+ 'SET @v_ExecutionLogID = SCOPE_IDENTITY()'
			+ @v_NewLine

		SET @v_ParamLogging = 'INSERT INTO ' + ISNULL(@v_DBTD_Database+'.','')+'dbo.' + @v_ParameterLogTableName+'('+@v_ParameterLogTableColumns+') '
							+' VALUES (@v_ExecutionLogID,'+CAST(@v_PretendID AS VARCHAR(50))+',GETDATE(), @v_UnitTestRunID'

		--(B) Log parameter values
		DECLARE DBTD_PRETEND_OBJECT_PARAM_CURSOR CURSOR 
			FOR SELECT ParameterName, IsOutputParameter FROM @v_ParameterList;
		OPEN DBTD_PRETEND_OBJECT_PARAM_CURSOR;
		FETCH NEXT FROM DBTD_PRETEND_OBJECT_PARAM_CURSOR INTO @v_ParamName, @v_IsOutputParameter;
		WHILE @@FETCH_STATUS = 0
		BEGIN
			--In the cursor populate the list of log values
			SET @v_BEGIN_StoredProc = @v_BEGIN_StoredProc + @v_NewLine + ' INSERT INTO '+ISNULL(@v_DBTD_Database+'.','')+'dbo.DBTD_TBL_PRETEND_OBJECT_PARAM_LOG '
				+' (PretendID,EventTime,ParamName,ParamValue,UnitTestRunID, ExecutionLogID) '
				+ @v_NewLine + ' VALUES ( '
				+ CAST(@v_PretendID AS VARCHAR(50)) + ', GETDATE(), '
				+ ' ''' + @v_ParamName + ''', '
				--+ 'ISNULL(CAST('+@v_ParamName+' AS NVARCHAR(MAX)), ''NULL''), @v_UnitTestRunID ); ' + @v_NewLine;
				+ 'CAST('+@v_ParamName+' AS NVARCHAR(MAX)), @v_UnitTestRunID, @v_ExecutionLogID ); ' + @v_NewLine;
	
			SET @v_ParameterCallSQL = @v_ParameterCallSQL 
				+ @v_ParameterCallDelimeter + @v_NewLine 
				+ @v_ParamName + ' = ' + @v_ParamName + CASE WHEN @v_IsOutputParameter = 1 THEN ' OUTPUT ' ELSE ' ' END			
			SET @v_ParameterCallDelimeter = ', ';

			SET @v_ParamLogging = @v_ParamLogging + ',' + @v_ParamName

			FETCH NEXT FROM DBTD_PRETEND_OBJECT_PARAM_CURSOR INTO @v_ParamName, @v_IsOutputParameter;
		END
		CLOSE DBTD_PRETEND_OBJECT_PARAM_CURSOR;
		DEALLOCATE DBTD_PRETEND_OBJECT_PARAM_CURSOR;
	
		SET @v_ParamLogging = @v_ParamLogging + ' );'
		IF @v_ProcHasParameters = 1 
		BEGIN
			SET @v_BEGIN_StoredProc = @v_BEGIN_StoredProc + @v_NewLine +  @v_ParamLogging
		END

		--print @v_ParamLogging

		--(B1) Update last used time
		SET @v_BEGIN_StoredProc = @v_BEGIN_StoredProc + @v_NewLine + 
			+ ' UPDATE '+ISNULL(@v_DBTD_Database+'.','')+'dbo.DBTD_TBL_PRETEND_OBJECT SET LastUsedTime = GETDATE() WHERE PretendID = ' 
			+ CAST(@v_PretendID AS VARCHAR(50)) + '; ' + @v_NewLine

		--(C) incorporate client code
		SET @v_BEGIN_StoredProc= @v_BEGIN_StoredProc + @v_NewLine + ISNULL( @v_BeforeSQL, '') + ' ' + @v_NewLine
		IF @v_InsteadOfSQL = 'RUN ORIGINAL CODE'
		BEGIN
			SET @v_InsteadOfSQL = 'EXEC ' + @v_OriginalProc_CorrectedName + ' ' + @v_ParameterCallSQL
		END
		SET @v_BEGIN_StoredProc= @v_BEGIN_StoredProc + @v_NewLine + ISNULL( @v_InsteadOfSQL, '') + ' ' + @v_NewLine
		SET @v_BEGIN_StoredProc= @v_BEGIN_StoredProc + @v_NewLine + ISNULL( @v_AfterSQL, '') + ' ' + @v_NewLine

		--Close the stored procedure text, rename existing and execute the code in the target DB
		SET @v_FinalSQLCode = @v_ProcSignature + @v_NewLine + @v_BEGIN_StoredProc + @v_NewLine + @v_END_StoredProc;
		--Rename Original object 
		SET @v_SQL = 'EXEC sp_rename '''
			+ @v_PretendProc_CorrectedName + ''', ''' --This is the name of the mock
			+ @v_OriginalProc_Object +''' ' --This will be the temporary new name
		EXEC DBO.DBTD_SP_EXECUTESQL @v_TargetDatabase = @v_PretendProc_Database, @v_SQLCode = @v_SQL;
		EXEC DBO.DBTD_SP_EXECUTESQL @v_TargetDatabase = @v_PretendProc_Database, @v_SQLCode = @v_FinalSQLCode;
		--Now create parameter log table
		EXEC sp_executesql @v_ParameterLogTableSignature;

		--Find an object ID and update metadata
		EXEC DBO.DBTD_GET_OBJECT_ID @v_Object_Name = @v_PretendProc_CorrectedName,	@v_Object_ID = @v_ObjectID OUTPUT

		UPDATE DBTD_TBL_PRETEND_OBJECT
		SET ObjectID = @v_ObjectID
		WHERE  PretendID = @v_PretendID;
	END TRY 
	BEGIN CATCH
		SET @v_Message = 'FATAL ERROR: ' +  CAST(ERROR_NUMBER() AS VARCHAR) + ' : ' + ERROR_MESSAGE();
		EXEC DBTD_LOG_MESSAGE_EXT 'ERROR', @v_ThisProcName, @v_Message
		SET @v_Message = 'ERROR: UNABLE TO CREATE PRETEND OBJECT (MOCK or STUB) FOR: ' + @v_ProcName
		EXEC DBTD_FAILURE @v_Message
	END CATCH;	
END
GO

--************************************************************************************************
--internal CORE procedure that initialize unit test 
CREATE PROCEDURE DBTD_INITIALIZE
(
	@v_TestName		SYSNAME,		--Unit Test
	@v_TestOwner	VARCHAR(128)	--Test Owner
)
WITH ENCRYPTION AS
BEGIN 
	SET NOCOUNT ON;
	DECLARE @v_ThisProcName	NVARCHAR(128) = OBJECT_NAME(@@PROCID)
	DECLARE @v_Message NVARCHAR(MAX) = 'INITIATING TEST...' + @v_TestName;
	EXEC DBTD_LOG_MESSAGE_EXT 'DEBUG', @v_ThisProcName, @v_Message;

	DELETE FROM DBTD_TBL_ACTIVETEST;
	
	INSERT INTO DBTD_TBL_ACTIVETEST (IsError,IsFailure,TestName, [Owner], [Message]) 
	VALUES (0,0,@v_TestName,@v_TestOwner,@v_Message);

	IF EXISTS(SELECT * FROM DBTD_TBL_TESTRESULT WHERE UPPER(TestName) = UPPER(@v_TestName))
	BEGIN 
		SET @v_Message = 'Update DBTD_TBL_TESTRESULT with initial pre-run status for - ' + @v_TestName;
		EXEC DBTD_LOG_MESSAGE_EXT 'INFO', @v_ThisProcName, @v_Message;
		UPDATE DBTD_TBL_TESTRESULT 
		SET 
			StartTime = GETDATE(),
			RunCount = ISNULL(RunCount,0) + 1,
			IsError = 0,
			IsFailure = 0, 
			Status = 'STARTED',
			Message = @v_Message
		WHERE 
			UPPER(TestName) = UPPER(@v_TestName)
		;
	END
	ELSE BEGIN
		SET @v_Message = 'Add new record to DBTD_TBL_TESTRESULT table since it is the first run for the test - ' + @v_TestName;
		EXEC DBTD_LOG_MESSAGE_EXT 'INFO', @v_ThisProcName, @v_Message;
		INSERT INTO DBTD_TBL_TESTRESULT ([Owner],StartTime,TestName,IsError, IsFailure, [Status],  [Message], RunCount)
		VALUES ( @v_TestOwner, GETDATE(), @v_TestName, 0, 0, 'STARTED', @v_Message, 1);
	END;
END;
GO

--************************************************************************************************
--internal CORE procedure that finalize unit test 
--DROP PROCEDURE DBTD_FINALIZE
CREATE PROCEDURE DBTD_FINALIZE
(
	@v_TestName			SYSNAME,		--Unit Test
	@v_TestOwner		VARCHAR(128),	--Test Owner
	@v_SetupError		INT,			--Errors encountered during setup
	@v_ProcedureError	INT,			--Errors encountered during test run
	@v_TeardownError	INT,			--Errors encountered during teardown 
	@v_WasIgnored		BIT,			--0 if test were run, 1 - if test execution were ignored
	@v_MessageStack		NVARCHAR(MAX)	--Stack Trace message
)
WITH ENCRYPTION AS
BEGIN 
	SET NOCOUNT ON;
	DECLARE @v_Message		NVARCHAR(MAX) = 'FINALIZING TEST...' + @v_TestName,
			@v_IsFailure	BIT,
			@v_IsError		BIT,
			@v_FinalStatus  VARCHAR(50),
			@v_FinalError	BIT,
			@v_FinalMessage NVARCHAR(MAX);
	DECLARE @v_ThisProcName	NVARCHAR(128) = OBJECT_NAME(@@PROCID)
	EXEC DBTD_LOG_MESSAGE_EXT 'DEBUG', @v_ThisProcName, @v_Message;

	SET @v_IsError = 0;		--assume that there is an issue
	SET @v_IsFailure = 0;	--assume that there is an issue
	
	SELECT TOP 1 
		@v_IsError = ISNULL(IsError,1),
		@v_IsFailure = ISNULL(IsFailure,1) 
	FROM DBTD_TBL_ACTIVETEST
	WHERE 
		UPPER(TestName) = UPPER(@v_TestName); 

	SET @v_Message = @v_TestName + ' v_SetupError=' + CAST(@v_SetupError as varchar(50)) + ', v_ProcedureError='+cast(@v_ProcedureError as varchar(50)) 
		+',v_TeardownError='+CAST(@v_TeardownError as varchar(50))+',v_IsError='+CAST(@v_IsError as varchar(50))
		+',v_IsFailure='+CAST(@v_IsFailure as varchar(50))
		+',v_WasIgnored='+CAST(@v_WasIgnored as varchar(50));
	EXEC DBTD_LOG_MESSAGE_EXT 'INFO', @v_ThisProcName, @v_Message ;
	SET @v_Message = 'v_MessageStack= ' + @v_MessageStack;
	EXEC DBTD_LOG_MESSAGE_EXT 'INFO', @v_ThisProcName, @v_Message ;

	SET @v_FinalStatus = 'SUCCESS';
	SET @v_FinalError = 0;
	SET @v_FinalMessage = @v_TestName + ' - DONE.';

	IF (@v_SetupError != 0 OR @v_ProcedureError != 0 OR @v_TeardownError != 0 OR ISNULL(@v_IsError, 1) != 0 OR ISNULL(@v_IsFailure,1) != 0 ) 
	BEGIN
		SET @v_FinalStatus = 'ERROR';
		SET @v_FinalError = 1;
		SET @v_FinalMessage = @v_TestName + ' - Has issues. Please check DBTD_TBL_LOG table for error messages.'  + ' Stack Trace: ' + @v_MessageStack;
	END;

	IF (@v_WasIgnored != 0)
	BEGIN
		SET @v_FinalStatus = 'IGNORED';
		SET @v_FinalMessage = @v_FinalMessage + ' Stack Trace: ' + @v_MessageStack;
	END;

	SET @v_Message = @v_TestName + ' finished with FinalStatus='+@v_FinalStatus + ', IsError='+CAST(@v_FinalError as varchar(50)) +',FinalMessage='+@v_FinalMessage;
	EXEC DBTD_LOG_MESSAGE_EXT 'INFO', @v_ThisProcName, @v_Message;

	EXEC DBTD_SaveState 
		@v_TestName = @v_TestName,
		@v_TestOwner = @v_TestOwner,		
		@v_Status = @v_FinalStatus,	
		@v_IsError = @v_FinalError,	
		@v_IsFailure = @v_IsFailure,
		@v_Message = @v_FinalMessage;
END;
GO 

--************************************************************************************************
--CORE
--runs Global SetUp procedure(s) 
CREATE PROCEDURE DBTD_RUNGLOBALSETUP 
(
	@v_Message NVARCHAR(MAX)
)
WITH ENCRYPTION AS
BEGIN
	SET NOCOUNT ON;
	DECLARE @v_GlobalSetup		VARCHAR(128) = 'UT_SETUP',
			@v_SetupErrMessage	NVARCHAR(MAX)

	DECLARE @v_ThisProcName	NVARCHAR(128) = OBJECT_NAME(@@PROCID)
	DECLARE @v_TmpMessage NVARCHAR(MAX) = 'Running ' + @v_ThisProcName;
	EXEC DBTD_LOG_MESSAGE_EXT 'DEBUG', @v_ThisProcName, @v_TmpMessage;
	EXEC DBTD_LOG_MESSAGE_EXT 'INFO', @v_ThisProcName, @v_Message;

	IF (dbo.DBTD_IS_SERVER_ACCESS_ALLOWED() != 1) 
	BEGIN
		EXEC DBTD_LOG_MESSAGE_EXT 'ACCESS', @v_ThisProcName, 'Access not allowed check DBTD_TBL_SERVER_ACCESS table for more info';
		RETURN;
	END

	--run global set up for all the tests
	IF EXISTS (SELECT 1 FROM DBO.SYSOBJECTS WHERE ID = OBJECT_ID(@v_GlobalSetup) AND OBJECTPROPERTY(ID, N'ISPROCEDURE') = 1)
	BEGIN
		EXEC DBTD_LOG_MESSAGE_EXT 'INFO', @v_ThisProcName, 'RUNNING GLOBAL SETUP';
		BEGIN TRY
			EXECUTE @v_GlobalSetup;
		END TRY
		BEGIN CATCH
			SET @v_SetupErrMessage = ' GLOBAL SETUP ERROR: ' +  CAST(ERROR_NUMBER() AS VARCHAR) + ' : ' + ERROR_MESSAGE();
			PRINT @v_SetupErrMessage;
			EXEC DBTD_LOG_MESSAGE_EXT 'ERROR', @v_GlobalSetup, @v_SetupErrMessage;
		END CATCH;
	END; 
	ELSE BEGIN
		EXEC DBTD_LOG_MESSAGE_EXT 'INFO', @v_ThisProcName, 'GLOBAL SETUP FUNCTION IS NOT DEFINED';
	END;
END;
GO

--************************************************************************************************
--CORE
--runs Global Teardown procedure(s)
CREATE PROCEDURE DBTD_RUNGLOBALTEARDOWN 
(
	@v_Message NVARCHAR(MAX)
)
WITH ENCRYPTION AS
BEGIN
	SET NOCOUNT ON;
	DECLARE @v_GlobalTearDown	VARCHAR(128) =  'UT_TEARDOWN',
			@v_ErrMessage		NVARCHAR(MAX),
			@v_ThisProcName	NVARCHAR(128) = OBJECT_NAME(@@PROCID)
	DECLARE @v_TempMessage NVARCHAR(MAX) = 'Running ' + @v_ThisProcName;
	EXEC DBTD_LOG_MESSAGE_EXT 'DEBUG', @v_ThisProcName, @v_TempMessage;
	EXEC DBTD_LOG_MESSAGE_EXT 'INFO', @v_ThisProcName, @v_Message;

	IF (dbo.DBTD_IS_SERVER_ACCESS_ALLOWED() != 1) 
	BEGIN
		EXEC DBTD_LOG_MESSAGE_EXT 'ACCESS', @v_ThisProcName, 'Access not allowed check DBTD_TBL_SERVER_ACCESS table for more info';
		RETURN;
	END

	--run global teardown for all the tests
	IF EXISTS (SELECT 1 FROM DBO.SYSOBJECTS WHERE ID = OBJECT_ID(@v_GlobalTearDown) AND OBJECTPROPERTY(ID, N'ISPROCEDURE') = 1)
	BEGIN
		EXEC DBTD_LOG_MESSAGE_EXT 'INFO', @v_ThisProcName, 'RUNNING GLOBAL TEARDOWN';
		BEGIN TRY
			EXECUTE @v_GlobalTearDown;
		END TRY
		BEGIN CATCH
			SET @v_ErrMessage = ' GLOBAL SETUP ERROR: ' +  CAST(ERROR_NUMBER() AS VARCHAR) + ' : ' + ERROR_MESSAGE();
			PRINT @v_ErrMessage;
			EXEC DBTD_LOG_MESSAGE_EXT 'ERROR', @v_GlobalTearDown, @v_ErrMessage;
		END CATCH;
	END; 
	ELSE BEGIN
		EXEC DBTD_LOG_MESSAGE_EXT 'INFO', @v_ThisProcName, 'GLOBAL TEARDOWN FUNCTION IS NOT DEFINED';
	END;
END;
GO

--************************************************************************************************
--CORE 
--run one tests 
CREATE PROCEDURE DBTD_RUNONETEST_EXT 
(
	@v_TestName			SYSNAME,		--Name of the Unit Test to run 
	@v_HasSetup			BIT,			--1 if unit test have setup procedure
	@v_HasTeardown		BIT,			--1 if unit test have teardown procedure
	@v_TestOwner		VARCHAR(128),	
	@v_Ignore			BIT,			--Set to 1 to ignore unit test

	@v_SetupName		VARCHAR(128),	--Name of the suite setup stored procedure
	@v_TeardownName		VARCHAR(128),	--Name of the suite teardown stored procedure

	@v_RunSetupOnce		BIT	= 0,		--When set to 1 then setup assumed to be ran already
	@v_RunTeardownOnce	BIT	= 0,		--When set to 1 then teardown assumed to be ran already  
	@v_UseTransaction	BIT = 0			--When set to 1 then procedure will start transaction before running test setup and rollback transaction after teardown 
										--It is not nessesary to use teardown when using transactions
)
WITH ENCRYPTION AS
BEGIN
	SET NOCOUNT ON;
	DECLARE @v_ProcessName			VARCHAR(128) = OBJECT_NAME(@@PROCID),
			@v_SetupErrMessage		NVARCHAR(MAX) = '',
			@v_TestErrMessage		NVARCHAR(MAX) = '',
			@v_TeardownErrMessage	NVARCHAR(MAX) = '',
			@v_MessageStack			NVARCHAR(MAX) = '',
			@v_TransactionMessageStack NVARCHAR(MAX) = '',
			@v_SetupError		BIT = 0,
			@v_UnitTestError	BIT = 0,
			@v_TeardownError	BIT = 0,
			@v_IsError			BIT = 0,
			@v_WasIgnored		BIT = 0,		
			@v_Trancount		INT,
			@v_TranStarted		BIT = 0,
			@v_NamedTranStarted	BIT = 0,
			@v_UnitTestRunID	BIGINT,
			@v_XACT_STATE		INT,
			@v_NewLine VARCHAR(10)= '
			';
	DECLARE @v_Message NVARCHAR(MAX) = 'Running ' + @v_ProcessName;
	DECLARE @DBTD_CurrentTestResultsDetails_Cache TABLE(	
														EventID						BIGINT,
														EventDate					DATETIME,
														ObjectId					BIGINT,	
														ObjectName					NVARCHAR(128),		
														ObjectDatabaseName			NVARCHAR(128),		
														ObjectSchemaName			NVARCHAR(128),	
														ObjectFullName				NVARCHAR(128),	
														ObjectType					NVARCHAR(128),	
														UnitTestName				NVARCHAR(128),		
														UnitTestRunID				BIGINT,
														CallingProcName				NVARCHAR(128),	
														IsMSShipped					BIT,			
														Comments					NVARCHAR(500)
														);
	
	IF OBJECT_ID('tempdb.dbo.#DBTD_CurrentUnitTestRunID') IS NULL 
	BEGIN
		--TODO: rename table to the #DBTD_CurrentUnitTest_Metadata 
		CREATE TABLE #DBTD_CurrentUnitTestRunID(
			UnitTestRunID	BIGINT,
			UnitTestName	NVARCHAR(128)
		);				
	END
	ELSE DELETE FROM #DBTD_CurrentUnitTestRunID; 

	IF OBJECT_ID('tempdb.dbo.#DBTD_CurrentTestResultsDetails_Cache') IS NULL
	BEGIN
		--temp table is based on the DBTD_TBL_TESTRESULT_DETAILS permanent table
		CREATE TABLE #DBTD_CurrentTestResultsDetails_Cache(	
			EventID						BIGINT IDENTITY,
			EventDate					DATETIME CONSTRAINT DF_DBTD_TBL_TESTRESULT_DETAILS_EventDate DEFAULT GETDATE(),
			ObjectId					BIGINT,				--The actual asserted object
			ObjectName					NVARCHAR(128),		
			ObjectDatabaseName			NVARCHAR(128),		
			ObjectSchemaName			NVARCHAR(128),		--RESERVED: 
			ObjectFullName				NVARCHAR(128),		--RESERVED: 
			ObjectType					NVARCHAR(128),		--Object Type description
			UnitTestName				NVARCHAR(128),		
			UnitTestRunID				BIGINT,
			CallingProcName				NVARCHAR(128),		--OBJECT_NAME(@@PROCID) 
			IsMSShipped					BIT,				--RESERVED: 
			Comments					NVARCHAR(500)
		);
	END
	ELSE DELETE FROM #DBTD_CurrentTestResultsDetails_Cache; 

	EXEC DBTD_LOG_MESSAGE_EXT 'DEBUG', @v_ProcessName, @v_Message;
	SET @v_Message = ''

	IF (dbo.DBTD_IS_SERVER_ACCESS_ALLOWED() != 1) 
	BEGIN
		EXEC DBTD_LOG_MESSAGE_EXT 'ACCESS', @v_ProcessName, 'Access not allowed check DBTD_TBL_SERVER_ACCESS table for more info';
		RETURN;
	END

    SET @v_Trancount = @@trancount;
	EXEC DBTD_INITIALIZE @v_TestName, @v_TestOwner;

	BEGIN TRY --Transaction started 
		if (@v_Ignore = 0) 
		BEGIN 
			--Run tests that are not Ignored 
			--Handle transaction settings
			IF @v_UseTransaction = 1
			BEGIN
				SET @v_Message = 'BEGIN TRANSACTION; @v_UseTransaction is set to 1 for ' + @v_TestName;
				EXEC DBTD_LOG_MESSAGE_EXT 'DEBUG', @v_ProcessName, @v_Message;
				IF @v_Trancount = 0
				BEGIN
					BEGIN TRANSACTION
					SET @v_TranStarted = 1;
					SET @v_TransactionMessageStack = ISNULL(@v_TransactionMessageStack,'') + 'Started Transaction.'
				END 
				ELSE BEGIN
					SAVE TRANSACTION DBTD_RUNONETEST_EXT;
					SET @v_NamedTranStarted = 1;
					SET @v_TransactionMessageStack = ISNULL(@v_TransactionMessageStack,'') + 'Started NAMED Transaction.'
				END
			END; 

			SET @v_UnitTestRunID = CAST(rand() * 10000000 + rand() * 10000000 AS INT)
			INSERT INTO #DBTD_CurrentUnitTestRunID (UnitTestRunID, UnitTestName)	
				VALUES ( @v_UnitTestRunID, @v_TestName)
			SET @v_TransactionMessageStack = ISNULL(@v_TransactionMessageStack,'') 
				+ @v_NewLine + ' UnitTestRunID is set to ' + CAST(@v_UnitTestRunID AS VARCHAR(50));

			--Execute test setup step
			IF (@v_HasSetup = 1) AND (@v_RunSetupOnce = 0) BEGIN 
				SET @v_Message = 'RUNNING SETUP:' + @v_SetupName + ', for unit test:' + @v_TestName; 
				EXEC DBTD_LOG_MESSAGE_EXT 'INFO',@v_ProcessName, @v_Message;
				SET @v_TransactionMessageStack = ISNULL(@v_TransactionMessageStack,'') + @v_NewLine + ISNULL(@v_Message,'');
				BEGIN TRY
					EXECUTE @v_SetupName;
				END TRY
				BEGIN CATCH
					SET @v_SetupErrMessage = ' SETUP ERROR: ' +  CAST(ERROR_NUMBER() AS VARCHAR) + ' : ' + ERROR_MESSAGE();
					IF @v_UseTransaction != 1	--save status only when transaction not used 
					BEGIN
						EXEC DBTD_LOG_MESSAGE_EXT 'ERROR', @v_SetupName, @v_SetupErrMessage;
					END
					SET @v_SetupError = ERROR_NUMBER();
					SET @v_MessageStack = @v_MessageStack + @v_SetupErrMessage + ' ';
					SET @v_TransactionMessageStack = ISNULL(@v_TransactionMessageStack,'') + @v_NewLine + ISNULL(@v_SetupErrMessage,'');
					--get transaction status information 
					SET @v_XACT_STATE = XACT_STATE();
				END CATCH;
			END;

			--Execure test itselt
			IF (@v_SetupError= 0) BEGIN 
				SET @v_Message = 'RUNNING: ' + @v_TestName;
				EXEC DBTD_LOG_MESSAGE_EXT 'INFO', @v_ProcessName, @v_Message ;
				SET @v_TransactionMessageStack = ISNULL(@v_TransactionMessageStack,'') + @v_NewLine + ISNULL(@v_Message,'');
				BEGIN TRY
					EXECUTE @v_TestName;
					--Persist test result details information
					INSERT INTO @DBTD_CurrentTestResultsDetails_Cache 
						(EventID,EventDate,ObjectId,ObjectName,ObjectDatabaseName,ObjectSchemaName,ObjectFullName,ObjectType,UnitTestName,UnitTestRunID,CallingProcName,IsMSShipped,Comments)
						SELECT 
							EventID,EventDate,ObjectId,ObjectName,ObjectDatabaseName,ObjectSchemaName,ObjectFullName,ObjectType,UnitTestName,UnitTestRunID,CallingProcName,IsMSShipped,Comments
						FROM #DBTD_CurrentTestResultsDetails_Cache
				END TRY
				BEGIN CATCH
					SET @v_TestErrMessage = ' UNIT TEST ERROR: ' +  CAST(ERROR_NUMBER() AS VARCHAR) + ' : ' + ERROR_MESSAGE();
					IF @v_UseTransaction != 1	--save status only when transaction not used 
					BEGIN
						EXEC DBTD_LOG_MESSAGE_EXT 'ERROR', @v_TestName, @v_TestErrMessage;
					END
					SET @v_UnitTestError = ERROR_NUMBER();
					SET @v_IsError = 1;
					SET @v_MessageStack = @v_MessageStack + @v_TestErrMessage + ' ';
					SET @v_TransactionMessageStack = ISNULL(@v_TransactionMessageStack,'') + @v_NewLine + ISNULL(@v_TestErrMessage,'');
					--get transaction status information 
					SET @v_XACT_STATE = XACT_STATE();
				END CATCH;
			END
			ELSE BEGIN
				SET @v_WasIgnored = 1;
				SET @v_Message = 'Skipping ' + UPPER(@v_TestName) + ' unit test due to error ' + CAST(@v_SetupError AS VARCHAR) + ' in setup procedure ' + UPPER(@v_SetupName);
				IF @v_UseTransaction != 1	--save status only when transaction is not used 
				BEGIN
					EXEC DBTD_LOG_MESSAGE_EXT 'WARNING', @v_ProcessName, @v_Message ;
				END
				SET @v_MessageStack = @v_MessageStack + @v_Message + ' ';
				SET @v_TransactionMessageStack = ISNULL(@v_TransactionMessageStack,'') + @v_NewLine + ISNULL(@v_Message,'');
			END;

			--Run teardown if needed 
			IF (@v_HasTeardown=1) --we need teardown
				AND (@v_RunTeardownOnce = 0) --and we need to make sure that we are not runnning it once 
				AND (@v_UseTransaction != 1) --and there is no need for teardown when transaction will be rolled back anyway
			BEGIN 
				SET @v_Message = 'RUNNING TEARDOWN - ' + @v_TeardownName;
				EXEC DBTD_LOG_MESSAGE_EXT 'INFO', @v_ProcessName, @v_Message;
				SET @v_TransactionMessageStack = ISNULL(@v_TransactionMessageStack,'') + @v_NewLine + ISNULL(@v_Message,'');
				BEGIN TRY
					EXECUTE @v_TeardownName;
				END TRY
				BEGIN CATCH
					SET @v_TeardownErrMessage = ' TEARDOWN ERROR: ' +  CAST(ERROR_NUMBER() AS VARCHAR) + ' : ' + ERROR_MESSAGE();
					IF @v_UseTransaction != 1	--save status only when transaction is not used 
						EXEC DBTD_LOG_MESSAGE_EXT 'ERROR', @v_TeardownName, @v_TeardownErrMessage;
					SET @v_TeardownError = ERROR_NUMBER();
					SET @v_MessageStack = @v_MessageStack + @v_TeardownErrMessage + ' ';
					SET @v_TransactionMessageStack = ISNULL(@v_TransactionMessageStack,'') + @v_NewLine + ISNULL(@v_TeardownErrMessage,'');
					--get transaction status information 
					SET @v_XACT_STATE = XACT_STATE();
				END CATCH;
			END;
			
			--Handle transactions
			IF @v_UseTransaction = 1
			BEGIN
				IF @v_TranStarted = 1
				BEGIN 
					ROLLBACK;
				END 
				ELSE IF @v_NamedTranStarted = 1
				BEGIN
					ROLLBACK TRANSACTION DBTD_RUNONETEST_EXT;
				END 
				--insert the message after we have rolled back transaction so that we preserve logging information 
				SET @v_Message = 'ROLLBACK TRANSACTION; @v_UseTransaction is set to 1 for ' + @v_TestName;
				SET @v_TransactionMessageStack = ISNULL(@v_TransactionMessageStack,'') + @v_NewLine + ISNULL(@v_Message,'');
				EXEC DBTD_LOG_MESSAGE_EXT 'DEBUG STACK', @v_ProcessName, @v_TransactionMessageStack;
				EXEC DBTD_LOG_MESSAGE_EXT 'DEBUG', @v_ProcessName, @v_Message;
			END; 
		END
		ELSE BEGIN 
			SET @v_WasIgnored = 1;
			SET @v_MessageStack = ' Unit tests has been marked to be ignored.';
		END; 
	END TRY
	BEGIN CATCH
		SET @v_TestErrMessage = ' UNIT TEST ERROR: ' +  CAST(ERROR_NUMBER() AS VARCHAR) + ' : ' + ERROR_MESSAGE();
		SET @v_UnitTestError = ERROR_NUMBER();
		SET @v_IsError = 1;
		SET @v_MessageStack = @v_MessageStack + @v_TestErrMessage + ' ';
		SET @v_TransactionMessageStack = ISNULL(@v_TransactionMessageStack,'') + @v_NewLine + ISNULL(@v_TestErrMessage,'');
		SET @v_XACT_STATE = XACT_STATE();

		IF @v_UseTransaction = 1
		BEGIN
			--The current request has an active user transaction, but an error has occurred that has caused the transaction to be classified as an uncommittable transaction. The request cannot commit the transaction or roll back to a savepoint; it can only request a full rollback of the transaction. The request cannot perform any write operations until it rolls back the transaction. The request can only perform read operations until it rolls back the transaction. After the transaction has been rolled back, the request can perform both read and write operations and can begin a new transaction.
			--When a batch finishes running, the Database Engine will automatically roll back any active uncommittable transactions. If no error message was sent when the transaction entered an uncommittable state, when the batch finishes, an error message will be sent to the client application. This message indicates that an uncommittable transaction was detected and rolled back.
			 IF @v_XACT_STATE = -1
				ROLLBACK;
			 ELSE IF @v_NamedTranStarted = 1
				ROLLBACK TRANSACTION DBTD_RUNONETEST_EXT;
			 ELSE IF @v_TranStarted = -1
				ROLLBACK;
		END; 
		EXEC DBTD_LOG_MESSAGE_EXT 'ERROR STACK', @v_TestName, @v_TransactionMessageStack;
		EXEC DBTD_LOG_MESSAGE_EXT 'ERROR', @v_TestName, @v_TestErrMessage;
	END CATCH;
	
	--Persist surviving test results
	IF EXISTS (SELECT 1 FROM @DBTD_CurrentTestResultsDetails_Cache)
	BEGIN
		SET @v_Message = 'Saving DBTD_TBL_TESTRESULT_DETAILS information for ' + @v_TestName + ' Unit Test and UnitTestRunID=' + CAST(@v_UnitTestRunID AS VARCHAR(50));
		EXEC DBTD_LOG_MESSAGE_EXT 'INFO', @v_ProcessName, @v_Message;
		INSERT INTO DBTD_TBL_TESTRESULT_DETAILS
			(EventDate,ObjectId,ObjectName,ObjectDatabaseName,ObjectSchemaName,ObjectFullName,ObjectType,UnitTestName,UnitTestRunID,CallingProcName,IsMSShipped,Comments)
			SELECT 
				EventDate,ObjectId,ObjectName,ObjectDatabaseName,ObjectSchemaName,ObjectFullName,ObjectType,UnitTestName,UnitTestRunID,CallingProcName,IsMSShipped,Comments
			FROM @DBTD_CurrentTestResultsDetails_Cache
			ORDER BY EventID ASC 
		DELETE FROM @DBTD_CurrentTestResultsDetails_Cache;
	END

	EXEC DBTD_FINALIZE @v_TestName, @v_TestOwner, @v_SetupError, @v_UnitTestError, @v_TeardownError, @v_WasIgnored, @v_MessageStack;

	RETURN;
END;
GO

--************************************************************************************************
--CORE
--run all tests in the specified test suite. 
--note: if DBTD_TBL_TESTSLIST table is empty stored proc will attempt to refresh the list of all 
--      available tests
--note: oracle version will allow same test suite names used for the different owners, other DB
--      might not support this feature
CREATE PROCEDURE DBTD_RUNTESTSUITE_EXT 
(
	@v_SuiteName				VARCHAR(128),	--Test suite name
	@v_SuiteOwner				VARCHAR(128),	--Suite owner (Reserved)
	@v_ReloadTestsList			BIT,			--Refresh list of all available unit tests
	@v_RunGlobalSetupTeardown	BIT,			--Run global setup and teardown for given test suite
	@v_UseTransaction			BIT = 0			--Wrap unit test execution in to individuad transaction. Default is 0 
)
WITH ENCRYPTION AS
BEGIN
	SET NOCOUNT ON;
	DECLARE @v_ProcessName	NVARCHAR(128) = OBJECT_NAME(@@PROCID),
			@v_ErrorMessage NVARCHAR(MAX),
			@v_GlobalSetup	VARCHAR(128) = 'UT_SETUP',
			@v_GlobalTearDown VARCHAR(128) =  'UT_TEARDOWN',
			@v_HasSetup		BIT,			
			@v_HasTeardown	BIT,
			@v_Ignore		BIT,
			@v_IsError		BIT,
			@v_MessageStack NVARCHAR(MAX),	--used to accumulate messages and pass them to finalization
			@v_RunSetupOnce BIT = 0,
			@v_RunTeardownOnce BIT = 0,
			@v_SetupError	INT = 0,
			@v_SetupName	VARCHAR(128),
			@v_TeardownError INT,
			@v_TeardownName VARCHAR(128),
			@v_TestName		VARCHAR(128),
			@v_TestOwner	VARCHAR(128),
			@v_TestPrefix		CHAR(3) = 'UT_',
			@v_UnitTestCount	INT = 0,	--number of unit tests that were run for a given suite 
			@v_UnitTestError	INT,
			@v_WasIgnored		BIT,	--will be set to 1 if test execution was ignored during execution
			@v_IndividualUseTranSettings BIT, -- test specific transaction ussage settings
			@v_UseTran			BIT = NULL, -- test specific transaction ussage settings
			@v_Trancount		INT, --used to catch run away transactions
			@v_XACT_STATE		INT; --used to catch run away transactions
	DECLARE @v_Message NVARCHAR(MAX) = 'Running ' + @v_ProcessName;
	EXEC DBTD_LOG_MESSAGE_EXT 'DEBUG', @v_ProcessName, @v_Message;


	IF (dbo.DBTD_IS_SERVER_ACCESS_ALLOWED() != 1) 
	BEGIN
		EXEC DBTD_LOG_MESSAGE_EXT 'ACCESS', @v_ProcessName, 'Access not allowed check DBTD_TBL_SERVER_ACCESS table for more info';
		RETURN;
	END

	SET @v_SetupName = RTRIM(LTRIM(@v_TestPrefix)) +UPPER(RTRIM(LTRIM(@v_SuiteName))) + '_SETUP';
	SET @v_TeardownName = RTRIM(LTRIM(@v_TestPrefix)) +UPPER(RTRIM(LTRIM(@v_SuiteName))) + '_TEARDOWN';

	SET @v_Message = 'EXEC '+@v_ProcessName+' - ' + @v_SuiteName; 
	EXEC DBTD_LOG_MESSAGE_EXT 'DEBUG', @v_ProcessName, @v_Message;

	BEGIN TRY
		--check if we need to refresh results
		IF	((NOT EXISTS(SELECT 1 FROM DBTD_TBL_TESTSLIST)) OR (@v_ReloadTestsList = 1)) 
		BEGIN 
			EXEC DBTD_LOG_MESSAGE_EXT 'INFO', @v_ProcessName, 'REFRESH DBTD_TBL_TESTSLIST';
			EXEC DBTD_REFRESH_TESTSLIST; 
		END;

		IF (@v_RunGlobalSetupTeardown = 1)
		BEGIN 
			SET @v_Message = 'Running Global Setup from '+@v_ProcessName+' process'; 
			EXEC DBTD_RUNGLOBALSETUP @v_Message;
		END; 

		EXEC DBTD_LOG_MESSAGE_EXT 'DEBUG', @v_ProcessName, 'Check that we need to run setup only once per suite';
		SELECT 
			@v_RunSetupOnce = (CASE WHEN COUNT(*) > 0 THEN 1 ELSE 0 END)
		FROM sys.sql_modules AS C
		WHERE UPPER(object_definition(object_id)) LIKE '%DBTD\_RUN\_ONCE%'  ESCAPE '\'
			AND UPPER(object_name(object_id)) = UPPER(@v_SetupName);
		EXEC DBTD_LOG_MESSAGE_EXT 'DEBUG', @v_ProcessName, 'Check that we need to run teardown only once per suite';
		SELECT 
			@v_RunTeardownOnce = (CASE WHEN COUNT(*) > 0 THEN 1 ELSE 0 END)
		FROM sys.sql_modules AS C
		WHERE UPPER(object_definition(object_id)) LIKE '%DBTD\_RUN\_ONCE%'  ESCAPE '\'
			AND UPPER(object_name(object_id)) = UPPER(@v_TeardownName);

		SET @v_Message = 'Setup run once = ' + cast( @v_RunSetupOnce as varchar) + ', teardown run once = ' + cast( @v_RunTeardownOnce as varchar);
		EXEC DBTD_LOG_MESSAGE_EXT 'DEBUG', @v_ProcessName, @v_Message;

		IF (@v_RunSetupOnce = 1) BEGIN 
			SET @v_Message = 'Running setup procedure '+@v_SetupName+' once for a suite ' + @v_SuiteName; 
			EXEC DBTD_LOG_MESSAGE_EXT 'INFO',@v_ProcessName, @v_Message;
			BEGIN TRY
				EXECUTE @v_SetupName;
			END TRY
			BEGIN CATCH
				SET @v_ErrorMessage = ' SETUP ERROR: ' +  CAST(ERROR_NUMBER() AS VARCHAR) + ' : ' + ERROR_MESSAGE();
				EXEC DBTD_LOG_MESSAGE_EXT 'ERROR', @v_SetupName, @v_ErrorMessage;
				SET @v_SetupError = ERROR_NUMBER();
			END CATCH;
		END;

		--iterate through all available UTs for a given test suite
		DECLARE UNIT_TEST_CURSOR CURSOR FOR 
		SELECT	TestName, HasSetup, HasTeardown, [Owner], Ignore, UseTransaction 
		FROM	DBTD_TBL_TESTSLIST 
		WHERE	
			RTRIM(LTRIM(UPPER(Suite))) = RTRIM(LTRIM(UPPER( @v_SuiteName))) 
		ORDER BY TestName;

		OPEN unit_test_cursor

		FETCH NEXT FROM unit_test_cursor 
		INTO @v_TestName, @v_HasSetup, @v_HasTeardown, @v_TestOwner, @v_Ignore, @v_IndividualUseTranSettings; 

		WHILE @@FETCH_STATUS = 0
		BEGIN
			SET @v_UnitTestError=0;
			SET @v_TeardownError=0;
			SET @v_IsError = 0;
			SET @v_WasIgnored = 0;		
			SET @v_MessageStack = '';	
			SET @v_UnitTestCount = @v_UnitTestCount + 1;
			SET @v_UseTran = 
					CASE 
						WHEN @v_IndividualUseTranSettings IS NOT NULL THEN @v_IndividualUseTranSettings
						ELSE @v_UseTransaction
					END;
			BEGIN TRY
				EXEC DBTD_RUNONETEST_EXT
					@v_TestName, @v_HasSetup, @v_HasTeardown, @v_TestOwner, @v_Ignore,
					@v_SetupName, @v_TeardownName, @v_RunSetupOnce, @v_RunTeardownOnce,
					@v_UseTran; --prefer individual UT settings for the transaction handling
			END TRY 
			BEGIN CATCH
				SET @v_Trancount = @@trancount;
				SET @v_XACT_STATE = XACT_STATE();

				IF @v_Trancount > 0 AND @v_UseTran = 1
				BEGIN
					IF @v_Trancount >= 2 
						ROLLBACK TRANSACTION DBTD_RUNONETEST_EXT; --roll back savepoint
					ELSE IF @v_Trancount >= 1
						ROLLBACK;
					ELSE IF @v_XACT_STATE = -1
						ROLLBACK;				
				END

				IF	(CURSOR_STATUS('local', 'unit_test_cursor')) >= 0
					OR (CURSOR_STATUS('global', 'unit_test_cursor')) >= 0
				BEGIN 
					--release resources
					CLOSE unit_test_cursor;
					DEALLOCATE unit_test_cursor;
				END;
				SET @v_ErrorMessage = 'FATAL ERROR: ' +  CAST(ERROR_NUMBER() AS VARCHAR) + ' : ' + ERROR_MESSAGE();
				EXEC DBTD_LOG_MESSAGE_EXT 'ERROR', @v_ProcessName, @v_ErrorMessage;
			END CATCH;							
			--get next test information 
			FETCH NEXT FROM unit_test_cursor 
			INTO @v_TestName, @v_HasSetup, @v_HasTeardown, @v_TestOwner, @v_Ignore, @v_IndividualUseTranSettings; 
		END 
		--release resources
		CLOSE unit_test_cursor;
		DEALLOCATE unit_test_cursor;

		IF (@v_RunTeardownOnce = 1) BEGIN 
			SET @v_Message = 'Running teardown procedure '+@v_TeardownName+' ONCE at the end of the suite ' + @v_SuiteName;
			EXEC DBTD_LOG_MESSAGE_EXT 'INFO', @v_ProcessName, @v_Message;
			BEGIN TRY
				EXECUTE @v_TeardownName;
			END TRY
			BEGIN CATCH
				SET @v_ErrorMessage = ' TEARDOWN ERROR: ' +  CAST(ERROR_NUMBER() AS VARCHAR) + ' : ' + ERROR_MESSAGE();
				EXEC DBTD_LOG_MESSAGE_EXT 'ERROR', @v_TeardownName, @v_ErrorMessage;
				SET @v_TeardownError = ERROR_NUMBER();
			END CATCH;
		END;

		IF (@v_RunGlobalSetupTeardown = 1)
		BEGIN 
			SET @v_Message = 'Running Global Teardown from '+@v_ProcessName+' process'; 
			EXEC DBTD_RUNGLOBALTEARDOWN @v_Message;
		END; 

		SET @v_Message = CAST(@v_UnitTestCount AS VARCHAR(50)) + ' unit tests were executed for suite: ' + @v_SuiteName; 
		EXEC DBTD_LOG_MESSAGE_EXT 'INFO', @v_ProcessName, @v_Message ;

	END TRY
	BEGIN CATCH
		IF	(CURSOR_STATUS('local', 'unit_test_cursor')) >= 0
			OR (CURSOR_STATUS('global', 'unit_test_cursor')) >= 0
		BEGIN 
			--release resources
			CLOSE unit_test_cursor;
			DEALLOCATE unit_test_cursor;
		END;
		SET @v_ErrorMessage = 'FATAL ERROR: ' +  CAST(ERROR_NUMBER() AS VARCHAR) + ' : ' + ERROR_MESSAGE();
		EXEC DBTD_LOG_MESSAGE_EXT 'ERROR', @v_ProcessName, @v_ErrorMessage;
	END CATCH;
END;
GO

--************************************************************************************************
--CORE
--run all tests in the specified test suite. 
--note: if DBTD_TBL_TESTSLIST table is empty stored proc will attempt to refresh the list of all 
--      available tests
--note: oracle version will allow same test suite names used for the different owners, other DB
--      might not support this feature
CREATE PROCEDURE DBTD_RUNTESTSUITE 
(
	@v_SuiteName		VARCHAR(128),		--test suite name
	@v_SuiteOwner		VARCHAR(128),		--suite owner (Reserved)
	@v_ReloadTestsList	BIT					--refresh list of all available unit tests
)
WITH ENCRYPTION AS
BEGIN
	SET NOCOUNT ON;
	DECLARE @v_ThisProcName	NVARCHAR(128) = OBJECT_NAME(@@PROCID)
	DECLARE @v_Message NVARCHAR(MAX) = 'Running ' + @v_ThisProcName;
	EXEC DBTD_LOG_MESSAGE_EXT 'DEBUG', @v_ThisProcName, @v_Message;

	--run extended logic without global setup or teardown
	EXEC DBTD_RUNTESTSUITE_EXT @v_SuiteName, @v_SuiteOwner, @v_ReloadTestsList, 0;
END;
GO

--************************************************************************************************
--CORE
--runs all tests in current database
CREATE PROCEDURE DBTD_RUNTESTS 
(
	@v_UseTransaction BIT = 0
)	
WITH ENCRYPTION AS
BEGIN
	SET NOCOUNT ON;
	DECLARE @v_ThisProcName	NVARCHAR(128) = OBJECT_NAME(@@PROCID),
			@v_Suite	VARCHAR(128) = '%';
	DECLARE @v_Message NVARCHAR(MAX) = 'Running ' + @v_ThisProcName;
	EXEC DBTD_LOG_MESSAGE_EXT 'DEBUG', @v_ThisProcName, @v_Message;

	IF (dbo.DBTD_IS_SERVER_ACCESS_ALLOWED() != 1) 
	BEGIN
		EXEC DBTD_LOG_MESSAGE_EXT 'ACCESS', @v_ThisProcName, 'Access not allowed check DBTD_TBL_SERVER_ACCESS table for more info';
		RETURN;
	END

	DELETE FROM DBTD_TBL_LOG; 
	EXEC DBTD_LOG_MESSAGE_EXT 'INFO', @v_ThisProcName, 'STARTED DBTD_RUNTESTS';

	EXEC DBTD_REFRESH_TESTSLIST; --looking for any new unit test that were added in to database 

	EXEC DBTD_RUNGLOBALSETUP 'RUNNING GLOBAL SETUP from DBTD_RUNTESTS process';

	--iterate through all available UTs for a given test suite
	DECLARE suite_cursor CURSOR FOR 
	SELECT DISTINCT Suite 
	FROM DBTD_TBL_TESTSLIST 
	ORDER BY Suite;

	OPEN suite_cursor

	FETCH NEXT FROM suite_cursor INTO @v_Suite ; 

	WHILE @@FETCH_STATUS = 0
	BEGIN
	   	SET @v_Message = 'RUNNING TESTSUITE - ' + @v_Suite;
		EXEC DBTD_LOG_MESSAGE_EXT 'INFO', @v_ThisProcName,  @v_Message ;

		EXEC DBTD_RUNTESTSUITE_EXT --@v_Suite, NULL, 0, @v_UseTransaction; 	
				@v_SuiteName = @v_Suite,
				@v_SuiteOwner = NULL,
				@v_ReloadTestsList = 0,
				@v_RunGlobalSetupTeardown = 0,
				@v_UseTransaction = @v_UseTransaction;

	   	SET @v_Message = 'FINALIZING TESTSUITE -  ' + @v_Suite;
		EXEC DBTD_LOG_MESSAGE_EXT 'INFO', @v_ThisProcName, @v_Message ;

		FETCH NEXT FROM suite_cursor INTO @v_Suite; 
	END 
	--release resources
	CLOSE suite_cursor;
	DEALLOCATE suite_cursor;

	--run global set up for all the tests
	SET @v_Message = 'RUNNING GLOBAL TEARDOWN from '+@v_ThisProcName+' process'
	EXEC DBTD_RUNGLOBALTEARDOWN @v_Message;
	SET @v_Message = 'FINISH '+ @v_ThisProcName
	EXEC DBTD_LOG_MESSAGE_EXT 'INFO', @v_ThisProcName, @v_Message;
END;
GO

--************************************************************************************************
-- REPORTING
-- Jenkins Compatible XML Report
-- note: to get valid XML use "RptLine" column and make sure that result is sorted in ascending order
--       SELECT RptLine FROM DBTD_VW_RPT_Jenkins ORDER BY SectionOrder ASC, SuiteOrder ASC, TestOrder ASC
--*************** Start report
CREATE VIEW DBTD_VW_RPT_Jenkins
WITH ENCRYPTION AS 
SELECT 
	'ROOT OPEN' AS RowType,
	NULL AS Suite,
	NULL AS UnitTestName,
	-1 AS SectionOrder, 
	-1 AS SuiteOrder,
	-1 AS TestOrder,
	'<testsuites>' AS RptLine
--*************** Add Test Suites
UNION ALL 
SELECT 
	'SUITE OPEN' AS RowType,
	Suite,
	NULL AS UnitTestName,
	ROW_NUMBER() OVER (ORDER BY SUITE ASC) AS SectionOrder,
	1 AS SuiteOrder,
	-1 AS TestOrder,
	'   <testsuite name="'	+ SUITE + '" '
	+ ' tests="' + CAST(COUNT(1) AS VARCHAR(50)) + '" '	--TestCount
	+ ' errors="' + CAST(SUM(CASE WHEN (Status = 'ERROR') AND (IsError = 1) THEN 1 ELSE 0 END) AS VARCHAR(50)) + '" ' --ErrorCount
	+ ' failures="' + CAST(SUM(CASE WHEN (Status IN ('FAILURE', 'STARTED')) AND (IsFailure = 1) THEN 1 ELSE 0 END) AS VARCHAR(50)) + '" ' --FailureCount
	+ ' skipped="' + CAST(SUM(CASE WHEN (Status IN ('IGNORED')) THEN 1 ELSE 0 END) AS VARCHAR(50)) + '" '
	--+ ' timestamp="' + CAST( R.StopTime, VARCHAR(50)) + '" '
	+ ' time="0.005">'  --total time to execute the suite
	AS RptLine
FROM 
	DBTD_TBL_TESTSLIST AS L
	INNER JOIN 
	DBTD_TBL_TESTRESULT AS R
	ON 
		L.TESTNAME = R.TESTNAME 
GROUP BY 
	SUITE  
--*************** Add Unit Tests\Test Cases
UNION ALL 
SELECT 
	'UNITTEST' AS RowType,
	SUITE, 
	R.TESTNAME AS UnitTestName,
	DENSE_RANK() OVER (ORDER BY SUITE ASC) AS SectionOrder,
	10 AS SuiteOrder,
	ROW_NUMBER() OVER (PARTITION BY SUITE ORDER BY SUITE ASC, R.TESTNAME ASC) AS TestOrder,
	'      <testcase name="' + R.TESTNAME + '" classname="' + R.TESTNAME + '" time="0.00005" ' + 
	CASE
		WHEN Status = 'ERROR' THEN '> <error message="' + R.TESTNAME + ' finished with errors">' + Message + '</error> ' 
		WHEN Status = 'FAILURE' THEN '> <failure message="' + R.TESTNAME + ' failed">' + Message + '</failure> ' 
		WHEN Status = 'IGNORED' THEN '> <skipped/> '
		ELSE ' '
	END  +
	CASE
		WHEN Status = 'SUCCESS' THEN '/>'
		ELSE  '</testcase>'
	END  AS RptLine
FROM 
	DBTD_TBL_TESTSLIST AS L
	INNER JOIN 
	DBTD_TBL_TESTRESULT AS R
	ON 
		L.TESTNAME = R.TESTNAME 
--*************** Wrap-Up Suites
UNION ALL 
SELECT 
	DISTINCT 
	'SUITE CLOSE' AS RowType,
	Suite,
	NULL AS UnitTestName,
	ROW_NUMBER() OVER (ORDER BY SUITE ASC) AS SectionOrder,
	100 AS SuiteOrder,
	1000000 AS TestOrder,
	'   </testsuite><!-- ' + SUITE + '-->'  AS RptLine
FROM 
	DBTD_TBL_TESTSLIST AS L
	INNER JOIN 
	DBTD_TBL_TESTRESULT AS R
	ON 
		L.TESTNAME = R.TESTNAME 
GROUP BY 
	SUITE  
--*************** Finish report
UNION ALL 
SELECT 
	'ROOT CLOSE' AS RowType,
	NULL AS Suite,
	NULL AS UnitTestName,
	1000000 AS SectionOrder, 
	1000000 AS SuiteOrder,
	1000000 AS TestOrder,
	'</testsuites>' AS RptLine
;
GO

--************************************************************************************************
-- REPORTING
-- TeamCity Compatible Test Run Report 
-- note: to get valid output use "RptLine" column and make sure that result is sorted in ascending order
--       SELECT RptLine FROM DBTD_VW_RPT_Jenkins ORDER BY SectionOrder ASC, SuiteOrder ASC, TestOrder ASC
--*************** Start report
CREATE VIEW DBTD_VW_RPT_TeamCity
WITH ENCRYPTION AS 
SELECT 
	'SUITE OPEN' AS RowType,
	Suite,
	NULL AS UnitTestName,
	ROW_NUMBER() OVER (ORDER BY SUITE ASC) AS SectionOrder,
	1 AS SuiteOrder,
	'-0000000001' AS TestOrder,
	'##teamcity[testSuiteStarted name=''' + SUITE + '''] ' AS RptLine 
FROM 
	DBTD_TBL_TESTSLIST AS L
	INNER JOIN 
	DBTD_TBL_TESTRESULT AS R
	ON 
		L.TESTNAME = R.TESTNAME 
GROUP BY 
	SUITE  
--*************** Add Unit Tests\Test Cases - START
UNION ALL 
SELECT 
	'UNITTEST_OPEN' AS RowType,
	SUITE, 
	R.TESTNAME AS UnitTestName,
	DENSE_RANK() OVER (ORDER BY SUITE ASC) AS SectionOrder,
	'0000000010' AS SuiteOrder,
	RIGHT('0000000000' + CAST((ROW_NUMBER() OVER (PARTITION BY SUITE ORDER BY SUITE ASC, R.TESTNAME ASC)) AS VARCHAR(10)),10) + '_1' AS TestOrder,
	'##teamcity[testStarted name=''' + R.TESTNAME + ''' captureStandardOutput=''true'']' AS RptLine
FROM 
	(SELECT '?' as uc) AS C,
	DBTD_TBL_TESTSLIST AS L
	INNER JOIN 
	DBTD_TBL_TESTRESULT AS R
	ON 
		L.TESTNAME = R.TESTNAME 
--*************** Add Unit Tests\Test Cases --BODY
UNION ALL 
SELECT 
	'UNITTEST' AS RowType,
	SUITE, 
	R.TESTNAME AS UnitTestName,
	DENSE_RANK() OVER (ORDER BY SUITE ASC) AS SectionOrder,
	10 AS SuiteOrder,
	RIGHT('0000000000' + CAST((ROW_NUMBER() OVER (PARTITION BY SUITE ORDER BY SUITE ASC, R.TESTNAME ASC)) AS VARCHAR(10)), 10) + '_2' AS TestOrder,
	CASE
		WHEN Status IN ('ERROR', 'FAILURE') 
			THEN '##teamcity[testFailed name=''' + R.TESTNAME + ''' message='''
			+ 	REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE( R.[Message], 
				'|', '||'),'''','|'''), '[','|['),']','|]'),'\n','|n'),'\r','|r'),'\u0085','|x'),'\u2028','|l'),'\u2029','|p')
			+ ''' details='''
			+ 	REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE( R.[Message], 
				'|', '||'),'''','|'''), '[','|['),']','|]'),'\n','|n'),'\r','|r'),'\u0085','|x'),'\u2028','|l'),'\u2029','|p')
			+''']' 
		WHEN Status = 'IGNORED' THEN '##teamcity[testIgnored name=''' + R.TESTNAME + ''' message=''Ignored'']'
		ELSE 'PASS' --todo: add extra report info for successful tests 
	END	AS RptLine
FROM 
	(SELECT '?' as uc) AS C,
	DBTD_TBL_TESTSLIST AS L
	INNER JOIN 
	DBTD_TBL_TESTRESULT AS R
	ON 
		L.TESTNAME = R.TESTNAME 
--*************** Add Unit Tests\Test Cases - FINISH
UNION ALL 
SELECT 
	'UNITTEST_CLOSE' AS RowType,
	SUITE, 
	R.TESTNAME AS UnitTestName,
	DENSE_RANK() OVER (ORDER BY SUITE ASC) AS SectionOrder,
	10 AS SuiteOrder,
	RIGHT('0000000000' + CAST((ROW_NUMBER() OVER (PARTITION BY SUITE ORDER BY SUITE ASC, R.TESTNAME ASC)) AS VARCHAR(10)), 10) + '_3' AS TestOrder,
	'##teamcity[testFinished name=''' + R.TESTNAME + ''']' AS RptLine
FROM 
	(SELECT '?' as uc) AS C,
	DBTD_TBL_TESTSLIST AS L
	INNER JOIN 
	DBTD_TBL_TESTRESULT AS R
	ON 
		L.TESTNAME = R.TESTNAME 
--*************** Wrap-Up Suites
UNION ALL 
SELECT 
	DISTINCT 
	'SUITE CLOSE' AS RowType,
	Suite,
	NULL AS UnitTestName,
	ROW_NUMBER() OVER (ORDER BY SUITE ASC) AS SectionOrder,
	100 AS SuiteOrder,
	'0001000000' AS TestOrder,
	'##teamcity[testSuiteFinished name=''' + SUITE + ''']'  AS RptLine
FROM 
	DBTD_TBL_TESTSLIST AS L
	INNER JOIN 
	DBTD_TBL_TESTRESULT AS R
	ON 
		L.TESTNAME = R.TESTNAME 
GROUP BY 
	SUITE  
;
GO

--************************************************************************************************
--REPORTING 
--splits delimited list in to the DBTD_TBL_RPTPARAM for given v_UniqueRptRunID
CREATE PROCEDURE DBTD_ParseRptParam
(
	@v_ListOfSuits		NVARCHAR(MAX),
	@v_Delim			CHAR,
	@v_UniqueRptRunID	DATETIME		--unique ID that identifies set of parameters
)
WITH ENCRYPTION AS
BEGIN
	SET NOCOUNT ON;
	DECLARE @v_ThisProcName	NVARCHAR(128) = OBJECT_NAME(@@PROCID)
	DECLARE @v_Message NVARCHAR(MAX) = 'Running ' + @v_ThisProcName;
	EXEC DBTD_LOG_MESSAGE_EXT 'DEBUG', @v_ThisProcName, @v_Message;

	DECLARE @v_Item	VARCHAR(MAX), 
			@v_List	VARCHAR(MAX),
			@v_Pos	INT;
	
	SET @v_List = LTRIM(RTRIM(@v_ListOfSuits))+ @v_Delim;
	SET @v_Pos = CHARINDEX(@v_Delim, @v_List, 1);
	
	WHILE @v_Pos > 0
	BEGIN
		SET @v_Item = LTRIM(RTRIM(LEFT(@v_List, @v_Pos - 1)));
		IF (@v_Item <> '')
		BEGIN
			INSERT INTO DBTD_TBL_RPTPARAM (Value, ReportID)
			VALUES (CAST(@v_Item AS VARCHAR(128)), @v_UniqueRptRunID);
		END
		SET @v_List = RIGHT(@v_List, LEN(@v_List) - @v_Pos);
		SET @v_Pos = CHARINDEX(@v_Delim, @v_List, 1);
	END;
END;
GO

--************************************************************************************************
--REPORTING
--run all tests in the specified test suite. 
--note: oracle version will allow same test suite names used for the different owners, other DB
--      might not support this feature
CREATE PROCEDURE DBTD_REPORT 
(
	@v_ListOfSuits	VARCHAR(MAX),		--coma separated list of Test Suites to include into the report, NULL or empty string will include all unit test suites in the report  
	@v_SuiteOwner	VARCHAR(128),		--suite owner (Reserved)
	@v_Format		VARCHAR(128)		--report format: JENKINS, TEAMCITY, ...
)
WITH ENCRYPTION AS
BEGIN
	SET NOCOUNT ON;
	DECLARE @v_UniqueRptRunID DATETIME,
			@v_GetFullReport int = 0;
	DECLARE @v_ThisProcName	NVARCHAR(128) = OBJECT_NAME(@@PROCID)
	DECLARE @v_Message NVARCHAR(MAX) = 'Running ' + @v_ThisProcName;
	EXEC DBTD_LOG_MESSAGE_EXT 'DEBUG', @v_ThisProcName, @v_Message;

	--check if we need to return complete report
	SET @v_UniqueRptRunID  = GETDATE();

	IF (@v_ListOfSuits IS NULL or @v_ListOfSuits = '') BEGIN
		SET @v_GetFullReport = 1;
	END
	ELSE BEGIN 
		--save list of suites in to the table 
		SET @v_GetFullReport = 0;
		EXEC DBTD_ParseRptParam @v_ListOfSuits, ',', @v_UniqueRptRunID;
	END; 

	--get the report 
	IF (@v_Format = 'JENKINS') BEGIN
		SELECT		RptLine, SectionOrder, SuiteOrder, TestOrder 
		FROM		DBTD_VW_RPT_Jenkins 
		WHERE 		
			@v_GetFullReport = 1	--get all unit tests
			OR
			(
			@v_GetFullReport = 0	--get list of specified tests
			AND (
				Suite IS NULL --used to pick up ROOT XML tag 
				OR Suite IN (SELECT value FROM DBTD_TBL_RPTPARAM WHERE ReportID = @v_UniqueRptRunID)
				)
			)
		ORDER BY	SectionOrder ASC, SuiteOrder ASC, TestOrder ASC;
	END
	ELSE IF (@v_Format = 'TEAMCITY') BEGIN
		SELECT 		RptLine, SectionOrder, SuiteOrder, TestOrder 
		FROM 		DBTD_VW_RPT_TeamCity 
		WHERE		
			@v_GetFullReport = 1	--get all unit tests
			OR
			(
			@v_GetFullReport = 0	--get list of specified tests
			AND Suite IN (SELECT value FROM DBTD_TBL_RPTPARAM WHERE ReportID = @v_UniqueRptRunID)
			)
		ORDER BY 	SectionOrder ASC, SuiteOrder ASC, TestOrder ASC;
	END;
END;
GO

--************************************************************************************************
--INTERNAL STATISTICS: Do not use this procedure in your unit tests, procedure can be removed,
--          signature or procedure name can be changed at any release
--DROP PROCEDURE DBTD_GET_CoverageDetails
CREATE PROCEDURE DBTD_GET_CoverageDetails
	@v_DatabaseName			 SYSNAME	--Database name 
WITH ENCRYPTION AS
BEGIN
	SET NOCOUNT ON; 
	INSERT INTO #CoverageDetails 
		(ObjectId,ObjectName,ObjectDatabaseName,ObjectSchemaName,ObjectFullName,ObjectType,UnitTestName,UnitTestRunID,CallingProcName,IsMSShipped,Comments)
		SELECT 
			DISTINCT 
			d.ObjectId,
			d.ObjectName,			
			d.ObjectDatabaseName,	
			d.ObjectSchemaName,	
			d.ObjectFullName,		
			d.ObjectType,			
			d.UnitTestName,		
			d.UnitTestRunID,		
			d.CallingProcName,		
			d.IsMSShipped,
			d.Comments
		FROM dbo.DBTD_TBL_TESTRESULT_DETAILS d
			LEFT OUTER JOIN #CoverageExceptions e
				ON e.ObjectName = d.ObjectName
				AND e.ObjectDatabaseName = d.ObjectDatabaseName
				AND e.ObjectSchemaName = d.ObjectSchemaName
				AND (e.ObjectType IS NULL OR e.ObjectType = d.ObjectType)
		WHERE d.ObjectDatabaseName = @v_DatabaseName
			AND e.ObjectName IS NULL
END
GO

--************************************************************************************************
--INTERNAL STATISTICS: Do not use this procedure in your unit tests, procedure can be removed,
--          signature or procedure name can be changed at any release
--DROP PROCEDURE DBTD_GET_AssertedObjects
CREATE PROCEDURE DBTD_GET_AssertedObjects
	@v_DatabaseName	SYSNAME	--Database name 
WITH ENCRYPTION AS
BEGIN
	SET NOCOUNT ON; 
	--Get list of all #AssertedObjects excluding Object that created by an internal SQL Server components
	INSERT INTO #AssertedObjects 
		(ObjectId,ObjectName,ObjectDatabaseName,ObjectSchemaName,ObjectFullName, ObjectType)
		SELECT 
			DISTINCT 
			d.ObjectId, 
			d.ObjectName, 
			d.ObjectDatabaseName, 
			d.ObjectSchemaName, 
			d.ObjectFullName,
			d.ObjectType
		FROM #CoverageDetails AS d
		WHERE d.ObjectDatabaseName = @v_DatabaseName
			AND ISNULL(d.IsMSShipped,0) = 0
END
GO

--************************************************************************************************
--INTERNAL STATISTICS: Do not use this procedure in your unit tests, procedure can be removed,
--          signature or procedure name can be changed at any release
--DROP PROCEDURE DBTD_GET_ExistingDatabaseObjects
CREATE PROCEDURE DBTD_GET_ExistingDatabaseObjects
	@v_DatabaseName	SYSNAME	--Database name 
WITH ENCRYPTION AS
BEGIN
	SET NOCOUNT ON; 
	DECLARE @v_SQL NVARCHAR(MAX) = ''

	SET @v_SQL = 
		'INSERT INTO #DatabaseObjects
		(ObjectID, ObjectName, ObjectSchemaName, ObjectDatabaseName, ObjectType)
		SELECT 
			DISTINCT 
			so.object_id AS ObjectID,
			so.name AS ObjectName, 
			s.name AS ObjectSchemaName, '
			+ '''' + @v_DatabaseName + ''' AS ObjectDatabaseName,
			so.type_desc AS ObjectType 
		FROM ' + @v_DatabaseName + '.sys.objects AS so	
			INNER JOIN ' + @v_DatabaseName + '.sys.schemas AS s
				ON so.schema_id = s.schema_id
		WHERE so.[is_ms_shipped] = 0' 

	EXEC DBO.DBTD_SP_EXECUTESQL @v_TargetDatabase = @v_DatabaseName, @v_SQLCode = @v_SQL
END
GO

--************************************************************************************************
--INTERNAL STATISTICS: Do not use this procedure in your unit tests, procedure can be removed,
--          signature or procedure name can be changed at any release
--DROP PROCEDURE DBTD_GET_UntestedObjects
CREATE PROCEDURE DBTD_GET_UntestedObjects
	@v_DatabaseName	SYSNAME	--Database name 
WITH ENCRYPTION AS
BEGIN
	SET NOCOUNT ON; 
	DECLARE @v_SQL NVARCHAR(MAX) = ''
	
	INSERT INTO #UntestedObjects
		(ObjectName, ObjectSchemaName, ObjectDatabaseName, ObjectType)
		SELECT 
			DISTINCT
			o.ObjectName, 
			o.ObjectSchemaName, 
			o.ObjectDatabaseName, 
			o.ObjectType
		FROM #DatabaseObjects AS o
			LEFT OUTER JOIN #AssertedObjects AS t
				ON o.ObjectName = t.ObjectName	
				AND o.ObjectSchemaName = t.ObjectSchemaName
				AND o.ObjectDatabaseName = t.ObjectDatabaseName
				AND o.ObjectType = t.ObjectType
				--AND o.ObjectId = t.ObjectId --NOTE: we dont need ID because it migh be different in cases we external statistic database is used
			LEFT OUTER JOIN #CoverageExceptions e
				ON e.ObjectName = o.ObjectName
				AND e.ObjectDatabaseName = o.ObjectDatabaseName
				AND e.ObjectSchemaName = o.ObjectSchemaName
				AND (e.ObjectType IS NULL OR e.ObjectType = o.ObjectType)
		WHERE o.ObjectDatabaseName = @v_DatabaseName
			AND t.ObjectName IS NULL
			AND e.ObjectName IS NULL --exclude known coverage exceptions
END
GO

--************************************************************************************************
--INTERNAL STATISTICS: Do not use this procedure in your unit tests, procedure can be removed,
--          signature or procedure name can be changed at any release
--DROP PROCEDURE DBTD_GET_CoverageExceptions
CREATE PROCEDURE DBTD_GET_CoverageExceptions
	@v_DatabaseName	SYSNAME	--Database name 
WITH ENCRYPTION AS
BEGIN
	SET NOCOUNT ON; 
	DECLARE @v_FrameworkDatabaseName	NVARCHAR(128) = DB_NAME()
	INSERT INTO #CoverageExceptions
		(ObjectName,ObjectDatabaseName,ObjectSchemaName,ObjectType,ExceptionDescription) 
		SELECT TestName, @v_FrameworkDatabaseName, 'dbo', 'SQL_STORED_PROCEDURE', 'Unit Test' FROM DBTD_TBL_TESTSLIST
		UNION SELECT SuiteSetupName, @v_FrameworkDatabaseName, 'dbo', 'SQL_STORED_PROCEDURE', 'Suite Setup Procedute' FROM DBTD_TBL_TESTSLIST WHERE SuiteSetupName IS NOT NULL
		UNION SELECT SuiteTeardownName, @v_FrameworkDatabaseName, 'dbo', 'SQL_STORED_PROCEDURE', 'Suite Teardown Procedute' FROM DBTD_TBL_TESTSLIST WHERE SuiteTeardownName IS NOT NULL
		UNION SELECT 'UT_SETUP', @v_FrameworkDatabaseName, 'dbo', 'SQL_STORED_PROCEDURE', 'Global Setup Procedure'
		UNION SELECT 'UT_TEARDOWN', @v_FrameworkDatabaseName, 'dbo', 'SQL_STORED_PROCEDURE', 'Global Teardown Procedure'
		UNION SELECT DISTINCT ObjectName,ObjectDatabaseName,ObjectSchemaName,ObjectType,ExceptionDescription FROM DBTD_TBL_CODE_COVERAGE_EXCEPTIONS
END
GO

--************************************************************************************************
--STATISTICS 
--    - if temp tables does not exist this procedure will create them and populate with data
--      if objects exist them data will be cleared before report run 
--TODO: this procedure might change its name, how about DBTD_Load_Statistics
--TODO: make sure it can run same report agains DBTestDrivenStatistics database
--DROP PROCEDURE DBTD_Statistics 
CREATE PROCEDURE DBTD_Statistics
	@v_DatabaseName	SYSNAME,					--Database name 
	@v_DisplayLevel	VARCHAR(100) = 'RunSilent'	--RunSilent - doe not output any results, just populate temp tables
WITH ENCRYPTION AS
BEGIN
	SET NOCOUNT ON;
	DECLARE @v_ThisProcName				NVARCHAR(128) = OBJECT_NAME(@@PROCID)
	DECLARE @v_FrameworkDatabaseName	NVARCHAR(128) = DB_NAME(),
			@v_SQL						NVARCHAR(MAX) = '',
			@v_Message					NVARCHAR(MAX) = 'Running ' + @v_ThisProcName,
			@v_NumberOfDatabaseObjects	INT,
			@v_NumberOfUntestedObjects	INT,
			@v_CoveragePercent			NUMERIC(20,10)

	EXEC DBTD_LOG_MESSAGE_EXT 'DEBUG', @v_ThisProcName, @v_Message;

	IF OBJECT_ID('TEMPDB.dbo.#Statistics') IS NULL 
	BEGIN
		CREATE TABLE #Statistics(
			StatName	VARCHAR(500),	--Something like: "Number of objects excluded from coverage analysis"
			StatValue 	VARCHAR(500),	--Value can be: 37
			StatMetrics	VARCHAR(100),	--Value Can be: empty, %, etc. that defines what metrics is used for a value
			SortOrder	INT
		)
	END
	ELSE DELETE FROM #Statistics;
	
	IF OBJECT_ID('TEMPDB.dbo.#StatisticsByObjectType') IS NULL 
	BEGIN
		CREATE TABLE #StatisticsByObjectType(
			ObjectType					VARCHAR(250),
			NumberOfObjects				INT,
			NumberOfCoveredObjects		INT,
			NumberOfNotTestedObjects	INT,
			NumberOfExceptions			INT,
			CoveragePercent				NUMERIC(10,4)
		)
	END
	ELSE DELETE FROM #StatisticsByObjectType;

	IF OBJECT_ID('TEMPDB.dbo.#CoverageExceptions') IS NULL 
	BEGIN
		CREATE TABLE #CoverageExceptions(
			ObjectName			SYSNAME, 
			ObjectDatabaseName	SYSNAME, 
			ObjectSchemaName	SYSNAME, 
			ObjectType			VARCHAR(250),
			ExceptionDescription VARCHAR(250)
		)
	END
	ELSE DELETE FROM #CoverageExceptions;

	IF OBJECT_ID('TEMPDB.dbo.#CoverageDetails') IS NULL 
	BEGIN
		CREATE TABLE #CoverageDetails(
			ObjectId					BIGINT,
			ObjectName					SYSNAME,
			ObjectDatabaseName			NVARCHAR(128),
			ObjectSchemaName			NVARCHAR(128),
			ObjectFullName				NVARCHAR(128),
			ObjectType					VARCHAR(250),
			UnitTestName				NVARCHAR(128),
			UnitTestRunID				BIGINT,
			CallingProcName				NVARCHAR(128),		--OBJECT_NAME(@@PROCID) 
			IsMSShipped					BIT,				--RESERVED: 
			Comments					NVARCHAR(500)
		)
	END
	ELSE DELETE FROM #CoverageDetails;

	IF OBJECT_ID('TEMPDB.dbo.#AssertedObjects') IS NULL 
	BEGIN
		CREATE TABLE #AssertedObjects(
			ObjectId			BIGINT,
			ObjectName			SYSNAME,
			ObjectDatabaseName	NVARCHAR(128),
			ObjectSchemaName	NVARCHAR(128),
			ObjectFullName		NVARCHAR(128),
			ObjectType			VARCHAR(250)
		)
	END
	ELSE DELETE FROM #AssertedObjects;

	IF OBJECT_ID('TEMPDB.dbo.#DatabaseObjects') IS NULL 
	BEGIN
		CREATE TABLE #DatabaseObjects(
			ObjectID			INT,
			ObjectName			SYSNAME,
			ObjectSchemaName	NVARCHAR(128),
			ObjectDatabaseName	SYSNAME,
			ObjectType			VARCHAR(100)
		)
	END
	ELSE DELETE FROM #DatabaseObjects;

	IF OBJECT_ID('TEMPDB.dbo.#UntestedObjects') IS NULL 
	BEGIN
		CREATE TABLE #UntestedObjects(
			ObjectID			INT,
			ObjectName			SYSNAME,
			ObjectSchemaName	NVARCHAR(128),
			ObjectDatabaseName	SYSNAME,
			ObjectType			VARCHAR(100)
		)
	END
	ELSE DELETE FROM #UntestedObjects;

	--Populate exclusions data
	EXEC DBTD_GET_CoverageExceptions @v_DatabaseName

	--Get list of all #CoverageDetails excluding Object that created by an internal SQL Server components
	EXEC DBTD_GET_CoverageDetails @v_DatabaseName

	--Get list of all #AssertedObjects excluding Object that created by an internal SQL Server components
	EXEC DBTD_GET_AssertedObjects @v_DatabaseName

	--Get list of all #DatabaseObjects excluding Object that created by an internal SQL Server components
	EXEC DBTD_GET_ExistingDatabaseObjects @v_DatabaseName

	--Populate list of untested objects
	EXEC DBTD_GET_UntestedObjects @v_DatabaseName

	;WITH 
		CTE_AssertedObjects AS (
				SELECT DISTINCT cd.ObjectName, cd.ObjectSchemaName, cd.ObjectDatabaseName, cd.ObjectType 
				FROM #AssertedObjects cd
		),
		CTE_ALL_Details AS (
			SELECT 
				o.ObjectID,
				COALESCE(o.ObjectName			, cd.ObjectName			) AS ObjectName,
				COALESCE(o.ObjectSchemaName		, cd.ObjectSchemaName 	) AS ObjectSchemaName, 		
				COALESCE(o.ObjectDatabaseName	, cd.ObjectDatabaseName	) AS ObjectDatabaseName,
				COALESCE(o.ObjectType			, cd.ObjectType			) AS ObjectType,
				CASE WHEN cd.ObjectName IS NOT NULL THEN 1 ELSE 0 END AS IsCovered,
				CASE WHEN u.ObjectName IS NOT NULL THEN 1 ELSE 0 END AS IsNotTested,
				CASE WHEN e.ObjectName IS NOT NULL THEN 1 ELSE 0 END AS IsCoverageException
			FROM #DatabaseObjects AS o
				LEFT OUTER JOIN CTE_AssertedObjects AS cd
					ON o.ObjectName = cd.ObjectName
					AND o.ObjectSchemaName = cd.ObjectSchemaName
					AND o.ObjectDatabaseName = cd.ObjectDatabaseName
					AND (cd.ObjectType IS NULL OR o.ObjectType = cd.ObjectType)
				LEFT OUTER JOIN #UntestedObjects AS u
					ON o.ObjectName = u.ObjectName
					AND o.ObjectSchemaName = u.ObjectSchemaName
					AND o.ObjectDatabaseName = u.ObjectDatabaseName
					AND (cd.ObjectType IS NULL OR o.ObjectType = u.ObjectType)
				LEFT OUTER JOIN #CoverageExceptions AS e
					ON o.ObjectName = e.ObjectName
					AND o.ObjectDatabaseName = e.ObjectDatabaseName
					AND o.ObjectSchemaName = e.ObjectSchemaName
					AND (e.ObjectType IS NULL OR o.ObjectType = e.ObjectType)
		),
		CTE_ALL_Stats AS (
			SELECT 
				ObjectType,
				COUNT(1) AS NumberOfObjects, 
				CAST(SUM(IsCovered) AS NUMERIC(10,4)) AS NumberOfCoveredObjects,
				CAST(SUM(IsNotTested) AS NUMERIC(10,4))  AS NumberOfNotTestedObjects,
				CAST(SUM(IsCoverageException) AS NUMERIC(10,4))  AS NumberOfExceptions
			FROM CTE_ALL_Details
			GROUP BY ObjectType
		)
	INSERT INTO #StatisticsByObjectType
		(ObjectType,NumberOfObjects,NumberOfCoveredObjects,NumberOfNotTestedObjects,NumberOfExceptions,CoveragePercent)
		SELECT 
			ObjectType,
			NumberOfObjects,
			NumberOfCoveredObjects,
			NumberOfNotTestedObjects,
			NumberOfExceptions, 
			CAST((1-NumberOfNotTestedObjects/(NumberOfObjects - NumberOfExceptions)) AS NUMERIC(10,4)) * 100 AS CoveragePercent
		FROM CTE_ALL_Stats

	SET @v_NumberOfDatabaseObjects = (SELECT COUNT(1) FROM #DatabaseObjects)
	SET @v_NumberOfUntestedObjects = (SELECT COUNT(1) FROM #UntestedObjects)

	;WITH
		CTE_Totals AS (
			SELECT 
				CAST(SUM(NumberOfObjects) AS NUMERIC(10,4)) AS NumberOfObjects, 
				CAST(SUM(NumberOfCoveredObjects) AS NUMERIC(10,4)) AS NumberOfCoveredObjects,
				CAST(SUM(NumberOfNotTestedObjects) AS NUMERIC(10,4))  AS NumberOfNotTestedObjects,
				CAST(SUM(NumberOfExceptions) AS NUMERIC(10,4))  AS NumberOfExceptions
			FROM #StatisticsByObjectType
		)
	SELECT 
		@v_CoveragePercent = CAST((1-NumberOfNotTestedObjects/(NumberOfObjects - NumberOfExceptions)) AS NUMERIC(10,4)) * 100
	FROM CTE_Totals

	INSERT INTO #Statistics
		(StatName,StatValue,StatMetrics, SortOrder)
		SELECT 'Database Name', @v_DatabaseName, '', 10 UNION ALL
		SELECT 'Code Coverage', CAST(@v_CoveragePercent AS VARCHAR(50)), '%', 15 UNION ALL
		SELECT 'Number of Database objects', CAST(@v_NumberOfDatabaseObjects AS VARCHAR(50)), '', 20 UNION ALL
		SELECT 'Number of objects Excluded from coverage analysis', CAST(COUNT(1) AS VARCHAR(50)), '', 30 FROM #CoverageExceptions UNION ALL
		SELECT 'Number of Tested objects', CAST(COUNT(1) AS VARCHAR(50)), '', 35 FROM #AssertedObjects UNION ALL
		SELECT 'Number of Un-tested objects', CAST(@v_NumberOfUntestedObjects AS VARCHAR(50)), '', 40

	IF @v_DisplayLevel != 'RunSilent'
	BEGIN
		SELECT '#Statistics',				* FROM 	#Statistics
		SELECT '#StatisticsByObjectType',	* FROM 	#StatisticsByObjectType
		SELECT '#AssertedObjects',			* FROM 	#AssertedObjects ORDER BY ObjectType, ObjectName
		SELECT '#DatabaseObjects',			* FROM 	#DatabaseObjects ORDER BY ObjectType, ObjectName
		SELECT '#UntestedObjects',			* FROM 	#UntestedObjects ORDER BY ObjectType, ObjectName
		SELECT '#CoverageExceptions',		* FROM 	#CoverageExceptions  ORDER BY ObjectType, ObjectName
		SELECT '#CoverageDetails',			* FROM 	#CoverageDetails  ORDER BY ObjectType, ObjectName
	END
	
	--(A1) Statistics per object type
	--   Object type (by object type) 
	--   Number of objects (by object type) 
	--   Coverage percentage (by object type)  
	--(B) Tested objects
	--(C) Asserted objects excluding system objects and code coverage exceptions
	--(D) Coverage details (database, object, unit test)
END;
GO


