/*
************************************************************************************************
-- VERSION:	   DBTestDriven - Oracle - 3.3.1.24
-- COPYRIGHT:  (c) 2011-2012 Job Continent, DBTestDriven Project by Alex Podlesny
-- http://www.dbtestdriven.com
*************************************************************************************************
*/

--************************************************************************************************
--CORE TABLE
--note: not all test runners will use this table 
--this table is the communication media for actively running test, all data in this table is temporary  
--this table will be cleaned before each test run when DBTD_RUNTESTSUITE procedure iterates through the 
--available tests in the test suite. external test runners might not use this stored procedure
CREATE TABLE DBTD_TBL_ACTIVETEST (
	Owner		VARCHAR2(128),
	TestName	VARCHAR2 (255) NULL ,
	IsError		CHAR(1) DEFAULT 'N' CHECK (IsError IN ( 'Y', 'N' )) NOT NULL,		--indicates that active test had an error
	IsFailure	CHAR(1) DEFAULT 'N' CHECK (IsFailure IN ( 'Y', 'N' )) NOT NULL ,	--indicates that active test failed or not
	Message		NVARCHAR2 (2000) NOT NULL											--latest message
); 

--************************************************************************************************
--CORE TABLE 
--stores the current list of all tests.
--table is used by test runner(s)  
--to update the list run DBTD_REFRESH_TESTSLIST stored procedure
CREATE TABLE DBTD_TBL_TESTSLIST (
	Owner					VARCHAR2(128),
	TestName				VARCHAR2(128),
	Suite					VARCHAR2(128),
	HasSetup				CHAR(1) DEFAULT 'N' CHECK (HasSetup IN ( 'Y', 'N' )),
	HasTeardown				CHAR(1) DEFAULT 'N' CHECK (HasTeardown IN ( 'Y', 'N' )),
	Ignore					CHAR(1) DEFAULT 'N' CHECK (Ignore IN ( 'Y', 'N' )),
	SuiteSetupName			VARCHAR2(128),			
	SuiteTeardownName		VARCHAR2(128),			
	SuiteSetupRunOnce		CHAR(1) DEFAULT 'N' CHECK (SuiteSetupRunOnce IN ( 'Y', 'N' )),			
	SuiteTeardownRunOnce	CHAR(1) DEFAULT 'N' CHECK (SuiteTeardownRunOnce IN ( 'Y', 'N' ))
	-- reserved columns
	--ObjectID			INT
);

--************************************************************************************************
--CORE TABLE
--stores latest test results information for a given test
--while DBTD_TBL_TESTSLIST has most unit tests list this table might have old unit test information
--NOTE: it pay attention to the test start and stop time, this table might include 
--      information about older test that failed long time ago.
CREATE TABLE DBTD_TBL_TESTRESULT (
	TestName	VARCHAR2(128) NOT NULL,				--unit test (or test suite) name
	Owner		VARCHAR2(128),
	RunCount	NUMBER,								--number if times test have run 
	StartTime	TIMESTAMP NOT NULL ,				--last start time
	StopTime	TIMESTAMP NULL ,					--last finish time
	IsError		CHAR(1) DEFAULT 'N' CHECK (IsError IN ( 'Y', 'N' )) NOT NULL,		--'Y' if has errors
	IsFailure	CHAR(1) DEFAULT 'N' CHECK (IsFailure IN ( 'Y', 'N' )) NOT NULL,		--'Y' if failed 
	Status		VARCHAR2(50) NULL,					--SUCCESS, FAILURE, ERROR, etc.
	Message		NVARCHAR2(2000) NULL				--error, warning, failure or other message
);

--************************************************************************************************
-- CORE TABLE
--active log table for the framework
CREATE TABLE DBTD_TBL_LOG (
	LogID		NUMBER NOT NULL ,
	EventType	VARCHAR2(10) NULL,		--INFO, ERROR, WARNING, DEBUG etc.
	EventSource VARCHAR2(128) NULL,
	EventTime	TIMESTAMP  NULL,
	Message		NVARCHAR2 (2000) NULL
);

--************************************************************************************************
--CORE VIEW
--note: read-only view that adds artificial unique ID used by the test runner 
CREATE OR REPLACE VIEW DBTD_TBL_COLUMNS
AS
SELECT 
  ROWNUM AS ColID,
  Table_Name AS TableName, 
  Owner AS TableOwner, 
  Column_ID AS ColumnOrder, 
  Column_Name AS ColumnName, 
  Data_Type AS DataType
FROM ALL_TAB_COLUMNS; 

--************************************************************************************************
--note: not all databases utilize sequence, this object is DB specific 
--general DB Test Driven sequence that generated unique IDs for the framework
CREATE SEQUENCE DBTD_SEQUENCE
    MINVALUE 1
    START WITH 1
    INCREMENT BY 1
    CACHE 20; 

--************************************************************************************************
-- CORE
-- saves the message with specified type and source in the log
-- used by native and external test runners 
CREATE OR REPLACE PROCEDURE DBTD_LOG_MESSAGE_EXT 
(
	v_Type		VARCHAR2,
	v_Source	VARCHAR2,		--message source
	v_Message	NVARCHAR2
)
AS
	PRAGMA AUTONOMOUS_TRANSACTION;
BEGIN
	BEGIN
		INSERT INTO DBTD_TBL_LOG(LogID, EventType, EventTime, EventSource, Message) 
		VALUES( DBTD_SEQUENCE.nextval, v_Type, SYSDATE, v_Source, SUBSTR(v_Message,0,2000));
		COMMIT; --we want to preserve the message 
	EXCEPTION
	WHEN OTHERS THEN
		COMMIT; --we want to preserve the message 
	END;
END;
/
ALTER PROCEDURE DBTD_LOG_MESSAGE_EXT COMPILE; 
/

--************************************************************************************************
-- CORE
-- Saves message with provided type into the log table.
-- used by native and external test runners 
CREATE OR REPLACE PROCEDURE DBTD_LOG_MESSAGE 
(
	v_Type		VARCHAR2,	-- 	Message Type INFO, DEBUG, WARNING, ERROR, etc.
	v_Message	NVARCHAR2	-- 	Message to log
)
AS
BEGIN
	DBTD_LOG_MESSAGE_EXT(v_Type, NULL, v_Message);
END;
/
ALTER PROCEDURE DBTD_LOG_MESSAGE COMPILE; 
/

--************************************************************************************************
--internal CORE procedure that saves state for Unit Test that is running or have run in the past 
--note: when NULL value is supplied then this column does not get updated in the table   
CREATE OR REPLACE PROCEDURE DBTD_SAVESTATE
(
	v_TestName	VARCHAR2,	--Unit Test
	v_TestOwner	VARCHAR2,	--Test Owner
	v_Status	VARCHAR2,	--Status,  note: when NULL value is supplied then this column does not get updated in the table  
	v_IsError	CHAR,		--Error,   note: when NULL value is supplied then this column does not get updated in the table   
	v_IsFailure	CHAR,		--Failure, note: when NULL value is supplied then this column does not get updated in the table  
	v_Message	VARCHAR2	--Message
)
AS
	PRAGMA AUTONOMOUS_TRANSACTION;
BEGIN 
	DBTD_LOG_MESSAGE_EXT ( 'DEBUG', 'DBTD_SaveState', v_TestName );

	UPDATE	DBTD_TBL_TESTRESULT
	SET		
		StopTime = SYSDATE,
		IsError = 
				CASE 
					WHEN v_IsError IS NULL THEN IsError --do not change state if null value provided
					ELSE v_IsError --set new state if it is not a null
				END,
		IsFailure = 
				CASE
					WHEN v_IsFailure IS NULL THEN IsFailure --do not change state if null value provided
					ELSE v_IsFailure --set new state if it is not a null
				END,
		Status =
				CASE
					WHEN v_Status IS NULL THEN Status --do not change state if null value provided
					ELSE v_Status --set new state if it is not a null
				END,
		Message = v_Message
	WHERE 
		UPPER(TestName) = UPPER(v_TestName)
		AND UPPER(Owner) = UPPER(v_TestOwner); 
	COMMIT;

	UPDATE DBTD_TBL_ACTIVETEST
	SET 
		IsError = 
				CASE 
					WHEN v_IsError IS NULL THEN IsError --do not change state if null provided
					ELSE v_IsError --set new state if it is not a null
				END,
		IsFailure = 
				CASE
					WHEN v_IsFailure IS NULL THEN IsFailure --do not change state if null provided
					ELSE v_IsFailure --set new state if it is not a null
				END,
		Message = v_Message
	WHERE 
		UPPER(TestName) = UPPER(v_TestName)
		AND UPPER(Owner) = UPPER(v_TestOwner); 
	COMMIT; 
END;
/
ALTER PROCEDURE DBTD_SaveState COMPILE; 
/

--************************************************************************************************
-- CORE
--refreshes DBTD_TBL_TESTSLIST
--this is one of the core stored procedures that refreshes the list of all available unit tests
--in the database   
CREATE OR REPLACE PROCEDURE DBTD_REFRESH_TESTSLIST
AS
    v_GlobalSetup VARCHAR2(128);
  	v_ErrorMessage VARCHAR2(255);
BEGIN
	DBTD_LOG_MESSAGE_EXT ( 'DEBUG', 'DBTD_REFRESH_TESTSLIST', 'DBTD_REFRESH_TESTSLIST()');
	DELETE FROM DBTD_TBL_TESTSLIST;
  
	INSERT INTO  DBTD_TBL_TESTSLIST ( Owner, TestName, Suite, HasSetup, HasTeardown, Ignore, SuiteSetupName, SuiteTeardownName  )
	SELECT 
		TTT.Owner,
		TTT.FULL_NAME, 
		TTT.SUITE_NAME, 
		NVL(S.HAS_SETUP,'N'), 
		NVL(TR.HAS_TEARDOWN,'N'), 
		NVL(I.IGNORED_TEST,'N'),
		TTT.SUITE_SETUP_NAME, 
		TTT.SUITE_TEARDOWN_NAME 
	FROM
		(
		SELECT OBJECT_ID, Owner, FULL_NAME, SUITE_NAME, 'UT_' || SUITE_NAME || '_SETUP' AS SUITE_SETUP_NAME, 'UT_' || SUITE_NAME || '_TEARDOWN' AS SUITE_TEARDOWN_NAME	
		FROM
			(
			SELECT 
				OBJECT_ID, Owner, FULL_NAME, 
				CASE 
					WHEN (instr(NO_PREFIX, '_') != 0) THEN SUBSTR(NO_PREFIX, 1, instr(NO_PREFIX, '_') - 1) 
					WHEN (instr(NO_PREFIX, '_') != 0) THEN SUBSTR(NO_PREFIX, 1, instr(NO_PREFIX, '_') - 1) 
					ELSE NO_PREFIX 
				END AS SUITE_NAME
			FROM
				(
				SELECT OBJECT_ID, Owner, OBJECT_NAME AS FULL_NAME, SUBSTR(OBJECT_NAME, 4) AS NO_PREFIX	
				FROM all_procedures 
				WHERE UPPER(OBJECT_NAME) like 'UT\_%' ESCAPE '\'
				)  T
			WHERE 
				T.FULL_NAME != 'UT_SETUP' 
				AND T.FULL_NAME != 'UT_TEARDOWN'
				AND T.FULL_NAME not like 'UT\_%\_SETUP' ESCAPE '\'
				AND T.FULL_NAME not like 'UT\_%\_TEARDOWN' ESCAPE '\'
			) TT
		) TTT
		LEFT OUTER JOIN 
		( 
		SELECT Owner, OBJECT_NAME AS SETUP_NAME, 'Y' AS HAS_SETUP 
		FROM all_procedures 
		WHERE UPPER(OBJECT_NAME) like 'UT\_%\_SETUP' ESCAPE '\' 
		) S
			ON TTT.SUITE_SETUP_NAME = S.SETUP_NAME
			AND TTT.Owner = S.Owner 
		LEFT OUTER JOIN 
		(
		SELECT Owner, OBJECT_NAME AS TEARDOWN_NAME, 'Y' AS HAS_TEARDOWN 
		FROM all_procedures
		WHERE  UPPER(OBJECT_NAME) like 'UT\_%\_TEARDOWN' ESCAPE '\' 
		) TR
			ON TTT.SUITE_TEARDOWN_NAME = TR.TEARDOWN_NAME
			AND TTT.Owner = TR.Owner 
		LEFT OUTER JOIN
		( 
		SELECT Owner, NAME AS IGNORED_TEST_NAME, 'Y' AS IGNORED_TEST 
		FROM ALL_SOURCE 
		WHERE UPPER(TEXT) LIKE '%DBTD\_IGNORE%'  ESCAPE '\' 
		) I 
			ON TTT.FULL_NAME = I.IGNORED_TEST_NAME
			AND TTT.Owner = I.Owner;
	COMMIT; --commiting to know latest state of all unit tests
END;
/
ALTER PROCEDURE DBTD_REFRESH_TESTSLIST COMPILE; 
/

--************************************************************************************************
--note: used it to report errors in Unit Tests
--saves error into log table and raise the error to the parent process
--v_ErrorID  > -20999 or < -20000 - is the user error,  
--all other are Oracle errors
create or replace PROCEDURE DBTD_ERROR 
(
	v_ErrorID NUMBER
) 
AS
	v_Message VARCHAR2(2000);
	v_TestName VARCHAR2(128);	
	v_Owner VARCHAR2(128);	
BEGIN
	DBTD_LOG_MESSAGE_EXT ( 'DEBUG', 'DBTD_ERROR', 'DBTD_ERROR (NUMBER) ');
	
	IF ((v_ErrorID > -20999) and (v_ErrorID < -20000)) THEN -- user defined error message generated by raiserrror 
		v_Message := 'USER DEFINED ERROR ' || CAST( v_ErrorID AS VARCHAR2);
	ELSE
		v_Message := 'ORACLE ERROR ' || CAST( v_ErrorID AS VARCHAR2); 
	END IF;

	SELECT TestName INTO v_TestName	FROM DBTD_TBL_ACTIVETEST;
	SELECT Owner INTO v_Owner FROM DBTD_TBL_ACTIVETEST;

	DBTD_LOG_MESSAGE_EXT ( 'ERROR', v_TestName, NVL( v_Message,'(NO DESCRIPTION)'));

	DBTD_SaveState(v_TestName, v_Owner, 'ERROR', 'Y', NULL, v_Message);

	--finally raise exception to outer process
	RAISE_APPLICATION_ERROR (v_ErrorID, v_Message);
END;
/  
ALTER PROCEDURE DBTD_ERROR COMPILE; 
/
 
--************************************************************************************************
--records failure message in the log and raises exception UP to the parent process
CREATE OR REPLACE PROCEDURE DBTD_FAILURE 
(
	v_Message NVARCHAR2
)
AS
	v_TestName VARCHAR2(128);
	v_Owner VARCHAR2(128);
BEGIN
	DBTD_LOG_MESSAGE_EXT ( 'DEBUG', 'DBTD_FAILURE', 'DBTD_FAILURE (NVARCHAR2(255))');

	SELECT TestName INTO v_TestName	FROM DBTD_TBL_ACTIVETEST;
	SELECT Owner INTO v_Owner FROM DBTD_TBL_ACTIVETEST;

	DBTD_LOG_MESSAGE_EXT ( 'FAILURE', v_TestName, NVL( v_Message,'(NO DESCRIPTION)'));

	DBTD_SaveState(v_TestName, v_Owner, 'FAILURE', NULL, 'Y', NVL( v_Message ,'(NO DESCRIPTION)'));

	--finally raise exception to outer process
	RAISE_APPLICATION_ERROR ( -20001,  v_Message);
END;
/
ALTER PROCEDURE DBTD_FAILURE COMPILE; 
/

--************************************************************************************************
-- assert function that takes SQL query, executes it and 
-- report failure if script succeeded  
CREATE OR REPLACE PROCEDURE DBTD_ASSERT_WILL_FAIL 
(
	v_SQL VARCHAR2,		--SQL query
	v_UserMessage NVARCHAR2	--Message 
)
AS
	v_IsFailed char(1); 
	v_Message VARCHAR2(2000);
	v_TestName VARCHAR2(128);
	v_Owner VARCHAR2(128);
BEGIN
	v_IsFailed := 'N'; 
	v_Message := 'EXEC DBTD_ASSERT_WILL_FAIL';
	DBTD_LOG_MESSAGE_EXT ('DEBUG', 'DBTD_ASSERT_WILL_FAIL', v_Message);

	BEGIN
		EXECUTE IMMEDIATE v_SQL;
		v_Message := 'SQL EXPECTED TO FAIL, but it did not.'; 
		DBTD_FAILURE (v_Message); 
	EXCEPTION
	WHEN OTHERS THEN
		BEGIN
			v_Message := 'Listed above SQL FAILED AS EXPECTED with error: ' ||  SUBSTR(sqlerrm, 0, 1500);
			DBTD_LOG_MESSAGE_EXT ('INFO', 'DBTD_ASSERT_WILL_FAIL (1)', v_SQL);
			DBTD_LOG_MESSAGE_EXT ('INFO', 'DBTD_ASSERT_WILL_FAIL (2)', v_Message);
			--update status with the SUCCESS message in case when DBTD_ASSERT_WILL_FAIL 
			--runs to checks failure of a unit test that uses DBTD_FAILURE\DBTD_ERROR to report status
			SELECT TestName into v_TestName FROM DBTD_TBL_ACTIVETEST;
			SELECT Owner into v_Owner FROM DBTD_TBL_ACTIVETEST;
			--clean up 
			UPDATE DBTD_TBL_ACTIVETEST 	
			SET 
				IsError = 'N',
				IsFailure = 'N',
				Message = NVL( v_Message ,'SUCCESS');

			UPDATE DBTD_TBL_TESTRESULT
			SET IsFailure = 'N',
				Message = NVL( v_Message ,'FAILURE')
			WHERE 
				UPPER(TestName) = UPPER(v_TestName)
				AND UPPER(Owner) = UPPER(v_Owner);
			COMMIT; --release resources after cleanup
		END;
	END;
END;
/
ALTER PROCEDURE DBTD_ASSERT_WILL_FAIL COMPILE; 
/

--************************************************************************************************
-- assert function that takes SQL query, executes it and 
-- report failure if script failed
CREATE PROCEDURE DBTD_ASSERT_WILL_SUCCEED 
	(
	v_SQL VARCHAR2,				--SQL query
	v_UserMessage NVARCHAR2		--error message
	)
AS
	v_IsFailed char(1); 
	v_Message VARCHAR2(2000);
BEGIN
	v_IsFailed := 'N'; 
	v_Message := 'DBTD_ASSERT_WILL_SUCCEED';
	DBTD_LOG_MESSAGE_EXT ('DEBUG', 'DBTD_ASSERT_WILL_SUCCEED', v_Message);

	BEGIN
		EXECUTE IMMEDIATE v_SQL;
		v_IsFailed := 'N';
		v_Message := '';
	EXCEPTION
	WHEN OTHERS THEN
		BEGIN
			v_IsFailed := 'Y';
			v_Message := 'FAILED WITH ERROR: ' || SUBSTR(sqlerrm, 0, 1500);
		END;
	END;

	IF (v_IsFailed = 'Y') THEN
		v_Message := 'Provided SQL EXPECTED TO SUCCEED, but it has ' || v_Message; 
		DBTD_FAILURE (v_Message); 
	END IF;
END;
/
ALTER PROCEDURE DBTD_ASSERT_WILL_SUCCEED COMPILE; 
/

--************************************************************************************************
-- assert function that takes actual value, expected value, compares them for equality 
-- report failure if the not equal
CREATE OR REPLACE PROCEDURE DBTD_ASSERT_ARE_EQUAL 
(
	v_ActualValue	NVARCHAR2, 
	v_ExpectedValue NVARCHAR2, 
	v_UserMessage	NVARCHAR2
)
AS
	v_Message VARCHAR2(255);
BEGIN
	DBTD_LOG_MESSAGE_EXT ( 'DEBUG', 'DBTD_ASSERT_ARE_EQUAL', 'DBTD_ASSERT_ARE_EQUAL');
	
	IF (v_ActualValue != v_ExpectedValue)  THEN
		v_Message := v_UserMessage 
			|| ' Actual value is NOT EQUAL Expected value. ' 
			|| ' EXPECTED: ' || v_ExpectedValue 
			|| ' ACTUAL: ' || v_ActualValue ; 
		DBTD_FAILURE (v_Message); 
	END IF;
END;
/
ALTER PROCEDURE DBTD_ASSERT_ARE_EQUAL COMPILE; 
/

--************************************************************************************************
-- assert function that takes actual value, expected value, compares them for equality 
-- report failure if values are equal
CREATE OR REPLACE PROCEDURE DBTD_ASSERT_ARE_NOT_EQUAL 
(
	v_ActualValue		NVARCHAR2, 
	v_NotExpectedValue	NVARCHAR2, 
	v_UserMessage		NVARCHAR2
)
AS
	v_Message VARCHAR2(255);
BEGIN
	DBTD_LOG_MESSAGE_EXT ( 'DEBUG', 'DBTD_ASSERT_ARE_NOT_EQUAL', 'DBTD_ASSERT_ARE_NOT_EQUAL (NVARCHAR2(255), NVARCHAR2(255), NVARCHAR2(255))');

	IF (v_ActualValue = v_NotExpectedValue)  THEN 
	    v_Message := v_UserMessage 
			|| ' Actual value is EQUAL to Not Expected value. ' 
			|| ' NOT EXPECTED: ' || v_NotExpectedValue 
			|| ' ACTUAL: ' || v_ActualValue;
		DBTD_FAILURE (v_Message); 
	END IF;
END;
/
ALTER PROCEDURE DBTD_ASSERT_ARE_NOT_EQUAL COMPILE; 
/

--************************************************************************************************
-- assert function that takes actual value, expected value, 
-- and checks that actual value is greater or equal than expected value 
-- report failure if values is equal or smaller
CREATE OR REPLACE PROCEDURE DBTD_ASSERT_IS_LESS_OR_EQUAL 
(	
	v_ActualValue	NUMBER,
	v_ExpectedValue NUMBER,
	v_UserMessage	NVARCHAR2
)
AS
	v_Message VARCHAR2(255);
BEGIN
	DBTD_LOG_MESSAGE_EXT ( 'DEBUG', 'DBTD_ASSERT_IS_LESS_OR_EQUAL', 'DBTD_ASSERT_IS_LESS_OR_EQUAL');

	IF (v_ActualValue > v_ExpectedValue)  THEN
		v_Message := v_UserMessage 
			|| ' Actual value is NOT LESS OR EQUAL Expected value. ' 
			|| ' EXPECTED: ' || CAST(v_ExpectedValue AS  VARCHAR2)
			|| ' ACTUAL: ' || CAST(v_ActualValue AS  VARCHAR2) ; 
		DBTD_FAILURE (v_Message); 
	END IF;
END;
/
ALTER PROCEDURE DBTD_ASSERT_IS_LESS_OR_EQUAL COMPILE; 
/

--************************************************************************************************
-- assert function that takes actual value, expected value, 
-- and checks that actual value is greater than  expected value 
-- report failure if values is equal or smaller
CREATE OR REPLACE PROCEDURE DBTD_ASSERT_IS_GREATER 
(
	v_ActualValue	NUMBER,
	v_ExpectedValue NUMBER,
	v_UserMessage	NVARCHAR2
)
AS
	v_Message VARCHAR2(255);
BEGIN
	DBTD_LOG_MESSAGE_EXT ( 'DEBUG', 'DBTD_ASSERT_IS_GREATER', 'DBTD_ASSERT_IS_GREATER (NUMBER(18,8),NUMBER(18,8),NVARCHAR2(255))');
	
	IF (v_ActualValue <= v_ExpectedValue)  THEN
		v_Message := v_UserMessage 
			|| ' Actual value is NOT GREATER then Expected value. ' 
			|| ' EXPECTED: ' || CAST(v_ExpectedValue AS  VARCHAR2)
			|| ' ACTUAL: ' || CAST(v_ActualValue AS  VARCHAR2) ; 
		DBTD_FAILURE (v_Message); 
	END IF;
END;
/
ALTER PROCEDURE DBTD_ASSERT_IS_GREATER COMPILE; 
/

--************************************************************************************************
-- assert function that takes actual timestamp value, expected timestamp value, 
-- and checks that actual timestamp value is greater than expected timestamp value 
-- report failure if values is equal or smaller
-- note: Oracle DBTD framework uses shorter name while other databases use 
--       DBTD_ASSERT_DATETIME_IS_GREATER name
CREATE OR REPLACE PROCEDURE DBTD_ASSERT_DT_IS_GRTR
(
	v_ActualValue	TIMESTAMP,
	v_ExpectedValue TIMESTAMP,
	v_UserMessage	NVARCHAR2
)
AS
	v_Message VARCHAR2(2000);
BEGIN
	DBTD_LOG_MESSAGE_EXT ( 'DEBUG', 'DBTD_ASSERT_DT_IS_GRTR', 'runnning DBTD_ASSERT_DT_IS_GRTR');

	IF (v_ActualValue <= v_ExpectedValue)  THEN
		v_Message := v_UserMessage 
			|| ' Actual value is NOT GREATER then Expected value. ' 
			|| ' EXPECTED: ' || CAST(v_ExpectedValue AS  VARCHAR2)
			|| ' ACTUAL: ' || CAST(v_ActualValue AS  VARCHAR2) ; 
		DBTD_FAILURE (v_Message); 
	END IF;
END;
/
ALTER PROCEDURE DBTD_ASSERT_DT_IS_GRTR COMPILE; 
/

--************************************************************************************************
--note: oracle supports only 32 letters long name, other DBs use following name:
--      DBTD_ASSERT_DATETIME_IS_GREATER_OR_EQUAL
-- assert function that takes actual timestamp value, expected timestamp value, 
-- and checks that actual timestamp value is greater or equal than expected timestamp value 
-- report failure if values is smaller
CREATE OR REPLACE PROCEDURE DBTD_ASSERT_DT_IS_GRTR_OR_EQL 
(
	v_ActualValue	TIMESTAMP,
	v_ExpectedValue TIMESTAMP,
	v_UserMessage	NVARCHAR2
)
AS
	v_Message VARCHAR2(2000);
BEGIN
	DBTD_LOG_MESSAGE_EXT ( 'DEBUG', 'DBTD_ASSERT_DATE_IS_GRTR_OR_EQL', 'DBTD_ASSERT_DATETIME_IS_GREATER_OR_EQUAL (TIMESTAMP,TIMESTAMP,NVARCHAR2(255))');
	
	IF (v_ActualValue < v_ExpectedValue)  THEN
		v_Message := v_UserMessage 
			|| ' Actual value is NOT GREATER OR EQUAL to Expected value. ' 
			|| ' EXPECTED: ' || CAST(v_ExpectedValue AS  VARCHAR2)
			|| ' ACTUAL: ' || CAST(v_ActualValue AS  VARCHAR2) ; 
		DBTD_FAILURE (v_Message); 
	END IF;
END;
/
ALTER PROCEDURE DBTD_ASSERT_DT_IS_GRTR_OR_EQL COMPILE; 
/

--************************************************************************************************
--checks if value is true and reports failure if it is not
--note: in comparison to other DBs Oracle uses char 'Y' as identifier for TRUE, anything other than 'Y'
--      treated as FALSE
CREATE OR REPLACE PROCEDURE DBTD_ASSERT_IS_TRUE 
(
  v_ActualValue CHAR,
  v_UserMessage NVARCHAR2
)
AS
  v_Message VARCHAR2(255);
BEGIN
  DBTD_LOG_MESSAGE_EXT ( 'DEBUG', 'DBTD_ASSERT_IS_TRUE', 'DBTD_ASSERT_IS_TRUE (boolean,NVARCHAR2(255))');

  IF (v_ActualValue != 'Y' )  THEN
    v_Message := v_UserMessage || ' Actual value is NOT TRUE.'; 
    DBTD_FAILURE (v_Message); 
  END IF;
END;
/
ALTER PROCEDURE DBTD_ASSERT_IS_TRUE COMPILE; 
/

--************************************************************************************************
--CORE HINT
--procedure itself does nothing, however if it is found anywhere in the body of the unit test procedure code 
--then execution of the test will be ignored all together
CREATE OR REPLACE PROCEDURE DBTD_IGNORE 
( 
	v_Message NVARCHAR2	--Message
)
AS
BEGIN
	DBTD_LOG_MESSAGE_EXT ( 'INFO', 'DBTD_IGNORE', 'DBTD_IGNORE with message ' || v_Message);
END;
/
ALTER PROCEDURE DBTD_IGNORE COMPILE; 
/

--************************************************************************************************
--CORE HINT
--if it is found anywhere in the body of the suite setup or teardown then setup will execute ONLY ONCE 
--once per suite and will not execute for the each test same will happen with teardown procedure. 
CREATE OR REPLACE PROCEDURE DBTD_RUN_ONCE 
( 
	v_Message NVARCHAR2	--Message
)
AS
BEGIN
	--DBTD_LOG_MESSAGE_EXT ('DEBUG', 'DBTD_RUN_ONCE', 'Running DBTD_RUN_ONCE Hint Procedure');
	DBTD_LOG_MESSAGE_EXT ( 'INFO', 'DBTD_RUN_ONCE', 'DBTD_RUN_ONCE with message ' || v_Message);
END;
/
ALTER PROCEDURE DBTD_RUN_ONCE COMPILE; 
/

--************************************************************************************************
-- checks that table has expected number of records base on supplied condition
CREATE OR REPLACE PROCEDURE DBTD_ASSERT_IS_EXPECTED_COUNT 
(
	v_ExpectedValue NUMBER,
	v_TableName		VARCHAR2,
	v_Condition		VARCHAR2,
	v_UserMessage	VARCHAR2
)
AS
	v_ActualValue NUMBER;
	v_Message VARCHAR2(255);
	v_SQL VARCHAR2(2000);
	TYPE t_CUR_TYPE IS REF CURSOR;
	v_Cursor t_CUR_TYPE;
BEGIN
	v_ActualValue := -1;
	DBTD_LOG_MESSAGE_EXT ( 'DEBUG', 'DBTD_ASSERT_IS_EXPECTED_COUNT', 'DBTD_ASSERT_IS_EXPECTED_COUNT');

	v_SQL := 'SELECT COUNT(1) AS CT FROM ' || v_TableName; 
	IF TRIM(v_Condition) IS NOT NULL THEN
		v_SQL := v_SQL || ' WHERE ' || v_Condition;
	END IF;

	-- Need a loop to get results from the dynamic query.
	OPEN v_Cursor FOR v_SQL; 
	LOOP
		FETCH v_Cursor INTO v_ActualValue;
		EXIT;
	END LOOP;
	CLOSE v_Cursor;
	IF (v_ActualValue IS NULL) THEN 
		v_ActualValue := 0; 
	END IF;

	IF (v_ActualValue != v_ExpectedValue )  THEN
		v_Message := v_UserMessage 
			|| ' Actual value is NOT EQUAL to Expected value. ' 
			|| ' EXPECTED: ' || CAST(v_ExpectedValue AS  VARCHAR2)
			|| ' ACTUAL: ' || CAST(v_ActualValue AS  VARCHAR2) 
			|| ' For SQL query: ' || v_SQL; 
		DBTD_FAILURE (v_Message); 
	END IF;
END;
/
ALTER PROCEDURE DBTD_ASSERT_IS_EXPECTED_COUNT COMPILE; 
/

--************************************************************************************************
-- checks that table does not have expected number of records base on supplied condition
--note: oracle support only 32 letters names. other DB use following name for this stored proc:
--      DBTD_ASSERT_IS_NOT_EXPECTED_COUNT
CREATE OR REPLACE PROCEDURE DBTD_ASSERT_IS_NOT_EXPECTED_CT 
(
	v_NotExpectedValue	NUMBER,
	v_TableName			VARCHAR2,
	v_Condition			VARCHAR2,
	v_UserMessage		VARCHAR2
)
AS
	v_ActualValue NUMBER;
	v_Message VARCHAR2(255);
	v_SQL VARCHAR2(2000);
	TYPE t_CUR_TYPE IS REF CURSOR;
	v_Cursor t_CUR_TYPE;
BEGIN
	DBTD_LOG_MESSAGE_EXT ( 'DEBUG', 'DBTD_ASSERT_IS_NOT_EXPECTED_CT', 'DBTD_ASSERT_IS_TRUE (boolean,NVARCHAR2(255))');

	v_SQL := 'SELECT COUNT(1) AS CT FROM ' || v_TableName; 
	IF TRIM(v_Condition) IS NOT NULL THEN
		v_SQL := v_SQL || ' WHERE ' || v_Condition;
	END IF;
	--v_SQL := v_SQL|| ';';
	-- Need a loop to get results from the dynamic query.
	OPEN v_Cursor FOR v_SQL; 
	LOOP
		FETCH v_Cursor INTO v_ActualValue;
		EXIT;
	END LOOP;
	CLOSE v_Cursor;
		
	IF (v_ActualValue = v_NotExpectedValue )  THEN
		v_Message := v_UserMessage 
			|| ' Actual value is EQUAL to Not-Expected value. ' 
			|| ' NOT EXPECTED: ' || CAST(v_NotExpectedValue AS  VARCHAR2)
			|| ' ACTUAL: ' || CAST(v_ActualValue AS  VARCHAR2) ; 
		DBTD_FAILURE (v_Message); 
	END IF;
END;
/
ALTER PROCEDURE DBTD_ASSERT_IS_NOT_EXPECTED_CT COMPILE; 
/

--************************************************************************************************
--checks that table is NOT empty and has records 
--note: other databases use DBTD_ASSERT_TABLE_HAS_RECORDS name
CREATE OR REPLACE PROCEDURE DBTD_ASSERT_TBL_HAS_RECORDS 
(
v_TableName NVARCHAR2,		--table name
v_UserMessage NVARCHAR2		--user message
)
AS
BEGIN
	DBTD_LOG_MESSAGE_EXT ('DEBUG', 'DBTD_ASSERT_TABLE_HAS_RECORDS', 'Running DBTD_ASSERT_TABLE_HAS_RECORDS');
	DBTD_ASSERT_IS_NOT_EXPECTED_CT (0, v_TableName, '', v_UserMessage);
END;
/
ALTER PROCEDURE DBTD_ASSERT_TBL_HAS_RECORDS COMPILE; 
/

--************************************************************************************************
--checks that table is empty and has no records 
--note: other databases use DBTD_ASSERT_TABLE_HAS_NO_RECORDS  name
CREATE OR REPLACE PROCEDURE DBTD_ASSERT_TBL_HAS_NO_RECORDS 
(
v_TableName NVARCHAR2,		--table name
v_UserMessage NVARCHAR2		--user message
)
AS
BEGIN
	DBTD_LOG_MESSAGE_EXT ('DEBUG', 'DBTD_ASSERT_TABLE_HAS_NO_RECORDS', 'Running DBTD_ASSERT_TABLE_HAS_NO_RECORDS');
	DBTD_ASSERT_IS_EXPECTED_COUNT (0, v_TableName, '', v_UserMessage);
END;
/
ALTER PROCEDURE DBTD_ASSERT_TBL_HAS_NO_RECORDS COMPILE; 
/

--************************************************************************************************
--internal CORE procedure that initialize unit test 
CREATE OR REPLACE PROCEDURE DBTD_INITIALIZE
(
	v_TestName		VARCHAR2,	--Unit Test
	v_TestOwner		VARCHAR2	--Test Owner
)
AS
	PRAGMA AUTONOMOUS_TRANSACTION;

	v_Message VARCHAR2(255);
	v_CountTests NUMBER;
BEGIN 
	DBTD_LOG_MESSAGE_EXT ( 'DEBUG', 'DBTD_INITIALIZE', v_TestName );
	DELETE FROM  DBTD_TBL_ACTIVETEST;
	COMMIT;
	v_Message := 'INITIATING TEST...';
	INSERT INTO DBTD_TBL_ACTIVETEST (IsError,IsFailure,TestName, Owner, Message) 
	VALUES ('N','N',v_TestName,v_TestOwner,v_Message);
	COMMIT;

	SELECT count(*) into v_CountTests 
	FROM DBTD_TBL_TESTRESULT 
	WHERE 
		UPPER(TestName) = UPPER(v_TestName)
		AND UPPER(Owner) = UPPER(v_TestOwner);
	IF v_CountTests > 0 THEN
		DBTD_LOG_MESSAGE_EXT ( 'INFO', 'DBTD_INITIALIZE', 'Update DBTD_TBL_TESTRESULT with initial pre-run status for - ' || v_TestName);
		UPDATE DBTD_TBL_TESTRESULT 
		SET 
			StartTime = SYSDATE,
			RunCount = NVL(RunCount,0) + 1,
			IsError = 'N',
			IsFailure = 'N', 
			Status = 'STARTED',
			Message = v_Message
		WHERE 
			UPPER(TestName) = UPPER(v_TestName)
			AND UPPER(Owner) = UPPER(v_TestOwner);
	ELSE 
		DBTD_LOG_MESSAGE_EXT ( 'INFO', 'DBTD_INITIALIZE', 'Add new record to DBTD_TBL_TESTRESULT table since it is the first run for the test - ' || v_TestName);
		INSERT INTO DBTD_TBL_TESTRESULT (Owner,StartTime,TestName,IsError, IsFailure, Status,  Message, RunCount)
		VALUES ( v_TestOwner, SYSDATE, v_TestName, 'N', 'N', 'STARTED', v_Message, 1);
	END IF;
	COMMIT;
END;
/
ALTER PROCEDURE DBTD_INITIALIZE COMPILE; 
/

--************************************************************************************************
--internal CORE procedure that finalize unit test 
CREATE OR REPLACE PROCEDURE DBTD_FINALIZE
(
	v_TestName			VARCHAR2,		--Unit Test
	v_TestOwner			VARCHAR2,		--Test Owner
	v_SetupError		NUMBER,			--Errors encountered during setup
	v_ProcedureError	NUMBER,			--Errors encountered during test run
	v_TeardownError		NUMBER,			--Errors encountered during teardown 
	v_WasIgnored		CHAR,			--"N" if test were run, "Y" - if test execution were ignored
	v_MessageStack		VARCHAR2		--Stack Trace message
)
AS
	v_Message VARCHAR2(255);
	v_CountTests NUMBER;
	v_IsFailure CHAR(1);
	v_IsError CHAR(1);
	v_FinalStatus   VARCHAR2(50);
	v_FinalError CHAR(1);
	v_FinalMessage VARCHAR2(2000);
BEGIN 
	DBTD_LOG_MESSAGE_EXT ( 'DEBUG', 'DBTD_FINALIZE', v_TestName );

	v_IsError := 'Y';		--assume that there is an issue
	v_IsFailure := 'Y';	--assume that there is an issue

	SELECT 	NVL(IsError,'Y') into v_IsError 
	FROM DBTD_TBL_ACTIVETEST
	WHERE 
		UPPER(TestName) = UPPER(v_TestName)
		AND UPPER(Owner) = UPPER(v_TestOwner); 
	SELECT 	NVL(IsFailure,'Y') into v_IsFailure 
	FROM DBTD_TBL_ACTIVETEST
	WHERE 
		UPPER(TestName) = UPPER(v_TestName)
		AND UPPER(Owner) = UPPER(v_TestOwner); 
	DBTD_LOG_MESSAGE_EXT ( 'INFO', 'DBTD_FINALIZE', v_TestName || ' v_SetupError='|| v_SetupError || ', v_ProcedureError='||v_ProcedureError ||',v_TeardownError='||v_TeardownError||',v_IsError='||v_IsError ||',v_IsFailure='||v_IsFailure);

	v_FinalStatus := 'SUCCESS';
	v_FinalError := 'N';
	v_FinalMessage := v_TestName ||' - DONE';

	IF (v_SetupError != 0 OR v_ProcedureError != 0 OR v_TeardownError != 0 OR NVL(v_IsError, 'Y') != 'N' OR NVL(v_IsFailure,'Y') != 'N' ) THEN 
		v_FinalStatus := 'ERROR';
		v_FinalError := 'Y';
		v_FinalMessage := v_TestName ||' - Has issues. Please check DBTD_TBL_LOG table for error messages. Stack Trace: ' || v_MessageStack;
	END IF;

	IF (v_WasIgnored != 'N') THEN
		v_FinalStatus := 'IGNORED';
		v_FinalMessage := v_FinalMessage || ' Stack Trace: ' || v_MessageStack;
	END IF;

	DBTD_LOG_MESSAGE_EXT ( 'INFO', 'DBTD_FINALIZE', v_TestName || ' finished with Status='|| v_FinalStatus || ', IsError='||v_FinalError ||',Message='||v_FinalMessage);

	DBTD_SaveState(v_TestName, v_TestOwner, v_FinalStatus, v_FinalError, v_IsFailure, v_FinalMessage);
END;
/
ALTER PROCEDURE DBTD_FINALIZE COMPILE; 
/

--************************************************************************************************
--run all tests in the specified test suite
--noet: if DBTD_TBL_TESTSLIST table is empty stored proc will attempt to refresh the list of all 
--      available tests
--note: oracle version will allow same test suite names used for the different owners, other DB
--      might not support this feature
CREATE OR REPLACE PROCEDURE DBTD_RunTestSuite 
(
	v_SuiteName			VARCHAR2,		--Suite Name
	v_SuiteOwner		VARCHAR2,		--Suite Owner
	v_ReloadTestsList	CHAR			--Refresh list of available tests (Y or N)
)
AS
	v_TestName VARCHAR2(128);
	v_HasSetup CHAR(1);
	v_HasTeardown CHAR(1);
	v_Ignore CHAR(1);					
	v_WasIgnored CHAR(1);				--will be set to "Y" if test execution was ignored during execution
	v_TestPrefix CHAR(3);
	v_SetupError NUMBER;
	v_TeardownError NUMBER;
	v_CountTests NUMBER;
	v_UnitTestCount NUMBER;				--number of unit tests that were run for a given suite 
	v_IsFailure CHAR(1);
	v_IsError CHAR(1);
	v_Message VARCHAR2(255);
	v_ErrorMessage VARCHAR2(2000);
	v_MessageStack VARCHAR2(2000);		--used to accumulate messages and pass them to finalization
	v_SetupName VARCHAR2(128);
	v_TeardownName VARCHAR2(128);
	v_CursorSQL VARCHAR2(2000);
	v_RunSetupOnce CHAR(1);
	v_RunTeardownOnce CHAR(1);
	v_ProcedureError NUMBER;
	v_FinalStatus VARCHAR2(50);
	v_FinalIsError CHAR(1);
	v_FinalMessage VARCHAR2(2000);
	TYPE t_CUR_TYPE IS REF CURSOR;
	v_Cursor t_CUR_TYPE;
BEGIN
	BEGIN --start exception handling blok	
		IF (v_SuiteOwner IS NULL) OR (TRIM(v_SuiteOwner) = '') THEN
			RAISE_APPLICATION_ERROR ( -20001,  'Suite Owner has not been supplied');
		END IF;
		v_CountTests := 0;
		v_UnitTestCount := 0;
		v_SetupError := 0;
		v_TeardownError := 0;
		v_TestPrefix := 'UT_';
		v_SetupName := TRIM(v_TestPrefix) ||TRIM(v_SuiteName) || '_SETUP';
		v_TeardownName := TRIM(v_TestPrefix) ||TRIM(v_SuiteName) || '_TEARDOWN';
		v_RunSetupOnce := 'N';
		v_RunTeardownOnce := 'N';

		DBTD_LOG_MESSAGE_EXT ( 'DEBUG', 'DBTD_RUNTESTSUITE', 'DBTD_RUNTESTSUITE - ' || v_SuiteName || ' with: v_ReloadTestsList='||v_ReloadTestsList);

		SELECT COUNT(1) INTO v_CountTests FROM DBTD_TBL_TESTSLIST;
		IF ((v_CountTests = 0) OR (v_ReloadTestsList = 'Y')) THEN
			DBTD_LOG_MESSAGE_EXT ( 'INFO', 'DBTD_RUNTESTSUITE', 'REFRESH DBTD_TBL_TESTSLIST, because v_ReloadTestsList='||v_ReloadTestsList || ', v_CountTests='||TO_CHAR(v_CountTests));
			DBTD_REFRESH_TESTSLIST(); 
		END IF;
		v_CountTests := 0;

		DBTD_LOG_MESSAGE_EXT ( 'DEBUG', 'DBTD_RUNTESTSUITE', 'Check that we need to run setup only once per suite - ' || v_SuiteName );
		SELECT (CASE WHEN COUNT(*) > 0 THEN 'Y' ELSE 'N' END) into v_RunSetupOnce
		FROM ALL_SOURCE
		WHERE 
			UPPER(TEXT) LIKE '%DBTD\_RUN\_ONCE%' ESCAPE '\' 
			AND UPPER(NAME) = UPPER(v_SetupName)
			AND UPPER(OWNER) = UPPER(v_SuiteOwner);

		DBTD_LOG_MESSAGE_EXT ( 'DEBUG', 'DBTD_RUNTESTSUITE', 'Check that we need to run teardown only once per suite - ' || v_SuiteName );
		SELECT (CASE WHEN COUNT(*) > 0 THEN 'Y' ELSE 'N' END) into v_RunTeardownOnce
		FROM ALL_SOURCE
		WHERE 
			UPPER(TEXT) LIKE '%DBTD\_RUN\_ONCE%' ESCAPE '\' 
			AND UPPER(NAME) = UPPER(v_TeardownName)
			AND UPPER(OWNER) = UPPER(v_SuiteOwner);

		IF (v_RunSetupOnce = 'Y') THEN
			DBTD_LOG_MESSAGE_EXT ( 'INFO', 'DBTD_RUNTESTSUITE', 'Running setup ' ||v_SetupName||' procedure ONCE for a suite ' || v_SuiteName );
			v_SetupError := 0;
			BEGIN
				EXECUTE IMMEDIATE 'CALL ' || v_SetupName || ' ()';
			EXCEPTION
			WHEN OTHERS THEN
				BEGIN
					v_ErrorMessage := ' SETUP ERROR: ' || SUBSTR(sqlerrm, 0, 1500);
					v_SetupError := 1000;
					DBTD_LOG_MESSAGE_EXT ( 'WARNING', v_SetupName, v_ErrorMessage );
				END;
			END;
		END IF;

		--iterate through all available UTs for a given test suite
		v_CursorSQL := 'SELECT TestName, HasSetup, HasTeardown, Ignore ' 
			|| 'FROM DBTD_TBL_TESTSLIST '
			|| 'WHERE TRIM(UPPER(Suite)) = TRIM(UPPER(''' || v_SuiteName || ''')) '
			|| 'AND TRIM(UPPER(Owner)) = TRIM(UPPER(''' || v_SuiteOwner || ''')) '
			|| 'ORDER BY TestName';

		OPEN v_Cursor for v_CursorSQL;
		LOOP
			FETCH v_Cursor INTO v_TestName, v_HasSetup, v_HasTeardown, v_Ignore; 
			EXIT WHEN v_Cursor%NOTFOUND;
			
			v_CountTests := v_CountTests + 1;
			v_UnitTestCount := v_UnitTestCount + 1;
			v_ProcedureError := 0;
			v_TeardownError := 0;
			v_ErrorMessage := ' ';
			v_WasIgnored := 'N';		
			v_MessageStack := ' ';	
			DBTD_LOG_MESSAGE_EXT ( 'DEBUG', 'DBTD_RUNTESTSUITE', 'Starting - ' || v_TestName || ' with: v_HasSetup='||v_HasSetup||', v_HasTeardown='||v_HasTeardown||', v_Ignore='||v_Ignore||', v_RunSetupOnce='||v_RunSetupOnce||', v_RunTeardownOnce='||v_RunTeardownOnce);

			DBTD_INITIALIZE(v_TestName, v_SuiteOwner);

			IF (v_Ignore = 'N') THEN
				--run tests that are not Ignored 
				IF (v_HasSetup = 'Y') AND (v_RunSetupOnce = 'N') THEN
					DBTD_LOG_MESSAGE_EXT ( 'INFO', 'DBTD_RUNTESTSUITE', 'RUNNING SETUP:'||v_SetupName||', for unit test:'||v_TestName );
					BEGIN
						EXECUTE IMMEDIATE 'CALL ' || v_SetupName || ' ()';
					EXCEPTION
					WHEN OTHERS THEN
						BEGIN
							v_ErrorMessage := ' SETUP ERROR: ' || SUBSTR(sqlerrm, 0, 1500);
							v_SetupError := 1000;
							DBTD_LOG_MESSAGE_EXT ( 'INFO', v_SetupName, v_ErrorMessage );
							v_MessageStack := v_MessageStack || v_ErrorMessage || ' ';
						END;
					END;
				END IF;

				IF (v_SetupError = 0) THEN
					DBTD_LOG_MESSAGE_EXT ( 'INFO', 'DBTD_RUNTESTSUITE', 'RUNNING: ' || v_TestName );
					BEGIN
						EXECUTE IMMEDIATE 'CALL ' || v_TestName || ' ()';
					EXCEPTION
					WHEN OTHERS THEN
						BEGIN
							v_ErrorMessage := 'UNIT TEST ERROR: ' || SUBSTR(sqlerrm, 0, 1500);
							v_ProcedureError := 1000;
							DBTD_LOG_MESSAGE_EXT ( 'ERROR', v_TestName, v_ErrorMessage );
							v_MessageStack := v_MessageStack || v_ErrorMessage || ' ';
						END;
					END;
				ELSE 
					v_WasIgnored := 1;
					v_Message := 'Skipping ' || UPPER(v_TestName) || ' unit test due to error ' || TO_CHAR(v_SetupError) || ' in setup procedure ' || UPPER(v_SetupName);
					DBTD_LOG_MESSAGE_EXT ('WARNING', 'DBTD_RUNTESTSUITE', v_Message);
					v_MessageStack := v_MessageStack || v_Message || ' ';
				END IF;

				IF (v_HasTeardown = 'Y') AND (v_RunTeardownOnce = 'N') THEN
					DBTD_LOG_MESSAGE_EXT ( 'INFO', 'DBTD_RUNTESTSUITE', 'RUNNING TEARDOWN - ' || v_TestName );
					BEGIN
						EXECUTE IMMEDIATE 'CALL ' || v_TeardownName || ' ()';
					EXCEPTION
					WHEN OTHERS THEN
						BEGIN
							v_ErrorMessage := ' TEARDOWN ERROR: ' || SUBSTR(sqlerrm, 0, 1500);
							v_TeardownError := 1000;
							DBTD_LOG_MESSAGE_EXT ( 'ERROR', v_TeardownName , v_ErrorMessage);
							v_MessageStack := v_MessageStack || v_Message || ' ';
						END;
					END;
				END IF;
			ELSE
				v_WasIgnored := 1;
				v_MessageStack := ' Unit tests has been marked to be ignored.';
			END IF;

			DBTD_FINALIZE( v_TestName, v_SuiteOwner, v_SetupError, v_ProcedureError, v_TeardownError, v_WasIgnored, v_MessageStack );
			--move to the next test in the queue
		END LOOP;
		CLOSE v_Cursor;

		IF (v_RunTeardownOnce = 'Y') THEN
			DBTD_LOG_MESSAGE_EXT ( 'INFO', 'DBTD_RUNTESTSUITE', 'Running teardown '||v_TeardownName||' procedure ONCE at the end of the Suite processing' );
			BEGIN
				EXECUTE IMMEDIATE 'CALL ' || v_TeardownName || ' ()';
			EXCEPTION
			WHEN OTHERS THEN
				BEGIN
					v_ErrorMessage := ' TEARDOWN ERROR: ' || SUBSTR(sqlerrm, 0, 1500);
					v_TeardownError := 1000;
					DBTD_LOG_MESSAGE_EXT ( 'ERROR', v_TeardownName , v_ErrorMessage);
				END;
			END;
		END IF;

		DBTD_LOG_MESSAGE_EXT ( 'INFO', 'DBTD_RUNTESTSUITE', CAST(v_UnitTestCount AS VARCHAR2) || ' unit tests were executed for suite: ' || v_SuiteName );

	EXCEPTION
	WHEN OTHERS THEN
		BEGIN
			DBTD_LOG_MESSAGE_EXT ( 'ERROR', 'DBTD_RUNTESTSUITE', 'DBTD_RUNTESTSUITE FATAL ERROR: ' || SUBSTR(sqlerrm, 0, 1500));
			CLOSE v_Cursor;
		END;
	END; --end exception handling blok
END;
/
ALTER PROCEDURE DBTD_RUNTESTSUITE COMPILE; 
/

--************************************************************************************************
--runs all tests for a given owner in current database
create or replace PROCEDURE DBTD_RUNTESTS
(
	v_Owner VARCHAR2
) 
AS
	v_Suite NVARCHAR2(255);
	v_TestSuite NVARCHAR2(255);
	v_CursorSQL VARCHAR2(2000);
	TYPE t_CUR_TYPE IS REF CURSOR;
	v_Cursor t_CUR_TYPE;
	v_GlobalSetupCount NUMBER;
	v_GlobalSetup  VARCHAR2(128);
	v_GlobalTearDownCount NUMBER;
	v_GlobalTearDown VARCHAR2(128);
	v_TmpMessage VARCHAR2(255);
BEGIN
	DELETE FROM DBTD_TBL_LOG; 
	DBTD_LOG_MESSAGE_EXT ( 'INFO', 'DBTD_RUNTESTS', 'STARTED DBTD_RUNTESTS');

	v_Suite :='%'; 
	v_GlobalSetup := 'UT_SETUP';
	v_GlobalTearDown :=  'UT_TEARDOWN';

	DBTD_REFRESH_TESTSLIST();	--looking for any new unit test that were added in to database 

	--run global set up for all the tests
	SELECT COUNT(1) INTO v_GlobalSetupCount 
	FROM all_procedures 
    WHERE 
		OBJECT_TYPE='PROCEDURE' 
		AND UPPER(OBJECT_NAME) = UPPER(TRIM(v_GlobalSetup))
		AND UPPER(Owner) = UPPER(v_Owner);

	IF (v_GlobalSetupCount > 0) THEN
		DBTD_LOG_MESSAGE_EXT ( 'INFO', 'DBTD_RUNTESTS', 'GLOBAL SETUP PROCEDURE: ' || v_GlobalSetup || '();' );
		EXECUTE IMMEDIATE ('CALL ' || v_GlobalSetup || '()') ;
	ELSE
		DBTD_LOG_MESSAGE_EXT ( 'INFO', 'DBTD_RUNTESTS', 'GLOBAL SETUP FUNCTION IS NOT DEFINED');
	END IF;
	
	v_CursorSQL :=  'SELECT DISTINCT Suite FROM DBTD_TBL_TESTSLIST WHERE Suite LIKE ''' 
		|| TRIM(v_Suite) || ''' AND UPPER(Owner) = UPPER(''' || v_Owner || ''') ORDER BY Suite';

    OPEN v_Cursor FOR v_CursorSQL;
    LOOP
        FETCH v_Cursor INTO v_TestSuite;
        EXIT WHEN v_Cursor%NOTFOUND;

		DBTD_LOG_MESSAGE_EXT  ('INFO', 'DBTD_RUNTESTS', 'RUNNING TESTSUITE - ' || v_TestSuite );
		DBTD_RUNTESTSUITE (v_TestSuite, v_Owner, 'N');	
		DBTD_LOG_MESSAGE_EXT  ('INFO', 'DBTD_RUNTESTS','FINALIZING TESTSUITE -  ' || v_TestSuite );
	END LOOP;
	CLOSE v_Cursor;

	--run global set up for all the tests
	SELECT COUNT(1) INTO v_GlobalTearDownCount 
	FROM all_procedures 
	WHERE 
		UPPER(OBJECT_NAME) = UPPER(TRIM(v_GlobalTearDown)) 
		AND UPPER(OWNER) = UPPER(v_Owner);

	IF (v_GlobalTearDownCount > 0) THEN
		v_TmpMessage :=  'CALL GLOBAL TEARDOWN FUNCTION ' || v_GlobalTearDown || '();';
		DBTD_LOG_MESSAGE_EXT ( 'INFO', 'DBTD_RUNTESTS', v_TmpMessage );
		EXECUTE IMMEDIATE ('CALL ' || v_GlobalTearDown || '();') ;
	ELSE
		DBTD_LOG_MESSAGE_EXT ( 'INFO', 'DBTD_RUNTESTS', 'GLOBAL TEARDOWN FUNCTION IS NOT DEFINED');
	END IF;

	DBTD_LOG_MESSAGE_EXT ( 'INFO', 'DBTD_RUNTESTS', 'FINISH DBTD_RUNTESTS');
END;
/
ALTER PROCEDURE DBTD_RUNTESTS COMPILE; 
/

COMMIT;




