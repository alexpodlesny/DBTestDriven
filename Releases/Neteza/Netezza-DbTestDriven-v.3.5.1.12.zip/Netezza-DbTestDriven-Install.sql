/*
*************************************************************************************************
-- VERSION:	   DBTestDriven - Netezza - 3.5.1.12
-- COPYRIGHT:  (c) 2011-2012 Job Continent, DBTestDriven Project by Alex Podlesny
-- http://www.dbtestdriven.com
*************************************************************************************************
*/

--************************************************************************************************
--CORE TABLE
--note: not all test runners will use this table 
--this table is the communication media for actively running test, all data in this table is temporary  
--this table will be cleaned before each test run when DBTD_RUNTESTSUITE procedure iterates through the 
--available tests in the test suite. external test runners might not use this stored procedure
CREATE TABLE DBTD_TBL_ACTIVETEST (
	Owner		VARCHAR (128) NULL,			--Reserverd
	TestName	VARCHAR (128) NULL,
	IsError		BOOLEAN NOT NULL DEFAULT FALSE,
	IsFailure	BOOLEAN NOT NULL DEFAULT FALSE,
	Message		NVARCHAR (4000) NOT NULL 
); 

--************************************************************************************************
--CORE TABLE: stores the current list of all tests, 
--used by test runner 
--to update the list run DBTD_REFRESH_TESTSLIST stored procedure
CREATE TABLE DBTD_TBL_TESTSLIST (
	Owner					VARCHAR(128),			--Test Owner
	TestName				VARCHAR(128),			--Test Name
	Suite					VARCHAR(128),			--Test Suite
	HasSetup				BOOLEAN DEFAULT FALSE,
	HasTeardown				BOOLEAN DEFAULT FALSE,
	Ignore					BOOLEAN DEFAULT FALSE,	--false by default
	SuiteSetupName			VARCHAR(128),			
	SuiteTeardownName		VARCHAR(128),			
	SuiteSetupRunOnce		BOOLEAN DEFAULT FALSE,			
	SuiteTeardownRunOnce	BOOLEAN DEFAULT FALSE			
	-- reserved columns
	--ObjectID				INT
);

--************************************************************************************************
--CORE TABLE
--stores latest test results information for a given test
--while DBTD_TBL_TESTSLIST has most unit tests list this table might have old unit test information
--NOTE: it pay attention to the test start and stop time, this table might include 
--      information about older test that failed long time ago.
CREATE TABLE DBTD_TBL_TESTRESULT (
	TestName		VARCHAR(128) NOT NULL,		--Unit test (or test suite) name
	Owner			VARCHAR(128),				--Test Owner
	RunCount		INT,						--Number of times test have run 
	StartTime		TIMESTAMP NOT NULL ,		--Last start time
	StopTime		TIMESTAMP NULL ,			--Last finish time
	IsError			BOOLEAN DEFAULT FALSE,		--TRUE if has errors
	IsFailure		BOOLEAN DEFAULT FALSE,		--TRUE if failed 
	Status			VARCHAR(50) NULL,			--SUCCESS, FAILURE, ERROR, etc.
	Message			NVARCHAR(4000) NULL			--Error, warning, failure or other message
);

--************************************************************************************************
-- CORE TABLE
--active log table for the framework
CREATE TABLE DBTD_TBL_LOG (
	LogID		INT NOT NULL ,
	EventType	VARCHAR(10) NULL,		--INFO, ERROR, WARNING, DEBUG etc.
	EventSource VARCHAR(128) NULL,
	EventTime	DATETIME  NULL,
	Message		NVARCHAR (4000) NULL
);

--************************************************************************************************
--NOTE: view signatures might be different for different database engines
--CORE VIEW
--View provides list of availble data types and their known aliases 
CREATE OR REPLACE VIEW DBTD_VW_DATATYPE
AS
SELECT 
	UPPER(DataType) AS DataType, 
	UPPER(DataType) AS Alias, 
	Description, 
	'Sourced from system view _V_DATATYPE' AS DataSource 
FROM 
	_V_DATATYPE
UNION ALL --get all records and it is ok to have duplicates
SELECT 
	DISTINCT
	UPPER(A.TYPE_NAME) AS DataType,
	UPPER(T.DataType) AS Alias, 
	T.Description,
	'Sourced from sys view _V_SYS_DATATYPE' AS DataSource
FROM 
	_V_DATATYPE AS T
	FULL OUTER JOIN 
	_V_SYS_DATATYPE AS A
	ON 
		T.OBJID = A.TYPE_OID
UNION ALL SELECT 'INT', 'INTEGER','32-bit values in range -2,147,483,648 to 2,147,483,647 4 bytes','Netezza Database User Guide 5.0.x'
UNION ALL SELECT 'DOUBLE PRECISION', 'FLOAT8','Equivalent to float(15). 8 bytes','Netezza Database User Guide 5.0.x' 
UNION ALL SELECT 'CHARACTER', 'CHAR','Fixed length, blank padded to length n. The default value of n is 1. The maximum character string size is 64,000','Netezza Database User Guide 5.0.x'
UNION ALL SELECT 'CHARACTER VARYING', 'VARCHAR','Variable length to a maximum length of n. No blank padding, stored as entered. The maximum character string size is 64,000','Netezza Database User Guide 5.0.x'
UNION ALL SELECT 'NATIONAL CHARACTER VARYING', 'NVARCHAR','Variable length to a maximum length of n. The maximum length of 16,000 characters','Netezza Database User Guide 5.0.x'
UNION ALL SELECT 'NATIONAL CHARACTER', 'NCHAR','length to a maximum length of n. The maximum length of 16,000 characters','Netezza Database User Guide 5.0.x'
UNION ALL SELECT 'TIME WITH TIME ZONE', 'TIMETZ','Hours, minutes, seconds to 6 decimal positions, and time zone offset from GMT. Ranging from 00:00:00.000000+13:00 to 23:59:59.999999-12:59.','Netezza Database User Guide 5.0.x'
UNION ALL SELECT 'TIMESPAN', 'INTERVAL','An interval of time. This is a nonstandard implementation. For more information','Netezza Database User Guide 5.0.x'
UNION ALL SELECT 'TIMESTAMP', 'DATETIME','Built-in NZ type','Netezza Stored ProceduresDeveloper Guide 5.X'
UNION ALL SELECT 'TIME', 'TIME WITHOUT TIME ZONE','Built-in NZ type','Netezza Stored ProceduresDeveloper Guide 5.X'
UNION ALL SELECT 'ABSTIME', 'ABSTIME','Built-in NZ type','Sys Tables _V_RELATION_COLUMN_DEF'
UNION ALL SELECT 'INT2VECTOR','INT2VECTOR','Built-in NZ type','Sys Tables _V_RELATION_COLUMN_DEF'
UNION ALL SELECT 'NAME','NAME','Built-in NZ type','Sys Tables _V_RELATION_COLUMN_DEF'
UNION ALL SELECT 'OID','OID','Built-in NZ type','Sys Tables _V_RELATION_COLUMN_DEF'
UNION ALL SELECT 'REGPROC','REGPROC','Built-in NZ type','Sys Tables _V_RELATION_COLUMN_DEF'
UNION ALL SELECT 'TEXT','TEXT','Built-in NZ type','Sys Tables _V_RELATION_COLUMN_DEF'
UNION ALL SELECT 'DEC','NUMERIC','Alias of the Numeric(18) ','Netezza Stored ProceduresDeveloper Guide 5.X'
UNION ALL SELECT 'FLOAT','DOUBLE PRECISION','Built-in NZ type','Sys Tables _V_RELATION_COLUMN_DEF'
UNION ALL SELECT 'DOUBLE','DOUBLE PRECISION','Built-in NZ type','Netezza Stored ProceduresDeveloper Guide 5.X'
UNION ALL SELECT 'FLOAT','REAL','Built-in NZ type','Sys Tables _V_RELATION_COLUMN_DEF'
;

--************************************************************************************************
--REPORTING 
--stores report parameter data, in particular the suite name 
CREATE TABLE DBTD_TBL_RPTPARAM (
	ReportID	DATETIME  NULL,		--unique ID that identifies set of parameters
	Value		VARCHAR(128) NULL	--parameter value
);

--************************************************************************************************
--REPORTING 
--NOTE: !!! Object available only in Netezza !!! 
--      This table do not intended to have any records in it. table used as refference to return 
--      table value from DBTD_REPORT stored procedure.
--NOTE: To get correctly formatted report always ORDER BY SectionOrder ASC, SuiteOrder ASC, TestOrder ASC
CREATE TABLE DBTD_TBL_RPT_REFTABLE (
	RptLine			VARCHAR(4000) NULL,
	SectionOrder	INT NULL, 
	SuiteOrder		INT NULL, 
	TestOrder		INT NULL
);

--************************************************************************************************
--CORE OBJECT
--note: not all databases utilize sequence, this object is DB specific 
--general DB Test Driven sequence that generated unique IDs for the framework
CREATE SEQUENCE DBTD_SEQUENCE AS INTEGER
	START WITH 1 
	INCREMENT BY 1
	MINVALUE 1 
	NO MAXVALUE 
	NO CYCLE;

--************************************************************************************************
-- CORE
-- saves the INFO message in the log
-- used by native and external test runners 
-- PARAMETER 1 - 	v_Message 
CREATE OR REPLACE PROCEDURE DBTD_LOG_MESSAGE_EXT 
(
	VARCHAR(10),	--Message type
	VARCHAR(128),	--Message Source
	NVARCHAR(4000)  --Message
)
LANGUAGE NZPLSQL
RETURNS BOOLEAN
AS
BEGIN_PROC
DECLARE 
	v_Type VARCHAR(10);
	v_Source VARCHAR(128);
	v_Message NVARCHAR(4000);
BEGIN
	v_Type := $1;
	v_Source := $2;
	v_Message := $3;
	INSERT INTO DBTD_TBL_LOG(LogID, EventType, EventSource, EventTime, Message) 
	VALUES( NEXT VALUE FOR DBTD_SEQUENCE, v_Type, v_Source, NOW(), v_Message);
	RETURN TRUE;
END;
END_PROC;

--************************************************************************************************
-- CORE
-- Saves message with provided type into the log table.
-- used by native and external test runners 
CREATE OR REPLACE PROCEDURE DBTD_LOG_MESSAGE 
(
	VARCHAR(10),	-- 	Message Type INFO, DEBUG, WARNING, ERROR, etc.
	NVARCHAR(4000)	-- 	Message to log
)
LANGUAGE NZPLSQL
RETURNS BOOLEAN
AS
BEGIN_PROC
DECLARE 
	v_Type VARCHAR(10);
	v_Message NVARCHAR(4000);
BEGIN
	v_Type := $1;
	v_Message :=$2;
	CALL DBTD_LOG_MESSAGE_EXT (v_Type, NULL,v_Message);
END;
END_PROC;


--************************************************************************************************
--internal CORE procedure that saves state for Unit Test that is running or have run in the past 
--note: when NULL value is supplied then this column does not get updated in the table   
CREATE OR REPLACE PROCEDURE DBTD_SaveState
(
	VARCHAR(128),	--Unit Test
	VARCHAR(128),	--Test Owner
	VARCHAR(50),	--Status,  note: when NULL value is supplied then this column does not get updated in the table  
	BOOLEAN,		--Error,   note: when NULL value is supplied then this column does not get updated in the table   
	BOOLEAN,		--Failure, note: when NULL value is supplied then this column does not get updated in the table  
	NVARCHAR(4000)	--Message
)
LANGUAGE NZPLSQL
RETURNS BOOLEAN
AS
BEGIN_PROC
DECLARE 
	v_TestName	VARCHAR(128);	
	v_TestOwner	VARCHAR(128);	
	v_Status	VARCHAR(50);	
	v_IsError	BOOLEAN;		
	v_IsFailure	BOOLEAN;		
	v_Message	NVARCHAR(4000);	
BEGIN 
	v_TestName	:= $1;
	v_TestOwner	:= $2;
	v_Status	:= $3;
	v_IsError	:= $4;
	v_IsFailure	:= $5;
	v_Message	:= $6;
	CALL DBTD_LOG_MESSAGE_EXT ( 'DEBUG', 'DBTD_SaveState', v_TestName );

	UPDATE	DBTD_TBL_TESTRESULT
	SET		
		StopTime = NOW(),
		IsError = 
				CASE 
					WHEN v_IsError IS NULL THEN IsError --do not change state if null value provided
					ELSE v_IsError --set new state if it is not a null
				END,
		IsFailure = 
				CASE
					WHEN v_IsFailure IS NULL THEN IsFailure --do not change state if null value provided
					ELSE v_IsFailure --set new state if it is not a null
				END,
		Status =
				CASE
					WHEN v_Status IS NULL THEN Status --do not change state if null value provided
					ELSE v_Status --set new state if it is not a null
				END,
		Message = v_Message
	WHERE 
		UPPER(TestName) = UPPER(v_TestName)
	--	AND UPPER(Owner) = UPPER(v_TestOwner)
	; 

	UPDATE DBTD_TBL_ACTIVETEST
	SET 
		IsError = 
				CASE 
					WHEN v_IsError IS NULL THEN IsError --do not change state if null provided
					ELSE v_IsError --set new state if it is not a null
				END,
		IsFailure = 
				CASE
					WHEN v_IsFailure IS NULL THEN IsFailure --do not change state if null provided
					ELSE v_IsFailure --set new state if it is not a null
				END,
		Message = v_Message
	WHERE 
		UPPER(TestName) = UPPER(v_TestName)
	--	AND UPPER(Owner) = UPPER(v_TestOwner)
	; 
END;
END_PROC;


--************************************************************************************************
-- CORE
--refreshes DBTD_TBL_TESTSLIST
--this is one of the core stored procedures that refreshes the list of all available unit tests
--in the database   
CREATE OR REPLACE PROCEDURE DBTD_REFRESH_TESTSLIST()
LANGUAGE NZPLSQL
RETURNS REFTABLE(DBTD_TBL_TESTSLIST)
AS
BEGIN_PROC
DECLARE
    v_GlobalSetup VARCHAR(128);
    v_TestName VARCHAR(128);
    v_ProcName VARCHAR(128);
    v_SuiteSetupName VARCHAR(128);
    v_SuiteTeardownName VARCHAR(128);
    v_HasSetup BOOLEAN;
	v_RunOnce BOOLEAN;
    v_Ignore BOOLEAN;
	v_SetupName VARCHAR(128);
	v_TeardownName VARCHAR(128);
    v_HasTeardown BOOLEAN;
    v_Suite VARCHAR(128);
    v_TestPrefix VARCHAR(10);
    v_LikeUnderscore CHAR(3);
    v_ParentTestPrefix CHAR(3);
    v_TempRecords RECORD;
    v_TempRecordsB RECORD;
    v_CursorSQL VARCHAR(8000);
	v_ErrorMessage VARCHAR(255);
BEGIN
	CALL DBTD_LOG_MESSAGE_EXT ( 'DEBUG', 'DBTD_REFRESH_TESTSLIST', 'START - DBTD_REFRESH_TESTSLIST()');

	CALL DBTD_LOG_MESSAGE_EXT ( 'DEBUG', 'DBTD_REFRESH_TESTSLIST', 'PHASE ONE: remove old records');
    DELETE FROM DBTD_TBL_TESTSLIST;
    
	CALL DBTD_LOG_MESSAGE_EXT ( 'DEBUG', 'DBTD_REFRESH_TESTSLIST', 'PHASE TWO: refresh unit test information');
	v_HasSetup := 0;
    v_HasTeardown := 0;
    v_LikeUnderscore := '_';
    v_TestPrefix := 'UT'||v_LikeUnderscore;
    v_ParentTestPrefix := 'UT_';
	v_GlobalSetup := 'UT_SETUP';
	
	--note: we use cursor to extract data because we are running into "ERROR: Type 'bytea' not supported by IBM Netezza SQL"
	v_CursorSQL := '
	SELECT 
		FULL_NAME, 
		SUITE_NAME, 
		NVL(S.HAS_SETUP, FALSE) AS HAS_SETUP, 
		NVL(TR.HAS_TEARDOWN, FALSE) AS HAS_TEARDOWN, 
		NVL(I.IGNORED_TEST, FALSE) AS IGNORED_TEST,
		SUITE_SETUP_NAME, 
		SUITE_TEARDOWN_NAME
	FROM
		(SELECT OBJID, FULL_NAME, SUITE_NAME, ''UT_''||SUITE_NAME||''_SETUP'' AS SUITE_SETUP_NAME, ''UT_''||SUITE_NAME||''_TEARDOWN'' AS SUITE_TEARDOWN_NAME	
		FROM
			(SELECT OBJID,FULL_NAME, CASE WHEN (POSITION(''_'' in NO_PREFIX) != 0) THEN SUBSTRING(NO_PREFIX, 1, POSITION(''_'' in NO_PREFIX) - 1) ELSE NO_PREFIX END AS SUITE_NAME
			FROM
				(SELECT OBJID, PROCEDURE AS FULL_NAME, SUBSTRING(PROCEDURE, 4) AS NO_PREFIX	FROM _V_PROCEDURE WHERE UPPER(PROCEDURE) like ''UT\_%'' ) AS T
				WHERE 
					UPPER(FULL_NAME) != ''UT_SETUP'' 
					AND UPPER(FULL_NAME) != ''UT_TEARDOWN'' 
					AND UPPER(FULL_NAME) not like ''UT\_%\_SETUP'' 
					AND UPPER(FULL_NAME) not like ''UT\_%\_TEARDOWN'' ) AS TT
		) AS TTT
		LEFT OUTER JOIN 
		( SELECT PROCEDURE AS SETUP_NAME, TRUE AS HAS_SETUP FROM _V_PROCEDURE WHERE UPPER(PROCEDURE) like ''UT\_%\_SETUP'' ) AS S
		ON UPPER(TTT.SUITE_SETUP_NAME) = UPPER(S.SETUP_NAME)
		LEFT OUTER JOIN 
		(SELECT PROCEDURE AS TEARDOWN_NAME, TRUE AS HAS_TEARDOWN FROM _V_PROCEDURE WHERE  UPPER(PROCEDURE) like ''UT\_%\_TEARDOWN'' ) AS TR
		ON UPPER(TTT.SUITE_TEARDOWN_NAME) = UPPER(TR.TEARDOWN_NAME)
		LEFT OUTER JOIN
		( SELECT OBJID, PROCEDURE AS IGNORED_TEST_NAME, TRUE AS IGNORED_TEST FROM _V_PROCEDURE WHERE UPPER(PROCEDURESOURCE) LIKE ''%DBTD\_IGNORE%'') AS I 
		ON TTT.OBJID = I.OBJID;
	';
    FOR v_TempRecords IN EXECUTE v_CursorSQL LOOP
		BEGIN
			v_TestName 		:= v_TempRecords.FULL_NAME;
			v_HasSetup 		:= v_TempRecords.HAS_SETUP;
			v_HasTeardown 	:= v_TempRecords.HAS_TEARDOWN;
			v_Suite 		:= v_TempRecords.SUITE_NAME;
			v_Ignore		:= v_TempRecords.IGNORED_TEST;
			v_SetupName		:= v_TempRecords.SUITE_SETUP_NAME;
			v_TeardownName	:= v_TempRecords.SUITE_TEARDOWN_NAME;

			INSERT INTO  DBTD_TBL_TESTSLIST ( TestName, Suite, HasSetup, HasTeardown, Ignore, SuiteSetupName, SuiteTeardownName )
			VALUES ( v_TestName, v_Suite, v_HasSetup, v_HasTeardown, v_Ignore, v_SetupName, v_TeardownName);
		EXCEPTION
			WHEN OTHERS THEN
				BEGIN
					v_ErrorMessage := 'DBTD_REFRESH_TESTSLIST ERROR: ' || sqlerrm;
					CALL DBTD_LOG_MESSAGE_EXT ('ERROR', 'DBTD_REFRESH_TESTSLIST', v_ErrorMessage );
				END;
		END;
    END LOOP;

	CALL DBTD_LOG_MESSAGE_EXT ( 'DEBUG', 'DBTD_REFRESH_TESTSLIST', 'PHASE THREE: update unit test records with extra information');
	--note: we use cursor to extract data because we are running into "ERROR: Type 'bytea' not supported by IBM Netezza SQL"
	v_CursorSQL := '
	SELECT 
		UPPER(PROCEDURE) AS ProcName,
		TRUE AS RunOnce
	FROM 
		_V_PROCEDURE 
	WHERE 
		UPPER(PROCEDURESOURCE) LIKE ''%DBTD\_RUN\_ONCE%''
		AND UPPER(PROCEDURE) != ''DBTD_RUN_ONCE'';
	';
    FOR v_TempRecordsB IN EXECUTE v_CursorSQL LOOP
		BEGIN
			v_ProcName	:= v_TempRecordsB.ProcName;
			v_RunOnce	:= v_TempRecordsB.RunOnce;
			--update setup info
			UPDATE DBTD_TBL_TESTSLIST 
			SET SuiteSetupRunOnce = v_RunOnce
			WHERE SuiteSetupName = v_ProcName;
			--update teardown info
			UPDATE DBTD_TBL_TESTSLIST 
			SET SuiteTeardownRunOnce = v_RunOnce
			WHERE SuiteTeardownName = v_ProcName;
		EXCEPTION
			WHEN OTHERS THEN
				BEGIN
					v_ErrorMessage := 'DBTD_REFRESH_TESTSLIST ERROR: ' || sqlerrm;
					CALL DBTD_LOG_MESSAGE_EXT ('ERROR', 'DBTD_REFRESH_TESTSLIST', v_ErrorMessage );
				END;
		END;
    END LOOP;

	CALL DBTD_LOG_MESSAGE_EXT ( 'DEBUG', 'DBTD_REFRESH_TESTSLIST', 'FINISH - DBTD_REFRESH_TESTSLIST()');
    RETURN REFTABLE;
END;
END_PROC;

--************************************************************************************************
--note: used it to report errors in Unit Tests
--saves error into log table and raise the error to the parent process
--v_ErrorID  = 14000 - is the user error,  
--v_ErrorID  != 14000 - is the NETEZZA error
CREATE OR REPLACE PROCEDURE DBTD_ERROR 
(
	INTEGER	--error number
) 
LANGUAGE NZPLSQL
RETURNS BOOLEAN
AS
BEGIN_PROC
DECLARE 
	v_Message NVARCHAR(4000);
	v_TestName VARCHAR(128);	
	v_ErrorID INT;
BEGIN
	CALL DBTD_LOG_MESSAGE_EXT ( 'DEBUG', 'DBTD_ERROR', 'CALL DBTD_ERROR (INTEGER) ');

	v_ErrorID := $1;
	IF (v_ErrorID = 14000) THEN 
		-- user defined error message generated by raiserrror 
		v_Message := 'USER DEFINED ERROR ' || CAST( v_ErrorID AS VARCHAR(50));
	ELSE
		v_Message := 'NETEZZA ERROR ' || CAST( v_ErrorID AS VARCHAR(50)); 
	END IF;

	SELECT TestName INTO v_TestName	FROM DBTD_TBL_ACTIVETEST LIMIT 1;

	CALL DBTD_SaveState (v_TestName, NULL, 'ERROR', TRUE, NULL, NVL(v_Message,'(NO DESCRIPTION)'));

	CALL DBTD_LOG_MESSAGE_EXT ( 'ERROR', v_TestName, NVL( v_Message,'(NO DESCRIPTION)'));

	RAISE EXCEPTION '%', v_Message;

	RETURN TRUE;
END;
END_PROC;

--************************************************************************************************
--records failure message in the log and raises exception UP to the parent process
CREATE OR REPLACE PROCEDURE DBTD_FAILURE 
(
	NVARCHAR(4000)	-- Failure Message
)
LANGUAGE NZPLSQL
RETURNS BOOLEAN
AS
BEGIN_PROC
DECLARE 
	v_Message VARCHAR(4000);
	v_TestName VARCHAR(128);	
BEGIN
	CALL DBTD_LOG_MESSAGE_EXT ( 'DEBUG', 'DBTD_FAILURE', 'CALL DBTD_FAILURE (NVARCHAR(255))');
	v_Message := $1;
	SELECT TestName INTO v_TestName	FROM DBTD_TBL_ACTIVETEST LIMIT 1;

	CALL DBTD_LOG_MESSAGE_EXT ( 'FAILURE', v_TestName, NVL( v_Message ,'(NO DESCRIPTION)'));

	CALL DBTD_SaveState (v_TestName, NULL, 'FAILURE', NULL, TRUE, NVL(v_Message,'(NO DESCRIPTION)'));

	RAISE EXCEPTION '%', v_Message;

	RETURN TRUE;
END;
END_PROC;

--************************************************************************************************
-- assert function that takes SQL query, executes it and 
-- report failure if script succeeded  
CREATE OR REPLACE PROCEDURE DBTD_ASSERT_WILL_FAIL 
(
	NVARCHAR(4000), --SQL query
	NVARCHAR(255)	--Message
)
LANGUAGE NZPLSQL
RETURNS BOOLEAN
AS
BEGIN_PROC
DECLARE 
	v_SQL NVARCHAR(4000);
	v_UserMessage NVARCHAR(255);
	v_IsFailed BOOLEAN;
	v_Message VARCHAR(4000);
	v_TestName VARCHAR(128); 
BEGIN
	v_SQL := $1;
	v_UserMessage := $2;

	v_IsFailed := FALSE; 
	v_Message := 'CALL DBTD_ASSERT_WILL_FAIL';
	CALL DBTD_LOG_MESSAGE_EXT ('DEBUG', 'DBTD_ASSERT_WILL_FAIL', v_Message);

	BEGIN
		EXECUTE IMMEDIATE v_SQL;
		v_Message := 'SQL EXPECTED TO FAIL, but it did not.'; 
		CALL DBTD_FAILURE (v_Message); 
	EXCEPTION
	WHEN OTHERS THEN
		BEGIN
			v_Message := 'Listed above SQL FAILED AS EXPECTED with error: ' ||  CAST(sqlerrm AS VARCHAR(3500))  ;
			CALL DBTD_LOG_MESSAGE_EXT ('INFO', 'DBTD_ASSERT_WILL_FAIL (1)', v_SQL);
			CALL DBTD_LOG_MESSAGE_EXT ('INFO', 'DBTD_ASSERT_WILL_FAIL (2)', v_Message);
			--update status with the SUCCESS message in case when DBTD_ASSERT_WILL_FAIL 
			--runs to checks failure of a unit test that uses DBTD_FAILURE\DBTD_ERROR to report status

			SELECT TestName into v_TestName
			FROM DBTD_TBL_ACTIVETEST LIMIT 1;

			CALL DBTD_SaveState (v_TestName, NULL, 'SUCCESS', FALSE, FALSE, NVL( v_Message ,'SUCCESS'));
		END;
	END;
END;
END_PROC;


--************************************************************************************************
-- assert function that takes SQL query, executes it and 
-- reports failure if script failed
CREATE OR REPLACE PROCEDURE DBTD_ASSERT_WILL_SUCCEED 
(	
	NVARCHAR(4000),	--SQL Query
	NVARCHAR(255)	--Message
)
LANGUAGE NZPLSQL
RETURNS BOOLEAN
AS
BEGIN_PROC
DECLARE 
	v_SQL NVARCHAR(4000);
	v_UserMessage NVARCHAR(255);
	v_Message VARCHAR(8000); 
	v_IsFailed BOOLEAN;
BEGIN
	v_SQL := $1;
	v_UserMessage := $2;

	v_IsFailed := FALSE; 
	v_Message := 'DBTD_ASSERT_WILL_SUCCEED';
	CALL DBTD_LOG_MESSAGE_EXT ('DEBUG', 'DBTD_ASSERT_WILL_SUCCEED', v_Message);

	BEGIN
		EXECUTE IMMEDIATE v_SQL;
		v_IsFailed := FALSE;
		v_Message := '';
	EXCEPTION
	WHEN OTHERS THEN
		BEGIN
			v_IsFailed := TRUE;
			v_Message := 'FAILED WITH ERROR: ' || CAST(sqlerrm AS VARCHAR(4000));
		END;
	END;

	IF (v_IsFailed = TRUE) THEN
		v_Message := 'Provided SQL EXPECTED TO SUCCEED, but it has ' || v_Message; 
		CALL DBTD_FAILURE (v_Message); 
	END IF;

END;
END_PROC;



--************************************************************************************************
-- assert function that takes actual value, expected value, compares them for equality 
-- reports failure if the not equal
CREATE OR REPLACE PROCEDURE DBTD_ASSERT_ARE_EQUAL 
(
	NVARCHAR(255),	--Actual Value
	NVARCHAR(255),	--Expected Value
	NVARCHAR(255)	--Error Message
)
LANGUAGE NZPLSQL
RETURNS BOOLEAN
AS
BEGIN_PROC
DECLARE 
	v_ActualValue  VARCHAR(255);
	v_ExpectedValue VARCHAR(255);
	v_UserMessage VARCHAR(255);
	v_Message VARCHAR(255);
BEGIN
	CALL DBTD_LOG_MESSAGE_EXT ( 'DEBUG', 'DBTD_ASSERT_ARE_EQUAL', 'CALL DBTD_ASSERT_ARE_EQUAL (NVARCHAR(255), NVARCHAR(255), NVARCHAR(255))');

	v_ActualValue := $1;
	v_ExpectedValue := $2;
	v_UserMessage := $3;
	
	IF (v_ActualValue != v_ExpectedValue)  THEN
		v_Message := v_UserMessage 
			|| ' Actual value is NOT EQUAL Expected value. ' 
			|| ' EXPECTED: ' || v_ExpectedValue 
			|| ' ACTUAL: ' || v_ActualValue ; 
		CALL DBTD_FAILURE (v_Message); 
		RETURN FALSE;
	END IF;
	RETURN TRUE;
END;
END_PROC;

--************************************************************************************************
-- assert function that takes actual value, expected value, compares them for equality 
-- reports failure if values are equal
CREATE OR REPLACE PROCEDURE DBTD_ASSERT_ARE_NOT_EQUAL 
(
	NVARCHAR(255),	--Actual Value
	NVARCHAR(255),	--Expected Value
	NVARCHAR(255)	--Error Message
)
LANGUAGE NZPLSQL
RETURNS BOOLEAN
AS
BEGIN_PROC
DECLARE 
	v_ActualValue  VARCHAR(255);
	v_ExpectedValue VARCHAR(255);
	v_UserMessage VARCHAR(255);
	v_Message VARCHAR(255);
BEGIN
	CALL DBTD_LOG_MESSAGE_EXT ( 'DEBUG', 'DBTD_ASSERT_ARE_NOT_EQUAL', 'CALL DBTD_ASSERT_ARE_NOT_EQUAL (NVARCHAR(255), NVARCHAR(255), NVARCHAR(255))');

	v_ActualValue := $1;
	v_ExpectedValue := $2;
	v_UserMessage := $3;
	
	IF (v_ActualValue = v_ExpectedValue)  THEN
		v_Message := v_UserMessage 
			|| ' Actual value is EQUAL to Not Expected value. ' 
			|| ' NOT EXPECTED: ' || v_ExpectedValue 
			|| ' ACTUAL: ' || v_ActualValue ; 
		CALL DBTD_FAILURE (v_Message); 
		RETURN FALSE;
	END IF;
	RETURN TRUE;
END;
END_PROC;

--************************************************************************************************
-- assert function that takes actual value, expected value, 
-- and checks that actual value is greater or equal then expected value 
-- reports failure if values is equal or smaller
CREATE OR REPLACE PROCEDURE DBTD_ASSERT_IS_LESS_OR_EQUAL 
(
	DECIMAL(18,8),	--Actual Value
	DECIMAL(18,8),	--Expected Value
	NVARCHAR(255)	--Error Message
)
LANGUAGE NZPLSQL
RETURNS BOOLEAN
AS
BEGIN_PROC
DECLARE 
	v_ActualValue  DECIMAL(18,8);
	v_ExpectedValue DECIMAL(18,8);
	v_UserMessage VARCHAR(255);
	v_Message VARCHAR(255);
BEGIN
	CALL DBTD_LOG_MESSAGE_EXT ( 'DEBUG', 'DBTD_ASSERT_IS_LESS_OR_EQUAL', 'CALL DBTD_ASSERT_IS_LESS_OR_EQUAL (DECIMAL(18,8),DECIMAL(18,8),NVARCHAR(255))');

	v_ActualValue := $1;
	v_ExpectedValue := $2;
	v_UserMessage := $3;
	
	IF (v_ActualValue > v_ExpectedValue)  THEN
		v_Message := v_UserMessage 
			|| ' Actual value is NOT LESS OR EQUAL Expected value. ' 
			|| ' EXPECTED: ' || CAST(v_ExpectedValue AS  VARCHAR(255))
			|| ' ACTUAL: ' || CAST(v_ActualValue AS  VARCHAR(255)) ; 
		CALL DBTD_FAILURE (v_Message); 
		RETURN FALSE;
	END IF;
	RETURN TRUE;
END;
END_PROC;

--************************************************************************************************
-- assert function that takes actual value, expected value, 
-- and checks that actual value is greater then expected value 
-- reports failure if values is equal or smaller
CREATE OR REPLACE PROCEDURE DBTD_ASSERT_IS_GREATER 
(
	DECIMAL(18,8),	--Actual Value
	DECIMAL(18,8),	--Expected Value
	NVARCHAR(255)	--Error Message
)
LANGUAGE NZPLSQL
RETURNS BOOLEAN
AS
BEGIN_PROC
DECLARE 
	v_ActualValue  DECIMAL(18,8);
	v_ExpectedValue DECIMAL(18,8);
	v_UserMessage VARCHAR(255);
	v_Message VARCHAR(255);
BEGIN
	CALL DBTD_LOG_MESSAGE_EXT ( 'DEBUG', 'DBTD_ASSERT_IS_GREATER', 'CALL DBTD_ASSERT_IS_GREATER (DECIMAL(18,8),DECIMAL(18,8),NVARCHAR(255))');

	v_ActualValue := $1;
	v_ExpectedValue := $2;
	v_UserMessage := $3;
	
	IF (v_ActualValue <= v_ExpectedValue)  THEN
		v_Message := v_UserMessage 
			|| ' Actual value is NOT GREATER then Expected value. ' 
			|| ' EXPECTED: ' || CAST(v_ExpectedValue AS  VARCHAR(255))
			|| ' ACTUAL: ' || CAST(v_ActualValue AS  VARCHAR(255)) ; 
		CALL DBTD_FAILURE (v_Message); 
		RETURN FALSE;
	END IF;
	RETURN TRUE;
END;
END_PROC;

--************************************************************************************************
-- assert function that takes actual timestamp value, expected timestamp value, 
-- and checks that actual timestamp value is greater, then expected timestamp value 
-- reports failure if values is equal or smaller
CREATE OR REPLACE PROCEDURE DBTD_ASSERT_DATETIME_IS_GREATER 
(
	DATETIME,		--Actual Value
	DATETIME,		--Expected Value
	NVARCHAR(255)	--Error Message
)
LANGUAGE NZPLSQL
RETURNS BOOLEAN
AS
BEGIN_PROC
DECLARE 
	v_ActualValue  DATETIME;
	v_ExpectedValue DATETIME;
	v_UserMessage VARCHAR(255);
	v_Message VARCHAR(2000);
BEGIN
	CALL DBTD_LOG_MESSAGE_EXT ( 'DEBUG', 'DBTD_ASSERT_DATETIME_IS_GREATER', 'CALL DBTD_ASSERT_DATETIME_IS_GREATER (DATETIME,DATETIME,NVARCHAR(255))');

	v_ActualValue := $1;
	v_ExpectedValue := $2;
	v_UserMessage := $3;
	
	IF (v_ActualValue <= v_ExpectedValue)  THEN
		v_Message := v_UserMessage 
			|| ' Actual value is NOT GREATER then Expected value. ' 
			|| ' EXPECTED: ' || CAST(v_ExpectedValue AS  VARCHAR(255))
			|| ' ACTUAL: ' || CAST(v_ActualValue AS  VARCHAR(255)) ; 
		CALL DBTD_FAILURE (v_Message); 
		RETURN FALSE;
	END IF;
	RETURN TRUE;
END;
END_PROC;

--************************************************************************************************
-- assert function that takes actual timestamp value, expected timestamp value, 
-- and checks that actual timestamp value is greater or equal then expected timestamp value 
-- reports failure if values is smaller
CREATE OR REPLACE PROCEDURE DBTD_ASSERT_DATETIME_IS_GREATER_OR_EQUAL 
(
	DATETIME,		--Actual Value
	DATETIME,		--Expected value
	NVARCHAR(255)	--Error message
)
LANGUAGE NZPLSQL
RETURNS BOOLEAN
AS
BEGIN_PROC
DECLARE 
	v_ActualValue  DATETIME;
	v_ExpectedValue DATETIME;
	v_UserMessage VARCHAR(255);
	v_Message VARCHAR(2000);
BEGIN
	CALL DBTD_LOG_MESSAGE_EXT ( 'DEBUG',  'DBTD_ASSERT_DATETIME_IS_GREATER_OR_EQUAL', 'CALL DBTD_ASSERT_DATETIME_IS_GREATER_OR_EQUAL (DATETIME,DATETIME,NVARCHAR(255))');

	v_ActualValue := $1;
	v_ExpectedValue := $2;
	v_UserMessage := $3;
	
	IF (v_ActualValue < v_ExpectedValue)  THEN
		v_Message := v_UserMessage 
			|| ' Actual value is NOT GREATER OR EQUAL to Expected value. ' 
			|| ' EXPECTED: ' || CAST(v_ExpectedValue AS  VARCHAR(255))
			|| ' ACTUAL: ' || CAST(v_ActualValue AS  VARCHAR(255)) ; 
		CALL DBTD_FAILURE (v_Message); 
		RETURN FALSE;
	END IF;
	RETURN TRUE;
END;
END_PROC;

--************************************************************************************************
--checks if Boolean value is true and reports failure if it is not
CREATE OR REPLACE PROCEDURE DBTD_ASSERT_IS_TRUE 
(
	boolean,		--value to check
	NVARCHAR(255)	--error message
)
LANGUAGE NZPLSQL
RETURNS BOOLEAN
AS
BEGIN_PROC
DECLARE 
	v_ActualValue  boolean;
	v_UserMessage VARCHAR(255);
	v_Message VARCHAR(255);
BEGIN
	CALL DBTD_LOG_MESSAGE_EXT ( 'DEBUG', 'DBTD_ASSERT_IS_TRUE', 'CALL DBTD_ASSERT_IS_TRUE (boolean,NVARCHAR(255))');

	v_ActualValue := $1;
	v_UserMessage := $2;
	
	IF (v_ActualValue != true )  THEN
		v_Message := v_UserMessage || ' Actual value is NOT TRUE.' 
		CALL DBTD_FAILURE (v_Message); 
		RETURN FALSE;
	END IF;
	RETURN TRUE;
END;
END_PROC;

--************************************************************************************************
--CORE HINT
--procedure itself does nothing, however if it is found anywhere in the body of the unit test procedure code 
--then execution of the test will be ignored all together
CREATE OR REPLACE PROCEDURE DBTD_IGNORE 
( 
	VARCHAR(4000)	--Message
)
LANGUAGE NZPLSQL
RETURNS BOOLEAN
AS
BEGIN_PROC
DECLARE 
	v_Message VARCHAR(4000);
BEGIN
	v_Message := $1;
	CALL DBTD_LOG_MESSAGE_EXT ( 'INFO', 'DBTD_IGNORE', 'CALL DBTD_IGNORE(NVARCHAR(255)) with message ' || v_Message);
	RETURN TRUE;
END;
END_PROC;

--************************************************************************************************
--CORE HINT
--if it is found anywhere in the body of the suite setup or teardown then setup will execute ONLY ONCE 
--once per suite and will not execute for the each test same will happen with teardown procedure. 
CREATE OR REPLACE PROCEDURE DBTD_RUN_ONCE 
( 
	VARCHAR(4000)	--Message 
)
LANGUAGE NZPLSQL
RETURNS BOOLEAN
AS
BEGIN_PROC
DECLARE 
	v_Message VARCHAR(4000);
BEGIN
	v_Message := $1;
	--CALL DBTD_LOG_MESSAGE_EXT ('DEBUG', 'DBTD_RUN_ONCE', 'Running DBTD_RUN_ONCE Hint Procedure');
	CALL DBTD_LOG_MESSAGE_EXT ( 'INFO', 'DBTD_RUN_ONCE', 'CALL DBTD_RUN_ONCE(NVARCHAR(4000)) with message ' || v_Message);
	RETURN TRUE;
END;
END_PROC;

--************************************************************************************************
-- checks that table has expected number of records base on supplied condition
CREATE OR REPLACE PROCEDURE DBTD_ASSERT_IS_EXPECTED_COUNT 
(
	BIGINT,			--expexted value
	NVARCHAR(255),	--table name
	NVARCHAR(255),	--condition
	NVARCHAR(255)	--user message
)
LANGUAGE NZPLSQL
RETURNS BOOLEAN
AS
BEGIN_PROC
DECLARE 
	v_ActualValue BIGINT;
	v_ExpectedValue BIGINT;
	v_TableName VARCHAR(255);
	v_Condition VARCHAR(255);
	v_UserMessage VARCHAR(255);
	v_Message VARCHAR(255);
	v_SQL NVARCHAR(2000);
	v_REC RECORD;
BEGIN
	CALL DBTD_LOG_MESSAGE_EXT ( 'DEBUG', 'DBTD_ASSERT_IS_EXPECTED_COUNT', 'CALL DBTD_ASSERT_IS_TRUE (boolean,NVARCHAR(255))');

	v_ExpectedValue := $1;
	v_TableName := $2;
	v_Condition := $3;
	v_UserMessage := $4;

	v_SQL := 'SELECT COUNT(1) AS CT FROM ' || v_TableName; 
	IF ((v_Condition IS NOT NULL) AND (TRIM(v_Condition) != '')) THEN
		v_SQL := v_SQL || ' WHERE ' || v_Condition;
	END IF;
	v_SQL := v_SQL|| ';';

	-- Need a loop to get results from the dynamic query.
	FOR v_REC IN EXECUTE v_SQL LOOP
		v_ActualValue := v_REC.CT;
	EXIT;
	END LOOP;
	IF (v_ActualValue IS NULL) THEN 
		v_ActualValue := 0; 
	END IF;
		
	IF (v_ActualValue != v_ExpectedValue )  THEN
		v_Message := v_UserMessage 
			|| ' Actual value is NOT EQUAL to Expected value. ' 
			|| ' EXPECTED: ' || CAST(v_ExpectedValue AS  VARCHAR(255))
			|| ' ACTUAL: ' || CAST(v_ActualValue AS  VARCHAR(255)) 
			|| ' For SQL query: ' || v_SQL;  
		CALL DBTD_FAILURE (v_Message); 
		RETURN FALSE;
	END IF;
	RETURN TRUE;
END;
END_PROC;

--************************************************************************************************
-- checks that table does not have expected number of records base on supplied condition
CREATE OR REPLACE PROCEDURE DBTD_ASSERT_IS_NOT_EXPECTED_COUNT 
(
	BIGINT,			--not expected value
	NVARCHAR(255),	--table name
	NVARCHAR(255),	--where condition
	NVARCHAR(255)	--Error message
)
LANGUAGE NZPLSQL
RETURNS BOOLEAN
AS
BEGIN_PROC
DECLARE 
	v_ActualValue BIGINT;
	v_NotExpectedValue BIGINT;
	v_TableName VARCHAR(255);
	v_Condition VARCHAR(255);
	v_UserMessage VARCHAR(255);
	v_Message VARCHAR(255);
	v_SQL NVARCHAR(2000);
	v_REC RECORD;
BEGIN
	CALL DBTD_LOG_MESSAGE_EXT ( 'DEBUG', 'DBTD_ASSERT_IS_NOT_EXPECTED_COUNT', 'CALL DBTD_ASSERT_IS_TRUE (boolean,NVARCHAR(255))');

	v_NotExpectedValue := $1;
	v_TableName := $2;
	v_Condition := $3;
	v_UserMessage := $4;

	v_SQL := 'SELECT COUNT(1) AS CT FROM ' || v_TableName; 
	IF ((v_Condition IS NOT NULL) AND (TRIM(v_Condition) != '')) THEN
		v_SQL := v_SQL || ' WHERE ' || v_Condition;
	END IF;
	v_SQL := v_SQL|| ';';

	-- Need a loop to get results from the dynamic query.
	FOR v_REC IN EXECUTE v_SQL LOOP
		v_ActualValue := v_REC.CT;
	EXIT;
	END LOOP;
		
	IF (v_ActualValue = v_NotExpectedValue )  THEN
		v_Message := v_UserMessage 
			|| ' Actual value is EQUAL to Not-Expected value. ' 
			|| ' NOT EXPECTED: ' || CAST(v_NotExpectedValue AS  VARCHAR(255))
			|| ' ACTUAL: ' || CAST(v_ActualValue AS  VARCHAR(255)) ; 
		CALL DBTD_FAILURE (v_Message); 
		RETURN FALSE;
	END IF;
	RETURN TRUE;
END;
END_PROC;

--************************************************************************************************
--checks that table is NOT empty and has records 
CREATE OR REPLACE PROCEDURE DBTD_ASSERT_TABLE_HAS_RECORDS 
(
	NVARCHAR(255),	--table name
	NVARCHAR(255)	--user message
)
LANGUAGE NZPLSQL
RETURNS BOOLEAN
AS
BEGIN_PROC
DECLARE
	v_TableName NVARCHAR(255);
	v_UserMessage NVARCHAR(255);
BEGIN
	v_TableName := $1;
	v_UserMessage := $2;

	CALL DBTD_LOG_MESSAGE_EXT ('DEBUG', 'DBTD_ASSERT_TABLE_HAS_RECORDS', 'Running DBTD_ASSERT_TABLE_HAS_RECORDS');
	CALL DBTD_ASSERT_IS_NOT_EXPECTED_COUNT (0, v_TableName, '', v_UserMessage);
END;
END_PROC;

--************************************************************************************************
--checks that table is empty and has no records 
CREATE OR REPLACE PROCEDURE DBTD_ASSERT_TABLE_HAS_NO_RECORDS 
(
	NVARCHAR(255),	--table name
	NVARCHAR(255)	--user message
)
LANGUAGE NZPLSQL
RETURNS BOOLEAN
AS
BEGIN_PROC
DECLARE
	v_TableName NVARCHAR(255);
	v_UserMessage NVARCHAR(255);
BEGIN
	v_TableName := $1;
	v_UserMessage := $2;

	CALL DBTD_LOG_MESSAGE_EXT ('DEBUG', 'DBTD_ASSERT_TABLE_HAS_NO_RECORDS', 'Running DBTD_ASSERT_TABLE_HAS_NO_RECORDS');
	CALL DBTD_ASSERT_IS_EXPECTED_COUNT (0, v_TableName, '', v_UserMessage);
END;
END_PROC;


--************************************************************************************************
--verifies that stored procedure do exists in the database
CREATE OR REPLACE PROCEDURE DBTD_ASSERT_PROC_EXISTS
(
	NVARCHAR(255),	--proc name
	NVARCHAR(255)	--user message
)
LANGUAGE NZPLSQL
RETURNS BOOLEAN
AS
BEGIN_PROC
DECLARE
	v_ProcName		NVARCHAR(255);
	v_UserMessage	NVARCHAR(255);
	v_Message		VARCHAR(255); 
    v_Count			INTEGER;
BEGIN
	v_ProcName := TRIM(UPPER($1));
	v_UserMessage := $2;
	v_Message := 'Running DBTD_ASSERT_PROC_EXISTS';
	CALL DBTD_LOG_MESSAGE_EXT( 'DEBUG', 'DBTD_ASSERT_PROC_EXISTS', v_Message);

	SELECT COUNT(*) INTO v_Count 
	FROM _V_PROCEDURE
	WHERE UPPER(PROCEDURE) = UPPER(v_ProcName);

	IF (v_Count = 0)
	THEN
		v_Message := v_UserMessage || ' Cannot find Stored Procedure "' || v_ProcName || '"' ; 
		CALL DBTD_FAILURE (v_Message); 
	END IF;
	RETURN TRUE;
END;
END_PROC;

--************************************************************************************************
--verifies that stored procedure does not exists in the database
CREATE OR REPLACE PROCEDURE DBTD_ASSERT_PROC_NOT_EXISTS
(
	NVARCHAR(255),	--proc name
	NVARCHAR(255)	--user message
)
LANGUAGE NZPLSQL
RETURNS BOOLEAN
AS
BEGIN_PROC
DECLARE
	v_ProcName		NVARCHAR(255);	
	v_UserMessage	NVARCHAR(255);
	v_Message		VARCHAR(255); 
    v_Count			INTEGER;
BEGIN
	v_ProcName	:= TRIM(UPPER($1));
	v_UserMessage := $2;

	v_Message := 'Running DBTD_ASSERT_PROC_NOT_EXISTS';
	CALL DBTD_LOG_MESSAGE_EXT ('DEBUG', 'DBTD_ASSERT_PROC_NOT_EXISTS', v_Message );

	SELECT COUNT(*) INTO v_Count 
	FROM _V_PROCEDURE
	WHERE UPPER(PROCEDURE) = UPPER(v_ProcName);

	IF (v_Count != 0)
	THEN
		v_Message := v_UserMessage || ' Unexpected Stored Procedure "' || v_ProcName || '" found in database' ; 
		CALL DBTD_FAILURE(v_Message); 
	END IF;
	RETURN TRUE;
END;
END_PROC;

--************************************************************************************************
--verifies that table do exists in the database
CREATE OR REPLACE PROCEDURE DBTD_ASSERT_TABLE_EXISTS
(
	NVARCHAR(255),	--table name
	NVARCHAR(255)	--user message
)
LANGUAGE NZPLSQL
RETURNS BOOLEAN
AS
BEGIN_PROC
DECLARE
	v_TableName		NVARCHAR(255);
	v_UserMessage	NVARCHAR(255);
	v_Message		VARCHAR(255); 
    v_Count			INTEGER;
BEGIN
	v_TableName	:= TRIM(UPPER($1));
	v_UserMessage := $2;

	v_Message := 'Running DBTD_ASSERT_TABLE_EXIST';
	CALL DBTD_LOG_MESSAGE_EXT('DEBUG', 'DBTD_ASSERT_TABLE_EXIST', v_Message);

	SELECT COUNT(*) INTO v_Count
	FROM _V_TABLE
	WHERE UPPER(TABLENAME) = UPPER(v_TableName);

	IF v_Count = 0
	THEN
		v_Message := v_UserMessage || ' Cannot find TABLE "' || v_TableName || '"' ; 
		CALL DBTD_FAILURE (v_Message); 
	END IF;
	RETURN TRUE;
END;
END_PROC;

--************************************************************************************************
--verifies that table does not exists in the database
CREATE OR REPLACE PROCEDURE DBTD_ASSERT_TABLE_NOT_EXISTS
(
	NVARCHAR(255),	--table name
	NVARCHAR(255)	--user message
)
LANGUAGE NZPLSQL
RETURNS BOOLEAN
AS
BEGIN_PROC
DECLARE
	v_TableName		NVARCHAR(255);	--table name
	v_UserMessage	NVARCHAR(255);	--user message
	v_Message		VARCHAR(255); 
    v_Count			INTEGER;
BEGIN
	v_TableName	:= TRIM(UPPER($1));
	v_UserMessage := $2;

	v_Message := 'Running DBTD_ASSERT_TABLE_NOT_EXIST';
	CALL DBTD_LOG_MESSAGE_EXT( 'DEBUG', 'DBTD_ASSERT_TABLE_NOT_EXIST', v_Message );

	SELECT COUNT(*) INTO v_Count
	FROM _V_TABLE
	WHERE UPPER(TABLENAME) = UPPER(v_TableName);

	IF v_Count != 0
	THEN
		v_Message := v_UserMessage || ' Unexpected TABLE "' || v_TableName || '" found in the database.' ; 
		CALL DBTD_FAILURE( v_Message); 
	END IF;
	RETURN TRUE;
END;
END_PROC;

--************************************************************************************************
--verifies that view do exists in the database
CREATE OR REPLACE PROCEDURE DBTD_ASSERT_VIEW_EXISTS
(
	NVARCHAR(255),	--view name
	NVARCHAR(255)	--user message
)
LANGUAGE NZPLSQL
RETURNS BOOLEAN
AS
BEGIN_PROC
DECLARE
	v_ViewName		NVARCHAR(255);
	v_UserMessage	NVARCHAR(255);
	v_Message		VARCHAR(255); 
    v_Count			INTEGER;
BEGIN
	v_ViewName := TRIM(UPPER($1));
	v_UserMessage := $2;
	v_Message := 'Running DBTD_ASSERT_VIEW_EXIST';
	CALL DBTD_LOG_MESSAGE_EXT ('DEBUG', 'DBTD_ASSERT_VIEW_EXIST', v_Message );

	SELECT COUNT(*) INTO v_Count
	FROM _V_VIEW
	WHERE OWNER != 'ADMIN' AND UPPER(VIEWNAME) = UPPER(v_ViewName);

	IF (v_Count = 0)
	THEN
		v_Message := v_UserMessage || ' Cannot find VIEW "' || v_ViewName || '"' ; 
		CALL DBTD_FAILURE (v_Message); 
	END IF;
	RETURN TRUE;
END;
END_PROC;

--************************************************************************************************
--verifies that view does not exists in the database
CREATE OR REPLACE PROCEDURE DBTD_ASSERT_VIEW_NOT_EXISTS
(
	NVARCHAR(255),	--view name
	NVARCHAR(255)	--user message
)
LANGUAGE NZPLSQL
RETURNS BOOLEAN
AS
BEGIN_PROC
DECLARE
	v_ViewName		NVARCHAR(255);
	v_UserMessage	NVARCHAR(255);
	v_Message		VARCHAR(255); 
    v_Count			INTEGER;
BEGIN
	v_ViewName := TRIM(UPPER($1));
	v_UserMessage := $2;
	v_Message := 'Running DBTD_ASSERT_VIEW_NOT_EXIST';
	CALL DBTD_LOG_MESSAGE_EXT ('DEBUG', 'DBTD_ASSERT_VIEW_NOT_EXIST', v_Message);

	SELECT COUNT(*) INTO v_Count
	FROM _V_VIEW
	WHERE OWNER != 'ADMIN' AND UPPER(VIEWNAME) = UPPER(v_ViewName);

	IF (v_Count != 0)
	THEN
		v_Message := v_UserMessage || ' Unexpected VIEW "' || v_ViewName || '" found in the database.' ; 
		CALL DBTD_FAILURE (v_Message); 
	END IF;
	RETURN TRUE;
END;
END_PROC;

--************************************************************************************************
--verifies that view or table does exists in the database
CREATE OR REPLACE PROCEDURE DBTD_ASSERT_TABLE_OR_VIEW_EXISTS
(
	NVARCHAR(255),	--table or view name
	NVARCHAR(255)	--user message
)
LANGUAGE NZPLSQL
RETURNS BOOLEAN
AS
BEGIN_PROC
DECLARE
	v_ObjectName	NVARCHAR(255);
	v_UserMessage	NVARCHAR(255);
	v_Message		VARCHAR(255); 
    v_Table_Count	INTEGER;
    v_View_Count	INTEGER;
BEGIN
	v_ObjectName := TRIM(UPPER($1));
	v_UserMessage := $2;

	v_Message := 'Running DBTD_ASSERT_TABLE_OR_VIEW_EXISTS';
	CALL DBTD_LOG_MESSAGE_EXT( 'DEBUG', 'DBTD_ASSERT_TABLE_OR_VIEW_EXISTS', v_Message) ;

	SELECT COUNT(*) INTO v_Table_Count
	FROM _V_TABLE
	WHERE UPPER(TABLENAME) = UPPER(v_ObjectName );

	SELECT COUNT(*) INTO v_View_Count
	FROM _V_VIEW
	WHERE OWNER != 'ADMIN' AND UPPER(VIEWNAME) = UPPER(v_ObjectName);

	IF	(v_Table_Count = 0) AND (v_View_Count = 0)
	THEN
		v_Message := v_UserMessage || ' Cannot find neither VIEW nor TABLE with name "' || v_ObjectName || '" in the database.' ; 
		CALL DBTD_FAILURE(v_Message); 
	END IF;
	RETURN TRUE;
END;
END_PROC;

--************************************************************************************************
-- Checks that column EXISTS in the exhisting table or view.  
CREATE OR REPLACE PROCEDURE DBTD_ASSERT_COLUMN_EXISTS
(
	NVARCHAR(255),	--Table or View name
	NVARCHAR(255),	--Column Name
	NVARCHAR(255)	--User message
)
LANGUAGE NZPLSQL
RETURNS BOOLEAN
AS
BEGIN_PROC
DECLARE 
	v_ObjectName	NVARCHAR(255);	--Table or View name
	v_ColumnName	NVARCHAR(255);	--Column Name
	v_UserMessage	NVARCHAR(255);	--User message
	v_Message 		VARCHAR(255);
    v_Count			INTEGER;
BEGIN
	v_ObjectName := TRIM(UPPER($1));
	v_ColumnName := TRIM(UPPER($2));
	v_UserMessage := $3;

	v_Message := 'Running DBTD_ASSERT_COLUMN_EXISTS';
	CALL DBTD_LOG_MESSAGE_EXT ('DEBUG', 'DBTD_ASSERT_COLUMN_EXISTS', v_Message);

	--first check that table even exists 
	CALL DBTD_ASSERT_TABLE_OR_VIEW_EXISTS (v_ObjectName, v_UserMessage);

	SELECT COUNT(*) INTO v_Count
	FROM 
		_V_RELATION_COLUMN
	WHERE 
		NAME = v_ObjectName 		--table name
		AND ATTName = v_ColumnName	--column name
	;	
	
	IF	(v_Count <= 0) THEN 
		v_Message := v_UserMessage 
			|| ' Object "' || TRIM(UPPER(v_ObjectName)) || '" does not have "'|| TRIM(UPPER(v_ColumnName)) ||'" column.' ; 
		CALL DBTD_FAILURE (v_Message);  
	END IF;
END;
END_PROC;

--************************************************************************************************
-- checks that column DOES NOT EXISTS in the existing table or view 
-- will fail if table does not exist
CREATE OR REPLACE PROCEDURE DBTD_ASSERT_COLUMN_NOT_EXISTS
(
	NVARCHAR(255),	--Table or View name
	NVARCHAR(255),	--Column Name
	NVARCHAR(255)	--User message
)
LANGUAGE NZPLSQL
RETURNS BOOLEAN
AS
BEGIN_PROC
DECLARE 
	v_ObjectName	NVARCHAR(255);	--Table or View name
	v_ColumnName	NVARCHAR(255);	--Column Name
	v_UserMessage	NVARCHAR(255);	--User message
	v_Message 		VARCHAR(255);
    v_Count			INTEGER;
BEGIN
	v_ObjectName := TRIM(UPPER($1));
	v_ColumnName := TRIM(UPPER($2));
	v_UserMessage := $3;
	
	v_Message := 'Running DBTD_ASSERT_COLUMN_EXISTS';
	CALL DBTD_LOG_MESSAGE_EXT( 'DEBUG', 'DBTD_ASSERT_COLUMN_EXISTS', v_Message );

	--first check that table even exists 
	CALL DBTD_ASSERT_TABLE_OR_VIEW_EXISTS (v_ObjectName, v_UserMessage);

	SELECT COUNT(*) INTO v_Count
	FROM 
		_V_RELATION_COLUMN
	WHERE 
		NAME = v_ObjectName 		--table name
		AND ATTName = v_ColumnName	--column name
	;	
	
	IF	(v_Count > 0) THEN
		v_Message = v_UserMessage || ' Object "' || TRIM(UPPER(v_ObjectName)) || '" have unexpected "'|| TRIM(UPPER(v_ColumnName)) ||'" column.' ; 
		CALL DBTD_FAILURE (v_Message);  
	END IF;
END;
END_PROC;

--************************************************************************************************
-- Checks that column is nullable in the existing table or view 
-- will fail if corresponding view or table cannot be found
CREATE OR REPLACE PROCEDURE DBTD_ASSERT_COLUMN_IS_NULLABLE
(
	NVARCHAR(255),	--Table or View name
	NVARCHAR(255),	--Column Name
	NVARCHAR(255)	--User message
)
LANGUAGE NZPLSQL
RETURNS BOOLEAN
AS
BEGIN_PROC
DECLARE 
	v_ObjectName	NVARCHAR(255);	--Table or View name
	v_ColumnName	NVARCHAR(255);	--Column Name
	v_UserMessage	NVARCHAR(255);	--User message
	v_Message 		VARCHAR(255);
    v_Count			INTEGER;
BEGIN
	v_ObjectName := TRIM(UPPER($1));
	v_ColumnName := TRIM(UPPER($2));
	v_UserMessage := $3;

	v_Message := 'Running DBTD_ASSERT_COLUMN_IS_NULLABLE';
	CALL DBTD_LOG_MESSAGE_EXT ('DEBUG', 'DBTD_ASSERT_COLUMN_IS_NULLABLE', v_Message);
	
	--first check that columns exists 
	CALL DBTD_ASSERT_COLUMN_EXISTS(v_ObjectName, v_ColumnName, v_UserMessage);

	SELECT COUNT(*) INTO v_Count
	FROM _V_RELATION_COLUMN_DEF
	WHERE 
		NAME = v_ObjectName 			--table name
		AND AttName = v_ColumnName		--column name
		--AND AttNotNULL = 'NOT NULL';	
		AND AttNotNULL = 'NOT NULL';	
	
	IF	(v_Count != 0) THEN
		v_Message := v_UserMessage || ' "'|| TRIM(UPPER(v_ColumnName)) ||'" column is NOT nullable in the "' || RTRIM(UPPER(v_ObjectName)) || '" object.' ; 
		CALL DBTD_FAILURE (v_Message);  
	END IF;
END;
END_PROC;

--************************************************************************************************
-- Checks that column is NOT nullable in the existing table or view 
-- Will fail if corresponding view or table cannot be found
CREATE OR REPLACE PROCEDURE DBTD_ASSERT_COLUMN_IS_NOT_NULLABLE
(
	NVARCHAR(255),	--Table or View name
	NVARCHAR(255),	--Column Name
	NVARCHAR(255)	--User message
)
LANGUAGE NZPLSQL
RETURNS BOOLEAN
AS
BEGIN_PROC
DECLARE 
	v_ObjectName	NVARCHAR(255);	--Table or View name
	v_ColumnName	NVARCHAR(255);	--Column Name
	v_UserMessage	NVARCHAR(255);	--User message
	v_Message 		VARCHAR(255);
    v_Count			INTEGER;
BEGIN
	v_ObjectName := TRIM(UPPER($1));
	v_ColumnName := TRIM(UPPER($2));
	v_UserMessage := $3;

	v_Message := 'Running DBTD_ASSERT_COLUMN_IS_NOT_NULLABLE';
	CALL DBTD_LOG_MESSAGE_EXT('DEBUG', 'DBTD_ASSERT_COLUMN_IS_NOT_NULLABLE', v_Message );

	--first check that columns exists 
	CALL DBTD_ASSERT_COLUMN_EXISTS(v_ObjectName, v_ColumnName, v_UserMessage);

	SELECT COUNT(*) INTO v_Count
	FROM _V_RELATION_COLUMN_DEF
	WHERE 
		NAME = v_ObjectName 			--table name
		AND AttName = v_ColumnName		--column name
		AND AttNotNULL = 'NOT NULL';	
	
	IF	(v_Count = 0) THEN
		v_Message := v_UserMessage || ' "'|| TRIM(UPPER(v_ColumnName)) ||'" column is nullable in the "' || TRIM(UPPER(v_ObjectName)) || '" object.' ; 
		CALL DBTD_FAILURE (v_Message); 
	END IF;
END;
END_PROC;

--************************************************************************************************
-- Will fail if column with given type and precision cannot be found in the table or view
CREATE OR REPLACE PROCEDURE DBTD_ASSERT_COLUMN_TYPE_AND_PRECISION
(
	NVARCHAR(255),	--Table or View name
	NVARCHAR(255),	--Column Name
	NVARCHAR(255),	--Column Type not including precision info, for instance NUMERIC 
	NVARCHAR(255),	--Column precision and scale, for instance (18,0), include brackets commas but no spaces 
	NVARCHAR(255)	--User message
)
LANGUAGE NZPLSQL
RETURNS BOOLEAN
AS
BEGIN_PROC
DECLARE 
	v_ObjectName		NVARCHAR(255);	--Table or View name
	v_ColumnName		NVARCHAR(255);	--Column Name
	v_ColumnType		NVARCHAR(255);	--Column Type
	v_ColumnPrecScale	NVARCHAR(255);	--Column precision and scale
	v_UserMessage		NVARCHAR(255);	--User message
	v_Message 			VARCHAR(255);
	v_AliasMessage		VARCHAR(255);
    v_Count				INTEGER;
BEGIN
	v_AliasMessage := '';

	v_ObjectName := TRIM(UPPER($1));
	v_ColumnName := TRIM(UPPER($2));
	v_ColumnType := TRIM(UPPER($3));
	v_ColumnPrecScale := NVL(TRIM(UPPER($4)),'');
	v_UserMessage := $5;

	v_Message := 'Running DBTD_ASSERT_COLUMN_TYPE_AND_PRECISION';
	CALL DBTD_LOG_MESSAGE_EXT ('DEBUG', 'DBTD_ASSERT_COLUMN_TYPE_AND_PRECISION', v_Message );

	--first check that columns exists 
	CALL DBTD_ASSERT_COLUMN_EXISTS(v_ObjectName, v_ColumnName, v_UserMessage);

	SELECT COUNT(*) INTO v_Count
	FROM
		(
		SELECT 
			v_ObjectName AS p_ObjectName,		
			v_ColumnName AS p_ColumnName,
			CASE
				WHEN v_ColumnType = 'FLOAT' AND v_ColumnPrecScale IN ('(1)','(2)','(3)','(4)','(5)','(6)') THEN 'REAL'
				WHEN v_ColumnType = 'FLOAT' AND v_ColumnPrecScale IN ('(7)','(8)','(9)','(10)','(11)','(12)','(13)','(14)','(15)') THEN 'DOUBLE PRECISION'
				ELSE v_ColumnType
			END AS p_ColumnType,
			CASE 
				WHEN v_ColumnType = 'FLOAT' AND v_ColumnPrecScale IN ('(1)','(2)','(3)','(4)','(5)','(6)') THEN '' --no precision used for REAL type
				WHEN v_ColumnType = 'FLOAT' AND v_ColumnPrecScale IN ('(7)','(8)','(9)','(10)','(11)','(12)','(13)','(14)','(15)') THEN ''	-- no precision used for DOUBLE PRECISION type
				ELSE v_ColumnPrecScale 
			END AS p_ColumnPrecScale,
			NAME, 		--name of the object (view or table)
			AttName, 	--column name
			AttType, 	--column type with precision
			POSITION('(' in AttType) AS PrecisionStart,
			POSITION(')' in AttType) AS PrecisionEnd,
			CASE
				WHEN PrecisionStart = 0 THEN AttType
				ELSE SUBSTRING(AttType, 0, PrecisionStart) 
			END AS DataType, --clean data type
			CASE 
				WHEN PrecisionStart = 0 THEN ''
				ELSE SUBSTRING(AttType, PrecisionStart, PrecisionEnd) 
			END AS DataTypePrecision,	--isolated precision
			CASE
				WHEN 
					DataType = 'NUMERIC'
					AND DataTypePrecision like '%,0)' 
					THEN SUBSTRING(DataTypePrecision, 0, POSITION(',' in DataTypePrecision)) || ')'
				ELSE DataTypePrecision	
			END AS PrecisionEquivalent 	--Equivalent of the isolated precision, for instance NUMERIC(p) is equivalent to NUMERIC(p,0)
		FROM _V_RELATION_COLUMN_DEF
		WHERE 
			NAME = p_ObjectName	--table or view name
			AND AttName = p_ColumnName	--column name
		) AS O
		LEFT OUTER JOIN 
		DBTD_VW_DATATYPE AS T 
		ON 
			O.DataType = T.DATATYPE
			OR O.DataType = T.Alias
	WHERE 
		(T.DATATYPE = p_ColumnType OR T.Alias = p_ColumnType)
		AND (
			p_ColumnPrecScale = ''
			OR p_ColumnPrecScale = DataTypePrecision
			OR p_ColumnPrecScale = PrecisionEquivalent
			)
	;

	v_Message := 'Found '||cast(v_Count as varchar(50))||' potential type matches.';
	CALL DBTD_LOG_MESSAGE_EXT ('DEBUG', 'DBTD_ASSERT_COLUMN_TYPE_AND_PRECISION', v_Message );

	--verify if there is anything were found
	IF	(v_Count <= 0) THEN
		v_Message := v_UserMessage 
			|| ' "' || TRIM(UPPER(v_ObjectName)) || '" object does not have "'
			|| TRIM(UPPER(v_ColumnName)) ||'" column with "' 
			|| TRIM(UPPER(v_ColumnType)) ||'" data type' ; 		

		IF (v_ColumnPrecScale != '' AND v_ColumnPrecScale IS NOT NULL) THEN
			v_Message := v_Message || ', and provided precision and scale ' || v_ColumnPrecScale ;
		END IF;

		IF (v_AliasMessage != '') THEN
			v_Message := v_Message || '. ' || v_AliasMessage;
		END IF;
				 
		CALL DBTD_FAILURE (v_Message);  
	END IF;
END;
END_PROC;

--************************************************************************************************
-- Checks column data type is of the expected data type in the existing table
-- Will fail if corresponding view or table cannot be found
CREATE OR REPLACE PROCEDURE DBTD_ASSERT_COLUMN_TYPE
(
	NVARCHAR(255),	--Table or View name
	NVARCHAR(255),	--Column Name
	NVARCHAR(255),	--Column Type not including precision info, for instance NUMERIC 
	NVARCHAR(255)	--User message
)
LANGUAGE NZPLSQL
RETURNS BOOLEAN
AS
BEGIN_PROC
DECLARE 
	v_Message 			VARCHAR(255);
BEGIN
	v_Message := 'Running DBTD_ASSERT_COLUMN_TYPE';
	CALL DBTD_LOG_MESSAGE_EXT ('DEBUG', 'DBTD_ASSERT_COLUMN_TYPE', v_Message );
	--note: precision is ommitted 
	CALL DBTD_ASSERT_COLUMN_TYPE_AND_PRECISION($1,$2,$3,'',$4);
END;
END_PROC;

--************************************************************************************************
--checks that value in the collumn is unique (or distinct) 
CREATE OR REPLACE PROCEDURE DBTD_ASSERT_IS_COLUMN_VALUE_UNIQUE
(
	NVARCHAR(255),	--table name
	NVARCHAR(255),	--column that should have unique\distinct values only
	NVARCHAR(255)	--user message
)
LANGUAGE NZPLSQL
RETURNS BOOLEAN
AS
BEGIN_PROC
DECLARE 
	v_ActualValue BIGINT;
	v_ExpectedValue BIGINT;
	v_TableName VARCHAR(255);
	v_ColumnName VARCHAR(255);
	v_ErrColumnName VARCHAR(255);	--
	v_UserMessage VARCHAR(255);
	v_Message VARCHAR(255);
	v_SQL NVARCHAR(2000);
	v_REC RECORD;
BEGIN
	CALL DBTD_LOG_MESSAGE_EXT ( 'DEBUG', 'DBTD_ASSERT_IS_COL_VALUE_UNIQUE', 'Running DBTD_ASSERT_IS_COL_VALUE_UNIQUE');

	v_TableName := TRIM(UPPER($1));
	v_ColumnName := TRIM(UPPER($2));
	v_UserMessage := $3;

	v_SQL := 'SELECT COL_NM, CT FROM (SELECT ' || v_ColumnName || ' AS COL_NM, COUNT(1) AS CT FROM ' 
	         || v_TableName || ' AS Y GROUP BY ' ||v_ColumnName || ') AS Z WHERE CT > 1;'; 

	--Need a loop to get results from the dynamic query.
	--We only need to check if there is at list one record that is not unique 
	FOR v_REC IN EXECUTE v_SQL LOOP
		v_ErrColumnName := v_REC.COL_NM;
		v_ActualValue := v_REC.CT;
		EXIT;
	END LOOP;

	IF (v_ActualValue IS NOT NULL)  THEN
		v_Message := v_UserMessage 
			|| ' Duplicate values "'||v_ErrColumnName
			||'" are found in the "' || v_TableName 
			|| '" table "' || v_ColumnName || '" column.';  
		CALL DBTD_FAILURE (v_Message); 
		RETURN FALSE;
	END IF;
	RETURN TRUE;
END;
END_PROC;

--************************************************************************************************
--checks that column have a given value at list in one row of a given table 
CREATE OR REPLACE PROCEDURE DBTD_ASSERT_COLUMN_HAVE_VALUE
(
	NVARCHAR(255),	--table name
	NVARCHAR(255),	--column that will be checked for a value
	NVARCHAR(4000),	--asserted value
	NVARCHAR(255),	--value data type
	NVARCHAR(255)	--user message
)
LANGUAGE NZPLSQL
RETURNS BOOLEAN
AS
BEGIN_PROC
DECLARE 
	v_ActualValue	VARCHAR(50);
	v_TableName		VARCHAR(255);
	v_ColumnName	VARCHAR(255);
	v_Value			VARCHAR(4000);
	v_ValueDataType	VARCHAR(255);
	v_UserMessage	VARCHAR(255);
	v_Message		VARCHAR(255);
	v_SQL			NVARCHAR(2000);
	v_REC			RECORD;
BEGIN
	CALL DBTD_LOG_MESSAGE_EXT ( 'DEBUG', 'DBTD_ASSERT_COLUMN_HAVE_VALUE', 'Running DBTD_ASSERT_COLUMN_HAVE_VALUE');

	v_TableName := TRIM(UPPER($1));
	v_ColumnName := TRIM(UPPER($2));
	v_Value := $3;
	v_ValueDataType := $4;
	v_UserMessage := $5;

	v_SQL := 'SELECT CAST(' || v_ColumnName || ' AS VARCHAR(50)) AS COL_VALUE FROM ' 
	         || v_TableName || ' WHERE ' || v_ColumnName || ' = CAST('''||v_Value||''' AS '||v_ValueDataType||');'; 

	--Need a loop to get results from the dynamic query.
	--We only need to check if there is at list one record that is not unique 
	FOR v_REC IN EXECUTE v_SQL LOOP
		v_ActualValue := v_REC.COL_VALUE;
		EXIT;
	END LOOP;

	IF (v_ActualValue IS NULL)  THEN
		v_Message := v_UserMessage 
			|| ' Expected values "'||v_Value
			|| '" of "' ||v_ValueDataType|| '" type '
			|| ' were NOT found in the "' || v_TableName 
			|| '" table "' || v_ColumnName || '" column.';  
		CALL DBTD_FAILURE (v_Message); 
		RETURN FALSE;
	END IF;
	RETURN TRUE;
END;
END_PROC;

--************************************************************************************************
--checks that column have a given value at list in one row of a given table 
CREATE OR REPLACE PROCEDURE DBTD_ASSERT_COLUMN_HAS_NO_VALUE
(
	NVARCHAR(255),	--table name
	NVARCHAR(255),	--column that will be checked for a value
	NVARCHAR(4000),	--asserted value
	NVARCHAR(255),	--value data type
	NVARCHAR(255)	--user message
)
LANGUAGE NZPLSQL
RETURNS BOOLEAN
AS
BEGIN_PROC
DECLARE 
	v_TableName		VARCHAR(255);
	v_ColumnName	VARCHAR(255);
	v_Value			VARCHAR(4000);
	v_ValueDataType	VARCHAR(255);
	v_UserMessage	VARCHAR(255);
	v_ActualValue	VARCHAR(50);
	v_Message		VARCHAR(255);
	v_SQL			NVARCHAR(2000);
	v_REC			RECORD;
	v_ProcessName	VARCHAR(50);
BEGIN
	v_ProcessName := 'DBTD_ASSERT_COLUMN_HAS_NO_VALUE';
	CALL DBTD_LOG_MESSAGE_EXT ( 'DEBUG', v_ProcessName, 'Running DBTD_ASSERT_COLUMN_HAS_NO_VALUE');

	v_TableName := TRIM(UPPER($1));
	v_ColumnName := TRIM(UPPER($2));
	v_Value := $3;
	v_ValueDataType := $4;
	v_UserMessage := $5;

	v_SQL := 'SELECT CAST(' || v_ColumnName || ' AS VARCHAR(50)) AS COL_VALUE FROM ' 
	         || v_TableName || ' WHERE ' || v_ColumnName || ' = CAST('''||v_Value||''' AS '||v_ValueDataType||');'; 

	CALL DBTD_LOG_MESSAGE_EXT ( 'DEBUG', v_ProcessName, v_SQL);

	--Need a loop to get results from the dynamic query.
	--We only need to check if there is at list one record that is not unique 
	FOR v_REC IN EXECUTE v_SQL LOOP
		v_ActualValue := v_REC.COL_VALUE;
		EXIT;
	END LOOP;

	IF (v_ActualValue IS NOT NULL)  THEN
		v_Message := v_UserMessage 
			|| ' NOT Expected values "'||v_Value
			|| '" of "' ||v_ValueDataType|| '" type '
			|| ' has been found in the "' || v_TableName 
			|| '" table "' || v_ColumnName || '" column.';  
		CALL DBTD_FAILURE (v_Message); 
		RETURN FALSE;
	END IF;
	RETURN TRUE;
END;
END_PROC;

--************************************************************************************************
--checks that both tables have same number of rows
CREATE OR REPLACE PROCEDURE DBTD_ASSERT_SAME_NUMBER_OF_ROWS
(
	NVARCHAR(255),	--name of the first table 
	NVARCHAR(255),	--name of the second table 
	NVARCHAR(255)	--user message
)
LANGUAGE NZPLSQL
RETURNS BOOLEAN
AS
BEGIN_PROC
DECLARE 
	v_TableNameA VARCHAR(255);
	v_TableNameB VARCHAR(255);
	v_UserMessage VARCHAR(255);
	v_ActualValue BIGINT;
	v_ExpectedValue BIGINT;
	v_Message VARCHAR(255);
	v_SQL NVARCHAR(2000);
	v_REC RECORD;
BEGIN
	CALL DBTD_LOG_MESSAGE_EXT ( 'DEBUG', 'DBTD_ASSERT_SAME_NUMBER_OF_ROWS', 'Running DBTD_ASSERT_SAME_NUMBER_OF_ROWS');

	v_TableNameA := TRIM(UPPER($1));
	v_TableNameB := TRIM(UPPER($2));
	v_UserMessage := $3;

	v_SQL := 'SELECT (SELECT COUNT(1) FROM '||v_TableNameA||') AS T1Count, (SELECT COUNT(1) FROM '||v_TableNameB||') AS T2Count;'; 

	--Need a loop to get results from the dynamic query.
	--We only need to check if there is at list one record that is not unique 
	FOR v_REC IN EXECUTE v_SQL LOOP
		v_ExpectedValue := v_REC.T1Count;
		v_ActualValue := v_REC.T2Count;
		EXIT;
	END LOOP;

	IF (v_ActualValue != v_ExpectedValue)  THEN
		v_Message := v_UserMessage 
			|| ' Tables have differen number of rows: '
			|| v_TableNameA || ' has ' || cast(v_ExpectedValue as varchar(50)) || ' rows'
			|| ' while  '
			|| v_TableNameB || ' has ' || cast(v_ActualValue as varchar(50)) || ' rows'
			;  
		CALL DBTD_FAILURE (v_Message); 
		RETURN FALSE;
	END IF;
	RETURN TRUE;
END;
END_PROC;

--************************************************************************************************
--checks that user exists in database
CREATE OR REPLACE PROCEDURE DBTD_ASSERT_USER_EXISTS
(
	NVARCHAR(255),	--User name 
	NVARCHAR(255)	--User message
)
LANGUAGE NZPLSQL
RETURNS BOOLEAN
AS
BEGIN_PROC
DECLARE 
	v_UserName		NVARCHAR(255);	--User name 
	v_UserMessage	NVARCHAR(255);	--User message
	v_ActualValue BIGINT;	 
	v_NotExpectedValue BIGINT;	 
	v_Message VARCHAR(255);
BEGIN
	v_UserName	:= TRIM(UPPER($1));
	v_UserMessage := $2;
	v_Message := 'Running DBTD_ASSERT_USER_EXISTS';
	v_NotExpectedValue := 0;	 

	CALL DBTD_LOG_MESSAGE_EXT( 'DEBUG', 'DBTD_ASSERT_USER_EXISTS', v_Message);

	--note: consider using select * from _V_OBJECT_DATA where OBJTYPE = 'USER';
	SELECT COUNT(1) INTO v_ActualValue
	FROM _V_USER
	WHERE USERNAME = UPPER(TRIM(v_UserName));

	IF v_ActualValue <= v_NotExpectedValue THEN 
		v_Message := v_UserMessage  || ' Cannot find User with name "' || TRIM(UPPER(v_UserName)) || '"' ; 
		CALL DBTD_FAILURE( v_Message); 
	END IF;	
END;
END_PROC;

--************************************************************************************************
--NOTE: definition stub DBTD_ASSERT_ROLE_EXISTS

--************************************************************************************************
--NOTE: definition stub DBTD_ASSERT_LOGIN_EXISTS

--************************************************************************************************
--checks that database exists on the server
CREATE OR REPLACE PROCEDURE DBTD_ASSERT_DB_EXISTS
(
	NVARCHAR(255),	--Database name 
	NVARCHAR(255)	--User message
)
LANGUAGE NZPLSQL
RETURNS BOOLEAN
AS
BEGIN_PROC
DECLARE 
	v_DatabaseName	NVARCHAR(255);	--Database name 
	v_UserMessage	NVARCHAR(255);	--User message
	v_ActualValue BIGINT;	 
	v_NotExpectedValue BIGINT;	 
	v_Message VARCHAR(255);
BEGIN
	v_DatabaseName	:= TRIM(UPPER($1));
	v_UserMessage	:= $2;
	v_Message := 'Running DBTD_ASSERT_DB_EXISTS';
	v_NotExpectedValue := 0;	 

	CALL DBTD_LOG_MESSAGE_EXT ('DEBUG', 'DBTD_ASSERT_DB_EXISTS', v_Message) ;

	--note: consider using select * from _V_OBJECT_DATA where OBJTYPE = 'DATABASE';
	select count(1) into  v_ActualValue
	from _V_DATABASE 
	where DataBase = v_DatabaseName;

	IF v_ActualValue = v_NotExpectedValue
	THEN
		v_Message := v_UserMessage 
			|| ' Cannot find database with name "' || TRIM(UPPER(v_DatabaseName)) || '"' ; 
		CALL DBTD_FAILURE( v_Message); 
	END IF;	
END;
END_PROC;

--************************************************************************************************
--NOTE: Netezza does not support triggers as of beginning 2013, however it does have _v_trigger
--      system view that migt allow us in the future to use this functionality, at list for system objects
--checks that trigger exists on the server
CREATE OR REPLACE PROCEDURE DBTD_ASSERT_TRIGGER_EXISTS
(
	NVARCHAR(255),	--Trigger name 
	NVARCHAR(255)	--User message
)
LANGUAGE NZPLSQL
RETURNS BOOLEAN
AS
BEGIN_PROC
DECLARE 
	v_TriggerName	NVARCHAR(255);	--Trigger name 
	v_UserMessage	NVARCHAR(255);	--User message
	v_ActualValue BIGINT;	 
	v_NotExpectedValue BIGINT;	 
	v_Message VARCHAR(255);
BEGIN
	v_TriggerName	:= TRIM(UPPER($1));
	v_UserMessage	:= $2;
	v_Message := 'Running DBTD_ASSERT_TRIGGER_EXISTS';
	v_NotExpectedValue := 0;	 

	CALL DBTD_LOG_MESSAGE_EXT ('DEBUG', 'DBTD_ASSERT_TRIGGER_EXISTS', v_Message) ;

	select count(1) into  v_ActualValue
	from _v_trigger 
	where Trigger = v_TriggerName;

	IF v_ActualValue = v_NotExpectedValue
	THEN
		v_Message := v_UserMessage 
			|| ' Cannot find trigger with name "' || TRIM(UPPER(v_TriggerName)) || '"' ; 
		CALL DBTD_FAILURE( v_Message); 
	END IF;	
END;
END_PROC;

--************************************************************************************************
--checks that user does not exists in database
CREATE OR REPLACE PROCEDURE DBTD_ASSERT_USER_NOT_EXISTS
(
	NVARCHAR(255),	--User name 
	NVARCHAR(255)	--User message
)
LANGUAGE NZPLSQL
RETURNS BOOLEAN
AS
BEGIN_PROC
DECLARE 
	v_UserName	NVARCHAR(255);		--user name 
	v_UserMessage	NVARCHAR(255);	--User message
	v_ActualValue BIGINT;	 
	v_ExpectedValue BIGINT;	 
	v_Message VARCHAR(255);
BEGIN
	v_UserName	:= TRIM(UPPER($1));
	v_UserMessage	:= $2;
	v_Message := 'Running DBTD_ASSERT_USER_NOT_EXISTS';
	v_ExpectedValue := 0;	 

	CALL DBTD_LOG_MESSAGE_EXT( 'DEBUG', 'DBTD_ASSERT_USER_NOT_EXISTS', v_Message );

	SELECT COUNT(1) INTO v_ActualValue
	FROM _V_USER
	WHERE USERNAME = UPPER(TRIM(v_UserName));

	IF v_ExpectedValue != v_ActualValue
	THEN 
		v_Message := v_UserMessage 
			|| ' Found user with name "' || TRIM(UPPER(v_UserName)) || '", when it is not expected to be present in the database' ; 
		CALL DBTD_FAILURE( v_Message); 
	END IF;	
END;
END_PROC;

--************************************************************************************************
--NOTE: definition stub DBTD_ASSERT_ROLE_NOT_EXISTS

--************************************************************************************************
--NOTE: definition stub DBTD_ASSERT_LOGIN_NOT_EXISTS

--************************************************************************************************
--checks that database does not exists on the server
CREATE OR REPLACE PROCEDURE DBTD_ASSERT_DB_NOT_EXISTS
(
	NVARCHAR(255),	--Database name 
	NVARCHAR(255)	--User message
)
LANGUAGE NZPLSQL
RETURNS BOOLEAN
AS
BEGIN_PROC
DECLARE 
	v_DatabaseName	NVARCHAR(255);	--Database name 
	v_UserMessage	NVARCHAR(255);	--User message
	v_ActualValue BIGINT;	 
	v_ExpectedValue BIGINT;	 
	v_Message VARCHAR(255);
BEGIN
	v_DatabaseName	= UPPER(TRIM($1));
	v_UserMessage	:= $2;
	v_Message := 'Running DBTD_ASSERT_DB_NOT_EXISTS';
	v_ExpectedValue := 0;	 

	CALL DBTD_LOG_MESSAGE_EXT( 'DEBUG', 'DBTD_ASSERT_DB_NOT_EXISTS', v_Message) ;

	--note: consider using select * from _V_OBJECT_DATA where OBJTYPE = 'DATABASE';
	select count(1) into  v_ActualValue
	from _V_DATABASE 
	where DataBase = v_DatabaseName;

	IF v_ActualValue != v_ExpectedValue
	THEN
		v_Message := v_UserMessage 
			|| ' Found database with name "' || TRIM(UPPER(v_DatabaseName)) || '", when it is not expected to be present' ; 
		CALL DBTD_FAILURE( v_Message); 
	END IF;	
END;
END_PROC;

--************************************************************************************************
--NOTE: Netezza does not support triggers as of beginning 2013, however it does have _v_trigger
--      system view that migt allow us in the future to use this functionality, at list for system objects
--checks that trigger does not exists on the server
CREATE OR REPLACE PROCEDURE DBTD_ASSERT_TRIGGER_NOT_EXISTS
(
	NVARCHAR(255),	--Trigger name 
	NVARCHAR(255)	--User message
)
LANGUAGE NZPLSQL
RETURNS BOOLEAN
AS
BEGIN_PROC
DECLARE 
	v_TriggerName	NVARCHAR(255);	--Trigger name 
	v_UserMessage	NVARCHAR(255);	--User message
	v_ActualValue BIGINT;	 
	v_ExpectedValue BIGINT;	 
	v_Message VARCHAR(255);
BEGIN
	v_TriggerName	:= TRIM(UPPER($1));
	v_UserMessage	:= $2;
	v_Message := 'Running DBTD_ASSERT_TRIGGER_NOT_EXISTS';
	v_ExpectedValue := 0;	 

	CALL DBTD_LOG_MESSAGE_EXT ('DEBUG', 'DBTD_ASSERT_TRIGGER_NOT_EXISTS', v_Message) ;

	select count(1) into  v_ActualValue
	from _v_trigger 
	where Trigger = v_TriggerName;

	IF v_ActualValue != v_ExpectedValue
	THEN
		v_Message := v_UserMessage 
			|| ' Cannot find trigger with name "' || TRIM(UPPER(v_TriggerName)) || '", when it is not expected to be present in the database' ; 
		CALL DBTD_FAILURE( v_Message); 
	END IF;	
END;
END_PROC;

--************************************************************************************************
--NOTE: Netezza does not support index concept, however it does have following views:
--			select * from _v_index;
--			select * from _v_table_index;
--      that allow us to use this functionality, at list for system objects
--checks that index defined for a given object (table or view) exist in database 
CREATE OR REPLACE PROCEDURE DBTD_ASSERT_INDEX_EXISTS
(
	NVARCHAR(255),	--Index name 
	NVARCHAR(255),	--Object name (table)
	NVARCHAR(255)	--User message
)
LANGUAGE NZPLSQL
RETURNS BOOLEAN
AS
BEGIN_PROC
DECLARE 
	v_IndexName	NVARCHAR(255);	--Index name 
	v_ObjectName	NVARCHAR(255);	--Object name (table or view)
	v_UserMessage	NVARCHAR(255);	--User message
	v_ActualValue BIGINT;	 
	v_NotExpectedValue BIGINT;	 
	v_Message VARCHAR(255);
BEGIN
	v_IndexName	:= TRIM(UPPER($1));
	v_ObjectName := TRIM(UPPER($2));
	v_UserMessage := $3;
	v_NotExpectedValue := 0;	 
	v_Message := 'INDEX is for system use only. Users cannot create\drop indexes. Not Supported Netezza functionality.';
	CALL DBTD_LOG_MESSAGE_EXT( 'WARNING', 'DBTD_ASSERT_INDEX_EXISTS', v_Message );

	select count(1) into  v_ActualValue
	from _v_table_index
	where 
		UPPER(IndexName) = v_IndexName
		AND UPPER (TableName) = v_ObjectName;

	IF v_ActualValue = v_NotExpectedValue
	THEN
		v_Message := v_UserMessage 
			|| ' Cannot find index [' || v_IndexName || '] that belongs to ['||v_ObjectName||'] object.'; 
		CALL DBTD_FAILURE( v_Message); 
	END IF;	
END;
END_PROC;

--************************************************************************************************
--NOTE: Netezza does not support index concept, however it does have following views:
--			select * from _v_index;
--			select * from _v_table_index;
--      that allow us to use this functionality, at list for system objects
--checks that index has not been defined for a given object (table or view)
CREATE OR REPLACE PROCEDURE DBTD_ASSERT_INDEX_NOT_EXISTS
(
	NVARCHAR(255),	--Index name 
	NVARCHAR(255),	--Object name (table or view)
	NVARCHAR(255)	--User message
)
LANGUAGE NZPLSQL
RETURNS BOOLEAN
AS
BEGIN_PROC
DECLARE 
	v_ActualValue BIGINT;	 
	v_ExpectedValue BIGINT;	 
	v_Message VARCHAR(255);
	v_IndexName	NVARCHAR(255);	--Index name 
	v_ObjectName	NVARCHAR(255);	--Object name (table or view)
	v_UserMessage	NVARCHAR(255);	--User message
BEGIN
	v_IndexName	:= TRIM(UPPER($1));
	v_ObjectName := TRIM(UPPER($2));
	v_UserMessage := $3;
	v_ExpectedValue := 0;	 
	v_Message := 'INDEX is for system use only. Users cannot create\drop indexes. Not Supported Netezza functionality.';

	CALL DBTD_LOG_MESSAGE_EXT( 'WARNING', 'DBTD_ASSERT_INDEX_NOT_EXISTS', v_Message) ;

	select count(1) into  v_ActualValue
	from _v_table_index
	where 
		UPPER(IndexName) = v_IndexName
		AND UPPER (TableName) = v_ObjectName;

	IF v_ActualValue != v_ExpectedValue
	THEN
		v_Message := v_UserMessage 
			|| ' Found index [' || v_IndexName || '] that belongs to ['||v_ObjectName||'] object, however it shouldnot exists in the database.'; 
		CALL DBTD_FAILURE( v_Message); 
	END IF;	
END;
END_PROC;

--************************************************************************************************
--NOTE: definition stub DBTD_ASSERT_INDEX_CLUSTERED

--************************************************************************************************
--NOTE: definition stub DBTD_ASSERT_INDEX_NOT_CLUSTERED

--************************************************************************************************
--NOTE: Netezza does not support index concept, however it does have following views:
--			select * from _v_table_index;
--      that allow us to use this functionality, at list for system objects
--checks that UNIQUE index has been defined for a given object (table or view)
CREATE OR REPLACE PROCEDURE DBTD_ASSERT_INDEX_UNIQUE
(
	NVARCHAR(255),	--Index name 
	NVARCHAR(255),	--Object name (table or view)
	NVARCHAR(255)	--User message
)
LANGUAGE NZPLSQL
RETURNS BOOLEAN
AS
BEGIN_PROC
DECLARE 
	v_ActualValue BIGINT;	 
	v_NotExpectedValue BIGINT;	 
	v_Message VARCHAR(255);
	v_IndexName	NVARCHAR(255);	--Index name 
	v_ObjectName	NVARCHAR(255);	--Object name (table or view)
	v_UserMessage	NVARCHAR(255);	--User message
BEGIN
	v_IndexName	:= TRIM(UPPER($1));
	v_ObjectName := TRIM(UPPER($2));
	v_UserMessage := $3;
	v_NotExpectedValue := 0;	 
	v_Message := 'INDEX is for system use only. Users cannot create\drop indexes. Not Supported Netezza functionality.';

	CALL DBTD_LOG_MESSAGE_EXT ('WARNING', 'DBTD_ASSERT_INDEX_UNIQUE', v_Message) ;

	select count(1) into  v_ActualValue
	from _v_table_index
	where 
		UPPER(IndexName) = v_IndexName
		AND UPPER (TableName) = v_ObjectName
		AND IndIsUnique = TRUE;

	IF v_ActualValue = v_NotExpectedValue
	THEN
		v_Message := v_UserMessage 
			|| ' Cannot find UNIQUE index [' || v_IndexName || '] that belongs to ['||v_ObjectName||'] object.'; 
		CALL DBTD_FAILURE( v_Message); 
	END IF;	
END;
END_PROC;

--************************************************************************************************
--NOTE: Netezza does not support index concept, however it does have following views:
--			select * from _v_table_index;
--      that allow us to use this functionality, at list for system objects
--checks that UNIQUE index has been defined for a given object (table or view)
CREATE OR REPLACE PROCEDURE DBTD_ASSERT_INDEX_NOT_UNIQUE
(
	NVARCHAR(255),	--Index name 
	NVARCHAR(255),	--Object name (table or view)
	NVARCHAR(255)	--User message
)
LANGUAGE NZPLSQL
RETURNS BOOLEAN
AS
BEGIN_PROC
DECLARE 
	v_IndexName	NVARCHAR(255);	--Index name 
	v_ObjectName	NVARCHAR(255);	--Object name (table or view)
	v_UserMessage	NVARCHAR(255);	--User message
	v_ActualValue BIGINT;	 
	v_NotExpectedValue BIGINT;	 
	v_Message VARCHAR(255);
BEGIN
	v_IndexName	:= TRIM(UPPER($1));
	v_ObjectName := TRIM(UPPER($2));
	v_UserMessage := $3;
	v_NotExpectedValue := 0;	 
	v_Message := 'INDEX is for system use only. Users cannot create\drop indexes. Not Supported Netezza functionality.';

	CALL DBTD_LOG_MESSAGE_EXT ('WARNING', 'DBTD_ASSERT_INDEX_NOT_UNIQUE', v_Message );

	select count(1) into  v_ActualValue
	from _v_table_index
	where 
		UPPER(IndexName) = v_IndexName
		AND UPPER (TableName) = v_ObjectName
		AND IndIsUnique = FALSE;

	IF v_ActualValue = v_NotExpectedValue
	THEN
		v_Message := v_UserMessage 
			|| ' Cannot find NOT UNIQUE index [' || v_IndexName || '] that belongs to ['||v_ObjectName||'] object.'; 
		CALL DBTD_FAILURE( v_Message); 
	END IF;	
END;
END_PROC;


--************************************************************************************************
--internal CORE procedure that initialize unit test 
CREATE OR REPLACE PROCEDURE DBTD_INITIALIZE
(
	VARCHAR(128),	--Unit Test
	VARCHAR(128)	--Test Owner
)
LANGUAGE NZPLSQL
RETURNS BOOLEAN
AS
BEGIN_PROC
DECLARE 
	v_Message		VARCHAR(255);
	v_CountTests	INT;
	v_TestName		VARCHAR(128);
	v_TestOwner		VARCHAR(128);
BEGIN 
	v_TestName	:= $1;
	v_TestOwner	:= $2;
	CALL DBTD_LOG_MESSAGE_EXT ( 'DEBUG', 'DBTD_INITIALIZE', v_TestName );

	DELETE FROM  DBTD_TBL_ACTIVETEST;
	v_Message := 'INITIATING TEST...';
	INSERT INTO DBTD_TBL_ACTIVETEST (IsError,IsFailure,TestName, Owner, Message) 
	VALUES (FALSE,FALSE,v_TestName,v_TestOwner,v_Message);

	SELECT count(*) into v_CountTests 
	FROM DBTD_TBL_TESTRESULT 
	WHERE 
		UPPER(TestName) = UPPER(v_TestName)
		--AND UPPER(Owner) = UPPER(v_TestOwner)
	;
	IF v_CountTests > 0 THEN
		CALL DBTD_LOG_MESSAGE_EXT ( 'INFO', 'DBTD_INITIALIZE', 'Update DBTD_TBL_TESTRESULT with initial pre-run status for - ' || v_TestName);
		UPDATE DBTD_TBL_TESTRESULT 
		SET 
			StartTime = NOW(),
			RunCount = NVL(RunCount,0) + 1,
			IsError = FALSE,
			IsFailure = FALSE, 
			Status = 'STARTED',
			Message = v_Message
		WHERE 
			UPPER(TestName) = UPPER(v_TestName)
			--AND UPPER(Owner) = UPPER(v_TestOwner)
		;
	ELSE 
		CALL DBTD_LOG_MESSAGE_EXT ( 'INFO', 'DBTD_INITIALIZE', 'Add new record to DBTD_TBL_TESTRESULT table since it is the first run for the test - ' || v_TestName);
		INSERT INTO DBTD_TBL_TESTRESULT (Owner,StartTime,TestName,IsError, IsFailure, Status,  Message, RunCount)
		VALUES ( v_TestOwner, NOW(), v_TestName, FALSE, FALSE, 'STARTED', v_Message, 1);
	END IF;
END;
END_PROC;

--************************************************************************************************
--internal CORE procedure that finalize unit test 
CREATE OR REPLACE PROCEDURE DBTD_FINALIZE
(
	VARCHAR(128),	--Unit Test
	VARCHAR(128),	--Test Owner
	INT,			--Errors encountered during setup
	INT,			--Errors encountered during test run
	INT,			--Errors encountered during teardown 
	BOOLEAN,		--FALSE if test were run, TRUE - if test execution were ignored
	VARCHAR(4000)	--Stack Trace message
)
LANGUAGE NZPLSQL
RETURNS BOOLEAN
AS
BEGIN_PROC
DECLARE 
	v_TestName		VARCHAR(128);
	v_TestOwner		VARCHAR(128);
	v_SetupError	INT;
	v_ProcedureError INT;
	v_TeardownError	INT;
	v_Message		VARCHAR(255);
	v_CountTests	INT;
	v_IsFailure		BOOLEAN;
	v_IsError		BOOLEAN;
	v_FinalStatus	VARCHAR(50);
	v_FinalError	BOOLEAN;
	v_FinalMessage	VARCHAR(2000);
	v_WasIgnored	BOOLEAN;		
	v_MessageStack	VARCHAR(4000);
BEGIN 
	v_TestName := $1;
	v_TestOwner := $2;
	v_SetupError := $3;
	v_ProcedureError := $4;
	v_TeardownError := $5;
	v_WasIgnored := $6;	
	v_MessageStack := $7;	

	CALL DBTD_LOG_MESSAGE_EXT ( 'DEBUG', 'DBTD_FINALIZE', v_TestName );

	v_IsError := FALSE;		--assume that there is an issue
	v_IsFailure := FALSE;	--assume that there is an issue
	SELECT 	NVL(IsError,TRUE) into v_IsError 
	FROM DBTD_TBL_ACTIVETEST
	WHERE 
		UPPER(TestName) = UPPER(v_TestName)
		--AND UPPER(Owner) = UPPER(v_TestOwner)
	; 
	SELECT 	NVL(IsFailure,TRUE) into v_IsFailure 
	FROM DBTD_TBL_ACTIVETEST
	WHERE 
		UPPER(TestName) = UPPER(v_TestName)
		--AND UPPER(Owner) = UPPER(v_TestOwner)
	; 
	CALL DBTD_LOG_MESSAGE_EXT ( 'INFO', 'DBTD_FINALIZE', v_TestName || ' v_SetupError='|| v_SetupError || ', v_ProcedureError='||v_ProcedureError ||',v_TeardownError='||v_TeardownError||',v_IsError='||v_IsError ||',v_IsFailure='||v_IsFailure);

	v_FinalStatus := 'SUCCESS';
	v_FinalError := FALSE;
	v_FinalMessage := v_TestName ||' - DONE';

	IF (v_SetupError != 0 OR v_ProcedureError != 0 OR v_TeardownError != 0 OR NVL(v_IsError, TRUE) != FALSE OR NVL(v_IsFailure,TRUE) != FALSE ) THEN 
		v_FinalStatus := 'ERROR';
		v_FinalError := TRUE;
		v_FinalMessage := v_TestName ||' - Finished with Errors. Check DBTD_TBL_LOG table for error messages' || ' Stack Trace: ' || v_MessageStack;
	END IF;

	IF ( v_WasIgnored != FALSE) THEN
		v_FinalStatus := 'IGNORED';
		v_FinalMessage := v_FinalMessage || ' Stack Trace: ' || v_MessageStack;
	END IF;

	CALL DBTD_LOG_MESSAGE_EXT ( 'INFO', 'DBTD_FINALIZE', v_TestName || ' finished with Status='|| v_FinalStatus || ', IsError='||v_FinalError ||',Message='||v_FinalMessage);

	CALL DBTD_SaveState(v_TestName, v_TestOwner, v_FinalStatus, v_FinalError, v_IsFailure, v_FinalMessage);
END;
END_PROC;

--************************************************************************************************
--CORE
--runs Global SetUp procedure(s) 
CREATE OR REPLACE PROCEDURE DBTD_RUNGLOBALSETUP 
(
	VARCHAR(255)	--Message
)
LANGUAGE NZPLSQL
RETURNS BOOLEAN
AS
BEGIN_PROC
DECLARE 
	v_Message VARCHAR(255);
	v_GlobalSetup VARCHAR(128);
	v_GlobalSetupCount INTEGER;
BEGIN
	v_Message := $1;
	v_GlobalSetup := 'UT_SETUP';

	CALL DBTD_LOG_MESSAGE_EXT( 'INFO', 'DBTD_RUNGLOBALSETUP', v_Message);

	--run global set up for all the tests
	SELECT COUNT(1) INTO v_GlobalSetupCount 
	FROM _V_PROCEDURE 
	WHERE 
		OBJTYPE='PROCEDURE' 
		AND UPPER(PROCEDURE) = UPPER(TRIM(v_GlobalSetup));

	IF (v_GlobalSetupCount > 0) 
	THEN
		v_Message :=  'CALL GLOBAL SETUP FUNCTION ' || v_GlobalSetup || '();';
		CALL DBTD_LOG_MESSAGE_EXT ( 'INFO', 'DBTD_RUNTESTS', v_Message );
		EXECUTE IMMEDIATE ('CALL ' || v_GlobalSetup || '();') ;
	ELSE
		CALL DBTD_LOG_MESSAGE_EXT ( 'INFO', 'DBTD_RUNTESTS', 'GLOBAL SETUP FUNCTION IS NOT DEFINED');
	END IF;

END;
END_PROC;

--************************************************************************************************
--CORE
--runs Global Teardown procedure(s)
CREATE OR REPLACE PROCEDURE DBTD_RUNGLOBALTEARDOWN 
(
	VARCHAR(255)	--Message
)
LANGUAGE NZPLSQL
RETURNS BOOLEAN
AS
BEGIN_PROC
DECLARE 
	v_Message VARCHAR(255);
	v_GlobalTearDown VARCHAR(128);
	v_GlobalTearDownCount INTEGER;
BEGIN
	v_Message := $1;
	v_GlobalTearDown :=  'UT_TEARDOWN';
	CALL DBTD_LOG_MESSAGE_EXT( 'INFO', 'DBTD_RUNGLOBALTEARDOWN', v_Message);

	--run global set up for all the tests
	SELECT COUNT(1) INTO v_GlobalTearDownCount 
	FROM _V_PROCEDURE 
	WHERE 
		OBJTYPE='PROCEDURE' 
		AND UPPER(PROCEDURE) = UPPER(TRIM(v_GlobalTearDown));

	IF (v_GlobalTearDownCount > 0) 
	THEN
		v_Message :=  'CALL GLOBAL TEARDOWN FUNCTION ' || v_GlobalTearDown || '();';
		CALL DBTD_LOG_MESSAGE_EXT ( 'INFO', 'DBTD_RUNTESTS', v_Message );
		EXECUTE IMMEDIATE ('CALL ' || v_GlobalTearDown || '();') ;
	ELSE
		CALL DBTD_LOG_MESSAGE_EXT ( 'INFO', 'DBTD_RUNTESTS', 'GLOBAL TEARDOWN FUNCTION IS NOT DEFINED');
	END IF;

END;
END_PROC;



--************************************************************************************************
--run all tests in the specified test Suite. 
--note: if DBTD_TBL_TESTSLIST table is empty stored proc will attempt to refresh the list of all 
--      available tests
--note: oracle version will allow same test Suite names used for the different owners, other DB
--      might not support this feature
CREATE OR REPLACE PROCEDURE DBTD_RUNTESTSUITE_EXT 
(
	VARCHAR(128),	--Test Suite name
	VARCHAR(128),	--Suite Owner name (Reserved)
	BOOLEAN,		--Refresh list of all available unit tests
	BOOLEAN			--Run global setup and teardown for given test suite
)
LANGUAGE NZPLSQL
RETURNS BOOLEAN
AS
BEGIN_PROC
DECLARE 
	v_RunGlobalSetupTeardown BOOLEAN;	--run global setup and teardown for given test suite
	v_TestName VARCHAR(128);
	v_TestOwner VARCHAR(128);
	v_HasSetup BOOLEAN;
	v_ReloadTestsList BOOLEAN;
	v_HasTeardown BOOLEAN;
	v_Ignore BOOLEAN;
	v_WasIgnored BOOLEAN;				--will be set to 1 if test execution was ignored during execution
	v_TestPrefix CHAR(3);
	v_SetupError INT;
	v_TeardownError INT;
	v_ProcedureError INT;
	v_CountTests INT;
	v_UnitTestCount INT;				--number of unit tests that were run for a given suite 
	v_Message NVARCHAR(255);
	v_ErrorMessage NVARCHAR(4000);
	v_MessageStack NVARCHAR(4000);		--used to accumulate messages and pass them to finalization
	v_SetupName VARCHAR(128);
	v_TeardownName VARCHAR(128);
	v_Suite NVARCHAR(255);
	v_CursorSQL VARCHAR(2000);
	v_TempRecords RECORD;
	v_RunSetupOnce boolean;
	v_RunTeardownOnce boolean;
	v_FinalStatus VARCHAR(50);
	v_FinalIsError BOOLEAN; 
	v_FinalIsFailure BOOLEAN;
	v_FinalMessage NVARCHAR(4000);
	v_IsError BOOLEAN; 
	v_IsFailure BOOLEAN; 
BEGIN
	BEGIN --start exception handling blok	
		v_CountTests := 0;
		v_UnitTestCount := 0;
		v_SetupError := 0;
		v_TestPrefix := 'UT_';
		v_Suite := UPPER($1);
		v_ReloadTestsList := $3;
		v_RunGlobalSetupTeardown := $4;
		v_SetupName := TRIM(v_TestPrefix) ||TRIM(v_Suite) || '_SETUP';
		v_TeardownName := TRIM(v_TestPrefix) ||TRIM(v_Suite) || '_TEARDOWN';

		CALL DBTD_LOG_MESSAGE_EXT ( 'DEBUG', 'DBTD_RUNTESTSUITE_EXT', 'CALL DBTD_RUNTESTSUITE - ' || v_Suite );

		SELECT COUNT(1) INTO v_CountTests FROM DBTD_TBL_TESTSLIST;
		IF ((v_CountTests = 0) OR (v_ReloadTestsList = TRUE)) THEN
			CALL DBTD_LOG_MESSAGE_EXT ( 'INFO', 'DBTD_RUNTESTSUITE_EXT', 'REFRESH DBTD_TBL_TESTSLIST');
			CALL DBTD_REFRESH_TESTSLIST(); 
		END IF;
		v_CountTests := 0;

		IF (v_RunGlobalSetupTeardown = TRUE)
		THEN 
			CALL DBTD_RUNGLOBALSETUP( 'Running Global Setup from DBTD_RUNTESTSUITE_EXT process');
		END IF; 

		CALL DBTD_LOG_MESSAGE_EXT ( 'DEBUG', 'DBTD_RUNTESTSUITE_EXT', 'Check that we need to run setup only once per suite - ' || v_Suite );
		SELECT (CASE WHEN COUNT(*) > 0 THEN TRUE ELSE FALSE	END) into v_RunSetupOnce
		FROM _V_PROCEDURE 
		WHERE 
			UPPER(PROCEDURESOURCE) LIKE '%DBTD\_RUN\_ONCE%'
			AND UPPER(PROCEDURE) = UPPER(v_SetupName);
		CALL DBTD_LOG_MESSAGE_EXT ( 'DEBUG', 'DBTD_RUNTESTSUITE_EXT', 'Check that we need to run teardown only once per suite - ' || v_Suite );
		SELECT (CASE WHEN COUNT(*) > 0 THEN TRUE ELSE FALSE	END) into v_RunTeardownOnce
		FROM _V_PROCEDURE 
		WHERE 
			UPPER(PROCEDURESOURCE) LIKE '%DBTD\_RUN\_ONCE%'
			AND UPPER(PROCEDURE) = UPPER(v_TeardownName);

		CALL DBTD_LOG_MESSAGE_EXT ( 'DEBUG', v_Suite, 'v_RunSetupOnce=' || CAST(v_RunSetupOnce AS VARCHAR(50)) || ', v_RunTeardownOnce='||CAST(v_RunTeardownOnce AS VARCHAR(50)));

		IF (v_RunSetupOnce = TRUE) THEN
			CALL DBTD_LOG_MESSAGE_EXT ( 'INFO', 'DBTD_RUNTESTSUITE_EXT', 'Running setup ' ||v_SetupName||' procedure ONCE for a suite ' || v_Suite );
			v_SetupError := 0;
			BEGIN
				EXECUTE IMMEDIATE 'CALL ' || v_SetupName || ' ();';
			EXCEPTION
			WHEN OTHERS THEN
				BEGIN
					v_ErrorMessage := ' SETUP ERROR: ' || sqlerrm;
					v_SetupError := 1000;
					CALL DBTD_LOG_MESSAGE_EXT ( 'INFO', v_SetupName, v_ErrorMessage );
				END;
			END;
		END IF;

		v_CursorSQL := 'SELECT TestName, HasSetup, HasTeardown, Owner, Ignore '
			|| ' FROM DBTD_TBL_TESTSLIST WHERE TRIM(UPPER(Suite)) = TRIM(UPPER(''' || v_Suite || ''')) ' 
			|| ' ORDER BY TestName;';

		FOR v_TempRecords IN EXECUTE v_CursorSQL LOOP
			v_TestName := v_TempRecords.TestName;
			v_HasSetup := v_TempRecords.HasSetup;
			v_HasTeardown := v_TempRecords.HasTeardown;
			v_TestOwner := v_TempRecords.Owner;
			v_Ignore := v_TempRecords.Ignore;
			v_WasIgnored = FALSE;		
			v_MessageStack = '';	
			v_CountTests := v_CountTests + 1;
			v_UnitTestCount := v_UnitTestCount + 1;
			v_ProcedureError := 0;
			v_TeardownError := 0;
			v_ErrorMessage := ' ';
			CALL DBTD_LOG_MESSAGE_EXT ( 'DEBUG', 'DBTD_RUNTESTSUITE_EXT', 'Starting - ' || v_TestName);
		
			CALL DBTD_INITIALIZE (v_TestName, v_TestOwner);

			IF (v_Ignore = FALSE) THEN
				--run tests that are not Ignored 
				IF (v_HasSetup = TRUE) AND (v_RunSetupOnce = FALSE) THEN
					CALL DBTD_LOG_MESSAGE_EXT ( 'INFO', 'DBTD_RUNTESTSUITE_EXT', 'RUNNING SETUP:'||v_SetupName||', for unit test:'||v_TestName );
					BEGIN
						EXECUTE IMMEDIATE 'CALL ' || v_SetupName || ' ();';
					EXCEPTION
					WHEN OTHERS THEN
						BEGIN
							v_ErrorMessage := ' SETUP ERROR: ' || sqlerrm;
							v_SetupError := 1000;
							CALL DBTD_LOG_MESSAGE_EXT ( 'ERROR', v_SetupName, v_ErrorMessage );
							v_MessageStack := v_MessageStack || v_ErrorMessage || ' ';
						END;
					END;
				END IF;

				IF (v_SetupError = 0) THEN
					CALL DBTD_LOG_MESSAGE_EXT ( 'INFO', 'DBTD_RUNTESTSUITE_EXT', 'RUNNING: ' || v_TestName );
					BEGIN
						EXECUTE IMMEDIATE 'CALL ' || v_TestName || ' ();';
					EXCEPTION
					WHEN OTHERS THEN
						BEGIN
							v_ErrorMessage := 'UNIT TEST NETEZZA ERROR: ' || sqlerrm;
							v_ProcedureError := 1000;
							CALL DBTD_LOG_MESSAGE_EXT ( 'ERROR', v_TestName, v_ErrorMessage );
							v_MessageStack := v_MessageStack || v_ErrorMessage || ' ';
						END;
					END;
				ELSE 
					v_WasIgnored := TRUE;
					v_Message = 'Skipping ' || UPPER(v_TestName) || ' unit test due to error ' || CAST(v_SetupError AS VARCHAR(50)) || ' in setup procedure ' || UPPER(v_SetupName);
					CALL DBTD_LOG_MESSAGE_EXT ('WARNING', 'DBTD_RUNTESTSUITE_EXT', v_Message);
					v_MessageStack := v_MessageStack || v_Message || ' ';
				END IF;

				IF (v_HasTeardown = TRUE) AND (v_RunTeardownOnce = FALSE) THEN
					CALL DBTD_LOG_MESSAGE_EXT ( 'INFO', 'DBTD_RUNTESTSUITE_EXT', 'RUNNING TEARDOWN - ' || v_TestName );
					BEGIN
						EXECUTE IMMEDIATE 'CALL ' || v_TeardownName || ' ();';
					EXCEPTION
					WHEN OTHERS THEN
						BEGIN
							v_ErrorMessage := ' TEARDOWN ERROR: ' || sqlerrm;
							v_TeardownError := 1000;
							CALL DBTD_LOG_MESSAGE_EXT ( 'ERROR', v_TeardownName , v_ErrorMessage);
							v_MessageStack := v_MessageStack || v_ErrorMessage || ' ';
						END;
					END;
				END IF;
			ELSE 
				v_WasIgnored := TRUE;
				v_MessageStack := ' Unit tests has been marked to be ignored.';
			END IF; 

			CALL DBTD_FINALIZE( v_TestName, v_TestOwner, v_SetupError, v_ProcedureError, v_TeardownError, v_WasIgnored, v_MessageStack);
		END LOOP;

		IF (v_RunTeardownOnce = TRUE) THEN
			CALL DBTD_LOG_MESSAGE_EXT ( 'INFO', 'DBTD_RUNTESTSUITE_EXT', 'Running teardown '||v_TeardownName||' procedure ONCE at ther end of the Suite processing' );
			BEGIN
				EXECUTE IMMEDIATE 'CALL ' || v_TeardownName || ' ();';
			EXCEPTION
			WHEN OTHERS THEN
				BEGIN
					v_ErrorMessage := ' TEARDOWN ERROR: ' || sqlerrm;
					v_TeardownError := 1000;
					CALL DBTD_LOG_MESSAGE_EXT ( 'ERROR', v_TeardownName , v_ErrorMessage);
				END;
			END;
		END IF;

		IF (v_RunGlobalSetupTeardown = TRUE) 
		THEN 
			CALL DBTD_RUNGLOBALTEARDOWN('Running Global Teardown from DBTD_RUNTESTSUITE_EXT process');
		END IF; 

		CALL DBTD_LOG_MESSAGE_EXT ( 'INFO', 'DBTD_RUNTESTSUITE_EXT', CAST(v_UnitTestCount AS VARCHAR(50)) || ' unit tests were executed for suite: ' || v_Suite );

	EXCEPTION
	WHEN OTHERS THEN
		BEGIN
			CALL DBTD_LOG_MESSAGE_EXT ( 'ERROR', 'DBTD_RUNTESTSUITE_EXT', 'DBTD_RUNTESTSUITE FATAL ERROR: ' || sqlerrm);
		END;
	END; --end exception handling blok
	RETURN TRUE;
END;
END_PROC;

--************************************************************************************************
--CORE
--run all tests in the specified test suite. 
--note: if DBTD_TBL_TESTSLIST table is empty stored proc will attempt to refresh the list of all 
--      available tests
--note: oracle version will allow same test suite names used for the different owners, other DB
--      might not support this feature
CREATE OR REPLACE PROCEDURE DBTD_RUNTESTSUITE 
(
	VARCHAR(128),		--Test suite name
	VARCHAR(128),		--Suite owner (Reserved)
	BOOLEAN					--Refresh list of all available unit tests
)
LANGUAGE NZPLSQL
RETURNS VARCHAR(50)
AS
BEGIN_PROC
DECLARE 
	v_SuiteName			VARCHAR(128);		--test suite name
	v_SuiteOwner		VARCHAR(128);		--suite owner (Reserved)
	v_ReloadTestsList	BOOLEAN;			--refresh list of all available unit tests
BEGIN
	v_SuiteName	:= $1;
	v_SuiteOwner	:= $3;
	v_ReloadTestsList	:= $3;

	--run extended logic without global setup or teardown
	CALL DBTD_RUNTESTSUITE_EXT( v_SuiteName, v_SuiteOwner, v_ReloadTestsList, FALSE);
END;
END_PROC;

--************************************************************************************************
--CORE
--runs all tests in database
CREATE OR REPLACE PROCEDURE DBTD_RUNTESTS() 
LANGUAGE NZPLSQL
RETURNS VARCHAR(50)
AS
BEGIN_PROC
DECLARE 
	v_TestSuite NVARCHAR(255);
	v_CursorSQL VARCHAR(8000);
	v_TempRecords RECORD;
	v_TmpMessage VARCHAR(255);
BEGIN
	DELETE FROM DBTD_TBL_LOG; 
	CALL DBTD_LOG_MESSAGE_EXT ( 'INFO', 'DBTD_RUNTESTS', 'CALL DBTD_RUNTESTS()');

	CALL DBTD_REFRESH_TESTSLIST();	--looking for any new unit test that were added in to database 

	CALL DBTD_RUNGLOBALSETUP('Running Global setup from DBTD_RUNTESTS process')
	 
	v_CursorSQL :=  'SELECT DISTINCT Suite FROM DBTD_TBL_TESTSLIST ORDER BY Suite;';
    FOR v_TempRecords IN EXECUTE v_CursorSQL LOOP
		v_TestSuite := v_TempRecords.Suite;

	   	CALL DBTD_LOG_MESSAGE_EXT ( 'INFO', 'DBTD_RUNTESTS', 'RUNNING TESTSUITE - ' || v_TestSuite );
		CALL DBTD_RUNTESTSUITE (v_TestSuite, FALSE);	
	   	CALL DBTD_LOG_MESSAGE_EXT ( 'INFO', 'DBTD_RUNTESTS', 'FINALIZING TESTSUITE -  ' || v_TestSuite );
	END LOOP;

	CALL DBTD_RUNGLOBALTEARDOWN( 'GLOBAL TEARDOWN FUNCTION from DBTD_RUNTESTS process');

	CALL DBTD_LOG_MESSAGE_EXT ( 'INFO', 'DBTD_RUNTESTS', 'FINISH DBTD_RUNTESTS');
END;
END_PROC;

--************************************************************************************************
-- REPORTING
-- Jenkins Compatible XML Report
-- note: to get valid XML use "RptLine" column and make sure that result is sorted in ascending order
--       SELECT RptLine FROM DBTD_VW_RPT_Jenkins ORDER BY SectionOrder ASC, SuiteOrder ASC, TestOrder ASC
CREATE OR REPLACE VIEW DBTD_VW_RPT_Jenkins
AS 
--*************** Start report
SELECT 
	'ROOT OPEN' AS RowType,
	NULL AS Suite,
	NULL AS UnitTestName,
	-1 AS SectionOrder, 
	-1 AS SuiteOrder,
	-1 AS TestOrder,
	'<testsuites>' AS RptLine
--*************** Add Test Suites
UNION ALL 
SELECT 
	'SUITE OPEN' AS RowType,
	Suite,
	NULL AS UnitTestName,
	ROW_NUMBER() OVER (ORDER BY SUITE ASC) AS SectionOrder,
	1 AS SuiteOrder,
	-1 AS TestOrder,
	'   <testsuite name="'	||SUITE || '" '
	|| ' tests="' || COUNT(1) || '" '	--TestCount
	|| ' errors="' || SUM(CASE WHEN (Status = 'ERROR') AND (IsError = TRUE) THEN 1 ELSE 0 END) || '" ' --ErrorCount
	|| ' failures="' || SUM(CASE WHEN (Status IN ('FAILURE', 'STARTED')) AND (IsFailure = TRUE) THEN 1 ELSE 0 END) || '" ' --FailureCount
	|| ' skipped="' || SUM(CASE WHEN (Status IN ('IGNORED')) THEN 1 ELSE 0 END) || '" '
	--|| ' timestamp="' || CAST( R.StopTime, VARCHAR(50)) || '" '
	|| ' time="0.005">'  --total time to execute the suite
	AS RptLine
FROM 
	DBTD_TBL_TESTSLIST AS L
	INNER JOIN 
	DBTD_TBL_TESTRESULT AS R
	ON 
		L.TESTNAME = R.TESTNAME 
GROUP BY 
	SUITE  
--*************** Add Unit Tests\Test Cases
UNION ALL 
SELECT 
	'UNITTEST' AS RowType,
	SUITE, 
	R.TESTNAME AS UnitTestName,
	DENSE_RANK() OVER (ORDER BY SUITE ASC) AS SectionOrder,
	10 AS SuiteOrder,
	ROW_NUMBER() OVER (PARTITION BY SUITE ORDER BY SUITE ASC, R.TESTNAME ASC) AS TestOrder,
	'      <testcase name="' || R.TESTNAME || '" classname="' || R.TESTNAME || '" time="0.00005" ' || 
	CASE
		WHEN Status = 'ERROR' THEN '> <error message="' || R.TESTNAME || ' finished with errors">' || Message || '</error> ' 
		WHEN Status = 'FAILURE' THEN '> <failure message="' || R.TESTNAME || ' failed">' || Message || '</failure> ' 
		WHEN Status = 'IGNORED' THEN '> <skipped/> '
		ELSE ' '
	END  ||
	CASE
		WHEN Status = 'SUCCESS' THEN '/>'
		ELSE  '</testcase>'
	END  AS RptLine	
FROM 
	DBTD_TBL_TESTSLIST AS L
	INNER JOIN 
	DBTD_TBL_TESTRESULT AS R
	ON 
		L.TESTNAME = R.TESTNAME 
--*************** Wrap-Up Suites
UNION ALL 
SELECT 
	DISTINCT 
	'SUITE CLOSE' AS RowType,
	Suite,
	NULL AS UnitTestName,
	ROW_NUMBER() OVER (ORDER BY SUITE ASC) AS SectionOrder,
	100 AS SuiteOrder,
	1000000 AS TestOrder,
	'   </testsuite><!-- ' || SUITE || '-->'  AS RptLine
FROM 
	DBTD_TBL_TESTSLIST AS L
	INNER JOIN 
	DBTD_TBL_TESTRESULT AS R
	ON 
		L.TESTNAME = R.TESTNAME 
GROUP BY 
	SUITE  
--*************** Finish report
UNION ALL 
SELECT 
	'ROOT CLOSE' AS RowType,
	NULL AS Suite,
	NULL AS UnitTestName,
	1000000 AS SectionOrder, 
	1000000 AS SuiteOrder,
	1000000 AS TestOrder,
	'</testsuites>' AS RptLine
;


--************************************************************************************************
-- REPORTING
-- TeamCity Compatible Test Run Report 
-- note: to get valid output use "RptLine" column and make sure that result is sorted in ascending order
--       SELECT RptLine FROM DBTD_VW_RPT_Jenkins ORDER BY SectionOrder ASC, SuiteOrder ASC, TestOrder ASC
--*************** Start report
CREATE VIEW DBTD_VW_RPT_TeamCity
AS 
--*************** Add Test Suites
SELECT 
	'SUITE OPEN' AS RowType,
	Suite,
	NULL AS UnitTestName,
	ROW_NUMBER() OVER (ORDER BY SUITE ASC) AS SectionOrder,
	1 AS SuiteOrder,
	-1 AS TestOrder,
	'##teamcity[testSuiteStarted name=''' || SUITE || '''] ' AS RptLine
FROM 
	DBTD_TBL_TESTSLIST AS L
	INNER JOIN 
	DBTD_TBL_TESTRESULT AS R
	ON 
		L.TESTNAME = R.TESTNAME 
GROUP BY 
	SUITE  
--*************** Add Unit Tests\Test Cases
UNION ALL 
SELECT 
	'UNITTEST' AS RowType,
	SUITE, 
	R.TESTNAME AS UnitTestName,
	DENSE_RANK() OVER (ORDER BY SUITE ASC) AS SectionOrder,
	10 AS SuiteOrder,
	ROW_NUMBER() OVER (PARTITION BY SUITE ORDER BY SUITE ASC, R.TESTNAME ASC) AS TestOrder,
	'##teamcity[testStarted name=''' || R.TESTNAME || ''' captureStandardOutput=''true'']'
	|| CASE
		WHEN Status IN ('ERROR', 'FAILURE') 
			THEN '##teamcity[testFailed name=''' || R.TESTNAME || ''' message='''
			|| translate(translate(translate(translate(translate(R.Message,'|',uc),'''',uc),'[',uc),']',uc),'\',uc) ||''' details='''
			|| translate(translate(translate(translate(translate(R.Message,'|',uc),'''',uc),'[',uc),']',uc),'\',uc) ||''']' 
		WHEN Status = 'IGNORED' THEN '##teamcity[testIgnored name=''' || R.TESTNAME || ''' message=''Ignored'']'
		ELSE ''
	END	
	--'##teamcity[testFinished name=''' || R.TESTNAME || ''' duration='{1}']'	
	|| '##teamcity[testFinished name=''' || R.TESTNAME || ''']'	
	AS RptLine
FROM 
	(SELECT '?' as uc) AS C,
	DBTD_TBL_TESTSLIST AS L
	INNER JOIN 
	DBTD_TBL_TESTRESULT AS R
	ON 
		L.TESTNAME = R.TESTNAME 
--*************** Wrap-Up Suites
UNION ALL 
SELECT 
	DISTINCT 
	'SUITE CLOSE' AS RowType,
	Suite,
	NULL AS UnitTestName,
	ROW_NUMBER() OVER (ORDER BY SUITE ASC) AS SectionOrder,
	100 AS SuiteOrder,
	1000000 AS TestOrder,
	'##teamcity[testSuiteFinished name=''' || SUITE || ''']'  AS RptLine
FROM 
	DBTD_TBL_TESTSLIST AS L
	INNER JOIN 
	DBTD_TBL_TESTRESULT AS R
	ON 
		L.TESTNAME = R.TESTNAME 
GROUP BY 
	SUITE  
;


--************************************************************************************************
--REPORTING 
--splits delimited list in to the DBTD_TBL_RPTPARAM for given v_UniqueRptRunID
CREATE OR REPLACE PROCEDURE DBTD_ParseRptParam
(
	VARCHAR(2000),	--List of Test Suites
	CHAR,			--Delimeter
	DATETIME		--unique ID that identifies set of parameters
)
LANGUAGE NZPLSQL
RETURNS BOOLEAN
AS
BEGIN_PROC
DECLARE 
	v_Item	VARCHAR(2000); 
	v_List	VARCHAR(2000);
	v_Pos	INT;
	v_ListOfSuits VARCHAR(2000);
	v_Delim CHAR;
	v_UniqueRptRunID DATETIME;
	v_Count INT;
	v_LockCount INT;
BEGIN
	v_ListOfSuits := $1;
	v_Delim := $2;
	v_UniqueRptRunID := $3;

	CALL DBTD_LOG_MESSAGE_EXT ( 'DEBUG', 'DBTD_ParseRptParam', 'Parsing parameters string "' || v_ListOfSuits || '" for the v_UniqueRptRunID="' || CAST(v_UniqueRptRunID AS VARCHAR(50)) ||'" with v_Delim="' || v_Delim || '"' );

	v_List := TRIM( v_ListOfSuits ) || v_Delim;
	v_Pos := INSTR( v_List, v_Delim, 1);
	
	v_Count := 0;
	v_LockCount := 0;
	WHILE v_Pos > 0
	LOOP
		v_LockCount := v_LockCount + 1;
		v_Item := TRIM(SUBSTR( v_List, 1, v_Pos - 1));
		IF (v_Item <> '') THEN 
			INSERT INTO DBTD_TBL_RPTPARAM (Value, ReportID)
			VALUES (CAST(v_Item AS VARCHAR(128)), v_UniqueRptRunID);
			v_Count := v_Count + 1;
		END IF;
		v_List := SUBSTR( v_List, v_Pos+1, LENGTH( v_List) -  v_Pos);
		v_Pos := INSTR( v_List, v_Delim, 1);
		IF (v_LockCount > 200) THEN 
			EXIT; --used to prevent wild looping
		END IF;
	END LOOP;
	CALL DBTD_LOG_MESSAGE_EXT ( 'DEBUG', 'DBTD_ParseRptParam', CAST(v_Count AS VARCHAR(50)) || ' - parameters has been parced.' );

END;
END_PROC;


--************************************************************************************************
--REPORTING
--run all tests in the specified test suite. 
--NOTE: to get JENKINS report run following quesry:
--      SELECT DBTD_REPORT ('','','JENKINS') ORDER BY SectionOrder ASC, SuiteOrder ASC, TestOrder ASC;
--      To get TEAMCITY report run following quesry:
--      SELECT DBTD_REPORT ('','','TEAMCITY') ORDER BY SectionOrder ASC, SuiteOrder ASC, TestOrder ASC;
--NOTE: Always order by SectionOrder ASC, SuiteOrder ASC, TestOrder ASC
CREATE OR REPLACE PROCEDURE DBTD_REPORT 
(
	VARCHAR(2000),		--coma separated list of Test Suites to include into the report, NULL or empty string will include all unit test suites in the report  
	VARCHAR(128),		--suite owner (Reserved)
	VARCHAR(128)		--report format: JENKINS, TEAMCITY, ...
)
LANGUAGE NZPLSQL
RETURNS REFTABLE(DBTD_TBL_RPT_REFTABLE) 
AS
BEGIN_PROC
DECLARE 
	v_UniqueRptRunID DATETIME;
	v_GetFullReport INT;
	v_ListOfSuits VARCHAR(2000);
	v_SuiteOwner VARCHAR(128);
	v_Format VARCHAR(128);
BEGIN
	v_ListOfSuits := $1;
	v_SuiteOwner := $2;
	v_Format := $3;

	v_GetFullReport := 0;
	--check if we need to return complete report
	v_UniqueRptRunID  := now();
	IF (v_ListOfSuits IS NULL or v_ListOfSuits = '') THEN
		v_GetFullReport := 1;
	ELSE 
		--save list of suites in to the parameters table 
		v_GetFullReport := 0;
		CALL DBTD_ParseRptParam (v_ListOfSuits, ',', v_UniqueRptRunID);
	END IF; 

	--get the report 
	EXECUTE IMMEDIATE 
		'INSERT INTO ' || REFTABLENAME 
		|| ' SELECT RptLine, SectionOrder, SuiteOrder, TestOrder FROM ( '
		|| ' SELECT RptLine, SectionOrder, SuiteOrder, TestOrder '
		|| ' FROM DBTD_VW_RPT_Jenkins '
		|| ' WHERE '
		|| '''' || UPPER(v_Format) || ''' = ''JENKINS''
			AND ('		
		|| CAST(v_GetFullReport AS VARCHAR(50)) || ' = 1 '	--get all unit tests
		|| 'OR ( '
		|| CAST(v_GetFullReport AS VARCHAR(50)) || ' = 0 '	--get list of specified tests
		|| ' AND ( Suite IS NULL ' --used to pick up ROOT XML tag 
		|| ' OR Suite IN (SELECT value FROM DBTD_TBL_RPTPARAM WHERE ReportID = ''' || CAST(v_UniqueRptRunID AS VARCHAR(50))|| ''')))) '
		||' UNION ALL 
		SELECT RptLine, SectionOrder, SuiteOrder, TestOrder 
		FROM DBTD_VW_RPT_TeamCity 
		WHERE '
		|| '''' || UPPER(v_Format) || ''' = ''TEAMCITY''
			AND ('				
		|| CAST(v_GetFullReport AS VARCHAR(50)) || ' = 1 ' --get all unit tests
		|| ' OR ( '
		|| CAST(v_GetFullReport AS VARCHAR(50)) || ' = 0 ' --get list of specified tests
		|| ' AND Suite IN (SELECT value FROM DBTD_TBL_RPTPARAM WHERE ReportID = ''' || CAST(v_UniqueRptRunID AS VARCHAR(50))|| ''')))) AS Z
		ORDER BY SectionOrder ASC, SuiteOrder ASC, TestOrder ASC';

	RETURN REFTABLE;
END;
END_PROC;