/*
*************************************************************************************************
-- VERSION:	   DBTestDriven - Netezza - 3.5.1.12
-- COPYRIGHT:  (c) 2011-2012 Job Continent, DBTestDriven Project by Alex Podlesny
-- http://www.dbtestdriven.com
*************************************************************************************************
*/

--************************************************************************************************
--COMPATIBILITY PACK
--DBTD_ASSERT_TABLE_OR_VIEW_EXISTS - Synonym
--verifies that view or table does exists in the database
--NOTE: Oracle Compatibility
CREATE OR REPLACE PROCEDURE DBTD_ASSERT_TBL_OR_VW_EXISTS
(
	NVARCHAR(255),	--table or view name
	NVARCHAR(255)	--user message
)
LANGUAGE NZPLSQL
RETURNS BOOLEAN
AS
BEGIN_PROC
DECLARE
	v_ObjectName	NVARCHAR(255);
	v_UserMessage	NVARCHAR(255);
BEGIN
	CALL DBTD_LOG_MESSAGE_EXT( 'DEBUG', 'DBTD_ASSERT_TBL_OR_VW_EXISTS', 'Running DBTD_ASSERT_TABLE_OR_VIEW_EXISTS in the compatibility mode.') ;
	v_ObjectName := $1;
	v_UserMessage := $2;
	CALL DBTD_ASSERT_TABLE_OR_VIEW_EXISTS(v_ObjectName, v_UserMessage);
END;
END_PROC;

--************************************************************************************************
--COMPATIBILITY PACK
--DBTD_ASSERT_COLUMN_TYPE_AND_PRECISION - Synonym
--Will fail if column with given type and precision cannot be found in the table or view
--NOTE: Oracle Compatibility
CREATE OR REPLACE PROCEDURE DBTD_ASSERT_COL_TYPE_AND_PRCN
(
	NVARCHAR(255),	--Table or View name
	NVARCHAR(255),	--Column Name
	NVARCHAR(255),	--Column Type not including precision info, for instance NUMERIC 
	NVARCHAR(255),	--Column precision and scale, for instance (18,0), include brackets commas but no spaces 
	NVARCHAR(255)	--User message
)
LANGUAGE NZPLSQL
RETURNS BOOLEAN
AS
BEGIN_PROC
DECLARE 
	v_ObjectName		NVARCHAR(255);	--Table or View name
	v_ColumnName		NVARCHAR(255);	--Column Name
	v_ColumnType		NVARCHAR(255);	--Column Type
	v_ColumnPrecScale	NVARCHAR(255);	--Column precision and scale
	v_UserMessage		NVARCHAR(255);	--User message
BEGIN
	v_ObjectName := $1;
	v_ColumnName := $2;
	v_ColumnType := $3;
	v_ColumnPrecScale := $4;
	v_UserMessage := $5;

	CALL DBTD_LOG_MESSAGE_EXT ('DEBUG', 'DBTD_ASSERT_COL_TYPE_AND_PRCN', 'Running DBTD_ASSERT_COLUMN_TYPE_AND_PRECISION in compatibility mode.');
	CALL DBTD_ASSERT_COLUMN_TYPE_AND_PRECISION( v_ObjectName, v_ColumnName, v_ColumnType, v_ColumnPrecScale, v_UserMessage);
END;
END_PROC;

--************************************************************************************************
--COMPATIBILITY PACK
--DBTD_ASSERT_COLUMN_IS_NOT_NULLABLE - Synonym
--Will fail if column with given type and precision cannot be found in the table or view
--NOTE: Oracle Compatibility
CREATE OR REPLACE PROCEDURE DBTD_ASSERT_COL_NOT_NULLABLE
(
	NVARCHAR(255),	--Table or View name
	NVARCHAR(255),	--Column Name
	NVARCHAR(255)	--User message
)
LANGUAGE NZPLSQL
RETURNS BOOLEAN
AS
BEGIN_PROC
DECLARE 
	v_ObjectName	NVARCHAR(255);	--Table or View name
	v_ColumnName	NVARCHAR(255);	--Column Name
	v_UserMessage	NVARCHAR(255);	--User message
BEGIN
	v_ObjectName := $1;
	v_ColumnName := $2;
	v_UserMessage := $3;

	CALL DBTD_LOG_MESSAGE_EXT ('DEBUG', 'DBTD_ASSERT_COL_NOT_NULLABLE', 'Running DBTD_ASSERT_COLUMN_IS_NOT_NULLABLE in compatibility mode.');
	CALL DBTD_ASSERT_COLUMN_IS_NOT_NULLABLE (v_ObjectName, v_ColumnName, v_UserMessage);
END;
END_PROC;

--************************************************************************************************
--COMPATIBILITY PACK
--DBTD_ASSERT_IS_COLUMN_VALUE_UNIQUE - Synonym
--checks that value in the collumn is unique (or distinct) 
--NOTE: Oracle Compatibility
CREATE OR REPLACE PROCEDURE DBTD_ASSERT_COL_VALUE_UNIQUE
(
	NVARCHAR(255),	--table name
	NVARCHAR(255),	--column that should have unique\distinct values only
	NVARCHAR(255)	--user message
)
LANGUAGE NZPLSQL
RETURNS BOOLEAN
AS
BEGIN_PROC
DECLARE 
	v_ObjectName	NVARCHAR(255);	--Table or View name
	v_ColumnName	NVARCHAR(255);	--Column Name
	v_UserMessage	NVARCHAR(255);	--User message
BEGIN
	v_ObjectName := $1;
	v_ColumnName := $2;
	v_UserMessage := $3;
	CALL DBTD_LOG_MESSAGE_EXT ('DEBUG', 'DBTD_ASSERT_COL_VALUE_UNIQUE', 'Running DBTD_ASSERT_IS_COLUMN_VALUE_UNIQUE in compatibility mode.');
	CALL DBTD_ASSERT_IS_COLUMN_VALUE_UNIQUE( v_ObjectName, v_ColumnName, v_UserMessage);
END;
END_PROC;


--************************************************************************************************
--COMPATIBILITY PACK
--DBTD_ASSERT_COLUMN_HAS_NO_VALUE - Synonym
--checks that column have a given value at list in one row of a given table 
--NOTE: Oracle Compatibility
CREATE OR REPLACE PROCEDURE DBTD_ASSERT_COL_HAS_NO_VALUE
(
	NVARCHAR(255),	--table name
	NVARCHAR(255),	--column that will be checked for a value
	NVARCHAR(4000),	--asserted value
	NVARCHAR(255),	--value data type
	NVARCHAR(255)	--user message
)
LANGUAGE NZPLSQL
RETURNS BOOLEAN
AS
BEGIN_PROC
DECLARE 
	v_TableName		VARCHAR(255);
	v_ColumnName	VARCHAR(255);
	v_Value			VARCHAR(4000);
	v_ValueDataType	VARCHAR(255);
	v_UserMessage	VARCHAR(255);
BEGIN
	v_TableName := $1;
	v_ColumnName := $2;
	v_Value := $3;
	v_ValueDataType := $4;
	v_UserMessage := $5;

	CALL DBTD_LOG_MESSAGE_EXT ('DEBUG', 'DBTD_ASSERT_COL_HAS_NO_VALUE', 'Running DBTD_ASSERT_COLUMN_HAS_NO_VALUE in compatibility mode.');
	CALL DBTD_ASSERT_COLUMN_HAS_NO_VALUE (v_TableName, v_ColumnName, v_Value, v_ValueDataType, v_UserMessage);
END;
END_PROC;

--************************************************************************************************
--COMPATIBILITY PACK
--DBTD_ASSERT_SAME_NUMBER_OF_ROWS  - Synonym
--checks that both tables have same number of rows
--NOTE: Oracle Compatibility
CREATE OR REPLACE PROCEDURE DBTD_ASSERT_SAME_NMBR_OF_ROWS
(
	NVARCHAR(255),	--name of the first table 
	NVARCHAR(255),	--name of the second table 
	NVARCHAR(255)	--user message
)
LANGUAGE NZPLSQL
RETURNS BOOLEAN
AS
BEGIN_PROC
DECLARE 
	v_TableNameA VARCHAR(255);
	v_TableNameB VARCHAR(255);
	v_UserMessage VARCHAR(255);
BEGIN
	v_TableNameA := TRIM(UPPER($1));
	v_TableNameB := TRIM(UPPER($2));
	v_UserMessage := $3;

	CALL DBTD_LOG_MESSAGE_EXT ('DEBUG', 'DBTD_ASSERT_SAME_NMBR_OF_ROWS', 'Running DBTD_ASSERT_SAME_NUMBER_OF_ROWS  in compatibility mode.');
	CALL DBTD_ASSERT_SAME_NUMBER_OF_ROWS( v_TableNameA, v_TableNameB, v_UserMessage);
END;
END_PROC;
